import pandas as pd
import re

def derive_column_from_regex_extraction(df, source_col, new_col, pattern, group_index=0):
    """Create a new column by extracting substrings using regex capture groups."""
    def extract_match(val):
        if pd.isnull(val):
            return None
        match = re.search(pattern, str(val))
        if match:
            groups = match.groups()
            if groups:
                idx = min(group_index, len(groups) - 1)
                return groups[idx]
            else:
                return match.group(0)
        return None
    df = df.copy()
    df[new_col] = df[source_col].apply(extract_match)
    return df