import pandas as pd

def add_constant_column(df, col_name, value):
    """Insert a new column filled with a constant value."""
    df = df.copy()
    df[col_name] = value
    return df