import re
from typing import Any, Callable, List, Dict, Union, Optional

def add_column(
    table: List[Dict[str, Any]],
    base_column_name: str,
    expression: Union[str, Callable],
    on_error: str,  # "set-to-blank" or "keep-original"
    new_column_name: str,
    column_insert_index: int,
) -> List[Dict[str, Any]]:
    """
    Add a new column to a table based on an expression applied to a base column.
    
    Parameters:
        table: Input table as list of row dicts (e.g., [{'col1': val1, ...}, ...])
        base_column_name: Name of the existing column used in the expression
        expression: Either a string expression (e.g., "row['age'] * 2") or a callable
                    that takes (row: dict, base_value: Any) and returns new value.
        on_error: "set-to-blank" or "keep-original"
        new_column_name: Name of the new column to add
        column_insert_index: Index at which to insert the new column (0-based)
    
    Returns:
        New table with the added column, preserving row order and other columns.
    """
    if not table:
        # Empty table: just add column name
        return []

    # Validate inputs
    if column_insert_index < 0:
        raise ValueError("column_insert_index must be >= 0")
    
    if not all(isinstance(row, dict) for row in table):
        raise TypeError("Each row must be a dictionary")
    
    if base_column_name not in table[0]:
        raise ValueError(f"Base column '{base_column_name}' not found in table")
    
    if new_column_name in table[0]:
        raise ValueError(f"New column '{new_column_name}' already exists")

    # Get ordered column names from first row
    original_columns = list(table[0].keys())
    if column_insert_index > len(original_columns):
        column_insert_index = len(original_columns)

    # Insert new column name at specified index
    new_columns = original_columns[:]
    new_columns.insert(column_insert_index, new_column_name)

    # Prepare output table
    new_table = []

    for row in table:
        if base_column_name not in row:
            raise ValueError(f"Row missing base column '{base_column_name}': {row}")

        base_value = row[base_column_name]
        new_value = None
        error_occurred = False

        try:
            if callable(expression):
                result = expression(row=row, base_value=base_value)
            elif isinstance(expression, str):
                # Safe evaluation context
                # Only allow access to 'row' and 'value'
                safe_globals = {"__builtins__": {}}
                safe_locals = {"row": row, "value": base_value}

                # Basic safety: disallow dangerous patterns
                if re.search(r'(__|exec|eval|import|open|system)', expression):
                    raise ValueError("Expression contains unsafe content")

                result = eval(expression, safe_globals, safe_locals)
            else:
                raise TypeError("expression must be str or callable")

            new_value = result

        except Exception:
            error_occurred = True
            if on_error == "set-to-blank":
                new_value = None
            elif on_error == "keep-original":
                new_value = base_value
            else:
                raise ValueError(f"Unknown on_error strategy: {on_error}")

        # Build new row with consistent column order
        new_row = {}
        for col in new_columns:
            if col == new_column_name:
                new_row[col] = new_value
            else:
                new_row[col] = row.get(col)  # Use .get() for robustness

        new_table.append(new_row)

    return new_table