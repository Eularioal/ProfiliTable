import pandas as pd

def generate_row_id_column(df, id_col="row_id", start=1, reset_on_key=None):
    """Add a sequential row ID column, optionally resetting on key changes."""
    df = df.copy()
    if reset_on_key is not None:
        df = df.sort_values(by=reset_on_key).reset_index(drop=True)
        df[id_col] = df.groupby(reset_on_key).cumcount() + start
    else:
        df = df.reset_index(drop=True)
        df[id_col] = range(start, start + len(df))
    return df