import pandas as pd
import numpy as np

def add_missing_columns_with_default(
    df,
    required_columns,
    default_value=None,
    default_map=None,
    dtype_map=None,
    reorder=False
):
    """
    Ensure the table contains a specified set of columns.
    Missing columns are added with default values.
    Existing columns are left untouched.
    """

    df = df.copy()

    if default_map is None:
        default_map = {}

    if dtype_map is None:
        dtype_map = {}

    for col in required_columns:
        if col not in df.columns:
            # determine default value
            if col in default_map:
                value = default_map[col]
            else:
                value = default_value

            df[col] = value

            # apply dtype if specified
            if col in dtype_map:
                try:
                    df[col] = df[col].astype(dtype_map[col])
                except Exception:
                    raise ValueError(f"Failed to cast column '{col}' to type {dtype_map[col]}")

    # optional reorder columns
    if reorder:
        existing_cols = [c for c in df.columns if c not in required_columns]
        df = df[existing_cols + list(required_columns)]

    return df
