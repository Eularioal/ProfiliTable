import pandas as pd
import re

def rename_columns(df, rename_map, regex=False, ensure_unique=True):
    """
    Rename one or more columns using a mapping from old names to new names.
    Columns not in the mapping remain unchanged.
    Supports regex-based renaming for batch operations.
    """

    df = df.copy()
    new_columns = []
    seen = {}

    for col in df.columns:
        new_col = col

        for old, new in rename_map.items():
            if regex:
                if re.search(old, col):
                    new_col = re.sub(old, new, col)
                    break
            else:
                if col == old:
                    new_col = new
                    break

        # ensure uniqueness if required
        if ensure_unique:
            if new_col in seen:
                seen[new_col] += 1
                new_col = f"{new_col}_{seen[new_col]}"
            else:
                seen[new_col] = 0

        new_columns.append(new_col)

    df.columns = new_columns
    return df
