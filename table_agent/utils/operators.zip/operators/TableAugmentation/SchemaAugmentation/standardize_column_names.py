import pandas as pd
import re

def standardize_column_names(df, case_style="snake_case"):
    """
    Transform column names to a consistent format (e.g., snake_case, lowerCamelCase).
    Removes special characters, collapses whitespace, applies case rules,
    and ensures uniqueness by appending suffixes if needed.
    """

    df = df.copy()

    def to_snake_case(name):
        name = re.sub(r"[^\w\s]", " ", name)      # remove special characters
        name = re.sub(r"\s+", "_", name.strip()) # collapse whitespace
        return name.lower()

    def to_lower_camel_case(name):
        name = re.sub(r"[^\w\s]", " ", name)
        parts = re.split(r"\s+", name.strip())
        if not parts:
            return name
        first = parts[0].lower()
        rest = [p.capitalize() for p in parts[1:]]
        return first + "".join(rest)

    new_columns = []
    seen = {}

    for col in df.columns:
        col_str = str(col)

        if case_style == "snake_case":
            new_col = to_snake_case(col_str)
        elif case_style == "lowerCamelCase":
            new_col = to_lower_camel_case(col_str)
        else:
            raise ValueError("case_style must be 'snake_case' or 'lowerCamelCase'")

        # ensure uniqueness
        if new_col in seen:
            seen[new_col] += 1
            new_col = f"{new_col}_{seen[new_col]}"
        else:
            seen[new_col] = 0

        new_columns.append(new_col)

    df.columns = new_columns
    return df
