import pandas as pd
import numpy as np
from dateutil import parser

def infer_and_cast_column_types(df, datetime_threshold=0.8):
    """
    Automatically infer the most appropriate data type for each column
    and cast the column accordingly. Returns transformed df and inference report.
    """

    df = df.copy()
    report = {}

    def try_cast(series, target_type):
        non_null = series.dropna()
        if len(non_null) == 0:
            return series, 0.0

        success = 0

        for val in non_null:
            try:
                if target_type == "int":
                    int(val)
                elif target_type == "float":
                    float(val)
                elif target_type == "bool":
                    if str(val).lower() in ["true", "false", "0", "1"]:
                        pass
                    else:
                        raise ValueError
                elif target_type == "datetime":
                    parser.parse(str(val))
                success += 1
            except Exception:
                pass

        confidence = success / len(non_null)
        return confidence

    for col in df.columns:
        series = df[col]
        non_null = series.dropna()

        best_type = "string"
        best_confidence = 0.0

        type_candidates = ["int", "float", "bool", "datetime"]

        scores = {}

        for t in type_candidates:
            conf = try_cast(series, t)
            scores[t] = conf
            if conf > best_confidence:
                best_confidence = conf
                best_type = t

        # cast column if confidence is high enough
        if best_type == "int" and best_confidence > 0.9:
            df[col] = pd.to_numeric(series, errors="coerce").astype("Int64")
        elif best_type == "float" and best_confidence > 0.9:
            df[col] = pd.to_numeric(series, errors="coerce")
        elif best_type == "bool" and best_confidence > 0.9:
            df[col] = series.astype(str).str.lower().map(
                {"true": True, "false": False, "1": True, "0": False}
            )
        elif best_type == "datetime" and best_confidence > datetime_threshold:
            df[col] = pd.to_datetime(series, errors="coerce")
        else:
            best_type = "string"

        report[col] = {
            "inferred_type": best_type,
            "confidence": round(best_confidence, 3),
            "scores": {k: round(v, 3) for k, v in scores.items()}
        }

    return df, report
