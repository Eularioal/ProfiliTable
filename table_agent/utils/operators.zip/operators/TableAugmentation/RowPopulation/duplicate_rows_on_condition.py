import pandas as pd

def duplicate_rows_on_condition(df, condition_col, condition_value, times=1):
    """Duplicate rows satisfying a condition multiple times."""
    df = df.copy()
    mask = df[condition_col] == condition_value
    duplicated = pd.concat([df[mask]] * times, ignore_index=True)
    df = pd.concat([df, duplicated], ignore_index=True)
    return df