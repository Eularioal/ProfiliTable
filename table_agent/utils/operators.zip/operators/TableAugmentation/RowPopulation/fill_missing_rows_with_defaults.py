import pandas as pd

def fill_missing_rows_with_defaults(df, key_col, expected_values, fill_values=None):
    """Insert missing rows for gaps in a sequence defined by key_col."""
    df = df.copy()
    if fill_values is None:
        fill_values = {col: None for col in df.columns}
    existing_keys = set(df[key_col].dropna())
    missing_keys = [v for v in expected_values if v not in existing_keys]
    missing_rows = []
    for k in missing_keys:
        row = fill_values.copy()
        row[key_col] = k
        missing_rows.append(row)
    if missing_rows:
        df = pd.concat([df, pd.DataFrame(missing_rows)], ignore_index=True)
    return df