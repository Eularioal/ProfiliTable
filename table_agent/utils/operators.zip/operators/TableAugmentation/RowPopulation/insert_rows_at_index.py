from typing import List, Dict, Any, Optional, Union

def insert_rows_at_index(
    table: List[Dict[str, Any]],
    added_rows: Optional[List[Dict[str, Any]]] = None,
    row_count: Optional[int] = None,
    insertion_index: int = -1,
) -> List[Dict[str, Any]]:
    """
    Add new rows to a table at a specified index.

    This function emulates OpenRefine's RowAdditionOperation.
    
    Parameters:
        table: Original table as list of row dicts.
        added_rows: (Optional) Explicit list of rows to insert. Each row is a dict.
                    If provided, `row_count` is ignored.
        row_count: (Optional) Number of empty rows to add (for legacy compatibility).
                   Only used if `added_rows` is None.
        insertion_index: Index where new rows are inserted.
                         - If -1 or >= len(table), append at end.
                         - If < 0 (but not -1), clamp to 0.

    Returns:
        A new table with rows inserted.
    """
    if not isinstance(table, list):
        raise TypeError("table must be a list of dictionaries")

    # Determine effective insertion index
    n = len(table)
    if insertion_index < 0 or insertion_index > n:
        insertion_index = n

    # Determine columns from existing table (if any)
    if table:
        columns = list(table[0].keys())
    else:
        # If table is empty, we cannot infer schema; use keys from added_rows if possible
        if added_rows and added_rows[0]:
            columns = list(added_rows[0].keys())
        else:
            columns = []

    # Decide what rows to insert
    if added_rows is not None:
        rows_to_insert = []
        for r in added_rows:
            if not isinstance(r, dict):
                raise TypeError("Each added row must be a dictionary")
            # Align with column schema: fill missing keys with None
            aligned_row = {col: r.get(col) for col in columns}
            rows_to_insert.append(aligned_row)
    elif row_count is not None:
        if row_count < 0:
            raise ValueError("row_count must be non-negative")
        # Create empty rows (all values None)
        rows_to_insert = [{col: None for col in columns} for _ in range(row_count)]
    else:
        rows_to_insert = []

    # Build new table
    new_table = (
        table[:insertion_index] +
        rows_to_insert +
        table[insertion_index:]
    )

    return new_table