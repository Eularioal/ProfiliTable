import pandas as pd
import json

def expand_rows_by_list_column(df, list_col, delimiter=None, json_parse=False):
    """Expand rows based on list-like values in a column."""
    def parse_value(val):
        if pd.isnull(val):
            return []
        if json_parse:
            try:
                return json.loads(val)
            except (ValueError, TypeError):
                return [val]
        elif delimiter:
            return str(val).split(delimiter)
        else:
            return [val]

    expanded_rows = []
    df = df.copy()
    for _, row in df.iterrows():
        items = parse_value(row[list_col])
        if not items:
            expanded_rows.append(row.copy())
        else:
            for item in items:
                new_row = row.copy()
                new_row[list_col] = item
                expanded_rows.append(new_row)
    return pd.DataFrame(expanded_rows).reset_index(drop=True)