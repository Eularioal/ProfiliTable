import pandas as pd
import os
import re
from typing import List, Dict, Any, Callable, Optional

def append_rows_by_template_with_contextual_inference(
    df: pd.DataFrame,
    target_condition: Dict[str, Any],
    new_records: List[Dict[str, Any]],
    id_column: str,
    id_prefix: str,
    id_numeric_width: int = 3,
    derived_fields: Optional[Dict[str, Callable]] = None,
    impute_fields: Optional[List[str]] = None,
    insert_after_last_target: bool = True
) -> pd.DataFrame:
    """
    Append new rows to a DataFrame based on templates, with contextual inference from a target subpopulation.
    Returns:
    - New DataFrame with appended rows.
    """
    df = df.copy()

    # Step 1: Filter target subpopulation
    mask = pd.Series([True] * len(df))
    for col, val in target_condition.items():
        mask &= (df[col] == val)
    target_df = df[mask]

    if target_df.empty:
        raise ValueError("Target subpopulation is empty; cannot infer context.")

    # Step 2: Infer imputed fields
    imputed_values = {}
    if impute_fields:
        for col in impute_fields:
            counts = target_df[col].value_counts()
            max_count = counts.max()
            candidates = counts[counts == max_count].index.tolist()
            # Tie-break: pick candidate with earliest first occurrence
            first_occurrence = {
                cand: target_df[target_df[col] == cand].index[0]
                for cand in candidates
            }
            imputed_values[col] = min(first_occurrence, key=first_occurrence.get)

    # Step 3: Determine next sequence number
    def extract_numeric_suffix(x):
        match = re.search(rf'{re.escape(id_prefix)}(\d+)$', str(x))
        return int(match.group(1)) if match else -1

    existing_nums = target_df[id_column].apply(extract_numeric_suffix)
    next_num = existing_nums.max() + 1

    # Step 4: Build new rows
    new_rows = []
    for i, base_record in enumerate(new_records):
        seq_num = next_num + i
        record = base_record.copy()

        # Add imputed fields
        record.update(imputed_values)

        # Add ID
        record[id_column] = f"{id_prefix}{str(seq_num).zfill(id_numeric_width)}"

        # Add sequence number for derived fields
        record['_seq'] = seq_num

        # Compute derived fields
        if derived_fields:
            for col, func in derived_fields.items():
                record[col] = func(record)

        # Remove helper field
        record.pop('_seq', None)

        new_rows.append(record)

    new_df = pd.DataFrame(new_rows)

    # Step 5: Insert at correct position
    if insert_after_last_target:
        last_idx = target_df.index[-1]
        before = df.iloc[:last_idx + 1]
        after = df.iloc[last_idx + 1:]
        result = pd.concat([before, new_df, after], ignore_index=True)
    else:
        result = pd.concat([df, new_df], ignore_index=True)

    return result