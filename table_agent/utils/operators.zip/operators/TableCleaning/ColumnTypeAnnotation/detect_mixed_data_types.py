import pandas as pd

def detect_mixed_data_types(df, col, report_col="mixed_type"):
    """Detect mixed types in a column."""
    df = df.copy()
    types = df[col].apply(lambda x: type(x).__name__ if pd.notnull(x) else 'null')
    unique_types = types.unique()
    df[report_col] = len(unique_types) > 2
    return df