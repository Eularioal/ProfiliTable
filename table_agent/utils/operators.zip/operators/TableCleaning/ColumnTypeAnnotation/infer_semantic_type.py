import pandas as pd
import re

def infer_semantic_type(df, col):
    """Heuristic semantic type inference (returns string label)."""
    sample = df[col].dropna().head(100)
    if sample.dtype == 'object':
        if sample.str.contains(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z]{2,}', case=False, na=False).any():
            return "email"
        if sample.str.match(r'^\d{5}(-\d{4})?$').any():
            return "postal_code"
        if sample.str.match(r'^\+?1?-?\d{3}-?\d{3}-?\d{4}$').any():
            return "phone"
    return "unknown"