import pandas as pd
import re

DOMAIN_RULES = {
    "country": {"china", "japan", "usa", "france", "germany", "canada"},
    "currency": {"usd", "eur", "cny", "jpy"},
    "gender": {"male", "female", "other"}
}

PATTERN_RULES = {
    "postal_code": r"^\d{4,10}$",
    "email": r"^[\w\.-]+@[\w\.-]+\.\w+$"
}

def detect_out_of_domain_values(df, column, semantic_type):
    """
    Identify values outside expected domain based on dictionary or regex rules.
    """

    anomalies = []
    series = df[column]

    for idx, val in series.items():
        if pd.isnull(val):
            continue

        v = str(val).strip().lower()
        valid = True

        if semantic_type in DOMAIN_RULES:
            if v not in DOMAIN_RULES[semantic_type]:
                valid = False

        elif semantic_type in PATTERN_RULES:
            if not re.match(PATTERN_RULES[semantic_type], v):
                valid = False

        if not valid:
            anomalies.append({
                "row": idx,
                "value": val,
                "semantic_type": semantic_type
            })

    return anomalies
