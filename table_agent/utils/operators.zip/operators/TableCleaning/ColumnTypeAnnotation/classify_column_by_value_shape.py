import pandas as pd
import re

def classify_column_by_value_shape(df, column, threshold=0.7):
    """
    Classify column based on value shape and character composition.
    """

    series = df[column].dropna().astype(str)
    if len(series) == 0:
        return {"column": column, "shape_type": "empty"}

    numeric_like = 0
    alpha_like = 0
    alnum_like = 0

    for v in series:
        v = v.strip()
        if re.fullmatch(r"\d+(\.\d+)?", v):
            numeric_like += 1
        elif re.fullmatch(r"[A-Za-z]+", v):
            alpha_like += 1
        elif re.fullmatch(r"[A-Za-z0-9\-_]+", v):
            alnum_like += 1

    total = len(series)

    ratios = {
        "numeric_like": numeric_like / total,
        "alpha_like": alpha_like / total,
        "alnum_like": alnum_like / total
    }

    shape_type = "text_like"
    for k, v in ratios.items():
        if v >= threshold:
            shape_type = k
            break

    return {
        "column": column,
        "shape_type": shape_type,
        "ratios": {k: round(v, 3) for k, v in ratios.items()}
    }
