import pandas as pd

def impute_with_global_mode(df, col):
    """Impute missing values with global mode."""
    df = df.copy()
    mode_series = df[col].mode()
    if not mode_series.empty:
        df[col] = df[col].fillna(mode_series[0])
    return df