import pandas as pd

def impute_column_with_backward_window(df, value_col, time_col, window_size=5):
    """
    Impute missing values in a specified column using the mean of up to `window_size`
    most recent **original** (non-imputed) non-null values before each missing entry,
    based on chronological order defined by a time column.
    
    Filled values are never used as reference for subsequent imputations.
    """
    # Sort by time column to ensure chronological order
    df = df.sort_values(by=time_col).reset_index(drop=True)
    
    # Preserve original values to avoid using imputed data in calculations
    original_values = df[value_col].copy()
    imputed_series = []

    for i in range(len(df)):
        if pd.notnull(original_values.iloc[i]):
            imputed_series.append(original_values.iloc[i])
        else:
            # Look backward for up to `window_size` valid original values
            valid_vals = []
            count = 0
            j = i - 1
            while j >= 0 and count < window_size:
                if pd.notnull(original_values.iloc[j]):
                    valid_vals.append(original_values.iloc[j])
                    count += 1
                j -= 1
            
            if valid_vals:
                imputed_val = sum(valid_vals) / len(valid_vals)
                imputed_series.append(imputed_val)
            else:
                imputed_series.append(None)  # or np.nan

    df[value_col] = imputed_series
    return df