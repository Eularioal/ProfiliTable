import pandas as pd

def impute_missing_with_most_frequent_on_condition(
    df,
    target_col,
    condition_col,
    condition_value,
    fill_only_where_condition=True
):
    """
    Impute missing values in `target_col` using the most frequent (mode) value 
    from rows where `condition_col == condition_value`.
    
    Returns:
    - df with imputed values in `target_col`
    """
    # Create a copy to avoid modifying original DataFrame unexpectedly
    df = df.copy()
    
    # Step 1: Extract the conditional subset
    conditional_subset = df[df[condition_col] == condition_value]
    
    # Step 2: Compute the most frequent value in target_col within the subset
    mode_series = conditional_subset[target_col].mode()
    if mode_series.empty:
        # No valid value to impute; leave missing as-is
        return df
    most_frequent_value = mode_series[0]
    
    # Step 3: Determine which rows to impute
    missing_mask = df[target_col].isnull()
    if fill_only_where_condition:
        # Only fill missing values where the row also meets the condition
        impute_mask = missing_mask & (df[condition_col] == condition_value)
    else:
        # Fill all missing values in target_col, regardless of condition in that row
        impute_mask = missing_mask
    
    # Step 4: Perform imputation
    df.loc[impute_mask, target_col] = most_frequent_value
    
    return df