from typing import List, Dict, Any, Optional

def is_non_blank_data(value: Any) -> bool:
    """
    Mimics OpenRefine's ExpressionUtils.isNonBlankData:
    - None, empty string, or whitespace-only string → blank
    - Everything else → non-blank
    """
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() != ""
    return True

def fill_down_by_key(
    table: List[Dict[str, Any]],
    column_name: str,
    key_column_name: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Perform "Fill Down" operation on a specified column.

    Parameters:
        table: Input table as list of row dicts.
        column_name: Name of the column to fill down.
        key_column_name: (Optional) Name of the key column.
                         If provided, enables "record-based mode":
                         whenever the key column is non-blank, reset the fill context.

    Returns:
        A new table with fill-down applied to `column_name`.
    """
    if not table:
        return []

    # Validate columns exist
    if column_name not in table[0]:
        raise ValueError(f"Target column '{column_name}' not found in table")
    if key_column_name is not None and key_column_name not in table[0]:
        raise ValueError(f"Key column '{key_column_name}' not found in table")

    new_table = []
    previous_value = None  # holds the last non-blank value in the target column

    for row in table:
        current_value = row.get(column_name)
        key_value = row.get(key_column_name) if key_column_name else None

        # Record-based mode: reset fill context when key column is non-blank
        if key_column_name is not None and is_non_blank_data(key_value):
            previous_value = None

        if is_non_blank_data(current_value):
            # Non-blank: update previous_value and keep original
            previous_value = current_value
            new_value = current_value
        else:
            # Blank: fill with previous if available
            new_value = previous_value  # could be None if no prior non-blank

        # Build new row
        new_row = row.copy()
        new_row[column_name] = new_value
        new_table.append(new_row)

    return new_table