import pandas as pd

def detect_inconsistent_capitalization(df, col, flag_col="inconsistent_case"):
    """Flag inconsistent casing in text column."""
    df = df.copy()
    normalized = df[col].str.lower().fillna("")
    modes = normalized.value_counts()
    if modes.empty:
        df[flag_col] = False
    else:
        canonical = modes.index[0]
        df[flag_col] = normalized != canonical
    return df