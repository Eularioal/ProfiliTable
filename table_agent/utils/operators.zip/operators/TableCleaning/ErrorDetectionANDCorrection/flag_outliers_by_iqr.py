import pandas as pd

def flag_outliers_by_iqr(df, col, flag_col="is_outlier"):
    """Flag outliers using IQR method."""
    df = df.copy()
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    df[flag_col] = ~df[col].between(lower, upper)
    return df