import pandas as pd
import re

def validate_against_regex_pattern(df, col, pattern, invalid_flag_col="invalid"):
    """Validate column against regex; flag invalid."""
    def is_valid(val):
        if pd.isnull(val):
            return False
        return bool(re.fullmatch(pattern, str(val)))
    df = df.copy()
    df[invalid_flag_col] = ~df[col].apply(is_valid)
    return df