import re
from typing import Any, Callable, Dict, List, Optional, Union, Tuple
from datetime import datetime

# ----------------------------
# Helper: mimic OpenRefine's ExpressionUtils
# ----------------------------

def is_non_blank_data(value: Any) -> bool:
    """Mimic ExpressionUtils.isNonBlankData"""
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() != ""
    return True

def is_error_value(value: Any) -> bool:
    """In OpenRefine, errors are special objects; here we assume errors are represented as dict with '__error__'."""
    return isinstance(value, dict) and "__error__" in value

def evaluate_expression(expr: Union[str, Callable], row: Dict[str, Any], column_name: str) -> Any:
    """
    Evaluate expression against a row.
    For simplicity, support:
      - "value" → row[column_name]
      - "value.trim()" → str(row[column_name]).strip()
      - custom callable
    In real OpenRefine, this is a full expression language (GREL).
    """
    if callable(expr):
        return expr(row=row, column_name=column_name)
    
    if expr == "value":
        return row.get(column_name)
    
    if expr == "value.trim()":
        val = row.get(column_name)
        if isinstance(val, str):
            return val.strip()
        return val
    
    # Add more built-in expressions as needed
    # For full GREL, you'd need a parser — out of scope here.
    raise ValueError(f"Unsupported expression: {expr}")

# ----------------------------
# Mass Edit Rule Definition
# ----------------------------

class EditRule:
    def __init__(
        self,
        from_values: Optional[List[str]] = None,
        from_blank: bool = False,
        from_error: bool = False,
        to_value: Any = None,
    ):
        self.from_values = from_values or []
        # In OpenRefine: fromBlank also triggered by [""] 
        self.from_blank = from_blank or (len(self.from_values) == 1 and self.from_values[0] == "")
        self.from_error = from_error
        self.to_value = to_value

# ----------------------------
# Main Function
# ----------------------------

def mass_edit_values(
    table: List[Dict[str, Any]],
    column_name: str,
    expression: Union[str, Callable] = "value",
    edits: List[EditRule] = None,
) -> List[Dict[str, Any]]:
    """
    Apply mass edit rules to a column.

    Parameters:
        table: Input table (list of row dicts).
        column_name: Column to transform.
        expression: Expression to compute intermediate value (default: "value").
        edits: List of EditRule objects defining replacements.

    Returns:
        New table with transformed column.
    """
    if not table:
        return []
    
    if column_name not in table[0]:
        raise ValueError(f"Column '{column_name}' not found")

    edits = edits or []
    
    # Build lookup maps (last rule wins)
    from_to_map: Dict[str, Any] = {}
    from_blank_to: Optional[Any] = None
    from_error_to: Optional[Any] = None

    for rule in edits:
        for f in rule.from_values:
            from_to_map[f] = rule.to_value
        if rule.from_blank:
            from_blank_to = rule.to_value
        if rule.from_error:
            from_error_to = rule.to_value

    new_table = []

    for row in table:
        try:
            # Step 1: Evaluate expression
            intermediate = evaluate_expression(expression, row, column_name)

            new_value = None

            # Step 2: Apply rules
            if is_error_value(intermediate):
                if from_error_to is not None:
                    new_value = from_error_to
            elif not is_non_blank_data(intermediate):
                if from_blank_to is not None:
                    new_value = from_blank_to
            else:
                # Non-blank, non-error → convert to string and match
                key = str(intermediate)
                if key in from_to_map:
                    new_value = from_to_map[key]

            # If no rule matched, keep original
            if new_value is None:
                new_value = row.get(column_name)

        except Exception:
            # Treat evaluation error as error value
            if from_error_to is not None:
                new_value = from_error_to
            else:
                new_value = row.get(column_name)

        # Build new row
        new_row = row.copy()
        new_row[column_name] = new_value
        new_table.append(new_row)

    return new_table