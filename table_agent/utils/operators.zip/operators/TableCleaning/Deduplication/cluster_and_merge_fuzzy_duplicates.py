import pandas as pd
from difflib import SequenceMatcher

def cluster_and_merge_fuzzy_duplicates(df, col, threshold=0.8):
    """Cluster similar strings and replace with canonical form."""
    df = df.copy()
    values = df[col].dropna().unique()
    clusters = []
    used = set()
    for v1 in values:
        if v1 in used:
            continue
        cluster = [v1]
        for v2 in values:
            if v2 in used or v1 == v2:
                continue
            sim = SequenceMatcher(None, str(v1).lower(), str(v2).lower()).ratio()
            if sim >= threshold:
                cluster.append(v2)
                used.add(v2)
        clusters.append(cluster)
        used.add(v1)
    
    mapping = {}
    for cluster in clusters:
        counts = df[df[col].isin(cluster)][col].value_counts()
        canonical = counts.index[0] if not counts.empty else cluster[0]
        for val in cluster:
            mapping[val] = canonical
    df[col] = df[col].map(mapping).fillna(df[col])
    return df