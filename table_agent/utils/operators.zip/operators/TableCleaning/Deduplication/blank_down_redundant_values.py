from typing import List, Dict, Any, Optional

def is_non_blank_data(value: Any) -> bool:
    """
    Mimics OpenRefine's ExpressionUtils.isNonBlankData:
    - None, empty string, or whitespace-only string → blank
    - Everything else → non-blank
    """
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() != ""
    return True

def blank_down_redundant_values(
    table: List[Dict[str, Any]],
    column_name: str,
    key_column_name: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Perform "Blank Down" operation on a specified column.

    Parameters:
        table: Input table as list of row dicts.
        column_name: Name of the column to apply blank-down.
        key_column_name: (Optional) Name of the key column.
                         If provided, enables "record-based mode":
                         whenever key column is non-blank, reset the previous value.

    Returns:
        New table with blank-down applied to `column_name`.
    """
    if not table:
        return []

    # Validate column exists
    if column_name not in table[0]:
        raise ValueError(f"Column '{column_name}' not found in table")

    if key_column_name is not None and key_column_name not in table[0]:
        raise ValueError(f"Key column '{key_column_name}' not found in table")

    new_table = []
    previous_value = None  # stores the last non-blank value in the target column

    for row in table:
        current_value = row.get(column_name)
        key_value = row.get(key_column_name) if key_column_name else None

        # Record-based mode: reset if key column is non-blank
        if key_column_name is not None and is_non_blank_data(key_value):
            previous_value = None

        if is_non_blank_data(current_value):
            # Current cell is non-blank
            if previous_value is not None and current_value == previous_value:
                # Same as previous → blank it out
                new_value = None
            else:
                # Different or first occurrence → keep it
                new_value = current_value
                previous_value = current_value
        else:
            # Current cell is blank → reset previous
            new_value = current_value  # usually None or ""
            previous_value = None

        # Build new row
        new_row = row.copy()
        new_row[column_name] = new_value
        new_table.append(new_row)

    return new_table