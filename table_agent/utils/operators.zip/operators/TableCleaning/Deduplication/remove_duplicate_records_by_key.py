import pandas as pd

def remove_duplicate_records_by_key(df, key_cols):
    """Remove duplicates based on composite key."""
    df = df.copy()
    return df.drop_duplicates(subset=key_cols, keep='first').reset_index(drop=True)