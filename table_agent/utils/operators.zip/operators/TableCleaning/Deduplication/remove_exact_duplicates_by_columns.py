from typing import List, Dict, Any, Optional
import datetime

def normalize_value(value: Any) -> str:
    """
    Normalize a cell value to a string for duplicate comparison,
    matching OpenRefine's behavior.
    """
    if value is None:
        return ""
    elif isinstance(value, datetime.datetime):
        # Format as ISO-like string without timezone: "yyyy-MM-dd'T'HH:mm:ss"
        return value.strftime("%Y-%m-%dT%H:%M:%S")
    elif isinstance(value, datetime.date):
        # If only date, treat as midnight
        return datetime.datetime.combine(value, datetime.time.min).strftime("%Y-%m-%dT%H:%M:%S")
    else:
        return str(value)

def remove_exact_duplicates_by_columns(
    table: List[Dict[str, Any]],
    criteria: List[str],
) -> List[Dict[str, Any]]:
    """
    Remove duplicate rows based on specified columns (criteria).
    Keeps the first occurrence, removes subsequent duplicates.

    Parameters:
        table: Input table as list of row dicts.
        criteria: List of column names to consider for deduplication.

    Returns:
        New table with duplicates removed.
    """
    if not table:
        return []

    # Validate criteria columns exist in at least one row
    sample_row = table[0]
    for col in criteria:
        if col not in sample_row:
            raise ValueError(f"Criteria column '{col}' not found in table")

    seen_keys = set()
    result = []

    for row in table:
        # Build normalized key tuple from criteria columns
        key_parts = tuple(normalize_value(row.get(col)) for col in criteria)
        key_hash = hash(key_parts)  # Use hash of tuple as unique key

        if key_hash in seen_keys:
            continue  # Skip duplicate
        else:
            seen_keys.add(key_hash)
            result.append(row)

    return result