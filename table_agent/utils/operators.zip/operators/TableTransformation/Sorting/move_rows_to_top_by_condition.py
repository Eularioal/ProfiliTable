import pandas as pd

def move_rows_to_top_by_condition(df, condition_expr):
    """Bring matching rows to top."""
    df = df.copy()
    mask = df.eval(condition_expr)
    top = df[mask].copy()
    bottom = df[~mask].copy()
    return pd.concat([top, bottom], ignore_index=True)