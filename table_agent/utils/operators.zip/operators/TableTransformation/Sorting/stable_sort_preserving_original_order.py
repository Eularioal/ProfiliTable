import pandas as pd

def stable_sort_preserving_original_order(df, sort_cols, ascending=True):
    """Stable sort using original index as tie-breaker."""
    df = df.copy()
    df['_orig_idx'] = range(len(df))
    asc_list = ascending if isinstance(ascending, list) else [ascending] * len(sort_cols)
    df = df.sort_values(by=sort_cols + ['_orig_idx'], ascending=asc_list + [True])
    return df.drop(columns='_orig_idx').reset_index(drop=True)