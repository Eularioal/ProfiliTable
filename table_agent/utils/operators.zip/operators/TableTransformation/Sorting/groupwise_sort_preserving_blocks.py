def groupwise_sort_preserving_blocks(
    df: pd.DataFrame,
    group_cols: list,
    sort_keys: list
) -> pd.DataFrame:
    """
    group_cols: ["group_id"] or ["country", "year"]
    sort_keys: same format as sort_by_multiple_keys_with_priority
    """

    # 记录原始 group 出现顺序
    df["_group_order"] = (
        df[group_cols]
        .astype(str)
        .agg("_".join, axis=1)
    )
    group_sequence = df["_group_order"].drop_duplicates().tolist()

    result_blocks = []

    for g in group_sequence:
        block = df[df["_group_order"] == g].copy()

        sort_cols = []
        ascending_list = []
        for k in sort_keys:
            sort_cols.append(k["column"])
            ascending_list.append(k.get("order", "asc") == "asc")

        block_sorted = block.sort_values(
            by=sort_cols,
            ascending=ascending_list,
            kind="mergesort"
        )
        result_blocks.append(block_sorted)

    result = pd.concat(result_blocks, ignore_index=True)
    result = result.drop(columns=["_group_order"])
    return result
