import pandas as pd

def sort_by_custom_value_map(df, col, value_order, new_index_col="sort_key"):
    """Sort using custom ordinal mapping."""
    df = df.copy()
    order_map = {v: i for i, v in enumerate(value_order)}
    df[new_index_col] = df[col].map(order_map)
    df = df.sort_values(by=new_index_col).drop(columns=new_index_col).reset_index(drop=True)
    return df