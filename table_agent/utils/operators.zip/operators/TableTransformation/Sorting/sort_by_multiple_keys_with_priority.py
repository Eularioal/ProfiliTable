import pandas as pd

def sort_by_multiple_keys_with_priority(df: pd.DataFrame, keys: list) -> pd.DataFrame:
    sort_cols = []
    ascending_list = []

    for k in keys:
        col = k["column"]
        order = k.get("order", "asc")
        sort_cols.append(col)
        ascending_list.append(order == "asc")

    sorted_df = df.sort_values(
        by=sort_cols,
        ascending=ascending_list,
        kind="mergesort"
    )
    return sorted_df.reset_index(drop=True)
