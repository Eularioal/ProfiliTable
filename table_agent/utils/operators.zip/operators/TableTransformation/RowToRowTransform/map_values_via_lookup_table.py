import pandas as pd

def map_values_via_lookup_table(df, col, mapping, unmapped='keep'):
    """Replace values using a dict lookup."""
    df = df.copy()
    if unmapped == 'keep':
        df[col] = df[col].map(mapping).fillna(df[col])
    elif unmapped == 'null':
        df[col] = df[col].map(mapping)
    return df