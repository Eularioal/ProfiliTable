from typing import Any, Callable, Dict, List, Optional, Union

# ----------------------------
# Helper: mimic OpenRefine's ExpressionUtils
# ----------------------------

def is_error_value(value: Any) -> bool:
    """Simulate error value (e.g., from failed expression)"""
    return isinstance(value, dict) and "__error__" in value

def same_value(a: Any, b: Any) -> bool:
    """Mimic ExpressionUtils.sameValue"""
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    return a == b

def wrap_storable(value: Any) -> Any:
    """In OpenRefine, wraps to Serializable; here pass-through."""
    return value

def evaluate_expression(expr: Union[str, Callable], row: Dict[str, Any], column_name: str) -> Any:
    """
    Simplified expression evaluator.
    Supports:
      - "value" → row[column_name]
      - "value.trim()" → str.strip()
      - "value.upper()" → str.upper()
      - custom callable
    """
    val = row.get(column_name)

    if callable(expr):
        return expr(row=row, column_name=column_name)

    if expr == "value":
        return val

    if expr == "value.trim()":
        return str(val).strip() if isinstance(val, str) else val

    if expr == "value.upper()":
        return str(val).upper() if isinstance(val, str) else val

    if expr == "value.lower()":
        return str(val).lower() if isinstance(val, str) else val

    # Extend as needed
    raise ValueError(f"Unsupported expression: {expr}")

# ----------------------------
# OnError Strategies
# ----------------------------

class OnError:
    KEEP_ORIGINAL = "keep-original"
    SET_TO_BLANK = "set-to-blank"
    STORE_ERROR = "store-error"  # not used in core logic

# ----------------------------
# Main Function
# ----------------------------

def transform_row_by_expression(
    table: List[Dict[str, Any]],
    column_name: str,
    expression: Union[str, Callable] = "value",
    on_error: str = OnError.KEEP_ORIGINAL,
    repeat: bool = False,
    repeat_count: int = 10,
) -> List[Dict[str, Any]]:
    """
    Apply a text transformation expression to a column.

    Parameters:
        table: Input table (list of row dicts).
        column_name: Column to transform.
        expression: Expression string (e.g., "value.trim()") or callable.
        on_error: "keep-original" | "set-to-blank"
        repeat: Whether to repeatedly apply the expression until stable.
        repeat_count: Max number of repetitions if repeat=True.

    Returns:
        New table with transformed column.
    """
    if not table:
        return []

    if column_name not in table[0]:
        raise ValueError(f"Column '{column_name}' not found")

    new_table = []

    for row in table:
        original_value = row.get(column_name)
        current_value = original_value
        error_occurred = False

        try:
            # First evaluation
            result = evaluate_expression(expression, row, column_name)
            if is_error_value(result):
                error_occurred = True
            else:
                current_value = wrap_storable(result)
        except Exception:
            error_occurred = True

        # Handle error
        if error_occurred:
            if on_error == OnError.SET_TO_BLANK:
                current_value = None
            elif on_error == OnError.KEEP_ORIGINAL:
                current_value = original_value
            else:  # STORE_ERROR (not implemented)
                current_value = original_value

        # Repeat if enabled
        if repeat and not error_occurred and not is_error_value(current_value):
            temp_row = row.copy()
            for _ in range(repeat_count):
                temp_row[column_name] = current_value
                try:
                    next_result = evaluate_expression(expression, temp_row, column_name)
                    if is_error_value(next_result):
                        break
                    next_value = wrap_storable(next_result)
                    if same_value(current_value, next_value):
                        break
                    current_value = next_value
                except Exception:
                    break

        # Build new row
        new_row = row.copy()
        new_row[column_name] = current_value
        new_table.append(new_row)

    return new_table