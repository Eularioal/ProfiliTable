import pandas as pd
import unicodedata
import re

def normalize_text_values(df, col):
    """Apply Unicode normalization, trim, case fold, collapse spaces."""
    def clean(text):
        if pd.isnull(text):
            return None
        text = unicodedata.normalize('NFC', str(text))
        text = text.strip()
        text = text.lower()
        text = re.sub(r'\s+', ' ', text)
        return text
    df = df.copy()
    df[col] = df[col].apply(clean)
    return df