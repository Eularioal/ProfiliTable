import pandas as pd

def apply_conditional_row_update(df, col, condition_expr, true_val, false_val=None):
    """Update column based on condition (uses DataFrame.eval)."""
    df = df.copy()
    mask = df.eval(condition_expr)
    if false_val is None:
        df.loc[mask, col] = true_val
    else:
        df[col] = df[col].where(~mask, true_val).where(mask, false_val)
    return df