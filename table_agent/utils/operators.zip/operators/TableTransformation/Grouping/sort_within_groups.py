import pandas as pd

def sort_within_groups(df, key_cols, sort_col, ascending=True):
    """Sort within groups without changing group order."""
    df = df.copy()
    df['_temp_order'] = df.groupby(key_cols).cumcount()
    df = df.sort_values(by=key_cols + [sort_col], ascending=[True]*len(key_cols) + [ascending])
    df = df.sort_values(by='_temp_order').drop(columns='_temp_order').reset_index(drop=True)
    return df