import pandas as pd

def collapse_groups_to_summary_row(df, key_cols, agg_dict):
    """Collapse groups to one row using aggregation rules."""
    df = df.copy()
    return df.groupby(key_cols).agg(agg_dict).reset_index()