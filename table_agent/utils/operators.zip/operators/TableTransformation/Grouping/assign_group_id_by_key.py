import pandas as pd

def assign_group_id_by_key(df, key_cols, group_id_col="group_id"):
    """Assign group ID based on key columns."""
    df = df.copy()
    df = df.sort_values(by=key_cols).reset_index(drop=True)
    df[group_id_col] = df.groupby(key_cols).ngroup() + 1
    return df