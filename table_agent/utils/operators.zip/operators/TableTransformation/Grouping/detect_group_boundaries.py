import pandas as pd

def detect_group_boundaries(df, key_col, boundary_col="is_boundary"):
    """Mark start of new group when key changes from blank to non-blank."""
    df = df.copy().reset_index(drop=True)
    is_nonblank = df[key_col].notna() & (df[key_col] != '')
    prev_blank = df[key_col].shift(1).isna() | (df[key_col].shift(1) == '')
    df[boundary_col] = is_nonblank & prev_blank.fillna(True)
    return df