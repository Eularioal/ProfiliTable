import pandas as pd
import re
from typing import List, Optional, Union

def split_column_multivalued(
    df: pd.DataFrame,
    column_name: str,
    mode: str = "separator",
    separator: Optional[str] = None,
    regex: bool = False,
    max_columns: Optional[int] = None,
    field_lengths: Optional[List[int]] = None,
    remove_original: bool = False,
    guess_types: bool = False
) -> pd.DataFrame:
    """
    Split a single column into multiple columns by separator or fixed field lengths.
    
    Belongs to benchmark task: TableTransformation-SplittingConcatenation
    
    Parameters:
        df: Input DataFrame.
        column_name: Column to split.
        mode: "separator" or "lengths".
        separator: Delimiter string (for "separator" mode).
        regex: If True, treat separator as regex.
        max_columns: Maximum number of columns to create (applies to separator mode).
        field_lengths: List of character lengths (for "lengths" mode).
        remove_original: Whether to drop the original column.
        guess_types: Whether to auto-convert new columns (e.g., "123" → int).

    Returns:
        New DataFrame with split columns.
    """
    if column_name not in df.columns:
        raise ValueError(f"Column '{column_name}' not found.")

    df = df.copy()
    new_cols_data = []  # List of lists, one per row
    max_split_len = 0

    def is_blank(val):
        return pd.isna(val) or (isinstance(val, str) and val == "")

    def parse_value(val: str):
        if not guess_types:
            return val
        # Simple type guessing: int → float → str
        try:
            if '.' in val:
                return float(val)
            else:
                return int(val)
        except (ValueError, TypeError):
            return val

    # Step 1: Split each cell and collect results
    for _, row in df.iterrows():
        cell_val = row[column_name]
        if is_blank(cell_val):
            split_vals = []
        else:
            s = str(cell_val)
            if mode == "lengths":
                if not field_lengths:
                    split_vals = [s]
                else:
                    parts = []
                    start = 0
                    for length in field_lengths:
                        if length <= 0:
                            parts.append("")
                        else:
                            end = start + length
                            parts.append(s[start:end])
                            start = end
                            if start >= len(s):
                                break
                    split_vals = parts
            elif mode == "separator":
                if not separator:
                    split_vals = [s]
                else:
                    if regex:
                        parts = re.split(separator, s, maxsplit=(max_columns - 1) if max_columns else -1)
                    else:
                        # Simulate splitByWholeSeparatorPreserveAllTokens with max limit
                        if max_columns is None or max_columns <= 0:
                            parts = s.split(separator)
                        else:
                            parts = s.split(separator, max_columns - 1)
                    split_vals = parts
            else:
                split_vals = [s]

        # Apply max_columns truncation (only for separator mode in OpenRefine, but we apply generally)
        if max_columns is not None and max_columns > 0:
            split_vals = split_vals[:max_columns]

        split_vals = [parse_value(v) if not is_blank(v) else pd.NA for v in split_vals]
        new_cols_data.append(split_vals)
        max_split_len = max(max_split_len, len(split_vals))

    # Step 2: Create new column names (avoid conflicts)
    new_col_names = []
    idx = 1
    while len(new_col_names) < max_split_len:
        candidate = f"{column_name} {idx}"
        if candidate not in df.columns:
            new_col_names.append(candidate)
        idx += 1

    # Step 3: Build split columns
    split_df = pd.DataFrame(
        [
            (row + [pd.NA] * (max_split_len - len(row)))[:max_split_len]
            for row in new_cols_data
        ],
        columns=new_col_names,
        index=df.index
    )

    # Step 4: Combine
    result = pd.concat([df, split_df], axis=1)

    if remove_original:
        result = result.drop(columns=[column_name])

    return result