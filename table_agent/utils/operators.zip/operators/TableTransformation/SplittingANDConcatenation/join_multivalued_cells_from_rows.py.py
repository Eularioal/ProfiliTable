import pandas as pd
from typing import Any

def table_transformation_splitting_concatenation(
    df: pd.DataFrame,
    column_name: str,
    key_column_name: str,
    separator: str
) -> pd.DataFrame:
    """
    Implements OpenRefine's MultiValuedCellJoinOperation.
    
    Joins values in `column_name` across consecutive rows that belong to the same logical record,
    where a new record starts when `key_column_name` is non-blank.
    
    - The joined string is placed in the first row of each group.
    - Other rows in the group have `column_name` set to blank (NaN).
    - Blank values (None, NaN, empty string) in `column_name` are skipped during join.
    
    Belongs to benchmark task type: TableTransformation-SplittingConcatenation
    """
    if column_name not in df.columns:
        raise ValueError(f"Column '{column_name}' not found.")
    if key_column_name not in df.columns:
        raise ValueError(f"Key column '{key_column_name}' not found.")
    if separator is None:
        raise ValueError("Separator must be provided.")

    def is_blank(val: Any) -> bool:
        return pd.isna(val) or (isinstance(val, str) and val.strip() == "")

    # Work on a copy to avoid modifying original
    df = df.copy()
    n = len(df)
    new_rows = []
    i = 0

    while i < n:
        current_row = df.iloc[i]

        # If key column is blank, treat as standalone row (no grouping)
        if is_blank(current_row[key_column_name]):
            new_rows.append(current_row.copy())
            i += 1
            continue

        # Start of a new group: find all consecutive rows until next non-blank key
        group_start = i
        i += 1
        while i < n and is_blank(df.iloc[i][key_column_name]):
            i += 1
        group_end = i  # exclusive

        # If group has only one row, no join needed
        if group_end == group_start + 1:
            new_rows.append(current_row.copy())
            continue

        # Collect non-blank values from the group in `column_name`
        values = []
        for idx in range(group_start, group_end):
            val = df.iloc[idx][column_name]
            if not is_blank(val):
                values.append(str(val))

        joined_value = separator.join(values)

        # Build new rows for the group
        for idx in range(group_start, group_end):
            row = df.iloc[idx].copy()
            if idx == group_start:
                # First row gets the joined value
                row[column_name] = joined_value
            else:
                # Subsequent rows get blank in the target column
                row[column_name] = pd.NA
            new_rows.append(row)

    result_df = pd.DataFrame(new_rows, columns=df.columns).reset_index(drop=True)
    return result_df