import pandas as pd
import os
from typing import List

def union_homogeneous_csv_tables(
    input_file_paths: List[str],
    output_dir: str,
    output_filename: str = "output.csv",
    keep_default_na: bool = False,
    na_values: List[str] = None
) -> str:
    """
    Vertically merge multiple CSV files with identical headers.
    Returns:
    - Path to the output file.
    """
    if not input_file_paths:
        raise ValueError("At least one input file path must be provided.")

    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)

    dataframes = []
    first_header = None

    for file_path in input_file_paths:
        try:
            df = pd.read_csv(
                file_path,
                dtype=str,
                keep_default_na=keep_default_na,
                na_values=na_values,
                encoding='utf-8'
            )
        except pd.errors.EmptyDataError:
            # Skip truly empty files
            continue

        if df.empty:
            # Skip files with no data (only header or completely empty)
            continue

        # Record header from first non-empty file
        if first_header is None:
            first_header = df.columns.tolist()
        else:
            # Optional: enforce header consistency (uncomment if needed)
            # if df.columns.tolist() != first_header:
            #     raise ValueError(f"Header mismatch in {file_path}")
            pass

        dataframes.append(df)

    if dataframes:
        merged_df = pd.concat(dataframes, ignore_index=True, sort=False)
    else:
        # If all files were empty, create an empty DataFrame using the first file's header
        try:
            empty_df = pd.read_csv(input_file_paths[0], nrows=0, dtype=str)
            merged_df = empty_df
        except Exception:
            # Fallback: create completely empty DataFrame
            merged_df = pd.DataFrame()

    output_path = os.path.join(output_dir, output_filename)
    merged_df.to_csv(output_path, index=False, encoding='utf-8')
    return output_path