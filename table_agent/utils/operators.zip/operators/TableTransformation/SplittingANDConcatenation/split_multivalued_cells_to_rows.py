import pandas as pd
import re
from typing import List, Optional, Union

def split_multivalued_column(
    df: pd.DataFrame,
    column_name: str,
    key_column_name: str,
    mode: str = "separator",
    separator: Optional[str] = None,
    regex: bool = False,
    field_lengths: Optional[List[int]] = None
) -> pd.DataFrame:
    """
    Split a multi-valued cell into multiple rows, mimicking OpenRefine's MultiValuedCellSplitOperation.

    Parameters:
        df: Input DataFrame.
        column_name: Name of the column to split.
        key_column_name: Name of the key column (non-blank indicates start of new record).
        mode: One of "separator", "regex", or "lengths".
        separator: Separator string (required for "separator"/"regex" modes).
        regex: If True and mode is "separator", treat separator as regex.
        field_lengths: List of lengths for "lengths" mode.

    Returns:
        New DataFrame with split values in separate rows.
    """
    if column_name not in df.columns:
        raise ValueError(f"Column '{column_name}' not found.")
    if key_column_name not in df.columns:
        raise ValueError(f"Key column '{key_column_name}' not found.")

    # Helper: check if a value is blank (None, NaN, or empty string)
    def is_blank(val):
        return pd.isna(val) or (isinstance(val, str) and val == "")

    new_rows = []
    i = 0
    n = len(df)

    while i < n:
        row = df.iloc[i]
        cell_val = row[column_name]

        if is_blank(cell_val):
            new_rows.append(row.copy())
            i += 1
            continue

        s = str(cell_val)

        # --- Split logic ---
        if mode == "lengths":
            if not field_lengths or all(l <= 0 for l in field_lengths):
                values = [s]
            else:
                values = []
                start = 0
                for length in field_lengths:
                    if length <= 0:
                        values.append("")
                    else:
                        end = start + length
                        values.append(s[start:end])
                        start = end
                        if start >= len(s):
                            # Pad remaining with empty strings if needed?
                            # Java version stops here, so we do too.
                            break
                # No padding beyond specified lengths
        elif mode in ("separator", "regex"):
            if not separator:
                values = [s]
            else:
                if regex:
                    # Use re.split, but ensure trailing empty strings are kept
                    # Java's Pattern.split keeps trailing empty strings by default
                    values = re.split(separator, s, flags=re.UNICODE)
                else:
                    # Simulate StringUtils.splitByWholeSeparatorPreserveAllTokens
                    # This preserves empty tokens including trailing ones
                    if separator == "":
                        values = [s]
                    else:
                        parts = []
                        start = 0
                        sep_len = len(separator)
                        while True:
                            idx = s.find(separator, start)
                            if idx == -1:
                                parts.append(s[start:])
                                break
                            else:
                                parts.append(s[start:idx])
                                start = idx + sep_len
                        values = parts
        else:
            values = [s]

        # If no actual split, keep original row
        if len(values) < 2:
            new_rows.append(row.copy())
            i += 1
            continue

        # First value stays in current row
        first_row = row.copy()
        first_row = first_row.copy()  # Ensure writable
        first_row[column_name] = values[0]
        new_rows.append(first_row)

        # Handle remaining values
        v_idx = 1
        next_i = i + 1

        while v_idx < len(values):
            current_value = values[v_idx]

            # Try to reuse next row if it's blank in both target and key columns
            if next_i < n:
                next_row = df.iloc[next_i]
                if is_blank(next_row[column_name]) and is_blank(next_row[key_column_name]):
                    reused = next_row.copy()
                    reused = reused.copy()
                    reused[column_name] = current_value
                    new_rows.append(reused)
                    v_idx += 1
                    next_i += 1
                    continue

            # Otherwise, create a new blank row
            new_row = pd.Series(index=df.columns, dtype=object)
            new_row[column_name] = current_value
            # All other columns remain NaN (blank)
            new_rows.append(new_row)
            v_idx += 1

        # Skip any rows we consumed
        i = next_i

    # Reconstruct DataFrame
    result_df = pd.DataFrame(new_rows, columns=df.columns)
    result_df.reset_index(drop=True, inplace=True)
    return result_df