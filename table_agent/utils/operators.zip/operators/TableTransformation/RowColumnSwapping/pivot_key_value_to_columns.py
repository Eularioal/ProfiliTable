from typing import List, Dict, Any, Optional, Tuple
import re

def is_non_blank_data(value: Any) -> bool:
    """Mimic OpenRefine's ExpressionUtils.isNonBlankData"""
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() != ""
    return True

def get_unduplicated_column_name(existing_names: set, base_name: str) -> str:
    """Generate a column name not in existing_names, e.g., 'name', 'name 2', etc."""
    if base_name not in existing_names:
        return base_name
    i = 2
    while f"{base_name} {i}" in existing_names:
        i += 1
    return f"{base_name} {i}"

def pivot_key_value_to_columns(
    table: List[Dict[str, Any]],
    key_column_name: str,
    value_column_name: str,
    note_column_name: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Transform key-value pairs into columns (wide format).

    Parameters:
        table: Input table (list of row dicts).
        key_column_name: Column whose values become new column names.
        value_column_name: Column whose values populate the new columns.
        note_column_name: Optional column for notes; generates extra columns like "note : key".

    Returns:
        New table in wide format.
    """
    if not table:
        return []

    # Validate required columns
    sample = table[0]
    if key_column_name not in sample:
        raise ValueError(f"Key column '{key_column_name}' not found")
    if value_column_name not in sample:
        raise ValueError(f"Value column '{value_column_name}' not found")
    if note_column_name and note_column_name not in sample:
        raise ValueError(f"Note column '{note_column_name}' not found")

    # Identify "other" columns (to group by)
    all_columns = set(sample.keys())
    special_cols = {key_column_name, value_column_name}
    if note_column_name:
        special_cols.add(note_column_name)
    other_columns = sorted([col for col in all_columns if col not in special_cols])

    new_rows = []
    new_column_names = set(other_columns)  # start with unchanged columns

    if not other_columns:
        # Degenerate case: only key/value (and maybe note)
        current_row = {col: None for col in other_columns}  # empty dict
        new_rows.append(current_row)

        for row in table:
            key_val = row.get(key_column_name)
            if not is_non_blank_data(key_val):
                # Blank key → start new record
                current_row = {col: None for col in other_columns}
                new_rows.append(current_row)
                continue

            key_str = str(key_val)
            value_cell = row.get(value_column_name)
            note_val = row.get(note_column_name) if note_column_name else None

            # Ensure column exists
            safe_key_col = get_unduplicated_column_name(new_column_names, key_str)
            new_column_names.add(safe_key_col)

            # Assign value
            current_row[safe_key_col] = value_cell

            # Handle note
            if note_column_name and is_non_blank_data(note_val):
                note_col_name = get_unduplicated_column_name(
                    new_column_names, f"{note_column_name} : {key_str}"
                )
                new_column_names.add(note_col_name)
                existing_note = current_row.get(note_col_name)
                if existing_note and is_non_blank_data(existing_note):
                    current_row[note_col_name] = f"{existing_note};{note_val}"
                else:
                    current_row[note_col_name] = note_val

    else:
        # General case: group by other_columns
        group_key_to_row: Dict[Tuple, Dict[str, Any]] = {}

        for row in table:
            key_val = row.get(key_column_name)
            if not is_non_blank_data(key_val):
                # Blank key → emit as-is (no transformation)
                new_rows.append(row.copy())
                continue

            key_str = str(key_val)
            value_cell = row.get(value_column_name)
            note_val = row.get(note_column_name) if note_column_name else None

            # Build group key from other columns
            group_key = tuple(row.get(col) for col in other_columns)

            if group_key not in group_key_to_row:
                # Initialize new row with other columns
                new_row = {col: row[col] for col in other_columns}
                group_key_to_row[group_key] = new_row
                new_rows.append(new_row)

            target_row = group_key_to_row[group_key]

            # Add value column
            safe_key_col = get_unduplicated_column_name(new_column_names, key_str)
            new_column_names.add(safe_key_col)
            target_row[safe_key_col] = value_cell

            # Add note column if needed
            if note_column_name and is_non_blank_data(note_val):
                note_col_base = f"{note_column_name} : {key_str}"
                safe_note_col = get_unduplicated_column_name(new_column_names, note_col_base)
                new_column_names.add(safe_note_col)

                existing_note = target_row.get(safe_note_col)
                if existing_note and is_non_blank_data(existing_note):
                    target_row[safe_note_col] = f"{existing_note};{note_val}"
                else:
                    target_row[safe_note_col] = note_val

    # Normalize all rows to have same columns (fill missing with None)
    final_columns = sorted(new_column_names)
    normalized_table = []
    for row in new_rows:
        normalized_row = {col: row.get(col) for col in final_columns}
        # Also preserve original other columns order if desired (optional)
        normalized_table.append(normalized_row)

    # Remove completely empty rows (all None)
    cleaned_table = [
        row for row in normalized_table
        if any(is_non_blank_data(v) for v in row.values())
    ]

    return cleaned_table