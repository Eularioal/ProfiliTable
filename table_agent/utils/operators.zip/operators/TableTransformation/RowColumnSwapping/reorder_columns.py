def reorder_columns(df, column_order):
    missing = set(column_order) - set(df.columns)
    if missing:
        raise ValueError(f"Columns not found: {missing}")
    return df[column_order]