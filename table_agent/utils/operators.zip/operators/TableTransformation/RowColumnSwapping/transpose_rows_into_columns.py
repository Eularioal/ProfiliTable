from typing import List, Dict, Any, Optional

def transpose_rows_into_columns(
    table: List[Dict[str, Any]],
    column_name: str,
    row_count: int,
) -> List[Dict[str, Any]]:
    """
    Transpose groups of rows into columns (long-to-wide).

    Parameters:
        table: Input table as list of row dicts.
        column_name: Name of the column to transpose.
        row_count: Number of rows per group.

    Returns:
        New table with rows grouped and transposed.
    """
    if not table:
        return []

    if row_count <= 0:
        raise ValueError("row_count must be positive")

    columns = list(table[0].keys())
    if column_name not in columns:
        raise ValueError(f"Column '{column_name}' not found")

    col_index = columns.index(column_name)

    # Build new column names for transposed values
    new_transposed_cols = []
    base_name = column_name
    used_names = set(columns)
    for i in range(1, row_count + 1):
        candidate = f"{base_name} {i}"
        while candidate in used_names:
            i += 1
            candidate = f"{base_name} {i}"
        new_transposed_cols.append(candidate)
        used_names.add(candidate)

    # Other columns (unchanged)
    leading_cols = columns[:col_index]
    trailing_cols = columns[col_index + 1:]
    new_columns = leading_cols + new_transposed_cols + trailing_cols

    new_table = []

    # Process groups of `row_count` rows
    for group_start in range(0, len(table), row_count):
        group = table[group_start:group_start + row_count]
        new_row = {col: None for col in new_columns}

        # Fill leading and trailing columns from first non-empty row in group
        for col in leading_cols + trailing_cols:
            for r in group:
                val = r.get(col)
                if val is not None:
                    new_row[col] = val
                    break

        # Fill transposed columns
        for i, row in enumerate(group):
            if i >= row_count:
                break
            new_row[new_transposed_cols[i]] = row.get(column_name)

        new_table.append(new_row)

    return new_table