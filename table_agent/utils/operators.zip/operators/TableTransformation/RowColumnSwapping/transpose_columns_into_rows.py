from typing import List, Dict, Any, Optional

def is_non_blank_data(value: Any) -> bool:
    """Mimic OpenRefine's ExpressionUtils.isNonBlankData"""
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() != ""
    return True

def transpose_columns_into_rows(
    table: List[Dict[str, Any]],
    start_column_name: str,
    column_count: int = -1,
    ignore_blank_cells: bool = True,
    fill_down: bool = False,
    # Combined mode
    combined_column_name: Optional[str] = None,
    prepend_column_name: bool = False,
    separator: str = ": ",
    # Split mode
    key_column_name: Optional[str] = None,
    value_column_name: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Transpose a range of columns into rows (wide-to-long).

    Parameters:
        table: Input table as list of row dicts.
        start_column_name: Name of the first column to transpose.
        column_count: Number of columns to transpose.
                      If <= 0, transpose from start to end.
        ignore_blank_cells: Skip blank cells if True.
        fill_down: Fill down leading column values to new rows.
        combined_column_name: If provided, use combined mode.
        prepend_column_name: In combined mode, prepend column name.
        separator: Separator in combined mode.
        key_column_name, value_column_name: Required in split mode.

    Returns:
        New table in long format.
    """
    if not table:
        return []

    columns = list(table[0].keys())
    if start_column_name not in columns:
        raise ValueError(f"Start column '{start_column_name}' not found")

    start_idx = columns.index(start_column_name)
    if column_count > 0:
        end_idx = start_idx + column_count
    else:
        end_idx = len(columns)

    transpose_cols = columns[start_idx:end_idx]
    leading_cols = columns[:start_idx]
    trailing_cols = columns[end_idx:]

    # Validate mode
    if combined_column_name is not None:
        # Combined mode
        if combined_column_name in leading_cols or combined_column_name in trailing_cols:
            raise ValueError(f"Combined column name '{combined_column_name}' already exists")
        new_columns = leading_cols + [combined_column_name] + trailing_cols
    else:
        # Split mode
        if not key_column_name or not value_column_name:
            raise ValueError("key_column_name and value_column_name required in split mode")
        if key_column_name in columns or value_column_name in columns:
            raise ValueError("Key or value column name already exists")
        new_columns = leading_cols + [key_column_name, value_column_name] + trailing_cols

    new_table = []

    for row in table:
        # Extract leading and trailing values
        leading_values = {col: row[col] for col in leading_cols}
        trailing_values = {col: row[col] for col in trailing_cols}

        transposed_rows = []

        for col in transpose_cols:
            cell_value = row.get(col)
            is_blank = not is_non_blank_data(cell_value)

            if ignore_blank_cells and is_blank:
                continue

            if combined_column_name is not None:
                # Combined mode
                if is_blank and prepend_column_name:
                    combined_value = col + separator
                elif prepend_column_name:
                    combined_value = col + separator + str(cell_value)
                else:
                    combined_value = cell_value if not is_blank else None

                transposed_row = {
                    **leading_values,
                    combined_column_name: combined_value,
                    **trailing_values,
                }
            else:
                # Split mode
                transposed_row = {
                    **leading_values,
                    key_column_name: col,
                    value_column_name: cell_value,
                    **trailing_values,
                }

            transposed_rows.append(transposed_row)

        if not transposed_rows:
            # No valid transposed cells → create one row with blanks
            if combined_column_name is not None:
                dummy_row = {
                    **leading_values,
                    combined_column_name: None,
                    **trailing_values,
                }
            else:
                dummy_row = {
                    **leading_values,
                    key_column_name: None,
                    value_column_name: None,
                    **trailing_values,
                }
            transposed_rows = [dummy_row]

        # Apply fill_down: propagate leading values to all but first row
        if fill_down and len(transposed_rows) > 1:
            for i in range(1, len(transposed_rows)):
                for col in leading_cols:
                    if transposed_rows[i][col] is None:
                        transposed_rows[i][col] = transposed_rows[0][col]

        new_table.extend(transposed_rows)

    return new_table