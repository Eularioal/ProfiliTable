import pandas as pd

def retain_top_k_rows_per_group(df, group_cols, sort_col, k=1, ascending=False):
    """Keep top-k per group."""
    df = df.copy()
    df = df.sort_values(by=sort_col, ascending=ascending)
    return df.groupby(group_cols).head(k).reset_index(drop=True)