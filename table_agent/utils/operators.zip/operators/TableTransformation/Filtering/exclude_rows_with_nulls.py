import pandas as pd

def exclude_rows_with_nulls(df, cols=None):
    """Drop rows with any null in specified columns."""
    df = df.copy()
    if cols is None:
        cols = df.columns
    return df.dropna(subset=cols).reset_index(drop=True)