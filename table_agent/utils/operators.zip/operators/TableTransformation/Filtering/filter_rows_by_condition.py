import pandas as pd

def filter_rows_by_condition(df, condition_expr):
    """Keep rows satisfying condition."""
    df = df.copy()
    return df.query(condition_expr).reset_index(drop=True)