import pandas as pd

def filter_by_value_frequency(df, col, min_freq=2, keep_rare=False):
    """Filter rows by frequency of value in col."""
    df = df.copy()
    freq = df[col].value_counts()
    if keep_rare:
        valid_vals = freq[freq < min_freq].index
    else:
        valid_vals = freq[freq >= min_freq].index
    return df[df[col].isin(valid_vals)].reset_index(drop=True)