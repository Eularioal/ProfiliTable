import pandas as pd
import re

def extract_all_matches_from_text(df, text_col, pattern, new_col="matches"):
    """Extract all regex matches into list."""
    def find_all(val):
        if pd.isnull(val):
            return []
        return re.findall(pattern, str(val))
    df = df.copy()
    df[new_col] = df[text_col].apply(find_all)
    return df