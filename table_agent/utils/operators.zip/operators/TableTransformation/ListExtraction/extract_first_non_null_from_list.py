import pandas as pd

def extract_first_non_null_from_list(df, list_col, new_col, delimiter=None):
    """Extract first non-empty element from delimited string or list."""
    def first_non_null(val):
        if pd.isnull(val):
            return None
        if delimiter:
            parts = str(val).split(delimiter)
        else:
            parts = val if isinstance(val, list) else [val]
        for p in parts:
            if pd.notnull(p) and str(p).strip() != '':
                return p
        return None
    df = df.copy()
    df[new_col] = df[list_col].apply(first_non_null)
    return df