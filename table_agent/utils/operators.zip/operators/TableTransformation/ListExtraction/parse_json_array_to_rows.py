import pandas as pd
import json

def parse_json_array_to_rows(df, json_col):
    """Parse JSON array column into rows."""
    expanded = []
    df = df.copy()
    for _, row in df.iterrows():
        try:
            arr = json.loads(row[json_col]) if pd.notnull(row[json_col]) else []
        except (ValueError, TypeError):
            arr = [row[json_col]]
        if isinstance(arr, list):
            for item in arr:
                new_row = row.copy()
                new_row[json_col] = item
                expanded.append(new_row)
        else:
            expanded.append(row)
    return pd.DataFrame(expanded).reset_index(drop=True)