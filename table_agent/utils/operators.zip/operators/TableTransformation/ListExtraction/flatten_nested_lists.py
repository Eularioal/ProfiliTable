import pandas as pd

def flatten_nested_lists(df, list_col, flattened_col=None):
    """Flatten list of lists into single list."""
    if flattened_col is None:
        flattened_col = list_col + "_flat"
    def flatten(val):
        if pd.isnull(val):
            return []
        if isinstance(val, list):
            result = []
            for item in val:
                if isinstance(item, list):
                    result.extend(item)
                else:
                    result.append(item)
            return result
        return [val]
    df = df.copy()
    df[flattened_col] = df[list_col].apply(flatten)
    return df