import pandas as pd
from difflib import SequenceMatcher

def link_records_via_fuzzy_join(df1, df2, on_col, threshold=0.8):
    """Fuzzy join on a column."""
    results = []
    for _, r1 in df1.iterrows():
        best_sim = 0
        best_r2 = None
        for _, r2 in df2.iterrows():
            sim = SequenceMatcher(None, str(r1[on_col]), str(r2[on_col])).ratio()
            if sim > best_sim:
                best_sim = sim
                best_r2 = r2
        if best_sim >= threshold and best_r2 is not None:
            merged = {**r1.to_dict(), **{f"{k}_right": v for k, v in best_r2.to_dict().items()}, "similarity": best_sim}
            results.append(merged)
    return pd.DataFrame(results) if results else pd.DataFrame()