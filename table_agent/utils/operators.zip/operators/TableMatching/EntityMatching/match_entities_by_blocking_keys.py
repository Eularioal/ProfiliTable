import pandas as pd
from difflib import SequenceMatcher

def match_entities_by_blocking_keys(df1, df2, block_keys, similarity_threshold=0.8):
    """Perform blocking + fuzzy match on name."""
    matches = []
    for bk in block_keys:
        if bk not in df1.columns or bk not in df2.columns:
            continue
        for v in df1[bk].dropna().unique():
            sub1 = df1[df1[bk] == v]
            sub2 = df2[df2[bk] == v]
            for _, r1 in sub1.iterrows():
                for _, r2 in sub2.iterrows():
                    sim = SequenceMatcher(None, str(r1.get('name', '')), str(r2.get('name', ''))).ratio()
                    if sim >= similarity_threshold:
                        matches.append((r1.name, r2.name, sim))
    return matches