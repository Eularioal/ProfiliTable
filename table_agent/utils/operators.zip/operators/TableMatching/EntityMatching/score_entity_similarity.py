import pandas as pd
from difflib import SequenceMatcher

def score_entity_similarity(df1, df2, fields, weights=None):
    """Compute composite similarity score between all pairs."""
    if weights is None:
        weights = {f: 1.0 for f in fields}
    scores = []
    for _, r1 in df1.iterrows():
        for _, r2 in df2.iterrows():
            total = 0
            w_sum = 0
            for f in fields:
                if f not in r1 or f not in r2:
                    continue
                w = weights[f]
                sim = SequenceMatcher(None, str(r1[f]), str(r2[f])).ratio()
                total += w * sim
                w_sum += w
            scores.append(total / w_sum if w_sum > 0 else 0)
    return scores