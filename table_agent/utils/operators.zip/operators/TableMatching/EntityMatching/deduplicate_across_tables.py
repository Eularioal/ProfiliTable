import pandas as pd

def deduplicate_across_tables(tables, key_cols, similarity_threshold=0.8):
    """Stub: merge and dedup using exact key match."""
    combined = pd.concat(tables, ignore_index=True)
    return combined.drop_duplicates(subset=key_cols, keep='first').reset_index(drop=True)