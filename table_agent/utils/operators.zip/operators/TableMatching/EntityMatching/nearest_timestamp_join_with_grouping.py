import pandas as pd
from typing import List, Optional, Dict, Any

def nearest_timestamp_join_with_grouping(
    left_df: pd.DataFrame,
    right_df: pd.DataFrame,
    left_time_col: str,
    right_time_col: str,
    group_keys: Optional[List[str]] = None,
    max_lag_days: float = 20.0,
    right_suffix: str = "_right"
) -> pd.DataFrame:
    """
    Perform a group-wise nearest timestamp join where right_time <= left_time and within max_lag.

    Parameters:
    - left_df: Left DataFrame.
    - right_df: Right DataFrame.
    - left_time_col: Column name of timestamp in left_df.
    - right_time_col: Column name of timestamp in right_df.
    - group_keys: List of column names to group by. If None, no grouping.
    - max_lag_days: Maximum allowed time lag in days (right must be >= left - max_lag_days).
    - right_suffix: Suffix to add to right-side columns to avoid naming conflicts.

    Returns:
    - Merged DataFrame with all left columns and matched right columns (or nulls if no match).
      Timestamp columns are converted to ISO 8601 strings.
    """
    # Make copies to avoid modifying inputs
    left = left_df.copy()
    right = right_df.copy()

    # Convert timestamp columns to datetime
    left[left_time_col] = pd.to_datetime(left[left_time_col])
    right[right_time_col] = pd.to_datetime(right[right_time_col])

    # Add suffix to right non-group columns to avoid collision
    common_cols = set(left.columns) & set(right.columns)
    cols_to_rename = [col for col in right.columns if col not in (group_keys or [])]
    rename_map = {col: col + right_suffix for col in cols_to_rename if col in common_cols}
    right = right.rename(columns=rename_map)

    # Update time column name after rename
    right_time_col_renamed = rename_map.get(right_time_col, right_time_col)

    # Sort both DataFrames
    sort_cols_left = (group_keys or []) + [left_time_col]
    sort_cols_right = (group_keys or []) + [right_time_col_renamed]
    left = left.sort_values(by=sort_cols_left).reset_index(drop=True)
    right = right.sort_values(by=sort_cols_right).reset_index(drop=True)

    results = []

    if group_keys:
        # Group-wise matching
        for group_key, left_group in left.groupby(group_keys, sort=False):
            if not isinstance(group_key, tuple):
                group_key = (group_key,)
            mask = True
            for key, val in zip(group_keys, group_key):
                mask &= (right[key] == val)
            right_group = right[mask].copy()
            
            for _, left_row in left_group.iterrows():
                if right_group.empty:
                    # No right data for this group
                    result_row = left_row.to_dict()
                    # Fill right columns with NaN
                    for col in right.columns:
                        if col not in (group_keys or []):
                            result_row[col] = pd.NA
                    results.append(result_row)
                    continue

                # Filter:
                valid_mask = right_group[right_time_col_renamed] <= left_row[left_time_col]
                valid_subset = right_group[valid_mask]

                if valid_subset.empty:
                    # No earlier right record
                    result_row = left_row.to_dict()
                    for col in right.columns:
                        if col not in (group_keys or []):
                            result_row[col] = pd.NA
                    results.append(result_row)
                    continue

                # Enforce max_lag
                lag_threshold = left_row[left_time_col] - pd.Timedelta(days=max_lag_days)
                valid_subset = valid_subset[valid_subset[right_time_col_renamed] >= lag_threshold]

                if valid_subset.empty:
                    result_row = left_row.to_dict()
                    for col in right.columns:
                        if col not in (group_keys or []):
                            result_row[col] = pd.NA
                    results.append(result_row)
                else:
                    # Pick the last (most recent) valid row
                    nearest_row = valid_subset.iloc[-1]
                    result_row = {**left_row.to_dict(), **nearest_row.to_dict()}
                    results.append(result_row)
    else:
        # No grouping: global matching
        for _, left_row in left.iterrows():
            valid_mask = (right[right_time_col_renamed] <= left_row[left_time_col]) & \
                         (right[right_time_col_renamed] >= left_row[left_time_col] - pd.Timedelta(days=max_lag_days))
            valid_subset = right[valid_mask]
            if not valid_subset.empty:
                nearest_row = valid_subset.iloc[-1]
                result_row = {**left_row.to_dict(), **nearest_row.to_dict()}
            else:
                result_row = left_row.to_dict()
                for col in right.columns:
                    result_row[col] = pd.NA
            results.append(result_row)

    # Build result DataFrame
    result_df = pd.DataFrame(results)

    # Convert timestamp columns to ISO format strings
    for ts_col in [left_time_col, right_time_col_renamed]:
        if ts_col in result_df.columns:
            result_df[ts_col] = result_df[ts_col].apply(
                lambda x: x.isoformat() if pd.notnull(x) else ""
            )

    return result_df