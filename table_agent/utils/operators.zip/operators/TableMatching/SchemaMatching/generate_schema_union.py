def generate_schema_union(tables):
    """Generate unified schema from list of DataFrames."""
    all_cols = set()
    for df in tables:
        all_cols.update(df.columns)
    return sorted(all_cols)