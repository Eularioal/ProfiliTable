import pandas as pd
import re
from typing import Dict, Callable


def merge_tables_by_predefined_synonym_keys(
    left_df: pd.DataFrame,
    right_df: pd.DataFrame,
    synonym_map: Dict[str, str],
    missing_value_placeholder: str = '-',
) -> pd.DataFrame:
    """
    Merge two DataFrames using a predefined synonym mapping as join keys,
    with value standardization to handle formatting inconsistencies.

    Parameters:
    - left_df: Primary table (column names in output follow this schema).
    - right_df: Secondary table.
    - synonym_map: Dict {left_col: right_col} defining key correspondences.
    - missing_value_placeholder: Value to fill NaN (default: '-').
    - standardize_func: Optional custom function to normalize key values (e.g., for phone numbers, addresses).
                      If None, defaults to str.strip().str.lower() for object columns.

    Returns:
    - Merged DataFrame with standardized keys, outer join, and placeholder-filled missing values.
    """
    # Step 1: Rename right_df key columns to match left_df
    rename_map = {v: k for k, v in synonym_map.items()}
    right_renamed = right_df.rename(columns=rename_map)

    # Step 2: Identify key columns (from left_df perspective)
    key_columns = list(synonym_map.keys())

    # Step 3: Validate that all key columns exist
    missing_in_left = [col for col in key_columns if col not in left_df.columns]
    missing_in_right = [col for col in key_columns if col not in right_renamed.columns]
    if missing_in_left:
        raise ValueError(f"Key columns missing in left table: {missing_in_left}")
    if missing_in_right:
        raise ValueError(f"Key columns missing in right table after rename: {missing_in_right}")

    # Step 4: Standardize key column values in both tables
    left_clean = left_df.copy()
    right_clean = right_renamed.copy()

    # Step 5: Perform full outer join
    merged = pd.merge(
        left_clean,
        right_clean,
        on=key_columns,
        how='outer'
    )

    # Step 6: Fill missing values
    merged = merged.fillna(missing_value_placeholder)

    return merged