from typing import List, Dict, Any, Tuple
import copy

TYPE_PRIORITY = ["int", "float", "string"]

UNIT_CONVERSION = {
    ("cm", "m"): lambda x: x / 100,
    ("m", "cm"): lambda x: x * 100,
    ("kg", "g"): lambda x: x * 1000,
    ("g", "kg"): lambda x: x / 1000
}

def promote_type(type1: str, type2: str) -> str:
    """Promote two types to a common super type."""
    if type1 == type2:
        return type1
    return TYPE_PRIORITY[max(TYPE_PRIORITY.index(type1), TYPE_PRIORITY.index(type2))]


def resolve_schema_conflicts(
    table1: List[Dict[str, Any]],
    schema1: Dict[str, Dict[str, Any]],
    table2: List[Dict[str, Any]],
    schema2: Dict[str, Dict[str, Any]],
    annotate_conflicts: bool = True
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    Resolve schema conflicts when merging two tables with conflicting column definitions.
    Applies type promotion, unit conversion, or annotation.
    """

    merged_table = []
    conflict_report = {}

    common_columns = set(schema1.keys()) & set(schema2.keys())

    resolved_schema = copy.deepcopy(schema1)

    for col in common_columns:
        type1 = schema1[col].get("type")
        type2 = schema2[col].get("type")
        unit1 = schema1[col].get("unit")
        unit2 = schema2[col].get("unit")

        # case 1: same type and unit
        if type1 == type2 and unit1 == unit2:
            resolved_schema[col] = schema1[col]
            continue

        # case 2: type conflict → promote
        resolved_type = promote_type(type1, type2)

        # case 3: unit conflict → convert if possible
        conversion_key = (unit2, unit1)
        can_convert = conversion_key in UNIT_CONVERSION

        conflict_report[col] = {
            "type_conflict": (type1, type2),
            "unit_conflict": (unit1, unit2),
            "resolution": None
        }

        if can_convert:
            resolved_schema[col] = {
                "type": resolved_type,
                "unit": unit1
            }
            conflict_report[col]["resolution"] = "unit_conversion"

            for row in table2:
                val = row.get(col)
                if val is not None:
                    try:
                        row[col] = UNIT_CONVERSION[conversion_key](val)
                    except Exception:
                        pass

        else:
            if annotate_conflicts:
                new_col1 = f"{col}_source1"
                new_col2 = f"{col}_source2"

                for row in table1:
                    row[new_col1] = row.pop(col)

                for row in table2:
                    row[new_col2] = row.pop(col)

                conflict_report[col]["resolution"] = "annotation"
            else:
                resolved_schema[col] = {
                    "type": resolved_type,
                    "unit": unit1 or unit2
                }
                conflict_report[col]["resolution"] = "type_promotion"

    merged_table.extend(table1)
    merged_table.extend(table2)

    return merged_table, conflict_report
