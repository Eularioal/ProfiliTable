import pandas as pd

def infer_column_correspondence_by_type(df1, df2):
    """Propose column matches based on dtype compatibility."""
    mapping = {}
    numeric_types = {'int64', 'float64', 'int32', 'float32'}
    for c1 in df1.columns:
        t1 = df1[c1].dtype
        for c2 in df2.columns:
            t2 = df2[c2].dtype
            if t1 == t2:
                mapping[c1] = c2
                break
            elif t1 in numeric_types and t2 in numeric_types:
                mapping[c1] = c2
                break
    return mapping