import pandas as pd
from difflib import SequenceMatcher

def align_columns_by_name_similarity(df1, df2, threshold=0.6):
    """Return mapping of similar column names between two tables."""
    mapping = {}
    for c1 in df1.columns:
        best_score = 0
        best_c2 = None
        for c2 in df2.columns:
            score = SequenceMatcher(None, c1.lower(), c2.lower()).ratio()
            if score > best_score and score >= threshold:
                best_score = score
                best_c2 = c2
        if best_c2:
            mapping[c1] = best_c2
    return mapping