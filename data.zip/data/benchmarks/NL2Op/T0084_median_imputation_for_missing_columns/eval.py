#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
评测脚本 —— 检查选手是否对数值列按 *列中位数* 进行了缺失值填补

用法:
    python eval.py -o <candidate.csv>

输出:
    {"eval_score":"1.0"}   全部通过
    {"eval_score":"0.0"}   任何检查失败（原因写入 stderr）
"""

from __future__ import annotations
import argparse, json, sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT     = Path(__file__).resolve().parent
RAW_CSV  = ROOT / "raw" / "customers.csv"
GT_CSV   = ROOT / "expected" / "gt.csv"
ATOL     = 1e-6                 # 浮点误差容忍

# ────────── 工具 ──────────
def fail(msg: str, code: int = 1) -> None:
    print(f"[eval] {msg}", file=sys.stderr)
    print(json.dumps({"eval_score": "0.0"}))
    sys.exit(code)


def read_csv(path: Path, treat_na: bool = False) -> pd.DataFrame:
    na_vals = ["", "NA"] if treat_na else None
    return pd.read_csv(path, na_values=na_vals)  # keep_default_na=True


# ────────── 评测逻辑 ──────────
def evaluate(pred: pd.DataFrame,
             gt: pd.DataFrame,
             raw: pd.DataFrame) -> float:
    # 列集合、行数一致
    if pred.shape != gt.shape:
        fail(f"行列数不一致: 期望 {gt.shape} , 实际 {pred.shape}")
    if set(pred.columns) != set(gt.columns):
        miss  = set(gt.columns) - set(pred.columns)
        extra = set(pred.columns) - set(gt.columns)
        if miss:
            fail(f"缺少列: {', '.join(miss)}")
        if extra:
            fail(f"多余列: {', '.join(extra)}")
    pred = pred[gt.columns]  # 调整列顺序便于比较

    # 识别数值列
    num_cols = gt.select_dtypes(include=[np.number]).columns.tolist()
    if not num_cols:
        fail("未检测到数值列")

    # 1) 数值列校验
    for col in num_cols:
        if pred[col].isna().any():
            fail(f"列 {col} 仍包含缺失值")
        if not np.allclose(pred[col].astype(float).values,
                           gt[col].astype(float).values,
                           atol=ATOL, equal_nan=False):
            fail(f"列 {col} 不是使用中位数填补或误差超过 {ATOL}")

    # 2) 非数值列必须保持与原始数据一致
    cat_cols = [c for c in gt.columns if c not in num_cols]
    if not pred[cat_cols].astype(str).equals(raw[cat_cols].astype(str)):
        fail("非数值列与原始数据不一致")

    return 1.0


# ────────── CLI ──────────
def main() -> None:
    ap = argparse.ArgumentParser(description="Evaluate median-imputation operator")
    ap.add_argument("-o", "--output", required=True, help="candidate CSV file")
    args = ap.parse_args()

    cand_path = Path(args.output)
    if not cand_path.exists():
        fail(f"文件不存在: {cand_path}")

    try:
        raw = read_csv(RAW_CSV, treat_na=True)
        gt  = read_csv(GT_CSV)
        cand = read_csv(cand_path)
    except Exception as exc:
        fail(f"读取 CSV 失败: {exc}")

    score = evaluate(cand, gt, raw)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        fail(f"评测异常: {exc}", code=2)