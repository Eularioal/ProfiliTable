#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成两份 CSV：
1. raw/customers.csv       —— 含缺失("" / "NA") 的数据
2. expected/gt.csv         —— 数值列已按列中位数填补
"""

from pathlib import Path
import random
import numpy as np
import pandas as pd

# ───────── 可配置参数 ─────────
N_ROWS         = 180
NUMERIC_COLS   = ["age", "income", "credit_score"]
CATEGORIC_COLS = ["gender", "region"]
NA_RATIO       = 0.1             # 每个数值列缺失比例

RAW_DIR = Path("raw")
EXP_DIR = Path("expected")
RAW_CSV = RAW_DIR / "customers.csv"
GT_CSV  = EXP_DIR / "gt.csv"
# ────────────────────────────

random.seed(42)
np.random.seed(42)


def build_dataframe() -> pd.DataFrame:
    """构造带缺失值的 DataFrame"""
    df = pd.DataFrame({
        "age":          np.random.randint(18, 70,  size=N_ROWS),
        "income":       np.round(np.random.normal(7.5e4, 1.8e4, N_ROWS), 2),
        "credit_score": np.round(np.random.uniform(250, 850, N_ROWS), 1),
        "gender":       np.random.choice(["M", "F"],           N_ROWS),
        "region":       np.random.choice(["North", "South",
                                          "East", "West"],    N_ROWS),
    })

    # 向数值列注入缺失("" / "NA" 混用)
    for col in NUMERIC_COLS:
        df[col] = df[col].astype(object)           # 允许写入字符串
        miss_idx = np.random.choice(N_ROWS,
                                    size=int(N_ROWS * NA_RATIO),
                                    replace=False)
        for i in miss_idx:
            df.at[i, col] = random.choice(["", "NA"])
    return df


def main() -> None:
    RAW_DIR.mkdir(exist_ok=True)
    EXP_DIR.mkdir(exist_ok=True)

    df_raw = build_dataframe()
    df_raw.to_csv(RAW_CSV, index=False, encoding="utf-8")

    # 计算中位数并填补
    df_gt = df_raw.replace({"": np.nan, "NA": np.nan})
    for col in NUMERIC_COLS:
        median_val = df_gt[col].astype(float).median()
        df_gt[col] = df_gt[col].astype(float).fillna(median_val)

    df_gt.to_csv(GT_CSV, index=False, encoding="utf-8", float_format="%.6f")
    print("✓ 数据已生成：")
    print(f"  RAW -> {RAW_CSV.resolve()}")
    print(f"  GT  -> {GT_CSV.resolve()}")


if __name__ == "__main__":
    main()