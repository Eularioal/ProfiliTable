import csv
import random
import re
from pathlib import Path
import json
from datetime import datetime, timedelta

def random_date(start, end):
    delta = end - start
    random_days = random.randint(0, delta.days)
    return (start + timedelta(days=random_days)).strftime("%Y-%m-%d")

def valid_seat():
    # 1 uppercase letter + 1-3 digits
    letter = chr(random.randint(ord('A'), ord('Z')))
    number = str(random.randint(1, 999))
    return f"{letter}{number}"

def invalid_seat():
    # Generate some invalid formats, e.g. missing letter, lowercase letter, symbols, spaces
    options = [
        lambda: str(random.randint(1, 999)),           # just numbers
        lambda: chr(random.randint(ord('a'), ord('z'))) + str(random.randint(1, 999)), # lowercase letter + number
        lambda: chr(random.randint(ord('A'), ord('Z'))) + "-" + str(random.randint(1, 999)), # letter-number with dash
        lambda: chr(random.randint(ord('A'), ord('Z'))) + " " + str(random.randint(1, 999)), # letter space number
        lambda: "Seat" + str(random.randint(1, 50)),   # word prefix
        lambda: "",                                    # empty string
        lambda: chr(random.randint(33, 47)) + str(random.randint(1, 999)), # symbol + number
    ]
    return random.choice(options)()

def gen_all_data(num=100):
    data = []
    base_start = datetime(2023, 1, 1)
    base_end = datetime(2025, 12, 31)
    for i in range(1, num + 1):
        event_date = random_date(base_start, base_end)
        # 80% dirty with invalid seat_number
        if random.random() < 0.8:
            seat = invalid_seat()
        else:
            seat = valid_seat()

        data.append({
            "id": str(i),
            "ticket_id": f"T{i:06d}",
            "event_name": f"Event_{random.randint(1, 50)}",
            "event_date": event_date,
            "seat_number": seat
        })
    return data

def filter_gt(data, gt_num=20):
    # 筛选出seat_number符合格式的记录
    pattern = re.compile(r"^[A-Z]\d+$")
    filtered = [rec for rec in data if pattern.match(rec["seat_number"])]
    return filtered[:gt_num]

def save_jsonl(data, path):
    with open(path, "w", encoding="utf-8") as f:
        for rec in data:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

def save_csv(data, path):
    keys = data[0].keys()
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(data)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--task_id", type=str, required=True)
    parser.add_argument("--format", choices=["jsonl", "csv"], default="jsonl")
    args = parser.parse_args()

    task_dir = Path(f"data/benchmarks/NL2Op/{args.task_id}_")
    expected_dir = task_dir / "expected"
    raw_dir = task_dir / "raw"
    expected_dir.mkdir(parents=True, exist_ok=True)
    raw_dir.mkdir(parents=True, exist_ok=True)

    all_data = gen_all_data(num=100)
    gt_data = filter_gt(all_data, gt_num=20)

    if args.format == "jsonl":
        save_jsonl(gt_data, expected_dir / "gt.jsonl")
        save_jsonl(all_data, raw_dir / "customers.jsonl")
    else:
        save_csv(gt_data, expected_dir / "gt.csv")
        save_csv(all_data, raw_dir / "customers.csv")

    print(f"生成完成：脏数据共100条，符合要求的GT数据20条")

    # 可选调用大模型示例：
    # from utils.llm_serving import LLMServing
    # llm = LLMServing()
    # user_inputs = [f"Write a short formal sentence about {rec['event_name']}" for rec in gt_data]
    # system_prompt = "You are an AI that writes formal English."
    # results = llm.generate_from_input(user_inputs, system_prompt)
