import os
import json
import random

TASK_ID = "T0026"  # 替换为具体 Task_id
BASE_DIR = f"data/benchmarks/NL2Op/{TASK_ID}_"
GT_PATH = os.path.join(BASE_DIR, "expected", "gt.jsonl")
RAW_PATH = os.path.join(BASE_DIR, "raw", "customers.jsonl")

os.makedirs(os.path.dirname(GT_PATH), exist_ok=True)
os.makedirs(os.path.dirname(RAW_PATH), exist_ok=True)

def random_height(valid_cm=True):
    """
    valid_cm=True -> 身高以厘米存储 (>= 3)
    valid_cm=False -> 身高以米存储 (< 3)
    """
    if valid_cm:
        return round(random.uniform(140, 200), 1)  # 正常厘米值
    else:
        return round(random.uniform(1.40, 1.99), 2)  # 正常米值

def random_weight():
    return round(random.uniform(40, 120), 1)

def generate_raw_and_gt(total=100, dirty_count=80):
    raw_data = []
    gt_data = []

    dirty_indices = set(random.sample(range(total), dirty_count))

    for i in range(total):
        if i in dirty_indices:
            # Raw 用米，GT 转换成厘米
            height_m = random_height(valid_cm=False)
            height_cm_fixed = round(height_m * 100, 1)
            raw_data.append({
                "id": i+1,
                "patient_id": f"P{i+1:05d}",
                "height_cm": height_m,
                "weight_kg": random_weight()
            })
            gt_data.append({
                "id": i+1,
                "patient_id": f"P{i+1:05d}",
                "height_cm": height_cm_fixed,
                "weight_kg": raw_data[-1]["weight_kg"]
            })
        else:
            # Raw 和 GT 一致
            height_cm = random_height(valid_cm=True)
            raw_data.append({
                "id": i+1,
                "patient_id": f"P{i+1:05d}",
                "height_cm": height_cm,
                "weight_kg": random_weight()
            })
            gt_data.append(raw_data[-1].copy())

    return raw_data, gt_data

def save_jsonl(path, data):
    with open(path, "w", encoding="utf-8") as f:
        for row in data:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

if __name__ == "__main__":
    raw_data, gt_data = generate_raw_and_gt(total=100, dirty_count=80)

    save_jsonl(RAW_PATH, raw_data)
    save_jsonl(GT_PATH, gt_data)

    print(f"Raw data saved to {RAW_PATH}")
    print(f"GT data saved to {GT_PATH}")
