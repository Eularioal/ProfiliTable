import json
from pathlib import Path
import argparse

def load_jsonl(path):
    """加载 jsonl 文件，返回 id -> record 的映射"""
    data = {}
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            record = json.loads(line)
            data[str(record['id'])] = record
    return data

def height_equal(h1, h2):
    """判断 height_cm 数值是否相等（不比较小数点后精度差异）"""
    try:
        return float(h1) == float(h2)
    except (ValueError, TypeError):
        return False

def evaluate(expected_path, processed_path, show_diff=5):
    expected = load_jsonl(expected_path)
    processed = load_jsonl(processed_path)

    total = len(expected)
    matched = 0
    mismatches = []

    for id_, exp_record in expected.items():
        proc_record = processed.get(id_)
        if proc_record is None:
            mismatches.append((id_, "missing", exp_record, None))
            continue

        # 先比较 height_cm
        if not height_equal(exp_record["height_cm"], proc_record["height_cm"]):
            mismatches.append((id_, "height_mismatch", exp_record, proc_record))
            continue

        # 再比较其他字段
        other_fields_match = True
        for key in exp_record:
            if key != "height_cm" and exp_record[key] != proc_record.get(key):
                other_fields_match = False
                break

        if other_fields_match:
            matched += 1
        else:
            mismatches.append((id_, "field_mismatch", exp_record, proc_record))

    accuracy = matched / total if total > 0 else 0.0

    print({"eval_score": f"{accuracy:.4f}"})

    # if show_diff > 0 and mismatches:
    #     print("\nSample mismatches:")
    #     for m in mismatches[:show_diff]:
    #         print(m)

def get_gt():
    """自动找到 expected 目录下的第一个 .jsonl 作为 GT"""
    current_dir = Path(__file__).resolve().parent
    expected_dir = (current_dir / "./expected").resolve()
    jsonl_files = list(expected_dir.glob("*.jsonl"))
    if not jsonl_files:
        raise FileNotFoundError(f"No .jsonl file found in {expected_dir}")
    return jsonl_files[0]

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate height_cm normalization task")
    parser.add_argument(
        "-o", "--output",
        required=True,
        help="Path to the processed jsonl produced by your operator",
    )
    args = parser.parse_args()
    expected_path = get_gt()
    evaluate(expected_path, args.output)
