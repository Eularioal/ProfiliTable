import os
import csv
import random
from pathlib import Path

TASK_ID = "T0028"
BASE_DIR = Path(f"data/benchmarks/NL2Op/{TASK_ID}_")
GT_PATH = BASE_DIR / "expected" / "gt.csv"
RAW_PATH = BASE_DIR / "raw" / "customers.csv"

NUM_TOTAL = 100
NUM_GOOD = 20  # 合法记录数
NUM_DIRTY = NUM_TOTAL - NUM_GOOD  # 脏数据数

def gen_location_name(i):
    return f"Location_{i}"

def gen_valid_latitude():
    return round(random.uniform(-90, 90), 6)

def gen_valid_longitude():
    return round(random.uniform(-180, 180), 6)

def gen_invalid_latitude():
    return round(random.choice([random.uniform(-180, -91), random.uniform(91, 180)]), 6)

def gen_invalid_longitude():
    return round(random.choice([random.uniform(-360, -181), random.uniform(181, 360)]), 6)

def generate_good_data(start_id, count):
    rows = []
    for i in range(start_id, start_id + count):
        rows.append({
            "id": i,
            "location_id": f"L{i:05d}",
            "latitude": gen_valid_latitude(),
            "longitude": gen_valid_longitude(),
            "location_name": gen_location_name(i)
        })
    return rows

def generate_dirty_data(start_id, count):
    rows = []
    for i in range(start_id, start_id + count):
        lat = gen_valid_latitude()
        lon = gen_valid_longitude()
        # 至少一项是非法的
        corrupt_lat = random.choice([True, False])
        corrupt_lon = not corrupt_lat or random.choice([True, False])  # 至少一项保证非法

        if corrupt_lat:
            lat = gen_invalid_latitude()
        if corrupt_lon:
            lon = gen_invalid_longitude()

        rows.append({
            "id": i,
            "location_id": f"L{i:05d}",
            "latitude": lat,
            "longitude": lon,
            "location_name": gen_location_name(i)
        })
    return rows

def save_csv(data, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["id", "location_id", "latitude", "longitude", "location_name"]
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in data:
            writer.writerow(row)

if __name__ == "__main__":
    good_data = generate_good_data(1, NUM_GOOD)      # 20条合法
    dirty_data = generate_dirty_data(NUM_GOOD+1, NUM_DIRTY)  # 80条脏数据

    raw_data = good_data + dirty_data
    random.shuffle(raw_data)  # 打乱顺序

    save_csv(good_data, GT_PATH)    # GT只保留合法数据20条
    save_csv(raw_data, RAW_PATH)    # Raw包括100条全部数据

    print(f"✅ GT数据（20条）保存到: {GT_PATH}")
    print(f"✅ Raw数据（100条）保存到: {RAW_PATH}")
