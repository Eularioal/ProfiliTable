#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py — “按列取值拆分”算子 · 测试数据生成
────────────────────────────────────────────
生成目录结构
.
├── raw/
│   └── customers.csv              # 算子输入
└── expected/
    ├── gt_cn.csv                  # country == CN
    ├── gt_us.csv                  # country == US
    ├── gt_de.csv                  # country == DE
    └── gt_other.csv               # 其他或空值
"""

from __future__ import annotations
import csv
import random
import re
from pathlib import Path
from typing import Dict, List

from faker import Faker

# ────────────────────────── 可调参数 ──────────────────────────
TOTAL_ROWS   = 150
RANDOM_SEED  = 2025

SPLIT_COL    = "country"          # 按此列拆分
TARGET_VALUES = ["CN", "US", "DE"]  # 已知取值集合（大小写敏感）

PREFIX = "gt"                     # 输出文件名前缀

# ────────────────────────── 路径 ──────────────────────────
ROOT_DIR     = Path(__file__).resolve().parent
RAW_DIR      = ROOT_DIR / "raw"
EXPECTED_DIR = ROOT_DIR / "expected"
RAW_DIR.mkdir(exist_ok=True)
EXPECTED_DIR.mkdir(exist_ok=True)

RAW_PATH      = RAW_DIR / "customers.csv"
OUT_PATHS: Dict[str, Path] = {
    val: EXPECTED_DIR / f"{PREFIX}_{re.sub(r'[^0-9a-zA-Z]+', '_', val.lower())}.csv"
    for val in TARGET_VALUES
}
OUT_PATHS["other"] = EXPECTED_DIR / f"{PREFIX}_other.csv"

# ────────────────────────── Faker ──────────────────────────
random.seed(RANDOM_SEED)
fake = Faker()
Faker.seed(RANDOM_SEED)

HEADER = ["customer_id", "name", "country", "business_line", "balance"]

# ─────────────────────── 生成原始 customers.csv ───────────────────────
rows: List[List[str]] = []

forced_values = TARGET_VALUES + ["", "UK"]          # 包含空值 & 未知值确保覆盖

for cid in range(1, TOTAL_ROWS + 1):
    name  = fake.name()
    if cid <= len(forced_values):
        country = forced_values[cid - 1]
    else:
        country = random.choice(TARGET_VALUES + ["UK", "FR", ""])  # 部分未知
    biz   = random.choice(["Retail", "Global-Trading", "Finance"])
    bal   = str(random.randint(0, 20_000))
    rows.append([str(cid), name, country, biz, bal])

with RAW_PATH.open("w", newline="", encoding="utf-8") as f_raw:
    w = csv.writer(f_raw)
    w.writerow(HEADER)
    w.writerows(rows)

# ───────────────────────── 拆分逻辑（生成 GT） ─────────────────────────
slug = lambda s: re.sub(r"[^0-9a-zA-Z]+", "_", s.lower())

# 预先开  N+1  个 list 保存行
partitions: Dict[str, List[List[str]]] = {v: [] for v in TARGET_VALUES}
partitions["other"] = []

col_idx = HEADER.index(SPLIT_COL)

for row in rows:            # 保持顺序
    key = row[col_idx]
    if key in TARGET_VALUES:
        partitions[key].append(row)
    else:
        partitions["other"].append(row)

# 写出 expected/*.csv
for key, part_rows in partitions.items():
    out_path = OUT_PATHS[key]
    with out_path.open("w", newline="", encoding="utf-8") as f_out:
        w = csv.writer(f_out)
        w.writerow(HEADER)
        w.writerows(part_rows)

# ─────────────────────────────── 日志 ───────────────────────────────
msg = ["✅ 数据生成完毕", f"• {RAW_PATH.relative_to(ROOT_DIR)} ({len(rows)} 行)"]
for key, part_rows in partitions.items():
    msg.append(f"• {OUT_PATHS[key].relative_to(ROOT_DIR)} ({len(part_rows)} 行)")
print("\n".join(msg))