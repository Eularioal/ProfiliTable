#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― “按列取值拆分”算子 · Evaluation  (multi-output, dir-or-file version)
=============================================================================

与上一版相比
------------
1. 每个 `-o / --output` 参数 **既可以是目录，也可以是单个 `.csv` 文件**；
   目录内部仍按字典序读取所有 `.csv`。
2. 其它评测逻辑保持不变：
   * split_col = country
   * 目标取值 CN、US、DE，其余/空值 → other
   * 行顺序敏感，表头必须完全一致；全部正确得分 1.0
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Dict, Iterable, List

# ────────────────────────── 常量配置 ──────────────────────────
SPLIT_COL      = "country"
TARGET_VALUES  = ["CN", "US", "DE"]
PART_KEYS      = TARGET_VALUES + ["other"]          # GT与预测比对次序
ROOT_DIR       = Path(__file__).resolve().parent
EXPECTED_DIR   = ROOT_DIR / "expected"
EXPECTED_FILES = {
    "CN":    EXPECTED_DIR / "gt_cn.csv",
    "US":    EXPECTED_DIR / "gt_us.csv",
    "DE":    EXPECTED_DIR / "gt_de.csv",
    "other": EXPECTED_DIR / "gt_other.csv",
}

# ────────────────────────── 工具函数 ──────────────────────────
def load_csv_rows(path: Path) -> List[List[str]]:
    """把 CSV 读成二维列表（含表头）"""
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.reader(f))


def part_key(val: str) -> str:
    """根据 country 值决定落在哪个分区"""
    return val if val in TARGET_VALUES else "other"


def iter_csv_paths(specs: Iterable[Path]) -> Iterable[Path]:
    """
    接收多个路径（目录 / 文件），按传入顺序产出应读取的 CSV 文件。

    规则：
    1. 路径是目录 → 按字母序遍历该目录下所有 `.csv`
    2. 路径是文件 → 若后缀为 `.csv`，直接产出；否则忽略
    """
    for item in specs:
        if item.is_dir():
            # 目录：字母序
            for csv_path in sorted(item.glob("*.csv")):
                yield csv_path
        elif item.is_file():
            # 单文件：确保是 csv
            if item.suffix.lower() == ".csv":
                yield item
        # 其他情况（不存在/非法）在参数检查阶段已禁止


def harvest_partitions(outputs: List[Path],
                       header_ref: List[str]) -> Dict[str, List[List[str]]]:
    """遍历若干目录/文件，把行聚合到各分区"""
    parts: Dict[str, List[List[str]]] = {k: [] for k in PART_KEYS}
    csv_found = False

    for csv_path in iter_csv_paths(outputs):
        csv_found = True
        rows = load_csv_rows(csv_path)
        if not rows:
            continue
        header, body = rows[0], rows[1:]

        if header != header_ref:
            raise ValueError(f"{csv_path} 表头与期望不符")

        idx = header.index(SPLIT_COL)
        for r in body:
            parts[part_key(r[idx])].append(r)

    if not csv_found:
        raise ValueError("未找到任何 CSV 文件")

    return parts

# ──────────────────────────── 评测逻辑 ────────────────────────────
def evaluate(output_specs: List[Path]) -> float:
    # 读取基准
    gt_parts: Dict[str, List[List[str]]] = {}
    header_ref: List[str] | None = None
    for k in PART_KEYS:
        rows = load_csv_rows(EXPECTED_FILES[k])
        if header_ref is None:
            header_ref = rows[0]
        gt_parts[k] = rows[1:]
    assert header_ref is not None, "GT 缺失"

    # 读取预测
    try:
        pred_parts = harvest_partitions(output_specs, header_ref)
    except Exception as exc:
        print(f"[eval] 输出解析失败: {exc}", file=sys.stderr)
        return 0.0

    # 比对
    for k in PART_KEYS:
        if pred_parts[k] != gt_parts[k]:
            return 0.0
    return 1.0

# ─────────────────────────────── CLI ───────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(
        description="Evaluate split-by-value CSV operator "
                    "(accepts multiple -o, each can be directory or CSV file)"
    )
    parser.add_argument(
        "-o", "--output", required=True, action="append",
        help="Directory **or single CSV file** produced by operator (can specify multiple)"
    )
    args = parser.parse_args()

    out_specs = [Path(p) for p in args.output]

    # 参数合法性检查：路径必须存在且为目录或文件
    if any(not sp.exists() or not (sp.is_dir() or sp.is_file()) for sp in out_specs):
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)

    score = evaluate(out_specs)
    print(json.dumps({"eval_score": f"{score:.1f}"}))

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"[eval] 评测异常: {e}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)