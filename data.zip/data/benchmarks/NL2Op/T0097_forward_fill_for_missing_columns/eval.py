#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eval.py
=======

校验选手是否正确对指定列做分组 forward-fill

用法:
    python eval.py -o <candidate.csv>

通过: {"eval_score":"1.0"}
失败: {"eval_score":"0.0"} 并输出原因到 stderr
"""

from __future__ import annotations
import argparse, json, sys
from pathlib import Path

import numpy as np
import pandas as pd

# ───── 配置 (必须与 gen_data.py 保持一致) ─────
ROOT       = Path(__file__).resolve().parent
RAW_CSV    = ROOT / "raw" / "customers.csv"
GT_CSV     = ROOT / "expected" / "gt.csv"
GROUP_COL  = "device_id"
TIME_COL   = "event_time"
FILL_COLS  = ["temperature"]
ATOL       = 1e-8          # 数值误差容忍
# ───────────────────────────────────────────

def fail(msg: str, code: int = 1) -> None:
    print(f"[eval] {msg}", file=sys.stderr)
    print(json.dumps({"eval_score": "0.0"}))
    sys.exit(code)


def read(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, na_values=["", "NA"])


def evaluate(cand: pd.DataFrame,
             gt:   pd.DataFrame,
             raw:  pd.DataFrame) -> float:
    # 1) 行列/顺序
    if cand.shape != gt.shape:
        fail(f"行列数不一致: 期望 {gt.shape}, 实际 {cand.shape}")
    if list(cand.columns) != list(gt.columns):
        fail("列名或顺序与基准不一致")

    # 2) 指定填充列: 不得有遗漏且结果 = gt
    for col in FILL_COLS:
        if cand[col].isna().any():
            fail(f"{col} 仍存在缺失值(应已 ffill)")
        diff = np.abs(cand[col].astype(float) - gt[col].astype(float))
        if (diff > ATOL).any():
            fail(f"{col} 与基准 forward-fill 结果不一致")

    # 3) 其它列不得被修改
    other_cols = [c for c in cand.columns if c not in FILL_COLS]
    if not cand[other_cols].equals(raw[other_cols]):
        fail("非填充列被修改")

    return 1.0


def main() -> None:
    ap = argparse.ArgumentParser(description="Evaluate group forward-fill operator")
    ap.add_argument("-o", "--output", required=True, help="candidate CSV file")
    args = ap.parse_args()

    cand_path = Path(args.output)
    if not cand_path.exists():
        fail(f"文件不存在: {cand_path}")

    try:
        raw = read(RAW_CSV)
        gt  = read(GT_CSV)
        cand = read(cand_path)
    except Exception as exc:
        fail(f"读取 CSV 失败: {exc}")

    score = evaluate(cand, gt, raw)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        fail(f"评测脚本异常: {exc}", code=2)