#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py
===========

1. 生成 raw/devices.csv（含缺失）
2. 对指定列按 device_id 分组做 forward-fill，写 expected/gt.csv

依赖: pandas>=1.3, numpy
编码: UTF-8 无 BOM
"""

from pathlib import Path
import numpy as np
import pandas as pd

# ────────────── 可调参数 ──────────────
RAW_PATH = Path("raw/customers.csv")
GT_PATH  = Path("expected/gt.csv")

N_DEVICE  = 3           # 分组数量
N_RECORDS = 8           # 每个设备的记录条数
START_DT  = "2025-01-01"
TIME_COL  = "event_time"
GROUP_COL = "device_id"
FILL_COLS = ["temperature"]      # 需要 ffill 的列
RAND_SEED = 2025
MISS_RATE = 0.25                 # 缺失占比
# ────────────────────────────────────

rng = np.random.default_rng(RAND_SEED)


def make_raw() -> pd.DataFrame:
    """生成带缺失的原始数据"""
    records = []
    for d in range(1, N_DEVICE + 1):
        times = pd.date_range(START_DT, periods=N_RECORDS, freq="D")
        temp  = rng.normal(25, 3, size=N_RECORDS)
        df_d  = pd.DataFrame(
            {GROUP_COL: d, TIME_COL: times, "temperature": temp}
        )
        records.append(df_d)
    df = pd.concat(records, ignore_index=True)

    # 打乱行顺序 & 制造缺失
    df = df.sample(frac=1.0, random_state=RAND_SEED).reset_index(drop=True)
    miss_mask = rng.random(df.shape[0]) < MISS_RATE
    df.loc[miss_mask, "temperature"] = np.nan
    return df


def forward_fill(df: pd.DataFrame) -> pd.DataFrame:
    """同一 device_id 内，按时间排序后 forward-fill 指定列"""
    df_sorted = df.sort_values([GROUP_COL, TIME_COL]).copy()
    df_sorted[FILL_COLS] = (
        df_sorted.groupby(GROUP_COL)[FILL_COLS].ffill()
    )
    # 恢复乱序行索引，保持与 raw 完全对齐
    return df_sorted.loc[df.index].reset_index(drop=True)


def write(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8")   # 默认无 BOM


def main() -> None:
    raw_df = make_raw()
    write(raw_df, RAW_PATH)
    print(f"✅ raw 已生成: {RAW_PATH}")

    gt_df = forward_fill(raw_df)
    write(gt_df, GT_PATH)
    print(f"✅ forward-fill 结果写出: {GT_PATH}")


if __name__ == "__main__":
    main()