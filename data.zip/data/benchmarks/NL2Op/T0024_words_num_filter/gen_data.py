import json
import random
from pathlib import Path
from utils.llm_serving import LLMServing
import uuid

Task_id = "T0012"
base_dir = Path(f"data/benchmarks/NL2Op/{Task_id}_")
gt_path = base_dir / "expected/gt.jsonl"
raw_path = base_dir / "raw/customers.jsonl"

base_dir.mkdir(parents=True, exist_ok=True)
(gt_path.parent).mkdir(parents=True, exist_ok=True)
(raw_path.parent).mkdir(parents=True, exist_ok=True)

llm = LLMServing()

def count_words(text):
    return len(text.strip().split())

def generate_gt_sentences(topics, per_topic=1, min_words=20, max_words=100):
    user_inputs = [
        f"Write a short formal sentence about {topic} without using contractions."
        for topic in topics for _ in range(per_topic)
    ]
    system_prompt = "You are an AI that writes formal English without contractions."
    generated = llm.generate_from_input(user_inputs, system_prompt)
    results = []
    for txt in generated:
        words = txt.strip().split()
        if len(words) < min_words:
            repeat_times = (min_words // len(words)) + 1
            txt = " ".join(words * repeat_times)
            txt = " ".join(txt.strip().split()[:max_words])
        elif len(words) > max_words:
            txt = " ".join(words[:max_words])
        results.append(txt)
    return results

def write_jsonl(path, records):
    with path.open("w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

def build_gt(num_sentences=20):
    topics = [
        "artificial intelligence", "environment", "education", "technology",
        "healthcare", "sports", "finance", "travel", "history", "music"
    ]
    per_topic = max(1, num_sentences // len(topics))
    sentences = generate_gt_sentences(topics, per_topic=per_topic, min_words=20, max_words=100)
    # Cut to exact num_sentences if over-generated
    sentences = sentences[:num_sentences]
    gt_records = [{"id": str(uuid.uuid4()), "text": s} for s in sentences]
    write_jsonl(gt_path, gt_records)
    print(f"GT data generated: {len(gt_records)} records at {gt_path}")
    return gt_records

def introduce_dirty_data(gt_records, num_dirty=80):
    dirty_samples = []
    short_texts = [
        "Hi.", "Ok.", "Yes.", "No.", "Thanks.", "Sure.", "Wow!", "Hello!",
        "Good.", "Bye."
    ]
    long_text = " ".join(["word"] * 150)

    for _ in range(num_dirty):
        choice = random.choice(["short", "long", "empty"])
        if choice == "short":
            text = random.choice(short_texts)
        elif choice == "long":
            text = long_text
        else:
            text = " " * random.randint(0, 10)
        dirty_samples.append({"id": str(uuid.uuid4()), "text": text})

    mixed = gt_records + dirty_samples
    random.shuffle(mixed)
    write_jsonl(raw_path, mixed)
    print(f"Raw data with dirty samples generated: {len(mixed)} records at {raw_path}")

def main():
    gt_records = build_gt(num_sentences=20)
    introduce_dirty_data(gt_records, num_dirty=80)

if __name__ == "__main__":
    main()
