#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py  ―  同义字段映射去重 · 数据生成器
---------------------------------------------------------------
1. 同义列映射
   phone ← mobile, tel         （优先级 phone > mobile > tel）
   email ← e_mail, mail        （优先级 email > e_mail > mail）

2. 去重规则
   a. 先按优先级将同义列合并为统一字段 phone / email
   b. 以 (user, phone, email) 完全匹配划分重复组
   c. 每组保留 order_id 最小的一条

3. 数据规模
   NUM_GT      : 去重后应剩多少条（≥100）
   DUPS_PER_GT : 为每条 GT 生成多少条“脏”副本 (raw 会包含 1+N 倍)
"""

from pathlib import Path
import csv
import json
import random

# ─────────── 可以按需修改下面两个数字 ────────────
NUM_GT = 120      # ➜ 最终 GT 行数
DUPS_PER_GT = 3   # ➜ 每条 GT 额外生成几条脏数据
# ────────────────────────────────────────────────

random.seed(2024)

BASE_DIR = Path(__file__).resolve().parent
RAW_DIR = BASE_DIR / "raw"
EXP_DIR = BASE_DIR / "expected"
RAW_DIR.mkdir(parents=True, exist_ok=True)
EXP_DIR.mkdir(parents=True, exist_ok=True)

# ─────────────────────────────── 1. 生成 GT ───────────────────────────────
gt_records = []
for i in range(1, NUM_GT + 1):
    order_id = 1000 + i         # 最小的 id，保证保留
    user     = f"user{i:04d}"
    phone    = f"13{i:09d}"[-11:]   # 始终 11 位
    email    = f"{user}@example.com"
    gt_records.append(
        {
            "order_id": order_id,
            "user": user,
            "phone": phone,
            "email": email,
        }
    )

# ─────────────────────────────── 2. 生成 raw ──────────────────────────────
raw_records = []

def blank_row() -> dict[str, str]:
    return {
        "order_id": "",
        "user": "",
        "phone": "",
        "mobile": "",
        "tel": "",
        "email": "",
        "e_mail": "",
        "mail": "",
    }

dup_order_auto = 200000  # 从 200000 开始给脏数据分配递增 id

for rec in gt_records:
    # ① 原始“干净”行
    clean = blank_row()
    clean.update(
        {
            "order_id": rec["order_id"],
            "user": rec["user"],
            "phone": rec["phone"],
            "email": rec["email"],
        }
    )
    raw_records.append(clean)

    # ② 脏副本
    for _ in range(DUPS_PER_GT):
        dup = blank_row()
        dup["order_id"] = dup_order_auto
        dup_order_auto += 1

        dup["user"] = rec["user"]

        # phone family
        phone_slot = random.choice(["phone", "mobile", "tel"])
        dup[phone_slot] = rec["phone"]
        if random.random() < 0.25:                               # 25% 再写入另一个槽
            other_slot = random.choice([c for c in ["phone", "mobile", "tel"] if c != phone_slot])
            dup[other_slot] = rec["phone"]

        # email family
        email_slot = random.choice(["email", "e_mail", "mail"])
        dup[email_slot] = rec["email"]
        if random.random() < 0.25:
            other_slot = random.choice([c for c in ["email", "e_mail", "mail"] if c != email_slot])
            dup[other_slot] = rec["email"]

        # 10% 概率把电话或邮箱留空，制造缺失值场景
        if random.random() < 0.10:
            dup[random.choice(["phone", "mobile", "tel"])] = ""
        if random.random() < 0.10:
            dup[random.choice(["email", "e_mail", "mail"])] = ""

        raw_records.append(dup)

# ─────────────────────────────── 3. 写 raw 文件 ───────────────────────────
csv_headers = [
    "order_id",
    "user",
    "phone",
    "mobile",
    "tel",
    "email",
    "e_mail",
    "mail",
]

raw_csv = RAW_DIR / "customers.csv"
raw_jsonl = RAW_DIR / "customers.jsonl"

with raw_csv.open("w", encoding="utf-8", newline="") as cf, \
     raw_jsonl.open("w", encoding="utf-8") as jf:
    writer = csv.DictWriter(cf, fieldnames=csv_headers)
    writer.writeheader()
    for row in raw_records:
        writer.writerow(row)
        json.dump(row, jf, ensure_ascii=False)
        jf.write("\n")

# ─────────────────────────── 4. 写 expected / GT 文件 ─────────────────────
gt_csv = EXP_DIR / "gt.csv"
gt_jsonl = EXP_DIR / "gt.jsonl"

with gt_csv.open("w", encoding="utf-8", newline="") as cf, \
     gt_jsonl.open("w", encoding="utf-8") as jf:
    csv_writer = csv.writer(cf)
    csv_writer.writerow(["order_id", "user", "phone", "email"])
    for rec in gt_records:
        csv_writer.writerow([rec["order_id"], rec["user"], rec["phone"], rec["email"]])
        json.dump(rec, jf, ensure_ascii=False)
        jf.write("\n")

# ─────────────────────────────── 5. 完成提示 ──────────────────────────────
print(f"✅ 数据生成完毕：GT {len(gt_records)} 行，RAW {len(raw_records)} 行")