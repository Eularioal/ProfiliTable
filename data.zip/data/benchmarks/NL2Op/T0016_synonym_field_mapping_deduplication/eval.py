#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测“同义字段映射去重算子”

评测目标
--------
算子应输出去重后的订单列表（CSV / JSONL 均可），每行至少包含：
    • order_id  记录主键
    • user
    • phone / mobile / tel      (任意其一或多列)
    • email / e_mail / mail     (任意其一或多列)

算子需完成：
    1. 将同义列映射为统一字段：
         phone ← mobile ← tel     （取非空优先级从左到右）
         email ← e_mail ← mail    （取非空优先级从左到右）
    2. 以 (user, phone, email) 完全匹配去重
    3. 每个重复组保留 **order_id 最小** 的那条

评测标准
--------
黄金标准固定为 expected/gt.jsonl
行级 F1 计算  
    · TP：三元组 (user, phone, email) 与 GT 完全一致，且 order_id 与 GT 相等  
    · 重复行 / 额外三元组 / 字段值错误 → FP  
    · 缺失任何应输出三元组         → FN
终端仅打印一行 JSON： {"eval_score": "<score>"}

用法
----
python eval.py -o /path/to/your_output.jsonl     # 或 .csv
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple

# ────────────────────────── 常量 ──────────────────────────
GT_PATH = Path(__file__).parent / "expected" / "gt.csv"
PHONE_COLS = ["phone", "mobile", "tel"]
EMAIL_COLS = ["email", "e_mail", "mail"]


# ─────────────────────────  读文件工具  ─────────────────────────
def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open(encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                raise ValueError(f"{path}:{lineno} 不是合法 JSON: {e}") from e
    if not rows:
        raise ValueError(f"{path} 为空文件")
    return rows


def read_csv(path: Path) -> List[Dict[str, Any]]:
    with path.open(encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = [{k: v for k, v in row.items()} for row in reader]
    if not rows:
        raise ValueError(f"{path} 为空文件")
    return rows


def read_rows(path: Path) -> List[Dict[str, Any]]:
    if path.suffix.lower() == ".jsonl":
        return read_jsonl(path)
    if path.suffix.lower() == ".csv":
        return read_csv(path)
    raise ValueError(f"仅支持 .jsonl / .csv，收到 {path.name}")


# ────────────────────────  字段解析  ────────────────────────
def _pick_first(row: Dict[str, Any], cols: List[str]) -> str:
    for c in cols:
        v = row.get(c)
        if v is not None and str(v).strip():
            return str(v).strip()
    return ""


def canonical_triple(row: Dict[str, Any]) -> Tuple[str, str, str]:
    """
    返回 (user, phone, email) 三元组，若缺失任一元素则返回全空字符串元组
    """
    user = str(row.get("user", "")).strip()
    phone = _pick_first(row, PHONE_COLS)
    email = _pick_first(row, EMAIL_COLS)
    return user, phone, email


# ───────────────────────────  评分  ──────────────────────────
def compute_f1(
    gt_map: Dict[Tuple[str, str, str], str],   # triple -> order_id
    pred_rows: List[Dict[str, Any]],
) -> float:
    if not pred_rows:
        return 0.0

    tp: Set[Tuple[str, str, str]] = set()
    seen_pred: Set[Tuple[str, str, str]] = set()
    fp = 0

    for row in pred_rows:
        triple = canonical_triple(row)

        # 缺字段 或 完全缺失值
        if not all(triple):
            fp += 1
            continue

        # 重复行
        if triple in seen_pred:
            fp += 1
            continue
        seen_pred.add(triple)

        order_id_pred = str(row.get("order_id", "")).strip()
        order_id_gt = gt_map.get(triple)

        if order_id_gt is None:               # 额外三元组
            fp += 1
            continue

        if order_id_pred == order_id_gt:      # 完全命中
            tp.add(triple)
        else:                                 # 非最小 order_id
            fp += 1

    fn = len(gt_map) - len(tp)

    precision = len(tp) / (len(tp) + fp) if tp or fp else 0.0
    recall = len(tp) / (len(tp) + fn) if tp or fn else 0.0
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


# ─────────────────────────── 主流程 ───────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate synonym-field-mapping deduplication output")
    parser.add_argument("-o", "--output", required=True,
                        help="Path to JSONL/CSV produced by your operator")
    args = parser.parse_args()

    # ---------- 读取 GT ----------
    gt_rows = read_csv(GT_PATH)
    gt_map: Dict[Tuple[str, str, str], str] = {
        canonical_triple(r): str(r["order_id"]).strip() for r in gt_rows
    }

    # ---------- 读取预测 ----------
    pred_path = Path(args.output)
    if not pred_path.exists():
        print(f"文件不存在: {pred_path}", file=sys.stderr)
        sys.exit(1)
    pred_rows = read_rows(pred_path)

    # ---------- 评估 ----------
    score = compute_f1(gt_map, pred_rows)

    # ---------- 输出 ----------
    print(json.dumps({"eval_score": f"{score:.4f}"}))


if __name__ == "__main__":
    main()