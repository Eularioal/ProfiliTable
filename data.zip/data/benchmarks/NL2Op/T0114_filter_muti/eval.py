#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “过滤” 算子

使用方法
--------
python eval.py -o /path/to/your_output.csv

说明
----
1. 基准文件固定为同级目录 expected/gt.csv
2. -o 指向数据算子的输出CSV文件（预测结果）
3. 评测逻辑：
   - 验证GT和预测文件的列名完全一致（顺序+名称）
   - 逐单元格原始值比对，整行所有单元格一致则该行正确
   - 对齐行数（取最小行数）进行比对
4. 评测指标：Row-level Accuracy（正确行数/总比对行数）
5. 指标范围 ∈ [0,1]，输出格式：{"eval_score": 准确率（保留4位小数）}
"""

from __future__ import annotations
import argparse
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Tuple, Optional, Dict, List

# ------------------------------------------------------------------ 常量
GT_PATH = Path(__file__).parent / "expected" / "gt.csv"  # 固定基准文件路径
MISSING_LABEL = ""  # 缺失值统一标记（仅用于填充NaN/None，不修改其他值）

# ------------------------------------------------------------------ 工具函数
def read_and_validate_data(gt_path: str | Path, pred_path: str | Path) -> Tuple[Optional[pd.DataFrame], Optional[pd.DataFrame]]:
    """
    读取GT和Pred数据，验证列名一致性，对齐行数
    返回：(处理后的GT数据, 处理后的Pred数据)
    """
    # 1. 读取GT文件（保留原始值）
    try:
        df_gt = pd.read_csv(gt_path)
    except Exception as e:
        print(f"GT文件读取失败: {e}")
        return None, None
    
    # 2. 读取Pred文件（保留原始值）
    try:
        df_pred = pd.read_csv(pred_path)
    except Exception as e:
        print(f"预测文件读取失败: {e}")
        return None, None
    
    # 3. 验证列名完全一致（顺序+名称）
    if list(df_gt.columns) != list(df_pred.columns):
        print(f"错误: 列名不一致！")
        print(f"GT列名: {list(df_gt.columns)}")
        print(f"预测文件列名: {list(df_pred.columns)}")
        return None, None
    
    # 4. 对齐行数（取最小行数）
    min_rows = min(len(df_gt), len(df_pred))
    df_gt_aligned = df_gt.iloc[:min_rows].copy()
    df_pred_aligned = df_pred.iloc[:min_rows].copy()
    
    # 5. 仅填充缺失值（NaN/None→空字符串），不修改其他任何值
    df_gt_aligned = df_gt_aligned.fillna(MISSING_LABEL)
    df_pred_aligned = df_pred_aligned.fillna(MISSING_LABEL)
    
    print(f"数据验证完成 - 有效比对行数: {min_rows}, 列数: {len(df_gt_aligned.columns)}")
    return df_gt_aligned, df_pred_aligned

def compute_row_accuracy(df_gt: pd.DataFrame, df_pred: pd.DataFrame) -> Dict[str, float]:
    """
    计算行级Accuracy：整行所有单元格原始值一致则该行正确（仅缺失值统一标记）
    返回：包含accuracy、correct_rows、total_rows的指标字典
    """
    # 逐行比对所有单元格原始值
    row_match = (df_gt == df_pred).all(axis=1)
    correct_rows = int(row_match.sum())
    total_rows = len(row_match)
    
    # 计算Accuracy（避免零除法）
    accuracy = correct_rows / total_rows if total_rows > 0 else 0.0
    accuracy_rounded = round(accuracy, 4)

    
    return {
        "accuracy": accuracy_rounded,
        "correct_rows": correct_rows,
        "total_rows": total_rows
    }

# ------------------------------------------------------------------ 主流程
def main() -> None:
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="Evaluate Split-Concat output (Row-level Accuracy)")
    parser.add_argument(
        "-o", "--output", required=True,
        help="Path to CSV produced by your data standardization operator (prediction result)"
    )
    args = parser.parse_args()

    # 1. 检查基准文件是否存在
    if not GT_PATH.exists():
        print(f"错误：基准文件不存在，请先创建 {GT_PATH}")
        return

    # 2. 读取并验证数据
    df_gt, df_pred = read_and_validate_data(GT_PATH, args.output)
    if df_gt is None or df_pred is None:
        print({"eval_score": "0.0000"})
        return

    # 3. 计算行级Accuracy
    metrics = compute_row_accuracy(df_gt, df_pred)

    # 4. 输出最终结果（符合指定格式）
    print({"eval_score": f"{metrics['accuracy']:.4f}"})

if __name__ == "__main__":
    main()