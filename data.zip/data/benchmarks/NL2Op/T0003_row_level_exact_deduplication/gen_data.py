#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Generate GT (deduplicated) and RAW (with duplicates) CSV files
in directories that are *siblings* of this script:

./gendata.py
./expected/gt.csv
./raw/customers.csv
"""

from pathlib import Path
from datetime import datetime, timedelta
import csv
import random
import sys

try:
    from faker import Faker
except ModuleNotFoundError:
    sys.exit("❌ 依赖 Faker 未安装，请先运行: pip install faker==22.0.0")

# --------------------------- 参数 ---------------------------
SEED               = 42
N_GT_ROWS          = 100
MIN_EXTRA_DUPS     = 50     # 如果被改为 0，就只会有 100 行
MAX_EXTRA_DUPS     = 100

random.seed(SEED)

root_dir = Path(__file__).parent
gt_path  = root_dir / "expected" / "gt.csv"
raw_path = root_dir / "raw" / "customers.csv"

gt_path.parent.mkdir(parents=True, exist_ok=True)
raw_path.parent.mkdir(parents=True, exist_ok=True)

# ------------------------ 生成 GT ------------------------
fake = Faker("en_US")
Faker.seed(SEED)

def rand_date():
    start = datetime.now() - timedelta(days=3 * 365)
    dt = start + timedelta(days=random.randint(0, 3 * 365))
    return dt.strftime("%Y-%m-%d")

header = ["customer_id", "full_name", "email", "phone",
          "address", "signup_date", "country"]

gt_rows, fp_set = [], set()
while len(gt_rows) < N_GT_ROWS:
    row = {
        "customer_id": len(gt_rows) + 1,
        "full_name":   fake.name(),
        "email":       fake.unique.email(),
        "phone":       fake.phone_number(),
        "address":     fake.address().replace("\n", ", "),
        "signup_date": rand_date(),
        "country":     fake.country(),
    }
    fp = tuple(row.values())
    if fp not in fp_set:
        fp_set.add(fp)
        gt_rows.append(row)

with gt_path.open("w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=header)
    w.writeheader()
    w.writerows(gt_rows)

print(f"GT 生成完成: {gt_path}  行数={len(gt_rows)}")

# -------------------- 生成 RAW（含重复） --------------------
raw_rows = [list(r.values()) for r in gt_rows]

n_extra = random.randint(MIN_EXTRA_DUPS, MAX_EXTRA_DUPS)
for _ in range(n_extra):
    src = random.choice(raw_rows)   # 随机行
    k   = random.randint(1, 3)      # 复制次数
    raw_rows.extend([src.copy() for _ in range(k)])  # copy() → 避免同一对象引用

random.shuffle(raw_rows)

with raw_path.open("w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(header)
    w.writerows(raw_rows)

print(f"RAW 生成完成: {raw_path}  行数={len(raw_rows)}  (n_extra={n_extra})")