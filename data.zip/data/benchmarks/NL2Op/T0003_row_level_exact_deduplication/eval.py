#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “整行精确去重” 算子

使用方法
--------
python eval.py -o /path/to/your_output.csv

说明
----
1. 评测基准文件固定为同级目录下 expected/gt.csv
2. -o 指向的 CSV 可以是:
   • 运行去重算子得到的结果文件
   • 直接拿 expected/gt.csv 本身 (即上限得分 1.0)
3. 评分范围始终 ∈ [0,1] ，输出格式为字典字符串，例如:
   {"eval_score": "0.8735"}
"""

from __future__ import annotations
import argparse
import csv
from pathlib import Path
from typing import List, Tuple, Set

# ------------------------------------------------------------------ 常量
GT_PATH = Path(__file__).parent / "expected" / "gt.csv"

# ------------------------------------------------------------------ 工具
def load_csv_rows(path: Path) -> List[Tuple[str, ...]]:
    """
    读取 CSV（跳过表头）并返回「按行顺序」的 list。
    每行用 tuple 存储，方便哈希去重 / 比较。
    """
    rows: List[Tuple[str, ...]] = []
    with path.open(encoding="utf-8") as f:
        reader = csv.reader(f)
        header_skipped = False
        for row in reader:
            if not header_skipped:          # 跳过第一行表头
                header_skipped = True
                continue
            rows.append(tuple(row))
    return rows


def compute_f1(gt_rows: Set[Tuple[str, ...]], pred_rows: List[Tuple[str, ...]]) -> float:
    """
    严格按整行匹配计算 Precision / Recall / F1

    • gt_rows 为去重后的 set
    • pred_rows 保留原始顺序 & 重复行，用 list
      ——重复行会增加分母 (precision) 从而被惩罚
    """
    if not pred_rows:
        return 0.0

    tp_seen: Set[Tuple[str, ...]] = set()
    tp = 0
    for r in pred_rows:
        if r in gt_rows and r not in tp_seen:
            tp_seen.add(r)
            tp += 1

    precision = tp / len(pred_rows)   # 重复行计入分母
    recall    = tp / len(gt_rows)     # gt_rows 无重复

    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


# ------------------------------------------------------------------ 主流程
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate row-level exact-deduplication output")
    parser.add_argument(
        "-o", "--output", required=True,
        help="Path to CSV produced by your deduplication operator"
    )
    args = parser.parse_args()

    gt_rows_set = set(load_csv_rows(GT_PATH))
    pred_rows   = load_csv_rows(Path(args.output))

    score = compute_f1(gt_rows_set, pred_rows)

    print({"eval_score": f"{score:.4f}"})


if __name__ == "__main__":
    main()