import json
import argparse
from pathlib import Path
import numpy as np

TOLERANCE = 0.1  # 允许的最大误差 ±0.5

# 加载JSONL文件
def load_jsonl(path):
    data = {}
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            obj = json.loads(line)
            data[obj["patient_id"]] = obj
    return data

# 计算与待补全记录症状一致的体温平均值
def calculate_avg_temp(gt_data, symptoms):
    matching_temps = []
    for patient_id, gt_record in gt_data.items():
        # 匹配症状
        if all(gt_record.get(symptom) == value for symptom, value in symptoms.items()):
            temp = gt_record.get("temperature")
            if temp is not None:
                matching_temps.append(temp)
    if matching_temps:
        return np.mean(matching_temps)
    return None

# 评估补全准确度
def evaluate(gt_path, pred_path):
    gt_data = load_jsonl(gt_path)  # 加载GT数据
    pred_data = load_jsonl(pred_path)  # 加载预测数据

    correct_count = 0
    total_count = 0

    # 遍历预测数据
    for patient_id, pred_record in pred_data.items():
        if pred_record.get("empty") == True:  # 只有当empty为True时才进行评估
            gt_record = gt_data.get(patient_id)
            if not gt_record:
                continue  # 如果GT记录中没有该患者的记录，则跳过

            # # 获取该患者的症状组合
            # symptoms = {symptom: pred_record.get(symptom) for symptom in ['fever', 'cough', 'headache', 'fatigue', 'shortness_of_breath', 'nausea']}

            # # 计算症状一致的体温均值
            # avg_temp = calculate_avg_temp(gt_data, symptoms)

            # if avg_temp is None:
            #     continue  # 如果没有找到匹配的症状，跳过

            pred_temp = pred_record.get("temperature")
            if pred_temp is None:
                continue  # 如果预测温度缺失，跳过

            # 判断预测值与症状一致记录的体温均值是否在容忍范围内
            if abs(pred_temp - gt_record.get("temperature")) <= TOLERANCE:
                correct_count += 1
            total_count += 1

    if total_count == 0:
        return 0.0  # 如果没有需要评估的记录，返回准确度为0

    accuracy = correct_count / total_count
    return accuracy

def get_gt():
    current_dir = Path(__file__).resolve().parent
    expected_dir = (current_dir / "expected").resolve()
    csv_files = list(expected_dir.glob("*.jsonl"))
    if not csv_files:
        raise FileNotFoundError(f"No .jsonl file found in {expected_dir}")
    return csv_files[0]

# 主函数
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate temperature completion accuracy.")
    # parser.add_argument("-g", "--gt", required=True, help="GT JSONL 文件路径")
    parser.add_argument("-o", "--output", required=True, help="预测结果 JSONL 文件路径")
    args = parser.parse_args()

    # 评估补全准确度
    gt_path = get_gt()
    score = evaluate(gt_path, args.output)
    print(json.dumps({"eval_score": f"{score:.4f}"}))