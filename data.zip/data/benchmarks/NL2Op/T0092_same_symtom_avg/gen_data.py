import random
import numpy as np
import pandas as pd
import json
from pathlib import Path

# 用于生成GT数据（无缺失值）
def generate_gt_data():
    symptom_combinations = [
        (True, True, True, True, True, True),
        (True, False, True, False, True, False),
        (False, True, False, True, True, False),
        (True, True, False, False, True, True),
        (False, False, False, False, False, True)
    ]

    patient_ids = [f"patient_{i}" for i in range(1, 101)]
    data = []
    
    for patient_id in patient_ids:
        # 随机生成症状组合
        symptoms = random.choice(symptom_combinations)
        
        # 随机生成体温数据，正常体温范围 36.5 到 37.5°C
        temperature = round(np.random.uniform(36.5, 37.5), 1)
        
        # 将数据组合
        patient_data = {
            "patient_id": patient_id,
            "fever": symptoms[0],
            "cough": symptoms[1],
            "headache": symptoms[2],
            "fatigue": symptoms[3],
            "shortness_of_breath": symptoms[4],
            "nausea": symptoms[5],
            "temperature": temperature,
            "empty": False,
        }
        
        data.append(patient_data)

    return pd.DataFrame(data)

# 用于引入缺失值并标记empty字段
def introduce_missing_values(df, missing_ratio=0.2):
    df_missing = df.copy()
    num_missing = int(len(df) * missing_ratio)
    
    # 随机选择缺失的体温数据的索引
    missing_indices = np.random.choice(df.index, num_missing, replace=False)
    
    for idx in missing_indices:
        df_missing.loc[idx, "temperature"] = np.nan
        df_missing.loc[idx, "empty"] = True
    
    return df_missing

# 通过症状组合填补缺失的体温
def fill_missing_temperatures(df):
    df_filled = df.copy()
    
    # 按症状组合分组
    grouped = df_filled.groupby(
        ["fever", "cough", "headache", "fatigue", "shortness_of_breath", "nausea"]
    )
    
    # 对于每组，计算该组的平均体温
    for group, group_df in grouped:
        mean_temp = group_df["temperature"].mean()
        
        # 填补缺失的体温
        df_filled.loc[group_df["temperature"].isna(), "temperature"] = mean_temp
        
    return df_filled

# 生成GT数据
gt_data = generate_gt_data()

# 引入缺失值并标记empty字段
raw_data = introduce_missing_values(gt_data, missing_ratio=0.2)

# 存储GT数据
gt_data["empty"] = raw_data["empty"]
gt_output_path = Path("data/benchmarks/NL2Op/T0092_same_symtom_avg/expected/gt.jsonl")
gt_output_path.parent.mkdir(parents=True, exist_ok=True)
with open(gt_output_path, 'w') as f:
    for record in gt_data.to_dict(orient="records"):
        f.write(json.dumps(record) + "\n")

# 存储带缺失值的数据（raw数据）
raw_output_path = Path("data/benchmarks/NL2Op/T0092_same_symtom_avg/raw/customers.jsonl")
raw_output_path.parent.mkdir(parents=True, exist_ok=True)
with open(raw_output_path, 'w') as f:
    for record in raw_data.to_dict(orient="records"):
        f.write(json.dumps(record) + "\n")

# 填补缺失值
# filled_data = fill_missing_temperatures(raw_data)

# 这里只是展示填补操作后的数据，实际上不需要保存
# print(filled_data.head())
