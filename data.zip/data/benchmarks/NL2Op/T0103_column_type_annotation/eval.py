#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “列类型标注” 算子

使用方法
--------
python eval.py -o /path/to/your_output.csv

说明
----
1. 基准文件固定为同级目录 expected/gt.csv
2. -o 指向列类型标注算子的输出CSV文件（预测结果）
3. CSV格式要求：第一列为列名，第二列为数据类型
4. 数据清洗规则：列名/类型去空格、统一小写，确保匹配准确
5. 缺失预测处理：模型未输出的列类型标记为"missing"
6. 评测指标：Weighted Precision/Recall/F1-score（零除法时指标为0）
7. 指标范围 ∈ [0,1]，依次打印 Precision、Recall、F1-score（保留4位小数）
"""

from __future__ import annotations
import argparse
import pandas as pd
from sklearn.metrics import precision_recall_fscore_support
from pathlib import Path
from typing import Tuple, Optional

# ------------------------------------------------------------------ 常量
GT_PATH = Path(__file__).parent / "expected" / "gt.csv"  # 固定基准文件路径
MISSING_TYPE_LABEL = "missing"  # 缺失预测的标记

# ------------------------------------------------------------------ 工具函数
def read_and_clean_type_csv(path: str | Path) -> Optional[pd.DataFrame]:
    """
    读取列类型标注CSV文件并完成数据清洗
    步骤：读取文件→保留前两列→重命名列→去空格→类型统一小写
    参数：path - CSV文件路径
    返回：清洗后的DataFrame（列：col_name, type），读取失败返回None
    """
    try:
        df = pd.read_csv(path)
    except Exception as e:
        print(f"文件读取失败: {e}")
        return None

    # 强制保留前两列并规范化列名
    df = df.iloc[:, [0, 1]]
    df.columns = ['col_name', 'type']

    # 文本清洗：去除空格，类型统一小写
    df['col_name'] = df['col_name'].astype(str).str.strip()
    df['type'] = df['type'].astype(str).str.strip().str.lower()

    return df

def align_type_data(df_gt: pd.DataFrame, df_pred: pd.DataFrame) -> Tuple[pd.Series, pd.Series]:
    """
    左连接对齐GT和Pred数据（以GT为主），填充缺失预测标记
    逻辑：GT有Pred无→Pred类型填MISSING_TYPE_LABEL
    返回：y_true (真实类型), y_pred (预测类型)
    """
    # 左连接确保每个GT列都被评测
    merged = pd.merge(
        df_gt.rename(columns={'type': 'true_type'}),
        df_pred.rename(columns={'type': 'pred_type'}),
        on='col_name',
        how='left'
    )

    # 填充缺失的预测类型
    merged['pred_type'] = merged['pred_type'].fillna(MISSING_TYPE_LABEL)

    return merged['true_type'], merged['pred_type']

# ------------------------------------------------------------------ 评分
def compute_type_annotation_metrics(y_true: pd.Series, y_pred: pd.Series) -> Tuple[float, float, float]:
    """
    计算列类型标注的加权Precision、Recall、F1-score
    参数：y_true - 真实类型序列，y_pred - 预测类型序列
    返回：(precision, recall, f1) 均保留4位小数
    """
    p, r, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average='weighted', zero_division=0
    )
    return round(p, 4), round(r, 4), round(f1, 4)

# ------------------------------------------------------------------ 主流程
def main() -> None:
    # 解析命令行参数（仅保留-o/--output指定预测文件路径）
    parser = argparse.ArgumentParser(description="Evaluate Column Type Annotation output")
    parser.add_argument(
        "-o", "--output", required=True,
        help="Path to CSV produced by your column type annotation operator (prediction result)"
    )
    args = parser.parse_args()

    # 1. 检查并读取基准文件（GT）
    if not GT_PATH.exists():
        print(f"错误：基准文件不存在，请先创建 {GT_PATH}")
        return
    
    df_gt = read_and_clean_type_csv(GT_PATH)
    if df_gt is None:
        return

    # 2. 检查并读取预测文件（Pred）
    pred_path = Path(args.output)
    if not pred_path.exists():
        print(f"错误：预测文件不存在 {pred_path}")
        return
    
    df_pred = read_and_clean_type_csv(pred_path)
    if df_pred is None:
        return

    # 3. 数据对齐（左连接+填充缺失）
    y_true, y_pred = align_type_data(df_gt, df_pred)

    # 4. 计算评测指标
    precision, recall, f1 = compute_type_annotation_metrics(y_true, y_pred)

    # 5. 输出结果
    print({"eval_score": f"{f1:.4f}"})

if __name__ == "__main__":
    main()