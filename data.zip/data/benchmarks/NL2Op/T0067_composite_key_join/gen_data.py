#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
gen_data.py ─ 生成 raw 与 expected/gt.csv
========================================

功能
    • 生成两个输入表 raw/customer1.csv 与 raw/customer2.csv
    • 基于复合键等值连接：
        left(country, region, customer_id) = right(country_code, region, id)
    • 解决冲突列（email, status）策略：
        - left  : 左优先（保留左侧冲突列，右侧冲突列丢弃）
        - right : 右优先（保留右侧冲突列，左侧冲突列丢弃）
        - suffix: 左右后缀（email_left/email_right, status_left/status_right）
    • 写出 expected/gt.csv（含表头）

注意
    • 该脚本可多次运行，生成内容固定且可复现。
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Dict, List, Tuple


ROOT_DIR   = Path(__file__).resolve().parent
RAW_DIR    = ROOT_DIR / "raw"
EXP_DIR    = ROOT_DIR / "expected"
GT_PATH    = EXP_DIR / "gt.csv"
L_PATH     = RAW_DIR / "customer1.csv"
R_PATH     = RAW_DIR / "customer2.csv"

# 左表（customer1）列
LEFT_COLS  = ["country", "region", "customer_id", "email", "signup_date", "status", "notes"]
# 右表（customer2）列
RIGHT_COLS = ["country_code", "region", "id", "email", "last_order_date", "status", "vip"]

# 复合键映射：left keys -> right keys
LEFT_KEYS  = ["country", "region", "customer_id"]
RIGHT_KEYS = ["country_code", "region", "id"]


LEFT_ROWS = [
    # country, region, customer_id, email,                 signup_date,  status,   notes
    {"country": "US", "region": "CA", "customer_id": "1001", "email": "alice@example.com", "signup_date": "2021-01-10", "status": "active",   "notes": "L1"},
    {"country": "US", "region": "NY", "customer_id": "1002", "email": "bob@example.com",   "signup_date": "2021-02-12", "status": "inactive", "notes": "L2"},
    {"country": "CN", "region": "BJ", "customer_id": "2001", "email": "chen@example.cn",   "signup_date": "2020-11-05", "status": "active",   "notes": "L3"},
    {"country": "CN", "region": "SH", "customer_id": "2002", "email": "du@example.cn",     "signup_date": "2022-07-19", "status": "pending",  "notes": "L4"},
    {"country": "DE", "region": "BE", "customer_id": "3001", "email": "eva@example.de",    "signup_date": "2021-09-30", "status": "active",   "notes": "L5"},
    {"country": "US", "region": "CA", "customer_id": "1003", "email": "frank@example.com", "signup_date": "2020-06-15", "status": "active",   "notes": "L6"},
]

RIGHT_ROWS = [
    # country_code, region, id,    email,                    last_order_date, status,   vip
    {"country_code": "US", "region": "CA", "id": "1001", "email": "alice.us@example.com", "last_order_date": "2022-12-01", "status": "gold",     "vip": "true"},
    {"country_code": "US", "region": "NY", "id": "1002", "email": "bob@example.com",      "last_order_date": "2021-12-11", "status": "inactive", "vip": "false"},
    {"country_code": "CN", "region": "BJ", "id": "2001", "email": "chen_new@ex.cn",       "last_order_date": "2023-03-03", "status": "active",   "vip": "true"},
    {"country_code": "CN", "region": "GD", "id": "2005", "email": "gao@example.cn",       "last_order_date": "2021-05-05", "status": "active",   "vip": "false"},
    {"country_code": "DE", "region": "BE", "id": "3001", "email": "eva@example.de",       "last_order_date": "2022-02-02", "status": "paused",   "vip": "false"},
    {"country_code": "US", "region": "CA", "id": "9999", "email": "zoe@example.com",      "last_order_date": "2023-04-04", "status": "active",   "vip": "false"},
    {"country_code": "US", "region": "CA", "id": "1003", "email": "frank@example.com",    "last_order_date": "2020-07-01", "status": "inactive", "vip": "false"},
    {"country_code": "CN", "region": "SH", "id": "2002", "email": "du@alt.cn",            "last_order_date": "2022-08-01", "status": "active",   "vip": "true"},
]


def write_csv(path: Path, header: List[str], rows: List[Dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=header)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in header})


def key_tuple_from_row(row: Dict[str, str], cols: List[str]) -> Tuple[str, ...]:
    return tuple(row[c] for c in cols)


def build_right_index(rows: List[Dict[str, str]]) -> Dict[Tuple[str, ...], Dict[str, str]]:
    idx: Dict[Tuple[str, ...], Dict[str, str]] = {}
    for r in rows:
        k = key_tuple_from_row(r, RIGHT_KEYS)
        # 若右表存在重复键，这里默认后者覆盖前者（也可改成收集列表）
        idx[k] = r
    return idx


def compute_gt(strategy: str) -> Tuple[List[str], List[Dict[str, str]]]:
    """
    返回 (header, rows)
    strategy ∈ {"left", "right", "suffix"}
    """
    right_idx = build_right_index(RIGHT_ROWS)

    # 非键列集合
    left_non_keys  = [c for c in LEFT_COLS  if c not in LEFT_KEYS]
    right_non_keys = [c for c in RIGHT_COLS if c not in RIGHT_KEYS]
    conflict_cols  = sorted(set(left_non_keys).intersection(set(right_non_keys)))  # ["email", "status"]

    out_rows: List[Dict[str, str]] = []

    # 决定输出表头
    if strategy == "suffix":
        # 键列（左命名） + 左非键(冲突: *_left) + 右非键(冲突: *_right)
        header = list(LEFT_KEYS)
        # 左非键
        for c in left_non_keys:
            if c in conflict_cols:
                header.append(f"{c}_left")
            else:
                header.append(c)
        # 右非键
        for c in right_non_keys:
            if c in conflict_cols:
                header.append(f"{c}_right")
            else:
                header.append(c)
    elif strategy == "left":
        # 键列（左命名） + 左全部非键 + 右仅非冲突非键
        header = list(LEFT_KEYS) + list(left_non_keys) + [c for c in right_non_keys if c not in conflict_cols]
    elif strategy == "right":
        # 键列（左命名） + （左非键去除冲突） + 右全部非键（冲突占原名）
        header = list(LEFT_KEYS) + [c for c in left_non_keys if c not in conflict_cols] + list(right_non_keys)
    else:
        raise ValueError(f"未知策略: {strategy}")

    # 逐行连接（内连接）
    for l in LEFT_ROWS:
        k = (l["country"], l["region"], l["customer_id"])
        r = right_idx.get((l["country"], l["region"], l["customer_id"]))
        if r is None:
            continue  # 无匹配则不输出（内连接）

        out: Dict[str, str] = {}
        # 键列（统一采用左命名）
        for c in LEFT_KEYS:
            out[c] = l[c]

        if strategy == "suffix":
            # 左非键
            for c in left_non_keys:
                if c in conflict_cols:
                    out[f"{c}_left"] = l[c]
                else:
                    out[c] = l[c]
            # 右非键
            for c in right_non_keys:
                if c in conflict_cols:
                    out[f"{c}_right"] = r[c]
                else:
                    out[c] = r[c]
        elif strategy == "left":
            # 左全部非键
            for c in left_non_keys:
                out[c] = l[c]
            # 右仅非冲突非键
            for c in right_non_keys:
                if c not in conflict_cols:
                    out[c] = r[c]
        elif strategy == "right":
            # 左非键去除冲突
            for c in left_non_keys:
                if c not in conflict_cols:
                    out[c] = l[c]
            # 右全部非键（冲突占原名）
            for c in right_non_keys:
                out[c] = r[c]

        # 规范输出列顺序
        out_rows.append({col: out.get(col, "") for col in header})

    return header, out_rows


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate raw data and expected ground truth for composite-key join")
    parser.add_argument("--strategy", choices=["left", "right", "suffix"], default="suffix",
                        help="冲突列处理策略：left=左优先, right=右优先, suffix=左右后缀（默认）")
    args = parser.parse_args()

    # 写 raw
    write_csv(L_PATH, LEFT_COLS, LEFT_ROWS)
    write_csv(R_PATH, RIGHT_COLS, RIGHT_ROWS)

    # 计算并写 expected/gt.csv
    hdr, rows = compute_gt(args.strategy)
    write_csv(GT_PATH, hdr, rows)

    print(f"[gen_data] 已生成：")
    print(f"  - {L_PATH}")
    print(f"  - {R_PATH}")
    print(f"  - {GT_PATH}  (strategy={args.strategy})")


if __name__ == "__main__":
    main()