import argparse
from pathlib import Path
import pandas as pd
import numpy as np

def calculate_cell_accuracy(gt_path, output_path, float_tol=1e-6):
    """
    对照检查gt表与output.csv，计算单元格准确率、行准确率、表格整体打分
    :param gt_path: gt表文件路径（基准文件）
    :param output_path: 待检查的output.csv路径
    :param float_tol: 浮点数对比精度阈值（避免因计算精度差异导致误判）
    :return: 元组(单元格准确率, 行准确率, 表格整体打分, 详细结果字典)
             详细结果包含：总单元格数、匹配数、不匹配数、行级统计、表格打分等
    """
    print("=" * 80)
    print("开始执行gt表与output.csv的多维度对照检查")
    print(f"gt表路径：{gt_path}")
    print(f"output.csv路径：{output_path}")
    print("=" * 80)

    # 初始化详细结果字典（新增行级、表格级字段）
    result_dict = {
        "total_cells": 0,
        "matched_cells": 0,
        "unmatched_cells": 0,
        "unmatched_coords": [],
        # 新增行级统计字段
        "total_rows": 0,
        "matched_rows": 0,
        "unmatched_rows": 0,
        "unmatched_rows_list": [],  # 记录具体哪些行不匹配
        # 新增表格级打分字段
        "table_score": 0,  # 1=全对，0=有错误
        "error_msg": "",
        "success": False
    }

    # -------------------------- 1. 读取两个文件并捕获基础异常 --------------------------
    try:
        # 读取文件（增加编码容错，自动尝试UTF-8/GBK）
        df_gt = pd.read_csv(gt_path, encoding='utf-8')
    except UnicodeDecodeError:
        df_gt = pd.read_csv(gt_path, encoding='gbk')
    except FileNotFoundError as e:
        error_msg = f"文件读取失败：{str(e)}（请检查gt表路径是否正确）"
        print(f"\n❌ {error_msg}")
        result_dict["error_msg"] = error_msg
        return 0.0, 0.0, 0, result_dict
    except Exception as e:
        error_msg = f"gt表读取异常：{str(e)}（可能是文件格式错误或编码问题）"
        print(f"\n❌ {error_msg}")
        result_dict["error_msg"] = error_msg
        return 0.0, 0.0, 0, result_dict

    try:
        df_output = pd.read_csv(output_path, encoding='utf-8')
    except UnicodeDecodeError:
        df_output = pd.read_csv(output_path, encoding='gbk')
    except FileNotFoundError as e:
        error_msg = f"文件读取失败：{str(e)}（请检查output.csv路径是否正确）"
        print(f"\n❌ {error_msg}")
        result_dict["error_msg"] = error_msg
        return 0.0, 0.0, 0, result_dict
    except Exception as e:
        error_msg = f"output.csv读取异常：{str(e)}（可能是文件格式错误或编码问题）"
        print(f"\n❌ {error_msg}")
        result_dict["error_msg"] = error_msg
        return 0.0, 0.0, 0, result_dict

    print("\n✅ 两个文件均成功读取")

    # -------------------------- 2. 基础校验：列名、列数、行数一致性 --------------------------
    # 2.1 检查列名是否完全一致
    gt_columns = set(df_gt.columns)
    output_columns = set(df_output.columns)
    if gt_columns != output_columns:
        missing_in_output = gt_columns - output_columns  # gt有但output没有的列
        extra_in_output = output_columns - gt_columns    # output有但gt没有的列
        error_msg = "列名不一致"
        print(f"\n❌ {error_msg}：")
        if missing_in_output:
            print(f"   - output.csv缺失gt表的列：{sorted(missing_in_output)}")
            error_msg += f"，缺失列：{sorted(missing_in_output)}"
        if extra_in_output:
            print(f"   - output.csv多余gt表的列：{sorted(extra_in_output)}")
            error_msg += f"，多余列：{sorted(extra_in_output)}"
        result_dict["error_msg"] = error_msg
        return 0.0, 0.0, 0, result_dict

    # 2.2 检查列顺序是否一致（提示但不终止）
    if list(df_gt.columns) != list(df_output.columns):
        print(f"\n⚠️  列顺序不一致（不影响准确率计算，但建议与gt表对齐）：")
        print(f"   - gt表列顺序：{list(df_gt.columns)}")
        print(f"   - output.csv列顺序：{list(df_output.columns)}")

    # 2.3 检查行数是否一致
    if len(df_gt) != len(df_output):
        error_msg = f"行数不一致（gt表{len(df_gt)}行，output.csv{len(df_output)}行）"
        print(f"\n❌ {error_msg}")
        result_dict["error_msg"] = error_msg
        return 0.0, 0.0, 0, result_dict

    print(f"\n✅ 基础校验通过：")
    print(f"   - 列名完全一致（共{df_gt.shape[1]}列）")
    print(f"   - 行数完全一致（共{len(df_gt)}行）")

    # -------------------------- 3. 逐个单元格对比 --------------------------
    # 3.1 确保列顺序一致，避免对比错位
    df_output = df_output[df_gt.columns].copy()

    # 3.2 初始化单元格对比矩阵（避免NaN干扰sum计算）
    cell_match = pd.DataFrame(
        False,  # 默认值
        index=df_gt.index,
        columns=df_gt.columns,
        dtype=bool  # 显式指定布尔类型
    )

    for col in df_gt.columns:
        col_gt = df_gt[col].copy()
        col_output = df_output[col].copy()

        # 统一处理空字符串：将空字符串转为NaN（避免''和NaN被误判为不一致）
        if col_gt.dtype == object:
            col_gt = col_gt.replace('', np.nan)
        if col_output.dtype == object:
            col_output = col_output.replace('', np.nan)

        # 判断是否为数值列（包含int/float）
        is_gt_numeric = pd.api.types.is_numeric_dtype(col_gt)
        is_output_numeric = pd.api.types.is_numeric_dtype(col_output)

        if is_gt_numeric and is_output_numeric:
            # 场景1：数值列 - 处理精度和缺失值
            # 标记缺失值位置（至少一个为NaN/inf）
            nan_inf_mask = col_gt.isna() | col_output.isna() | \
                           np.isinf(col_gt) | np.isinf(col_output)
            value_mask = ~nan_inf_mask

            # 缺失/无穷值位置：两边都为NaN/inf才判定一致
            cell_match.loc[nan_inf_mask, col] = (
                (col_gt.isna() & col_output.isna()) |
                (np.isinf(col_gt) & np.isinf(col_output))
            ).loc[nan_inf_mask]

            # 非缺失值位置：用np.isclose判断数值接近度（处理精度问题）
            if value_mask.any():
                cell_match.loc[value_mask, col] = np.isclose(
                    col_gt.loc[value_mask],
                    col_output.loc[value_mask],
                    atol=float_tol,
                    equal_nan=False  # NaN已单独处理
                )
        else:
            # 场景2：非数值列（字符串/日期等）- 精确匹配+修复NaN判断
            # 先逐单元格比较（初始结果）
            cell_compare = (col_gt == col_output)
            # 修复NaN判断：两边都为NaN则改为True（因NaN==NaN返回False）
            both_nan_mask = col_gt.isna() & col_output.isna()
            cell_compare.loc[both_nan_mask] = True
            # 赋值到对比矩阵
            cell_match[col] = cell_compare

    # -------------------------- 4. 多维度准确率计算 --------------------------
    # 4.1 单元格级别统计
    total_cells = df_gt.shape[0] * df_gt.shape[1]
    matched_cells = cell_match.sum().sum()  # 布尔值sum：True=1，False=0
    unmatched_cells = total_cells - matched_cells
    cell_accuracy = round(matched_cells / total_cells if total_cells > 0 else 0.0, 4)

    # 4.2 行级别统计
    total_rows = len(df_gt)
    # 每行所有单元格都为True（匹配），则该行匹配
    row_match = cell_match.all(axis=1)  # axis=1：按行判断，全True则返回True
    matched_rows = row_match.sum()
    unmatched_rows = total_rows - matched_rows
    row_accuracy = round(matched_rows / total_rows if total_rows > 0 else 0.0, 4)
    # 收集不匹配的行号（从1开始，符合用户习惯）
    unmatched_rows_list = [idx + 1 for idx, is_match in row_match.items() if not is_match]

    # 4.3 表格整体打分
    table_score = 1 if (matched_cells == total_cells) else 0  # 全对=1，否则=0

    # 4.4 收集不匹配单元格位置
    unmatched_coords = []
    if unmatched_cells > 0:
        # 筛选出所有不匹配的单元格坐标
        unmatched_df = cell_match[cell_match == False].stack()
        for (row_idx, col_name) in unmatched_df.index:
            gt_val = df_gt.loc[row_idx, col_name]
            output_val = df_output.loc[row_idx, col_name]
            unmatched_coords.append({
                "row_num": row_idx + 1,  # 行号从1开始
                "original_index": row_idx,
                "column": col_name,
                "gt_value": gt_val,
                "output_value": output_val,
                "gt_type": type(gt_val).__name__,
                "output_type": type(output_val).__name__
            })

    # -------------------------- 5. 更新结果字典 --------------------------
    result_dict.update({
        # 单元格级别
        "total_cells": total_cells,
        "matched_cells": int(matched_cells),
        "unmatched_cells": int(unmatched_cells),
        "unmatched_coords": unmatched_coords,
        "cell_accuracy": cell_accuracy,
        # 行级别
        "total_rows": total_rows,
        "matched_rows": int(matched_rows),
        "unmatched_rows": int(unmatched_rows),
        "unmatched_rows_list": unmatched_rows_list,
        "row_accuracy": row_accuracy,
        # 表格级别
        "table_score": table_score,
        "success": True
    })

    # -------------------------- 6. 输出多维度详细结果 --------------------------
    print("\n" + "=" * 80)
    print("多维度对照检查结果汇总")
    print("=" * 80)
    
    # 单元格级别结果
    print("\n📊 【单元格级别】")
    print(f"   总单元格数量：{total_cells:,}（{df_gt.shape[0]}行 × {df_gt.shape[1]}列）")
    print(f"   匹配的单元格数量：{matched_cells:,}")
    print(f"   不匹配的单元格数量：{unmatched_cells:,}")
    print(f"   单元格准确率：{cell_accuracy:.4f}（{cell_accuracy*100:.2f}%）")
    
    # 行级别结果
    print("\n📊 【行级别】")
    print(f"   总行数：{total_rows:,}")
    print(f"   完全匹配的行数：{matched_rows:,}")
    print(f"   不完全匹配的行数：{unmatched_rows:,}")
    print(f"   行准确率：{row_accuracy:.4f}（{row_accuracy*100:.2f}%）")
    if unmatched_rows > 0:
        print(f"   不匹配的行号：{unmatched_rows_list}")
    
    # 表格级别打分
    print("\n📊 【表格整体打分】")
    print(f"   表格得分：{table_score}（1=所有单元格完全匹配，0=存在不匹配单元格）")

    # 输出前10个不匹配单元格位置
    if unmatched_cells > 0:
        print(f"\n⚠️  前10个不匹配的单元格位置：")
        for i, item in enumerate(unmatched_coords[:10]):
            print(f"   {i+1}. 行{item['row_num']}（原索引{item['original_index']}）：{item['column']}")
            print(f"      - gt表值：{item['gt_value']}（类型：{item['gt_type']}）")
            print(f"      - output.csv值：{item['output_value']}（类型：{item['output_type']}）")
        if len(unmatched_coords) > 10:
            print(f"   ... （还有{len(unmatched_coords)-10}个不匹配位置未显示）")

    print("\n" + "=" * 80)
    return cell_accuracy, row_accuracy, table_score, result_dict

# -------------------------- 执行检查（需根据实际文件路径修改） --------------------------
if __name__ == "__main__":
    GT_PATH = Path(__file__).parent / "expected" / "gt.csv"
    parser = argparse.ArgumentParser(description="Evaluate Split-Concat output (Row-level Accuracy)")
    parser.add_argument(
        "-o", "--output", required=True,
        help="Path to CSV produced by your data standardization operator (prediction result)"
    )
    args = parser.parse_args()
    OUTPUT_FILE_PATH = args.output
    
    # 执行多维度准确率计算
    cell_acc, row_acc, table_score, details = calculate_cell_accuracy(
        gt_path=GT_PATH,
        output_path=OUTPUT_FILE_PATH,
        float_tol=1e-6  # 浮点数精度阈值，可根据需求调整
    )
    print({"eval_score": f"{table_score}"})
    # 可选：打印完整的详细结果字典
    # print("\n完整详细结果：")
    # import json
    # print(json.dumps(details, ensure_ascii=False, indent=2))
    
    # 可选：保存不匹配详情到文件
    if details["unmatched_coords"]:
        pd.DataFrame(details["unmatched_coords"]).to_csv(
            "unmatched_cells_details.csv", 
            index=False, 
            encoding='utf-8'
        )
        print("\n不匹配单元格详情已保存到：unmatched_cells_details.csv")