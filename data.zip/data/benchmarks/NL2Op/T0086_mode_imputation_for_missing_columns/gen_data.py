#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成两份 CSV：
1. raw/customers.csv        —— 分类列含缺失("" / "NA")
2. expected/gt.csv          —— 分类列已用列众数填补
   （数值列保持与原始数据一致）
"""

from pathlib import Path
import random
import numpy as np
import pandas as pd

# ────── 参数 ──────
N_ROWS          = 160
NUMERIC_COLS    = ["age", "income"]
CATEGORIC_COLS  = ["gender", "region", "segment"]
NA_RATIO_CAT    = 0.15          # 分类列缺失比例
RAW_DIR         = Path("raw")
EXP_DIR         = Path("expected")
RAW_FILE        = RAW_DIR / "customers.csv"
GT_FILE         = EXP_DIR / "gt.csv"
# ─────────────────

random.seed(42)
np.random.seed(42)


def build_dataframe() -> pd.DataFrame:
    df = pd.DataFrame({
        "age":    np.random.randint(18, 70,  size=N_ROWS),
        "income": np.round(np.random.normal(7.5e4, 2e4, N_ROWS), 2),
        "gender":  np.random.choice(["M", "F"],                  N_ROWS),
        "region":  np.random.choice(["North", "South", "East",
                                     "West"],                    N_ROWS),
        "segment": np.random.choice(["VIP", "Gold", "Silver",
                                     "Bronze"],                  N_ROWS),
    })

    # 给分类列插入缺失("" / "NA")
    for col in CATEGORIC_COLS:
        df[col] = df[col].astype(object)
        miss_idx = np.random.choice(N_ROWS,
                                    size=int(N_ROWS * NA_RATIO_CAT),
                                    replace=False)
        for i in miss_idx:
            df.at[i, col] = random.choice(["", "NA"])
    return df


def main() -> None:
    RAW_DIR.mkdir(exist_ok=True)
    EXP_DIR.mkdir(exist_ok=True)

    df_raw = build_dataframe()
    df_raw.to_csv(RAW_FILE, index=False, encoding="utf-8")

    # 分类列按众数填补
    df_gt = df_raw.copy()
    for col in CATEGORIC_COLS:
        mode_val = (
            df_gt[col]
            .replace({"": np.nan, "NA": np.nan})
            .mode(dropna=True)
            .iloc[0]  # 若多众数，pandas.mode 返回排序后首个
        )
        df_gt[col] = df_gt[col].replace({"": np.nan, "NA": np.nan}).fillna(mode_val)

    df_gt.to_csv(GT_FILE, index=False, encoding="utf-8")
    print("✓ 数据已生成：")
    print(f"  RAW -> {RAW_FILE.resolve()}")
    print(f"  GT  -> {GT_FILE.resolve()}")


if __name__ == "__main__":
    main()