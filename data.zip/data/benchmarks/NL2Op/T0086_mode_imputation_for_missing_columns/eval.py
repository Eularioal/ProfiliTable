#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
评测脚本 —— 检查选手是否对所有分类列按列众数填补缺失值
用法:
    python eval.py -o <candidate.csv>
成功: {"eval_score":"1.0"}   失败: {"eval_score":"0.0"} 并写原因到 stderr
"""

from __future__ import annotations
import argparse, json, sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT       = Path(__file__).resolve().parent
RAW_CSV    = ROOT / "raw" / "customers.csv"
GT_CSV     = ROOT / "expected" / "gt.csv"
ATOL       = 1e-8   # 数值列误差（本任务不考察，但仍保留）

# ────────── 工具 ──────────
def fail(msg: str, code: int = 1) -> None:
    print(f"[eval] {msg}", file=sys.stderr)
    print(json.dumps({"eval_score": "0.0"}))
    sys.exit(code)


def read_csv(path: Path, treat_na: bool = False) -> pd.DataFrame:
    na_vals = ["", "NA"] if treat_na else None
    return pd.read_csv(path, na_values=na_vals)


# ────────── 评测核心 ──────────
def evaluate(pred: pd.DataFrame,
             gt: pd.DataFrame,
             raw: pd.DataFrame) -> float:
    # 1) 行列检查
    if pred.shape != gt.shape:
        fail(f"行列数不一致: 期望{gt.shape}, 实际{pred.shape}")
    if set(pred.columns) != set(gt.columns):
        miss  = set(gt.columns) - set(pred.columns)
        extra = set(pred.columns) - set(gt.columns)
        if miss:
            fail(f"缺少列: {', '.join(miss)}")
        if extra:
            fail(f"多余列: {', '.join(extra)}")
    pred = pred[gt.columns]

    # 2) 识别分类列 (= 非数值列)
    num_cols = gt.select_dtypes(include=[np.number]).columns.tolist()
    cat_cols = [c for c in gt.columns if c not in num_cols]
    if not cat_cols:
        fail("未检测到分类列")

    # 3) 分类列必须与 gt 中的众数填补结果一致且无缺失
    for col in cat_cols:
        if pred[col].isna().any() or (pred[col] == "").any() or (pred[col] == "NA").any():
            fail(f"分类列 {col} 仍包含缺失值")
        if not pred[col].astype(str).equals(gt[col].astype(str)):
            fail(f"分类列 {col} 不是众数填补结果")

    # 4) 数值列应保持与原始数据一致（不强求填补）
    if num_cols:
        # diff_flag = ~(pred[num_cols].astype(float).round(8)
        #               .equals(raw[num_cols].astype(float).round(8)))
        diff_flag = not pred[num_cols].astype(float).round(8).equals(
    raw[num_cols].astype(float).round(8)
)

        if diff_flag:
            fail("数值列被不必要地修改")

    return 1.0


# ────────── CLI ──────────
def main() -> None:
    ap = argparse.ArgumentParser(description="Evaluate mode-imputation (categorical) operator")
    ap.add_argument("-o", "--output", required=True, help="candidate CSV file")
    args = ap.parse_args()

    cand_path = Path(args.output)
    if not cand_path.exists():
        fail(f"文件不存在: {cand_path}")

    try:
        raw = read_csv(RAW_CSV, treat_na=True)
        gt  = read_csv(GT_CSV)
        cand = read_csv(cand_path)
    except Exception as exc:
        fail(f"读取 CSV 失败: {exc}")

    score = evaluate(cand, gt, raw)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        fail(f"评测异常: {exc}", code=2)