#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “错误修正” 算子

使用方法
--------
python eval.py -o /path/to/your_output.csv

说明
----
1. 基准文件固定为同级目录 expected/gt.csv
2. -o 指向数据算子的输出CSV文件（预测结果）
3. 评测逻辑：
   - 验证GT和预测文件的列名完全一致（顺序+名称），列名不一致则F1-score为0
   - GT中带**标注的单元格为「需要修正的目标单元格（正例）」
   - 移除所有单元格值中的**标注后进行值比对
   - 基于标注单元格计算F1-score（错误修正场景适配）
4. 评测指标：F1-score（针对需要修正的单元格）
5. 指标范围 ∈ [0,1]，输出格式：{"eval_score": F1值（保留4位小数）}
"""

from __future__ import annotations
import argparse
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Tuple, Optional, Dict, List

# ------------------------------------------------------------------ 常量
GT_PATH = Path(__file__).parent / "expected" / "gt.csv"  # 固定基准文件路径
MISSING_LABEL = ""  # 缺失值统一标记（仅用于填充NaN/None，不修改其他值）
ANNOTATION_MARKER = "**"  # 错误修正单元格标注符

# ------------------------------------------------------------------ 工具函数
def remove_annotation(val: str) -> str:
    """移除单元格值中的**标注符，返回纯净业务值"""
    if isinstance(val, str) and ANNOTATION_MARKER in val:
        return val.replace(ANNOTATION_MARKER, "").strip()
    return str(val).strip()

def read_and_validate_data(gt_path: str | Path, pred_path: str | Path) -> Tuple[Optional[pd.DataFrame], Optional[pd.DataFrame], Optional[pd.DataFrame]]:
    """
    读取GT和Pred数据，验证列名一致性，对齐行数
    返回：(GT纯净值矩阵, Pred纯净值矩阵, GT标注单元格掩码)
    """
    # 1. 读取GT文件（强制字符串类型，避免数值/字符串比对问题）
    try:
        df_gt_raw = pd.read_csv(gt_path, dtype=str).fillna(MISSING_LABEL)
    except Exception as e:
        print(f"GT文件读取失败: {e}")
        return None, None, None
    
    # 2. 读取Pred文件（强制字符串类型）
    try:
        df_pred_raw = pd.read_csv(pred_path, dtype=str).fillna(MISSING_LABEL)
    except Exception as e:
        print(f"预测文件读取失败: {e}")
        return None, None, None
    
    # 3. 验证列名完全一致（顺序+名称）
    if list(df_gt_raw.columns) != list(df_pred_raw.columns):
        print(f"错误: 列名不一致！")
        print(f"GT列名: {list(df_gt_raw.columns)}")
        print(f"预测文件列名: {list(df_pred_raw.columns)}")
        return None, None, None
    
    # 4. 对齐行数（取最小行数）
    min_rows = min(len(df_gt_raw), len(df_pred_raw))
    df_gt_aligned = df_gt_raw.iloc[:min_rows].copy()
    df_pred_aligned = df_pred_raw.iloc[:min_rows].copy()
    
    # 5. 生成GT标注单元格掩码（True=带**标注/需要修正，False=无需修正）
    mask_annotated = df_gt_aligned.applymap(lambda x: ANNOTATION_MARKER in str(x))
    
    # 6. 移除所有单元格的**标注，得到纯净值矩阵（用于比对）
    df_gt_clean = df_gt_aligned.applymap(remove_annotation)
    df_pred_clean = df_pred_aligned.applymap(remove_annotation)
    
    return df_gt_clean, df_pred_clean, mask_annotated

def compute_f1_score(df_gt: pd.DataFrame, df_pred: pd.DataFrame, mask_annotated: pd.DataFrame) -> Dict[str, float]:
    """
    计算错误修正场景的F1-score：
    - TP: GT标注单元格 + 预测值匹配
    - FN: GT标注单元格 + 预测值不匹配（该修正没改对）
    - FP: GT未标注单元格 + 预测值不匹配（不该改却改了）
    - Precision = TP / (TP + FP)
    - Recall = TP / (TP + FN)
    - F1 = 2 * (Precision * Recall) / (Precision + Recall)
    """
    # 1. 全单元格比对结果（True=值匹配，False=值不匹配）
    cell_match = (df_gt == df_pred)
    
    # 2. 计算TP/FN/FP
    # TP：标注单元格 + 匹配
    tp = int((cell_match & mask_annotated).sum().sum())
    # FN：标注单元格 + 不匹配
    fn = int((~cell_match & mask_annotated).sum().sum())
    # FP：未标注单元格 + 不匹配
    fp = int((~cell_match & ~mask_annotated).sum().sum())
    
    # 3. 计算精确率和召回率（处理分母为0的边界情况）
    precision = tp / (tp + fp) if (tp + fp) > 0 else 1.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 1.0
    
    # 4. 计算F1-score（处理分母为0的边界情况）
    if precision + recall == 0:
        f1 = 0.0
    else:
        f1 = 2 * (precision * recall) / (precision + recall)
    
    f1_rounded = round(f1, 4)
    
    return {
        "f1_score": f1_rounded,
        "tp": tp,
        "fn": fn,
        "fp": fp,
        "precision": round(precision, 4),
        "recall": round(recall, 4)
    }

# ------------------------------------------------------------------ 主流程
def main() -> None:
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="Evaluate error correction output (F1-score)")
    parser.add_argument(
        "-o", "--output", required=True,
        help="Path to CSV produced by your error correction operator (prediction result)"
    )
    args = parser.parse_args()

    # 1. 检查基准文件是否存在
    if not GT_PATH.exists():
        print(f"错误：基准文件不存在，请先创建 {GT_PATH}")
        print({"eval_score": "0.0000"})
        return

    # 2. 读取并验证数据
    df_gt, df_pred, mask_annotated = read_and_validate_data(GT_PATH, args.output)
    if df_gt is None or df_pred is None or mask_annotated is None:
        print({"eval_score": "0.0000"})
        return

    # 3. 计算F1-score
    metrics = compute_f1_score(df_gt, df_pred, mask_annotated)

    # 4. 输出最终结果（符合指定格式）
    print({"eval_score": f"{metrics['f1_score']:.4f}"})

if __name__ == "__main__":
    main()