import csv
import argparse
from pathlib import Path
import json

def load_csv(path):
    data = {}
    with open(path, encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data[row["id"]] = row
    return data

def evaluate(expected_path, processed_path, tolerance=5.0):
    expected_data = load_csv(expected_path)
    processed_data = load_csv(processed_path)

    total = len(expected_data)
    matched = 0

    for id_, exp_rec in expected_data.items():
        pred_rec = processed_data.get(id_)
        if pred_rec is None:
            continue  # 缺失视为不匹配
        try:
            exp_val = float(exp_rec["consumption_kwh"])
            pred_val = float(pred_rec["consumption_kwh"])
        except Exception:
            continue  # 解析失败视为不匹配

        if abs(exp_val - pred_val) <= tolerance:
            matched += 1

    accuracy = matched / total if total > 0 else 0.0
    print(json.dumps({"eval_score": f"{accuracy:.4f}"}))
    return accuracy

def get_gt():
    current_dir = Path(__file__).resolve().parent
    expected_dir = (current_dir / "expected").resolve()
    csv_files = list(expected_dir.glob("*.csv"))
    if not csv_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")
    return csv_files[0]

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate consumption_kwh with tolerance")
    parser.add_argument("-o", "--output", required=True, help="Path to processed csv file")
    parser.add_argument("--tolerance", type=float, default=0.5, help="Tolerance for consumption difference")
    args = parser.parse_args()

    expected_path = get_gt()
    processed_path = Path(args.output)
    evaluate(expected_path, processed_path, args.tolerance)
