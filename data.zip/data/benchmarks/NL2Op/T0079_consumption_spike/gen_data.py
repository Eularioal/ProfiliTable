import os
import random
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from pathlib import Path

TASK_ID = "T0040_"
BASE_DIR = Path(f"data/benchmarks/NL2Op/{TASK_ID}")
RAW_DIR = BASE_DIR / "raw"
EXPECTED_DIR = BASE_DIR / "expected"
RAW_DIR.mkdir(parents=True, exist_ok=True)
EXPECTED_DIR.mkdir(parents=True, exist_ok=True)

def generate_normal_series(meter_id, start_time, length=50):
    """生成平稳的电量消费序列，模拟小时采样"""
    timestamps = [start_time + timedelta(hours=i) for i in range(length)]
    # 正常消费值，正态分布，均值10，标准差2
    consumption = np.random.normal(loc=10, scale=2, size=length)
    consumption = np.clip(consumption, 0, None)  # 不允许负值
    data = []
    for i in range(length):
        data.append({
            "id": f"{meter_id}_{i}",
            "meter_id": meter_id,
            "timestamp": timestamps[i].strftime("%Y-%m-%d %H:%M:%S"),
            "consumption_kwh": round(consumption[i], 3),
            "dirty": False
        })
    return data

def introduce_spikes(data, spike_ratio=0.2):
    """
    在部分数据点引入尖峰异常（比相邻小时高5倍以上）
    返回带脏标记的数据列表
    """
    dirty_data = []
    length = len(data)
    num_spikes = int(length * spike_ratio)
    spike_indices = random.sample(range(1, length-1), num_spikes)  # 不选首尾，方便检测前后邻居
    
    data_copy = data.copy()
    for idx in spike_indices:
        prev_val = data_copy[idx-1]["consumption_kwh"]
        next_val = data_copy[idx+1]["consumption_kwh"]
        base_val = (prev_val + next_val) / 2
        # 制造尖峰，至少5倍基值
        spike_val = base_val * random.uniform(5.1, 10)
        data_copy[idx]["consumption_kwh"] = round(spike_val, 3)
        data_copy[idx]["dirty"] = True
    return data_copy

def create_gt_data(raw_data):
    """
    GT数据为修正后的consumption值（尖峰点替换为邻近平均）
    """
    gt_data = []
    length = len(raw_data)
    for i in range(length):
        item = raw_data[i].copy()
        if item["dirty"]:
            # 用前后邻居平均值替代
            prev_val = raw_data[i-1]["consumption_kwh"] if i > 0 else raw_data[i]["consumption_kwh"]
            next_val = raw_data[i+1]["consumption_kwh"] if i < length -1 else raw_data[i]["consumption_kwh"]
            item["consumption_kwh"] = round((prev_val + next_val) / 2, 3)
            item["dirty"] = False
        gt_data.append(item)
    return gt_data

def main():
    random.seed(42)
    np.random.seed(42)

    total_meters = 5
    points_per_meter = 20  # 总100条数据

    all_raw = []
    all_gt = []

    start_dt = datetime(2024, 1, 1, 0, 0, 0)

    for meter_i in range(total_meters):
        meter_id = f"METER_{meter_i:03d}"
        normal_series = generate_normal_series(meter_id, start_dt, length=points_per_meter)
        raw_series = introduce_spikes(normal_series, spike_ratio=0.2)  # 40%点带脏数据

        gt_series = create_gt_data(raw_series)

        all_raw.extend(raw_series)
        all_gt.extend(gt_series)

    # 保存raw文件（含脏数据）
    raw_path = RAW_DIR / "customers.csv"
    df_raw = pd.DataFrame(all_raw)
    df_raw.to_csv(raw_path, index=False, encoding="utf-8")

    # 保存gt文件（含修正数据）
    expected_path = EXPECTED_DIR / "gt.csv"
    df_gt = pd.DataFrame(all_gt)
    df_gt.to_csv(expected_path, index=False, encoding="utf-8")

    print(f"Raw data saved to: {raw_path}")
    print(f"GT data saved to: {expected_path}")

if __name__ == "__main__":
    main()
