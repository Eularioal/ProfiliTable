import csv
import os
import random
import re

def format_numbers_in_text(text):
    def format_match(match):
        number = float(match.group())
        return f"{number:.2f}"
    return re.sub(r"\d+(\.\d+)?", format_match, text)

def generate_clean_rows(topics, per_topic=5):
    """生成没有数字或数字已格式化的合法行"""
    entries = []
    idx = 0
    for topic in topics:
        for _ in range(per_topic):
            entries.append({
                "id": str(idx),
                "text": f"The result for {topic} is {round(random.uniform(1, 100), 2):.2f}",
                "topic": topic
            })
            idx += 1
    return entries

def generate_dirty_rows(start_id=1000):
    dirty = [
        ("Discount is 0.5555", "pricing"),
        ("Score was 4.2", "evaluation"),
        ("Accuracy reached 0.999", "metrics"),
        ("Time taken: 12.0 seconds", "timing"),
        ("Battery at 75", "status"),

        ("Interest rate is 3.14159%", "finance"),
        ("Response time is 100.5 ms", "performance"),
        ("Your grade is 89.123", "education"),
        ("Conversion rate: 0.8", "marketing"),
        ("Final amount: 45", "invoice"),

        ("It weighs 5.6", "weight"),
        ("Completion rate is 99.999%", "analytics"),
        ("The reading was 7", "sensor"),
        ("Memory usage: 2048.0 MB", "system"),
        ("Progress: 87.777%", "ui"),

        ("Speed is 27.5 km/h", "transport"),
        ("He scored 6", "game"),
        ("Temperature: 36.678°C", "weather"),
        ("Probability: 0.0001", "statistics"),
        ("Total income: 1200", "report"),
        
        ("Discount is 0.5555", "pricing"),
        ("Score was 4.2", "evaluation"),
        ("Accuracy reached 0.999", "metrics"),
        ("Time taken: 12.0 seconds", "timing"),
        ("Battery at 75", "status"),

        ("Interest rate is 3.14159%", "finance"),
        ("Response time is 100.5 ms", "performance"),
        ("Your grade is 89.123", "education"),
        ("Conversion rate: 0.8", "marketing"),
        ("Final amount: 45", "invoice"),

        ("It weighs 5.6", "weight"),
        ("Completion rate is 99.999%", "analytics"),
        ("The reading was 7", "sensor"),
        ("Memory usage: 2048.0 MB", "system"),
        ("Progress: 87.777%", "ui"),

        ("Speed is 27.5 km/h", "transport"),
        ("He scored 6", "game"),
        ("Temperature: 36.678°C", "weather"),
        ("Probability: 0.0001", "statistics"),
        ("Total income: 1200", "report"),

        ("Altitude is 350.0 meters", "geography"),
        ("Ping time was 50.1 ms", "network"),
        ("Success rate: 99.9999%", "metrics"),
        ("Clicks: 18", "ads"),
        ("Total duration: 8.333 hours", "media"),

        ("Exchange rate is 1.23456", "finance"),
        ("Threshold value: 0.7", "ai"),
        ("Points earned: 4000", "rewards"),
        ("Pressure was 101.325", "weather"),
        ("Storage left: 5.0 GB", "device"),

        ("Balance: 987", "banking"),
        ("Air quality index: 145.5", "environment"),
        ("You got 91.111%", "grading"),
        ("Frame rate: 59.94 fps", "video"),
        ("Load average: 0.876", "server"),

        ("Estimated time: 15.000 min", "scheduling"),
        ("File size: 20480", "storage"),
        ("Power output: 23.4567 kW", "energy"),
        ("Chance of rain: 66%", "weather"),
        ("Viewers: 123456", "streaming"),

        ("Latency: 0.95 ms", "network"),
        ("Travel distance: 305.7 km", "navigation"),
        ("Volume is 4", "audio"),
        ("Reported cases: 1205", "health"),
        ("CO2 level: 414.12 ppm", "climate"),

        ("Cycle count: 1500", "hardware"),
        ("Bounce rate: 57.789%", "web"),
        ("Gas level: 9.999%", "sensor"),
        ("Stock price: 280.12345", "finance"),
        ("Likes: 9999", "social"),

        ("Humidity: 83.333%", "climate"),
        ("Wait time: 2.5 min", "ui"),
        ("Task finished in 1.0 second", "backend"),
        ("Data transferred: 1048576", "infra"),
        ("Overhead: 3.0001%", "system"),

        ("Signal strength: -67.1 dBm", "network"),
        ("Electricity usage: 11.11 kWh", "utility"),
        ("Relevance score: 0.1", "ranking"),
        ("Response: 250", "server"),
        ("Bandwidth: 300.000 Mbps", "cloud"),

        ("Crash count: 32", "qa"),
        ("Training loss: 0.123456", "ml"),
        ("Retries: 5", "pipeline"),
        ("Defect rate: 2.222%", "manufacturing"),
        ("Download speed: 85.3333 Mbps", "internet"),

        ("Image resolution: 4096", "graphics"),
        ("Steps taken: 12345", "health"),
        ("Risk level: 0.0009", "finance"),
        ("Engagement: 91%", "marketing"),
        ("Production units: 88", "factory"),

        ("Render time: 24.06", "animation"),
        ("Score dropped to 3.0", "game"),
        ("Queue length: 78", "service"),
        ("Performance ratio: 1.0001", "benchmark"),
        ("Refunds: 4", "billing"),
    ]

    return [
        {"id": str(start_id + i), "text": text, "topic": topic}
        for i, (text, topic) in enumerate(dirty)
    ]

def write_csv(path, rows):
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "text", "topic"])
        writer.writeheader()
        writer.writerows(rows)

def main():
    # os.makedirs("data/benchmarks/NL2Op/T0005/raw", exist_ok=True)
    # os.makedirs("data/benchmarks/NL2Op/T0002-2/expected", exist_ok=True)

    topics = ["speed", "temperature", "performance", "accuracy", "cost"]
    clean_rows = generate_clean_rows(topics, per_topic=4)  # 25 clean rows
    dirty_rows = generate_dirty_rows()                    # 5 dirty rows

    all_rows = clean_rows + dirty_rows
    random.shuffle(all_rows)

    # 保存 raw/input.csv（混合数据）
    write_csv("data/benchmarks/NL2Op/T0005_/raw/customers.csv", all_rows)

    # 保存 expected/output.csv（格式化数字为两位小数）
    formatted_rows = []
    for row in all_rows:
        row_clean = row.copy()
        row_clean["text"] = format_numbers_in_text(row["text"])
        formatted_rows.append(row_clean)

    write_csv("data/benchmarks/NL2Op/T0005_/expected/gt.csv", formatted_rows)

    print("✅ CSV data generated at raw/input.csv and expected/output.csv")

if __name__ == "__main__":
    main()
