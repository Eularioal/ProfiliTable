#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
gen_data.py ─ 基准假数据 · LEFT SEMI JOIN (distinct) 版本
--------------------------------------------------------
1. raw/customers1.csv   左表 (≥100 行，含约 20% 键重复)
2. raw/customers2.csv   右表 (≈40% unique_id 匹配)
3. expected/gt.csv      左表中“存在匹配键”的首行子集
"""

import os
import random
from datetime import date, timedelta

import pandas as pd
from faker import Faker

# ─────────── 可调参数 ───────────
UNIQUE_IDS      = 120      # 左表唯一 customer_id 个数
DUP_RATIO       = 0.20     # 左表中出现重复键的比例
MATCH_RATIO     = 0.40     # 会出现在右表的 id 占比
SEED            = 2024

random.seed(SEED)
fake = Faker("en_US")
Faker.seed(SEED)

# ─────────── 目录 ───────────
os.makedirs("raw", exist_ok=True)
os.makedirs("expected", exist_ok=True)

# ─────────── 1. 生成左表 customers1 ───────────
def rand_signup():
    start = date.today() - timedelta(days=730)
    return fake.date_between(start_date=start, end_date="today").isoformat()

rows = []
for cid in range(1, UNIQUE_IDS + 1):
    # 首行（一定保留）
    rows.append(
        {
            "customer_id": cid,
            "name": fake.first_name(),
            "signup_date": rand_signup(),
            "segment": random.choice(["A", "B", "C"]),
        }
    )
    # 是否制造重复行
    if random.random() < DUP_RATIO:
        rows.append(
            {
                "customer_id": cid,             # 与首行相同键
                "name": fake.first_name(),      # 其他列可不同
                "signup_date": rand_signup(),
                "segment": random.choice(["A", "B", "C"]),
            }
        )

customers1 = pd.DataFrame(rows)
# 写入保持生成顺序 → “首行”=第一次出现
customers1.to_csv("raw/customers1.csv", index=False)

# ─────────── 2. 生成右表 customers2 ───────────
product_catalog = [
    "Widget", "Gadget", "Thingamajig", "Doohickey", "Contraption",
    "Whatchamacallit", "Gizmo", "Device", "Apparatus", "Instrument",
]

match_ids = random.sample(range(1, UNIQUE_IDS + 1), k=int(UNIQUE_IDS * MATCH_RATIO))

def rand_purchase():
    start = date.today() - timedelta(days=400)
    return fake.date_between(start_date=start, end_date="today").isoformat()

customers2 = pd.DataFrame(
    {
        "customer_id": match_ids,
        "product_name": [random.choice(product_catalog) for _ in match_ids],
        "last_purchase": [rand_purchase() for _ in match_ids],
    }
).sort_values("customer_id")

customers2.to_csv("raw/customers2.csv", index=False)

# ─────────── 3. 构造真值：LEFT SEMI JOIN (distinct) ───────────
semi = customers1[customers1["customer_id"].isin(customers2["customer_id"])]
semi_distinct = semi.drop_duplicates(subset="customer_id", keep="first")
# 仅保留左表列
semi_distinct.to_csv("expected/gt.csv", index=False)

print("✅ 假数据已生成：raw/*.csv 与 expected/gt.csv")