#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “行扩充” 算子

使用方法
--------
python eval.py -o /path/to/your_output.csv

说明
----
1. 基准文件固定为同级目录 expected/gt.csv
2. -o 指向数据算子的输出CSV文件（预测结果）
3. 评测逻辑：
   - GT表第一列为行号列，带**标注的行是需校验的新增行，仅计算这些行的Accuracy
   - Pred表无行号列，需先移除GT表的行号列再做列名验证
   - 验证移除行号后的GT和预测文件列名完全一致（顺序+名称）
   - 逐单元格原始值比对，整行所有单元格一致则该行正确
   - 仅对GT表中带**的行进行准确率计算
4. 评测指标：Row-level Accuracy（新增行正确行数/新增行总比对行数）
5. 指标范围 ∈ [0,1]，输出格式：{"eval_score": 准确率（保留4位小数）}
"""

from __future__ import annotations
import argparse
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Tuple, Optional, Dict, List

# ------------------------------------------------------------------ 常量
GT_PATH = Path(__file__).parent / "expected" / "gt.csv"  # 固定基准文件路径
MISSING_LABEL = ""  # 缺失值统一标记（仅用于填充NaN/None，不修改其他值）

# ------------------------------------------------------------------ 工具函数
def read_and_validate_data(gt_path: str | Path, pred_path: str | Path) -> Tuple[Optional[pd.DataFrame], Optional[pd.DataFrame], Optional[List[int]]]:
    """
    读取GT和Pred数据，处理GT表行号列，验证列名一致性，对齐行数
    返回：(处理后的GT数据(去行号列), 处理后的Pred数据, 带**的新增行索引列表)
    """
    # 1. 读取GT文件（保留原始值）
    try:
        df_gt = pd.read_csv(gt_path)
    except Exception as e:
        print(f"GT文件读取失败: {e}")
        return None, None, None
    
    # 2. 提取行号列并筛选带**的新增行索引
    row_num_col = df_gt.columns[0]  # 第一列为行号列
    # 找出行号值包含**的行的索引
    target_rows_mask = df_gt[row_num_col].astype(str).str.contains(r'\*\*', regex=True)
    target_rows_idx = df_gt[target_rows_mask].index.tolist()
    if not target_rows_idx:
        print("警告：GT表中未找到带**标注的新增行，准确率将为0.0000")
    
    # 3. 移除GT表的行号列（保留剩余列用于和pred表比对）
    df_gt_no_rownum = df_gt.drop(columns=[row_num_col])
    
    # 4. 读取Pred文件（保留原始值）
    try:
        df_pred = pd.read_csv(pred_path)
    except Exception as e:
        print(f"预测文件读取失败: {e}")
        return None, None, None
    
    # 5. 验证列名完全一致（顺序+名称）- 基于去行号后的GT表
    if list(df_gt_no_rownum.columns) != list(df_pred.columns):
        print(f"错误: 列名不一致！")
        print(f"GT列名(去行号后): {list(df_gt_no_rownum.columns)}")
        print(f"预测文件列名: {list(df_pred.columns)}")
        return None, None, None
    
    # 6. 对齐行数（取最小行数）
    min_rows = min(len(df_gt_no_rownum), len(df_pred))
    df_gt_aligned = df_gt_no_rownum.iloc[:min_rows].copy()
    df_pred_aligned = df_pred.iloc[:min_rows].copy()
    
    # 7. 过滤目标行索引：仅保留在对齐行数范围内的带**行索引
    target_rows_idx_filtered = [idx for idx in target_rows_idx if idx < min_rows]
    
    # 8. 仅填充缺失值（NaN/None→空字符串），不修改其他任何值
    df_gt_aligned = df_gt_aligned.fillna(MISSING_LABEL)
    df_pred_aligned = df_pred_aligned.fillna(MISSING_LABEL)
    
    print(f"数据验证完成 - 有效比对总行数: {min_rows}, 需校验新增行数量: {len(target_rows_idx_filtered)}")
    return df_gt_aligned, df_pred_aligned, target_rows_idx_filtered

def compute_target_row_accuracy(df_gt: pd.DataFrame, df_pred: pd.DataFrame, target_rows_idx: List[int]) -> Dict[str, float]:
    """
    计算指定行（带**的新增行）的Accuracy：仅校验目标行的单元格一致性
    返回：包含accuracy、correct_rows、total_target_rows的指标字典
    """
    if not target_rows_idx:
        return {
            "accuracy": 0.0,
            "correct_rows": 0,
            "total_target_rows": 0
        }
    
    # 逐行比对所有单元格原始值
    row_match = (df_gt == df_pred).all(axis=1)
    
    # 仅筛选目标行的比对结果
    target_match = row_match.iloc[target_rows_idx]
    correct_rows = int(target_match.sum())
    total_target_rows = len(target_match)
    
    # 计算Accuracy（避免零除法）
    accuracy = correct_rows / total_target_rows if total_target_rows > 0 else 0.0
    accuracy_rounded = round(accuracy, 4)
    
    return {
        "accuracy": accuracy_rounded,
        "correct_rows": correct_rows,
        "total_target_rows": total_target_rows
    }

# ------------------------------------------------------------------ 主流程
def main() -> None:
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="Evaluate Data Standardization output (Target Row-level Accuracy)")
    parser.add_argument(
        "-o", "--output", required=True,
        help="Path to CSV produced by your data standardization operator (prediction result)"
    )
    args = parser.parse_args()

    # 1. 检查基准文件是否存在
    if not GT_PATH.exists():
        print(f"错误：基准文件不存在，请先创建 {GT_PATH}")
        print({"eval_score": "0.0000"})
        return

    # 2. 读取并验证数据（处理行号列+筛选目标行）
    df_gt, df_pred, target_rows_idx = read_and_validate_data(GT_PATH, args.output)
    if df_gt is None or df_pred is None:
        print({"eval_score": "0.0000"})
        return

    # 3. 计算目标行（带**新增行）的Accuracy
    metrics = compute_target_row_accuracy(df_gt, df_pred, target_rows_idx)

    # 4. 输出最终结果（符合指定格式）
    print(f"新增行校验结果 - 正确行数: {metrics['correct_rows']}, 总校验行数: {metrics['total_target_rows']}")
    print({"eval_score": f"{metrics['accuracy']:.4f}"})

if __name__ == "__main__":
    main()