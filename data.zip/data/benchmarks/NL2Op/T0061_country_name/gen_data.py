import json
import random
import csv
from pathlib import Path

# 简单国家名到ISO 3166-1 alpha-2代码映射（可扩展）
COUNTRY_MAP = {
    "China": "CN",
    "United States": "US",
    "France": "FR",
    "Germany": "DE",
    "Japan": "JP",
    "United Kingdom": "GB",
    "Canada": "CA",
    "Australia": "AU",
    "Brazil": "BR",
    "India": "IN",
    "Russia": "RU",
    "South Korea": "KR",
    # 可根据需要添加更多
}

def random_country_name(code):
    # 从映射反查部分国家名，随机返回一个对应国家名或不同大小写形式
    candidates = [k for k, v in COUNTRY_MAP.items() if v == code]
    if not candidates:
        return code
    name = random.choice(candidates)
    # 随机大小写变换模拟不规范脏数据
    def random_case(s):
        return ''.join(c.upper() if random.random() > 0.5 else c.lower() for c in s)
    return random_case(name)

def gen_gt_data(num=100):
    data = []
    for i in range(1, num + 1):
        code = random.choice(list(COUNTRY_MAP.values()))
        record = {
            "id": i,
            "supplier_id": f"S{i:05d}",
            "company_name": f"Company_{i}",
            "country": code,  # GT数据是标准代码
        }
        data.append(record)
    return data

def gen_dirty_data(gt_data, dirty_ratio=0.8):
    dirty_data = []
    num_dirty = int(len(gt_data) * dirty_ratio)
    dirty_indices = set(random.sample(range(len(gt_data)), num_dirty))

    for idx, record in enumerate(gt_data):
        rec = record.copy()
        if idx in dirty_indices:
            # 80%条目country字段是非标准格式的国家名（脏数据）
            code = rec["country"]
            rec["country"] = random_country_name(code)
        dirty_data.append(rec)
    return dirty_data

def save_jsonl(data, path):
    with open(path, "w", encoding="utf-8") as f:
        for rec in data:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

def save_csv(data, path):
    keys = data[0].keys()
    with open(path, "w", encoding="utf-8", newline='') as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(data)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--task_id", type=str, required=True, help="任务ID，用于目录命名")
    parser.add_argument("--format", choices=["jsonl", "csv"], default="jsonl")
    args = parser.parse_args()

    task_dir = Path(f"data/benchmarks/NL2Op/{args.task_id}_")
    expected_dir = task_dir / "expected"
    raw_dir = task_dir / "raw"
    expected_dir.mkdir(parents=True, exist_ok=True)
    raw_dir.mkdir(parents=True, exist_ok=True)

    gt_data = gen_gt_data(num=100)
    dirty_data = gen_dirty_data(gt_data, dirty_ratio=0.8)

    if args.format == "jsonl":
        save_jsonl(gt_data, expected_dir / "gt.jsonl")
        save_jsonl(dirty_data, raw_dir / "customers.jsonl")
    else:
        save_csv(gt_data, expected_dir / "gt.csv")
        save_csv(dirty_data, raw_dir / "customers.csv")

    print(f"生成完成，GT数据100条，脏数据共100条（其中80条country为非标准名称）")

    # 可选调用大模型（示例，视需要调整prompt）
    # from utils.llm_serving import LLMServing
    # llm = LLMServing()
    # user_inputs = [f"Write a short formal sentence about {rec['company_name']}" for rec in gt_data]
    # system_prompt = "You are an AI that writes formal English."
    # results = llm.generate_from_input(user_inputs, system_prompt)
