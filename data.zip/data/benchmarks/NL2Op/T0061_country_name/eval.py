import csv
import json
import argparse
from pathlib import Path

def load_csv(path):
    data = {}
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            id_ = row.get("id", "").strip()
            if id_:
                data[id_] = row
    return data

def compare_records(expected_rec, pred_rec):
    # id, supplier_id, company_name 完全相同（严格匹配）
    if expected_rec.get("id", "").strip() != pred_rec.get("id", "").strip():
        return False
    if expected_rec.get("supplier_id", "") != pred_rec.get("supplier_id", ""):
        return False
    if expected_rec.get("company_name", "") != pred_rec.get("company_name", ""):
        return False
    # country 字段大小写不敏感比较
    expected_country = expected_rec.get("country", "").strip().upper()
    pred_country = pred_rec.get("country", "").strip().upper()
    return expected_country == pred_country

def evaluate(expected_path, processed_path):
    expected_data = load_csv(expected_path)
    processed_data = load_csv(processed_path)

    total = len(expected_data)
    matched = 0
    mismatches = []

    for id_, exp_rec in expected_data.items():
        pred_rec = processed_data.get(id_)
        if pred_rec is None:
            mismatches.append((id_, "missing", exp_rec, None))
        else:
            if compare_records(exp_rec, pred_rec):
                matched += 1
            else:
                mismatches.append((id_, "mismatch", exp_rec, pred_rec))

    accuracy = matched / total if total > 0 else 0.0

    print(json.dumps({"eval_score": f"{accuracy:.4f}"}))
    # if mismatches:
    #     print(f"\nMismatches ({len(mismatches)}):")
    #     for i, (id_, status, exp, pred) in enumerate(mismatches, 1):
    #         print(f"[{i}] ID: {id_}, Status: {status}")
    #         print("  Expected:", json.dumps(exp, ensure_ascii=False))
    #         print("  Predicted:", json.dumps(pred, ensure_ascii=False) if pred else "None")

    return accuracy

def get_gt():
    current_dir = Path(__file__).resolve().parent
    expected_dir = (current_dir / "expected").resolve()
    csv_files = list(expected_dir.glob("*.csv"))
    if not csv_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")
    return csv_files[0]

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate country code normalization (CSV)")
    parser.add_argument("-o", "--output", required=True, help="Path to processed csv file")
    args = parser.parse_args()

    expected_path = get_gt()
    processed_path = Path(args.output)
    evaluate(expected_path, processed_path)
