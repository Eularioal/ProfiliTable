import json
import os
from pathlib import Path
from uuid import uuid4

from utils.llm_serving import LLMServing

llm = LLMServing()

# 项目符号（需过滤的前缀）
BULLETS = ['-', '*', '•']

# 文件路径
base_path = Path("data/benchmarks/NL2Op/T0021_")
raw_path = base_path / "raw"
expected_path = base_path / "expected"

raw_path.mkdir(parents=True, exist_ok=True)
expected_path.mkdir(parents=True, exist_ok=True)

raw_file = raw_path / "customers.jsonl"
gt_file = expected_path / "gt.jsonl"

# Step 1: 生成脏数据（80条，以项目符号开头）
bullet_prompt = "Write a short formal sentence that starts with a bullet point like '-', '*', or '•'."
dirty_inputs = [bullet_prompt for _ in range(80)]
dirty_system = "You are a helpful assistant generating bulleted formal statements."

dirty_results = llm.generate_from_input(dirty_inputs, dirty_system)

# Step 2: 生成金数据（20条，正常句子）
topics = ["science", "history", "education", "technology"]
clean_inputs = [f"Write a short formal sentence about {topic}." for topic in topics for _ in range(5)]
clean_system = "You are an AI that writes formal English."
clean_results = llm.generate_from_input(clean_inputs, clean_system)

# Step 3: 构造 JSONL 并保存
raw_records = []
gt_records = []

# Add 80 dirty (to be filtered)
for text in dirty_results:
    entry = {"id": str(uuid4()), "text": text.strip()}
    raw_records.append(entry)
    # 不加入 gt，因为要被过滤

# Add 20 clean (should remain in gt)
for text in clean_results:
    entry = {"id": str(uuid4()), "text": text.strip()}
    raw_records.append(entry)
    gt_records.append(entry)  # 保留干净数据

# 保存 raw
with raw_file.open("w", encoding="utf-8") as f:
    for entry in raw_records:
        json.dump(entry, f, ensure_ascii=False)
        f.write("\n")

# 保存 gt
with gt_file.open("w", encoding="utf-8") as f:
    for entry in gt_records:
        json.dump(entry, f, ensure_ascii=False)
        f.write("\n")

print(f"✅ Generated: {len(raw_records)} raw entries (with bullets + clean)")
print(f"✅ Generated: {len(gt_records)} gold entries (clean only)")
