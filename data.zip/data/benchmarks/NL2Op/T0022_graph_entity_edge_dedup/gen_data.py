#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py – 基准数据生成脚本（仅 CSV）
=====================================

目录结构（脚本自动创建）::
    .
    ├── expected
    │   └── gt.csv        # ground-truth
    └── raw
        └── customers.csv # 带脏数据

gt.csv 由两部分拼接而成，靠列名区分：
    1) 节点映射表   input_id,input_label,canon_id,canon_label
    2) 冗余边清单   redundant_src,redundant_dst,edge_type,weight
"""

import csv
import random
from pathlib import Path

random.seed(42)

# ------------------------------------------------------------
# ❶ 生成参数
# ------------------------------------------------------------
N_CANONICAL_NODES   = 10     # “真实”节点数量
DUP_VARIANTS_PER_ID = 2      # 每个节点造几个脏别名
EDGE_PER_PAIR       = 3      # 每对节点（有向）生成多少条边
EDGE_TYPES          = ["buy", "click", "transfer"]

# ------------------------------------------------------------
# ❷ 目录 & 文件准备
# ------------------------------------------------------------
ROOT = Path(__file__).resolve().parent
RAW_DIR = ROOT / "raw"
EXP_DIR = ROOT / "expected"
RAW_DIR.mkdir(parents=True, exist_ok=True)
EXP_DIR.mkdir(parents=True, exist_ok=True)

RAW_CSV = RAW_DIR / "customers.csv"
GT_CSV  = EXP_DIR / "gt.csv"

# ------------------------------------------------------------
# ❸ 工具：制造别名（大小写 & 空白差异）
# ------------------------------------------------------------
def alias(label: str, var: int) -> str:
    if var == 0:
        return f" {label} "
    elif var == 1:
        return label.upper()
    else:
        # 基于概率随意大小写混排并插空格
        out = []
        for ch in label:
            out.append(ch.upper() if random.random() < 0.5 else ch.lower())
            if random.random() < 0.2:
                out.append(" ")
        return ''.join(out)

# ------------------------------------------------------------
# ❹ 生成节点映射
# ------------------------------------------------------------
canon_nodes = {f"C{i:03d}": f"customer_{i:03d}" for i in range(N_CANONICAL_NODES)}

node_map = {}                                  # 输入节点 → (规范 id, 规范 label)
for cid, clabel in canon_nodes.items():
    node_map[cid] = (cid, clabel)              # 自身也是一种“别名”
    for v in range(DUP_VARIANTS_PER_ID):
        aid  = f"A{len(node_map):03d}"
        node_map[aid] = (cid, clabel)          # 别名指向同一规范节点

# ------------------------------------------------------------
# ❺ 生成边 & 冗余标记
# ------------------------------------------------------------
raw_rows, redundant_rows = [], []
seen = set()   # (canon_src, canon_dst, edge_type)

for src_alias, (src_canon, src_label) in node_map.items():
    for dst_alias, (dst_canon, dst_label) in node_map.items():
        if src_canon == dst_canon:                    # 忽略自环
            continue
        for _ in range(EDGE_PER_PAIR):
            etype  = random.choice(EDGE_TYPES)
            weight = round(random.uniform(0.1, 10.0), 3)

            # 写 raw 行
            raw_rows.append([
                src_alias, dst_alias,                 # id
                alias(src_label, 0), alias(dst_label, 1),  # label 加点噪声
                etype, weight
            ])

            # 判定冗余：规范三元组已出现就算冗余
            key = (src_canon, dst_canon, etype)
            if key in seen:
                redundant_rows.append([src_alias, dst_alias, etype, weight])
            else:
                seen.add(key)

# ------------------------------------------------------------
# ❻ 写 raw/customers.csv
# ------------------------------------------------------------
with RAW_CSV.open("w", newline='', encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(
        ["src_id", "dst_id", "src_label", "dst_label", "edge_type", "weight"]
    )
    writer.writerows(raw_rows)

# ------------------------------------------------------------
# ❼ 写 expected/gt.csv
#     前半部分：节点映射表
#     后半部分：冗余边（空行分隔，便于阅读）
# ------------------------------------------------------------
with GT_CSV.open("w", newline='', encoding="utf-8") as f:
    writer = csv.writer(f)

    # 7.1 节点映射
    writer.writerow(["input_id", "input_label", "canon_id", "canon_label"])
    for nid, (cid, clabel) in node_map.items():
        writer.writerow([nid, canon_nodes[cid], cid, clabel])

    # 空行分隔
    writer.writerow([])

    # 7.2 冗余边
    writer.writerow(["redundant_src", "redundant_dst", "edge_type", "weight"])
    writer.writerows(redundant_rows)

print("✅ 生成完毕:")
print(f"   raw      → {RAW_CSV.relative_to(ROOT)}")
print(f"   expected → {GT_CSV.relative_to(ROOT)}")