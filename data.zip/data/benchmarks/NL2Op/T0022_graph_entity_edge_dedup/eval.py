#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 节点/边去重算子 · 评测脚本（单 CSV 输出）
===========================================================
算子输出 (-o) 只需一个 CSV，包含两段：
    1) 节点映射段 header 必须含 input_id, canon_id
    2) 冗余边段   header 必须含 redundant_src, redundant_dst, edge_type
段与段之间可用空行或其它行分隔。

得分 = (F1_nodes + F1_edges) / 2
脚本只打印 {"eval_score": "<score>"}，保留 4 位小数
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Set, Tuple

ROOT   = Path(__file__).resolve().parent
GT_CSV = ROOT / "expected" / "gt.csv"


# ─────────────────── 通用工具 ────────────────────
def _ls(s: str) -> str:          # lower + strip
    return s.strip().lower()


# ───────────────────── 读取 GT ─────────────────────
def load_gt() -> Tuple[Set[Tuple[str, str]], Set[Tuple[str, str, str]]]:
    nodes: Set[Tuple[str, str]]         = set()
    edges: Set[Tuple[str, str, str]]    = set()
    section = "nodes"

    with GT_CSV.open(encoding="utf-8") as f:
        rdr = csv.reader(f)
        for row in rdr:
            if not row or not any(cell.strip() for cell in row):
                section = "edges"
                continue

            if section == "nodes":
                if _ls(row[0]) == "input_id":
                    in_idx = row.index("input_id")
                    ca_idx = row.index("canon_id")
                    continue
                nodes.add((_ls(row[in_idx]), _ls(row[ca_idx])))
            else:
                if _ls(row[0]) == "redundant_src":
                    s_idx = row.index("redundant_src")
                    d_idx = row.index("redundant_dst")
                    e_idx = row.index("edge_type")
                    continue
                edges.add((_ls(row[s_idx]), _ls(row[d_idx]), _ls(row[e_idx])))
    return nodes, edges


# ───────────────────── 读取预测 ─────────────────────
def load_pred(path: Path) -> Tuple[Set[Tuple[str, str]], Set[Tuple[str, str, str]]]:
    lines = list(csv.reader(path.open(encoding="utf-8")))
    if not lines:
        raise ValueError(f"{path} 为空文件")

    # 找两个 header 行（跳过空行）
    idx_node_hdr = next(
        (i for i, r in enumerate(lines) if r and _ls(r[0]) == "input_id"), None
    )
    idx_edge_hdr = next(
        (i for i, r in enumerate(lines) if r and _ls(r[0]) == "redundant_src"), None
    )

    if idx_node_hdr is None:
        raise ValueError("缺少节点映射 header: input_id")
    if idx_edge_hdr is None:
        raise ValueError("缺少冗余边 header: redundant_src")

    node_hdr = {h.lower(): i for i, h in enumerate(lines[idx_node_hdr])}
    edge_hdr = {h.lower(): i for i, h in enumerate(lines[idx_edge_hdr])}

    in_idx = node_hdr.get("input_id")
    ca_idx = node_hdr.get("canon_id")
    if in_idx is None or ca_idx is None:
        raise ValueError("节点映射需包含列 input_id 与 canon_id")

    s_idx = edge_hdr.get("redundant_src")
    d_idx = edge_hdr.get("redundant_dst")
    e_idx = edge_hdr.get("edge_type")
    if s_idx is None or d_idx is None or e_idx is None:
        raise ValueError("冗余边需包含列 redundant_src, redundant_dst, edge_type")

    # 节点映射段
    node_pairs = {
        (_ls(r[in_idx]), _ls(r[ca_idx]))
        for r in lines[idx_node_hdr + 1 : idx_edge_hdr]
        if len(r) > max(in_idx, ca_idx) and any(cell.strip() for cell in r)
    }

    # 冗余边段
    edge_pairs = {
        (_ls(r[s_idx]), _ls(r[d_idx]), _ls(r[e_idx]))
        for r in lines[idx_edge_hdr + 1 :]
        if len(r) > max(s_idx, d_idx, e_idx) and any(cell.strip() for cell in r)
    }

    return node_pairs, edge_pairs


# ───────────────────── 计算 F1 ─────────────────────
def f1(gt: Set[Tuple], pred: Set[Tuple]) -> float:
    tp = len(gt & pred)
    fp = len(pred - gt)
    fn = len(gt - pred)
    p  = tp / (tp + fp) if tp + fp else 0.0
    r  = tp / (tp + fn) if tp + fn else 0.0
    return 2 * p * r / (p + r) if p + r else 0.0


# ─────────────────────── 主函数 ───────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate node/edge deduplication operator (single CSV)")
    parser.add_argument("-o", "--output", required=True, help="CSV produced by your operator")
    args = parser.parse_args()

    out_path = Path(args.output)
    if not out_path.exists():
        print(f"文件不存在: {out_path}", file=sys.stderr)
        sys.exit(1)

    try:
        gt_nodes, gt_edges = load_gt()
        pred_nodes, pred_edges = load_pred(out_path)
        score = (f1(gt_nodes, pred_nodes) + f1(gt_edges, pred_edges)) / 2
        print(json.dumps({"eval_score": f"{score:.4f}"}))
    except Exception as e:
        print(f"[eval.py] 评测失败: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()