import random
import csv
from datetime import datetime
from utils.llm_serving import LLMServing

# Initialize the LLM for potential data generation
llm = LLMServing()

# Helper function to generate a valid date in the format YYYY-MM-DD
def generate_valid_date():
    year = random.randint(2000, 2025)
    month = random.randint(1, 12)
    day = random.randint(1, 28)  # To avoid invalid dates, we'll limit to 28
    return datetime(year, month, day).strftime('%Y-%m-%d')

# Helper function to generate an invalid date
def generate_invalid_date():
    invalid_dates = [
        "April 4th, 2024",  # Month with a suffix
        "2024/01/22",       # Wrong separator
        "2024-02-31",       # Invalid date (Feb 31)
        "2024-13-01",       # Invalid month
        "2024-00-01",       # Invalid month (0)
        "abcd-ef-gh",       # Random invalid string
        "12345",            # Random number
        "01-01-2024",       # Wrong date format (DD-MM-YYYY)
    ]
    return random.choice(invalid_dates)

# Generate 20 GT data entries (valid dates)
def generate_gt_data(num_entries=20):
    gt_data = []
    for _ in range(num_entries):
        data_id = random.randint(1000, 9999)
        valid_date = generate_valid_date()
        gt_data.append({"id": data_id, "text": valid_date})
    return gt_data

# Generate 80 dirty data entries (invalid dates)
def generate_dirty_data(num_entries=80):
    dirty_data = []
    for _ in range(num_entries):
        data_id = random.randint(1000, 9999)
        invalid_date = generate_invalid_date()
        dirty_data.append({"id": data_id, "text": invalid_date})
    return dirty_data

# Function to save data as CSV
def save_to_csv(data, file_path):
    with open(file_path, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=["id", "text"])
        writer.writeheader()
        for row in data:
            writer.writerow(row)

# Generate the data
def generate_data(task_id):
    # Generate GT and dirty data
    gt_data = generate_gt_data()
    dirty_data = generate_dirty_data()
    
    # Save the GT data
    gt_file_path = f"data/benchmarks/NL2Op/{task_id}_/expected/gt.csv"
    save_to_csv(gt_data, gt_file_path)
    
    # Save the dirty data
    dirty_file_path = f"data/benchmarks/NL2Op/{task_id}_/raw/customers.csv"
    save_to_csv(dirty_data, dirty_file_path)

    print(f"Data generation complete. GT data saved to {gt_file_path}, dirty data saved to {dirty_file_path}")

if __name__ == "__main__":
    task_id = "T0023"
    generate_data(task_id)
