#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py — 数值键区间切分算子 · 测试数据生成
─────────────────────────────────────────────
生成：
    raw/customers.csv                    （输入）
    expected/gt1_[0_1000).csv            （0  ≤ balance < 1000）
    expected/gt2_[1000_5000).csv         (1000 ≤ balance < 5000)
    expected/gt3_[5000_*).csv            (5000 ≤ balance)
    expected/gt4.csv                     （其余）
"""

from __future__ import annotations
import csv
import random
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional

from faker import Faker

# ────────────────────────── 可调参数 ──────────────────────────
TOTAL_ROWS     = 200        # customers.csv 总行数
RANDOM_SEED    = 2025

# 分区配置
KEY_COL        = "balance"
RANGES         = [
    (0, 1000),          # [0,1000)
    (1000, 5000),       # [1000,5000)
    (5000, None)        # [5000, ∞)
]

# ────────────────────────── 路径 ──────────────────────────
ROOT_DIR      = Path(__file__).resolve().parent
RAW_DIR       = ROOT_DIR / "raw"
EXPECTED_DIR  = ROOT_DIR / "expected"
RAW_DIR.mkdir(exist_ok=True)
EXPECTED_DIR.mkdir(exist_ok=True)

RAW_PATH = RAW_DIR / "customers.csv"
GT_FILES = [
    EXPECTED_DIR / "gt1_0_1000.csv",
    EXPECTED_DIR / "gt2_1000_5000.csv",
    EXPECTED_DIR / "gt3_5000_.csv",
    EXPECTED_DIR / "gt4.csv"
]

# ────────────────────────── Faker ──────────────────────────
random.seed(RANDOM_SEED)
fake = Faker()
Faker.seed(RANDOM_SEED)

HEADER = ["customer_id", "name", "country", "balance"]

# ─────────────────────── 生成原始数据行 ──────────────────────
rows: List[List[str]] = []

# 为了覆盖边界，把部分余额设为区间端点
forced_balances = [0, 999, 1000, 4999, 5000, -50, 1_000_000]

for cid in range(1, TOTAL_ROWS + 1):
    name    = fake.name()
    country = fake.country_code(representation="alpha-2")
    if cid <= len(forced_balances):
        balance = forced_balances[cid - 1]
    else:
        balance = random.randint(-500, 20_000)
    rows.append([str(cid), name, country, str(balance)])

# ───────────────────── 写入 raw/customers.csv ─────────────────────
with RAW_PATH.open("w", newline="", encoding="utf-8") as f_raw:
    w = csv.writer(f_raw)
    w.writerow(HEADER)
    w.writerows(rows)

# ───────────────────────── 分区逻辑 ─────────────────────────
def which_partition(balance: int) -> int:
    """
    返回行应当写入的分区索引：
        0 -> [0,1000)
        1 -> [1000,5000)
        2 -> [5000,∞)
        3 -> other
    """
    for idx, (lo, hi) in enumerate(RANGES):
        if (lo is None or balance >= lo) and (hi is None or balance < hi):
            return idx
    return len(RANGES)  # other

# 初始化 4 个分区容器
partitions: List[List[List[str]]] = [[] for _ in range(len(RANGES) + 1)]

balance_idx = HEADER.index(KEY_COL)

for row in rows:
    bal = int(row[balance_idx])
    p   = which_partition(bal)
    partitions[p].append(row)

# ───────────────────── 写出 expected/*.csv ─────────────────────
for path, part_rows in zip(GT_FILES, partitions):
    with path.open("w", newline="", encoding="utf-8") as f_gt:
        w = csv.writer(f_gt)
        w.writerow(HEADER)
        w.writerows(part_rows)

# ───────────────────── 打印统计日志 ─────────────────────
msg = ["✅ 数据生成完毕"]
msg.append(f"• {RAW_PATH.relative_to(ROOT_DIR)} ({len(rows)} 行)")
for path, part_rows in zip(GT_FILES, partitions):
    msg.append(f"• {path.relative_to(ROOT_DIR)} ({len(part_rows)} 行)")
print("\n".join(msg))