#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py -- 数值键区间切分算子 · Evaluation
========================================
使用方式
    1 个或多个 `-o/--output`：
        python eval.py -o /path/to/out_dir \
                       -o /path/to/another_dir \
                       -o /path/to/single_file.csv
    传入目录时将读取该目录下所有 *.csv；传入文件时只读取该文件。
    其余说明见原脚本注释。
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import List

# ────────────────────────── 常量配置 ──────────────────────────
KEY_COL  = "balance"
RANGES   = [(0, 1000), (1000, 5000), (5000, None)]  # None = 无上限
GT_FILES = [
    "gt1_0_1000.csv",
    "gt2_1000_5000.csv",
    "gt3_5000_.csv",
    "gt4.csv",
]

ROOT_DIR     = Path(__file__).resolve().parent
EXPECTED_DIR = ROOT_DIR / "expected"

# ────────────────────────── 工具函数 ──────────────────────────
def which_partition(value: int) -> int:
    """根据 balance 值返回所属分区索引"""
    for idx, (lo, hi) in enumerate(RANGES):
        if (lo is None or value >= lo) and (hi is None or value < hi):
            return idx
    return len(RANGES)  # other


def load_csv_rows(path: Path) -> List[List[str]]:
    """读取 CSV（含表头），返回 List[行]"""
    with path.open(newline="", encoding="utf-8") as f:
        return [row for row in csv.reader(f)]


def header_equal(h1: List[str], h2: List[str]) -> bool:
    return h1 == h2


def collect_pred_partitions(csv_sources: List[Path],
                            header_etalon: List[str]) -> List[List[List[str]]]:
    """
    读取所有预测 CSV 并根据 balance 分到 4 个列表：
        parts[0] → [0,1000)
        parts[1] → [1000,5000)
        parts[2] → [5000,∞)
        parts[3] → other
    csv_sources 中的元素可以是目录或文件；
    目录下会遍历 *.csv（不递归子目录）。
    """
    parts: List[List[List[str]]] = [[] for _ in range(len(RANGES) + 1)]
    csv_paths: List[Path] = []

    for src in csv_sources:
        if src.is_dir():
            csv_paths.extend(sorted(src.glob("*.csv")))
        elif src.is_file() and src.suffix.lower() == ".csv":
            csv_paths.append(src)
        else:
            raise ValueError(f"{src} 既不是目录也不是 CSV 文件")
    if not csv_paths:
        raise ValueError("未找到任何可用的 CSV")

    for p in csv_paths:
        rows = load_csv_rows(p)
        if not rows:
            continue
        header, body = rows[0], rows[1:]

        if not header_equal(header, header_etalon):
            raise ValueError(f"{p} 表头不符 (got {header}, expect {header_etalon})")

        bal_idx = header.index(KEY_COL)
        for r in body:
            try:
                bal = int(r[bal_idx])
            except ValueError:
                raise ValueError(f"{p}: balance 不是整数 -> {r[bal_idx]}")
            idx = which_partition(bal)
            parts[idx].append(r)

    return parts

# ────────────────────────────── 主函数 ──────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate range-split CSV operator")
    parser.add_argument(
        "-o", "--output",
        action="append",
        required=True,
        metavar="PATH",
        help="输出目录或单个 CSV，可重复传入"
    )
    args = parser.parse_args()
    out_paths = [Path(p) for p in args.output]

    # ---------- 读取 GT ----------
    gt_parts: List[List[List[str]]] = []
    header_etalon: List[str] | None = None
    for fname in GT_FILES:
        rows = load_csv_rows(EXPECTED_DIR / fname)
        if header_etalon is None:
            header_etalon = rows[0]
        gt_parts.append(rows[1:])   # 去除表头
    assert header_etalon is not None, "GT 表头读取失败"

    # ---------- 读取预测 ----------
    try:
        pred_parts = collect_pred_partitions(out_paths, header_etalon)
    except Exception as exc:
        print(f"[eval] 读取预测输出失败: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)

    # ---------- 比较 ----------
    # correct = all(pred_parts[i] == gt_parts[i] for i in range(len(gt_parts)))
    # for i in range(len(gt_parts)):
    #     if pred_parts[i] != gt_parts[i]:
    #         for j in range(len(pred_parts[i])):
    #             if pred_parts[i][j] != gt_parts[i][j]:
    #                 print(pred_parts[i][j], gt_parts[i][j])
    correct = all(
    sorted(pred_parts[i]) == sorted(gt_parts[i])
    for i in range(len(gt_parts))
    )
    score = 1.0 if correct else 0.0
    print(json.dumps({"eval_score": f"{score:.1f}"}))

import traceback
if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        traceback.print_exc()
        print(f"[eval] 评测异常: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)