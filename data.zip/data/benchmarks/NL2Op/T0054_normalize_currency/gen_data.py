import os
import json
import random
from pathlib import Path

# from utils.llm_serving import LLMServing  # 可选调用大模型

TASK_ID = "T0027"  # 你的任务ID
BASE_DIR = Path(f"data/benchmarks/NL2Op/{TASK_ID}_")
GT_PATH = BASE_DIR / "expected" / "gt.jsonl"
RAW_PATH = BASE_DIR / "raw" / "customers.jsonl"

NUM_TOTAL = 100
NUM_DIRTY = 80

ISO_CURRENCIES = ["USD", "EUR", "CNY", "JPY", "GBP", "AUD", "CAD"]

# 非标准表示示例，覆盖大小写、符号、拼写变体
NON_STANDARD_CURRENCIES = {
    "USD": ["usd", "Usd", "US$", "$", "us dollars", "US Dollar"],
    "EUR": ["eur", "Eur", "€", "Euros", "Euro"],
    "CNY": ["cny", "Cny", "RMB", "￥", "yuan", "Renminbi"],
    "JPY": ["jpy", "Jpy", "¥", "yen", "Yen"],
    "GBP": ["gbp", "Gbp", "£", "pounds", "British Pound"],
    "AUD": ["aud", "Aud", "A$", "Australian Dollar"],
    "CAD": ["cad", "Cad", "C$", "Canadian Dollar"],
}

def gen_price():
    return round(random.uniform(50000, 2000000), 2)

def gen_gt_data():
    """生成标准GT数据，currency均为ISO大写格式"""
    data = []
    for i in range(1, NUM_TOTAL + 1):
        currency = random.choice(ISO_CURRENCIES)
        data.append({
            "id": i,
            "property_id": f"PROP-{1000 + i}",
            "price": gen_price(),
            "currency": currency
        })
    return data

def gen_raw_data(gt_data):
    """在GT基础上生成脏数据raw，80条currency用非标准写法替代"""
    raw_data = []
    dirty_indices = set(random.sample(range(NUM_TOTAL), NUM_DIRTY))
    for idx, record in enumerate(gt_data):
        new_rec = record.copy()
        if idx in dirty_indices:
            iso_cur = record["currency"]
            if iso_cur in NON_STANDARD_CURRENCIES:
                new_rec["currency"] = random.choice(NON_STANDARD_CURRENCIES[iso_cur])
            else:
                # 兜底，转换为小写
                new_rec["currency"] = iso_cur.lower()
        raw_data.append(new_rec)
    return raw_data

def save_jsonl(data, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for rec in data:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

if __name__ == "__main__":
    gt_data = gen_gt_data()
    raw_data = gen_raw_data(gt_data)

    save_jsonl(gt_data, GT_PATH)
    save_jsonl(raw_data, RAW_PATH)

    print(f"✅ GT数据保存到: {GT_PATH}")
    print(f"✅ Raw数据保存到: {RAW_PATH}")
