#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
gen_data.py ― 基准假数据 · LEFT ANTI JOIN 版本
------------------------------------------------
1. raw/customer1.csv      左表（≥100 行）
2. raw/customer2.csv      右表（约 40% id 匹配）
3. expected/gt.csv        左表中在右表无匹配键的行
"""

import os
import random
from datetime import date, timedelta

import pandas as pd
from faker import Faker

# ─────────── 参数 ───────────
TOTAL_CUSTOMERS = 150      # 左表行数
MATCH_RATIO     = 0.4      # 会出现在右表的 id 比例
SEED            = 2024

random.seed(SEED)
fake = Faker("en_US")
Faker.seed(SEED)

# ─────────── 目录 ───────────
os.makedirs("raw", exist_ok=True)
os.makedirs("expected", exist_ok=True)

# ─────────── 左表 customer1 ───────────
def rand_signup():
    start = date.today() - timedelta(days=730)
    return fake.date_between(start_date=start, end_date="today").isoformat()

customer1 = pd.DataFrame(
    {
        "customer_id": range(1, TOTAL_CUSTOMERS + 1),
        "name":        [fake.first_name() for _ in range(TOTAL_CUSTOMERS)],
        "signup_date": [rand_signup()     for _ in range(TOTAL_CUSTOMERS)],
    }
)

# ─────────── 右表 customer2 ───────────
product_catalog = [
    "Widget", "Gadget", "Thingamajig", "Doohickey", "Contraption",
    "Whatchamacallit", "Gizmo", "Device", "Apparatus", "Instrument"
]

match_ids = random.sample(
    list(customer1["customer_id"]),
    k=int(TOTAL_CUSTOMERS * MATCH_RATIO),
)

def rand_purchase():
    start = date.today() - timedelta(days=400)
    return fake.date_between(start_date=start, end_date="today").isoformat()

customer2 = pd.DataFrame(
    {
        "customer_id": match_ids,
        "product_name": [random.choice(product_catalog) for _ in match_ids],
        "last_purchase": [rand_purchase()               for _ in match_ids],
    }
).sort_values("customer_id")

# ─────────── 保存原始 CSV ───────────
customer1.to_csv("raw/customer1.csv", index=False)
customer2.to_csv("raw/customer2.csv", index=False)

# ─────────── 生成真值 gt.csv (ANTI JOIN) ───────────
anti = customer1[~customer1["customer_id"].isin(customer2["customer_id"])]
anti.to_csv("expected/gt.csv", index=False)

print("✅ 数据已生成：raw/*.csv  与  expected/gt.csv")