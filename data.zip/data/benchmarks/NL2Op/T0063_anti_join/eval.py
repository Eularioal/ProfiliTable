#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― LEFT ANTI JOIN 算子评测
=================================

要求
    • 读取 raw/customer1.csv、raw/customer2.csv
    • 输出左表中在右表没有任何匹配 customer_id 的完整行
    • 结果保存为 CSV（含表头）

评测规则
    1. 输出必须是合法 CSV，且至少包含 expected/gt.csv 中的全部列。
       允许出现多余列。
    2. 仅比较 expected/gt.csv 列上的“行多重集合”，行顺序忽略。
    3. 完全一致得分 1.0，否则 0.0。

使用
    python eval.py -o <PATH_TO_OUTPUT_CSV>
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, List, Tuple

ROOT_DIR = Path(__file__).resolve().parent
GT_PATH  = ROOT_DIR / "expected" / "gt.csv"


# ─────────── IO ───────────
def load_csv(path: Path) -> Tuple[List[str], List[Dict[str, str]]]:
    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"{path} 缺少表头")
        header = reader.fieldnames
        rows   = [dict(r) for r in reader]
    return header, rows


def rows_to_counter(rows: List[Dict[str, str]], header: List[str]) -> Counter:
    return Counter(tuple(r.get(col, "") for col in header) for r in rows)


# ─────────── 评测核心 ───────────
def evaluate(gt_hdr: List[str],
             gt_rows: List[Dict[str, str]],
             pred_rows: List[Dict[str, str]]) -> float:
    # 1. 检查列
    missing_cols = [c for c in gt_hdr if c not in pred_rows[0]]
    if missing_cols:
        print(f"[eval] 输出缺少列: {missing_cols}", file=sys.stderr)
        return 0.0

    # 2. 行多重集合比较
    gt_counter   = rows_to_counter(gt_rows,   gt_hdr)
    pred_counter = rows_to_counter(pred_rows, gt_hdr)

    if gt_counter != pred_counter:
        diff_miss = gt_counter - pred_counter
        diff_extra = pred_counter - gt_counter
        if diff_miss:
            print(f"[eval] 输出缺失行示例: {list(diff_miss.elements())[:3]} ...", file=sys.stderr)
        if diff_extra:
            print(f"[eval] 输出多余行示例: {list(diff_extra.elements())[:3]} ...", file=sys.stderr)
        return 0.0

    return 1.0


# ─────────── CLI ───────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate left-anti-join operator")
    parser.add_argument("-o", "--output", required=True,
                        help="CSV file produced by the operator")
    args = parser.parse_args()

    pred_path = Path(args.output)
    if not pred_path.exists():
        print(f"文件不存在: {pred_path}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)

    try:
        gt_hdr,  gt_rows  = load_csv(GT_PATH)
        _,      pred_rows = load_csv(pred_path)
    except Exception as exc:
        print(f"[eval] CSV 读取失败: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)

    if not pred_rows:
        print("[eval] 输出为空", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)

    score = evaluate(gt_hdr, gt_rows, pred_rows)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"[eval] 评测异常: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)