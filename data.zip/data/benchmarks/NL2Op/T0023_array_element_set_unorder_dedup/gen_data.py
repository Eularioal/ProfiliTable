#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成：
  expected/gt.{jsonl,csv}
  raw/customers.{jsonl,csv}

全部路径均相对 `gen_data.py` 所在目录，不受启动目录影响。
"""
import csv
import json
import os
import random
import string
import unicodedata
from pathlib import Path

# ───────────────────────────── 基础设置 ──────────────────────────────
BASE_DIR = Path(__file__).resolve().parent          # 脚本所在目录
EXP_DIR  = BASE_DIR / "expected"
RAW_DIR  = BASE_DIR / "raw"

random.seed(42)

WORDS = """
apple banana cherry date elderberry fig grape honeydew icecream jackfruit kiwi
lemon mango nectarine orange papaya quince raspberry strawberry tangerine ugli
vanilla watermelon xigua yam zucchini almond biscuit croissant donut eclair
focaccia granola hotdog icepop jelly kebab lasagna muffin noodles oatmeal pizza
quiche risotto sandwich taco udon waffle yakitori zwieback
""".split()

ADJ   = ["fresh", "sweet", "tasty", "organic", "imported", "seasonal"]
BRAND = ["acme", "globex", "initech", "umbrella", "wayne", "stark", "wonka"]

# ───────────────────────────── 工具函数 ──────────────────────────────
def ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)

def random_items() -> list[str]:
    return [
        f"{random.choice(ADJ)} {random.choice(BRAND)} {random.choice(WORDS)}"
        for _ in range(random.randint(3, 7))
    ]

def shuffle_and_dirty(s: str) -> str:
    # 1. 大小写
    s = random.choice([s, s.upper(), s.lower(), s.title()])

    # 2. 前后及中间空格
    s = " " * random.randint(0, 2) + s + " " * random.randint(0, 2)
    if random.random() < 0.3:
        s = s.replace(" ", "  ")

    # 3. Unicode 重音
    if random.random() < 0.2:
        trans = {"a": "á", "e": "é", "i": "í", "o": "ó", "u": "ú"}
        s = "".join(trans.get(c.lower(), c) if random.random() < 0.3 else c for c in s)

    # 4. 全角空格
    if random.random() < 0.1:
        s = unicodedata.normalize("NFKC", s).replace(" ", "\u3000")
    return s

# ───────────────────────────── 生成 GT ──────────────────────────────
N_GT = 120          # ≥100
gt_recs = [{"doc_id": f"doc_{i:04d}", "items": random_items()} for i in range(1, N_GT+1)]

ensure_dir(EXP_DIR)
with (EXP_DIR / "gt.jsonl").open("w", encoding="utf-8") as fj,\
     (EXP_DIR / "gt.csv").open("w",  encoding="utf-8", newline="") as fc:
    csv_writer = csv.writer(fc)
    csv_writer.writerow(["doc_id", "items"])
    for rec in gt_recs:
        fj.write(json.dumps(rec, ensure_ascii=False) + "\n")
        csv_writer.writerow([rec["doc_id"], ";".join(rec["items"])])

# ────────────────────── 基于 GT 生成 RAW （含脏数据） ─────────────────
raw_recs = []
for rec in gt_recs:
    raw_recs.append(rec)                    # 原样
    for k in range(1, random.randint(2, 5)):
        dirty = [shuffle_and_dirty(it) for it in random.sample(rec["items"], len(rec["items"]))]
        raw_recs.append({"doc_id": f'{rec["doc_id"]}_dup{k}', "items": dirty})

random.shuffle(raw_recs)

ensure_dir(RAW_DIR)
with (RAW_DIR / "customers.jsonl").open("w", encoding="utf-8") as fj,\
     (RAW_DIR / "customers.csv").open("w",  encoding="utf-8", newline="") as fc:
    csv_writer = csv.writer(fc)
    csv_writer.writerow(["doc_id", "items"])
    for rec in raw_recs:
        fj.write(json.dumps(rec, ensure_ascii=False) + "\n")
        csv_writer.writerow([rec["doc_id"], ";".join(rec["items"])])

print(f"✅ Done. GT = {len(gt_recs)} rows, RAW = {len(raw_recs)} rows")