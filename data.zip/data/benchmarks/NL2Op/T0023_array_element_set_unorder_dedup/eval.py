#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “数组字段无序去重算子”

指标
----
基于 items 集合（忽略顺序 + 规范化）比较行级 F1:
  TP : 预测集合存在于 GT
  FP : 预测集合不存在于 GT，或同一集合重复出现
  FN : GT 中缺失的集合

算子输出格式
------------
必含字段:
  • doc_id (任选保留的行 id，评测时忽略)
  • items  (数组，去重后的元素)
可选字段:
  • merged_ids 等调试列 (都会忽略)

用法
----
python eval.py -o /path/to/operator_output.{jsonl|csv}
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
import unicodedata
from pathlib import Path
from typing import Any, Dict, List, Set

# ────────────────────────── 常量 ──────────────────────────
BASE_DIR = Path(__file__).resolve().parent
GT_PATH  = BASE_DIR / "expected" / "gt.jsonl"

# ────────────────────────── I/O ──────────────────────────
def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open(encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                raise ValueError(f"{path}:{lineno} 不是合法 JSON: {e}") from e
    if not rows:
        raise ValueError(f"{path} 为空文件")
    return rows


def read_csv(path: Path) -> List[Dict[str, Any]]:
    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        rows = [dict(r) for r in reader]
    if not rows:
        raise ValueError(f"{path} 为空文件")
    return rows


def load_rows(path: Path) -> List[Dict[str, Any]]:
    if path.suffix.lower() == ".jsonl":
        return read_jsonl(path)
    if path.suffix.lower() == ".csv":
        return read_csv(path)
    raise ValueError(f"仅支持 .jsonl / .csv，收到 {path.name}")


# ────────────────────────── 指纹函数 ──────────────────────────
def normalize(text: str) -> str:
    """
    Unicode NFKC 规范化 + 去前后空格 + 大小写折叠
    """
    return unicodedata.normalize("NFKC", text).strip().casefold()


def items_fingerprint(items: List[Any]) -> str:
    """
    将 items 视为无序集合 → 规范化后排序 → 以 '|' 连接成稳定字符串
    """
    canon = sorted({normalize(str(x)) for x in items})
    return "|".join(canon)


# ────────────────────────── 评分 ──────────────────────────
def compute_f1(pred_rows: List[Dict[str, Any]]) -> float:
    # 1. GT 指纹集合
    gt_rows = read_jsonl(GT_PATH)
    gt_fps: Set[str] = {items_fingerprint(r["items"]) for r in gt_rows}

    # 2. 预测
    seen_pred: Set[str] = set()
    tp = fp = 0

    for row in pred_rows:
        if "items" not in row:
            raise ValueError("预测行缺少 'items' 字段")
        fp_str = items_fingerprint(row["items"])

        # 重复行记 FP
        if fp_str in seen_pred:
            fp += 1
            continue
        seen_pred.add(fp_str)

        if fp_str in gt_fps:
            tp += 1
        else:
            fp += 1

    fn = len(gt_fps) - tp
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall    = tp / (tp + fn) if tp + fn else 0.0
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


# ────────────────────────── 主入口 ──────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate unordered-array dedup operator")
    parser.add_argument(
        "-o", "--output", required=True, help="Path to operator output (.jsonl / .csv)"
    )
    args = parser.parse_args()

    out_path = Path(args.output)
    if not out_path.exists():
        print(f"文件不存在: {out_path}", file=sys.stderr)
        sys.exit(1)

    pred_rows = load_rows(out_path)
    score = compute_f1(pred_rows)

    print(json.dumps({"eval_score": f"{score:.4f}"}))


if __name__ == "__main__":
    main()