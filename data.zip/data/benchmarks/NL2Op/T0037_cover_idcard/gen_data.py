from pathlib import Path
import json
import random
from datetime import datetime, timedelta

# 配置路径
TASK_ID = "T0019"
BASE_DIR = Path(f"data/benchmarks/NL2Op/{TASK_ID}_")
EXPECTED_PATH = BASE_DIR / "expected" / "gt.jsonl"
RAW_PATH = BASE_DIR / "raw" / "customers.jsonl"

BASE_DIR.joinpath("expected").mkdir(parents=True, exist_ok=True)
BASE_DIR.joinpath("raw").mkdir(parents=True, exist_ok=True)

def generate_valid_cn_id():
    area_code = random.choice(["110101", "310101", "440101", "330101", "510101"])
    birth_date = datetime.now() - timedelta(days=random.randint(18 * 365, 99 * 365))
    birth_str = birth_date.strftime("%Y%m%d")
    seq_code = f"{random.randint(100, 999)}"
    checksum = random.choice("0123456789X")
    return f"{area_code}{birth_str}{seq_code}{checksum}"

def mask_id(text, id_number):
    return text.replace(id_number, "*" * len(id_number))

def main():
    raw_data = []
    gt_data = []

    # ✅ 生成 80 条含身份证的记录
    for i in range(80):
        id_number = generate_valid_cn_id()
        text = f"客户身份证号是 {id_number}，请注意保护个人信息。"
        raw_data.append({
            "id": f"clean_{i:03d}",
            "text": text
        })
        gt_data.append({
            "id": f"clean_{i:03d}",
            "text": mask_id(text, id_number)
        })

    # ✅ 生成 20 条原样保留记录（无身份证）
    for i in range(20):
        if i < 10:
            text = f"这是客户编号 {random.randint(1000, 9999)} 的服务记录。"
        else:
            text = "客户已提交申请，等待审核结果。"
        raw_data.append({
            "id": f"copy_{i:03d}",
            "text": text
        })
        gt_data.append({
            "id": f"copy_{i:03d}",
            "text": text
        })

    # 写入文件
    with RAW_PATH.open("w", encoding="utf-8") as f:
        for item in raw_data:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")

    with EXPECTED_PATH.open("w", encoding="utf-8") as f:
        for item in gt_data:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")

    print(f"✅ 写入原始数据 {len(raw_data)} 条 → {RAW_PATH}")
    print(f"✅ 写入 GT 数据 {len(gt_data)} 条（其中 80 条已屏蔽）→ {EXPECTED_PATH}")

if __name__ == "__main__":
    main()
