#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
生成 ≥100 条的基准假数据
-------------------------------------------
1. raw/customer1.csv      ‒ 左表（全部保留）
2. raw/customer2.csv      ‒ 右表（部分 customer_id 匹配）
3. expected/gt.csv        ‒ 左连接后结果，
   无匹配的行用默认值 product_name="Unknown"、last_purchase=""
"""
import os
import random
from datetime import date, timedelta

import pandas as pd
from faker import Faker

# ----------------------------
# 可调参数
# ----------------------------
TOTAL_CUSTOMERS = 150          # 左表行数
MATCH_RATIO     = 0.4          # 有购买记录的客户占比
SEED            = 2024         # 保证重复生成时数据一致

random.seed(SEED)
fake = Faker("en_US")
Faker.seed(SEED)

# ----------------------------
# 1. 准备目录
# ----------------------------
os.makedirs("raw", exist_ok=True)
os.makedirs("expected", exist_ok=True)

# ----------------------------
# 2. 生成 customer1（左表）
# ----------------------------
def rand_signup():
    """最近 2 年内的随机注册日期字符串"""
    start = date.today() - timedelta(days=730)
    return fake.date_between(start_date=start, end_date="today").isoformat()

customer1 = pd.DataFrame(
    {
        "customer_id": range(1, TOTAL_CUSTOMERS + 1),
        "name": [fake.first_name() for _ in range(TOTAL_CUSTOMERS)],
        "signup_date": [rand_signup() for _ in range(TOTAL_CUSTOMERS)],
    }
)

# ----------------------------
# 3. 生成 customer2（右表）
# ----------------------------
product_catalog = [
    "Widget", "Gadget", "Thingamajig", "Doohickey", "Contraption",
    "Whatchamacallit", "Gizmo", "Device", "Apparatus", "Instrument"
]

match_ids = random.sample(
    list(customer1["customer_id"]),
    k=int(TOTAL_CUSTOMERS * MATCH_RATIO),
)

def rand_purchase_date():
    """最近 400 天内的购买日期"""
    start = date.today() - timedelta(days=400)
    return fake.date_between(start_date=start, end_date="today").isoformat()

customer2 = pd.DataFrame(
    {
        "customer_id": match_ids,
        "product_name": [random.choice(product_catalog) for _ in match_ids],
        "last_purchase": [rand_purchase_date() for _ in match_ids],
    }
).sort_values("customer_id")

# ----------------------------
# 4. 保存原始 CSV
# ----------------------------
customer1.to_csv("raw/customer1.csv", index=False)
customer2.to_csv("raw/customer2.csv", index=False)

# ----------------------------
# 5. 生成 gt.csv（左连接 + 默认值填补）
# ----------------------------
gt = (
    customer1.merge(customer2, on="customer_id", how="left")
    .assign(
        product_name=lambda df: df["product_name"].fillna("Unknown"),
        last_purchase=lambda df: df["last_purchase"].fillna(""),
    )
)

gt.to_csv("expected/gt.csv", index=False)

print("✅ 假数据生成完毕：raw/*.csv  与  expected/gt.csv")