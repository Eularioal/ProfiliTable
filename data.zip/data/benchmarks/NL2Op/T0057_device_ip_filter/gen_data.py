import os
import csv
import random
import ipaddress
from pathlib import Path

TASK_ID = "T0029"
BASE_DIR = Path(f"data/benchmarks/NL2Op/{TASK_ID}_")
GT_PATH = BASE_DIR / "expected" / "gt.csv"
RAW_PATH = BASE_DIR / "raw" / "customers.csv"

NUM_TOTAL = 100
NUM_GOOD = 20   # 合法ip记录数
NUM_DIRTY = NUM_TOTAL - NUM_GOOD  # 脏数据数

def gen_valid_ip():
    # 生成合法IPv4地址，避免网络和广播地址
    while True:
        ip = ".".join(str(random.randint(1, 254)) for _ in range(4))
        try:
            ipaddress.IPv4Address(ip)
            return ip
        except:
            continue

def gen_invalid_ip():
    # 生成明显非法的IPv4格式，如数字超范围，缺段，含非法字符等
    invalid_types = [
        lambda: f"{random.randint(256, 999)}.{random.randint(0, 255)}.{random.randint(0,255)}.{random.randint(0,255)}",
        lambda: f"{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}",  # 少一段
        lambda: f"{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}", # 多一段
        lambda: f"abc.def.ghi.jkl",  # 字母
        lambda: f"192.168.1.{random.choice(['300', 'x', '-1'])}", # 非法数字或字符
        lambda: "",  # 空字符串
        lambda: "....", # 仅点
        lambda: "256.256.256.256",
    ]
    return random.choice(invalid_types)()

def gen_status():
    return random.choice(["online", "offline", "unknown"])

def gen_last_seen():
    # 随机时间字符串
    year = random.randint(2020, 2023)
    month = random.randint(1, 12)
    day = random.randint(1, 28)
    hour = random.randint(0, 23)
    minute = random.randint(0, 59)
    second = random.randint(0, 59)
    return f"{year}-{month:02d}-{day:02d} {hour:02d}:{minute:02d}:{second:02d}"

def generate_good_data(start_id, count):
    rows = []
    for i in range(start_id, start_id + count):
        rows.append({
            "id": i,
            "device_id": f"DVC{i:05d}",
            "ip_address": gen_valid_ip(),
            "status": gen_status(),
            "last_seen": gen_last_seen(),
        })
    return rows

def generate_dirty_data(start_id, count):
    rows = []
    for i in range(start_id, start_id + count):
        rows.append({
            "id": i,
            "device_id": f"DVC{i:05d}",
            "ip_address": gen_invalid_ip(),
            "status": gen_status(),
            "last_seen": gen_last_seen(),
        })
    return rows

def save_csv(data, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["id", "device_id", "ip_address", "status", "last_seen"]
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in data:
            writer.writerow(row)

if __name__ == "__main__":
    good_data = generate_good_data(1, NUM_GOOD)      # 20条合法ip
    dirty_data = generate_dirty_data(NUM_GOOD + 1, NUM_DIRTY)  # 80条脏ip

    raw_data = good_data + dirty_data
    random.shuffle(raw_data)

    save_csv(good_data, GT_PATH)    # GT只包含20条合法记录
    save_csv(raw_data, RAW_PATH)    # Raw包含100条数据（20合法+80脏数据）

    print(f"✅ GT数据保存到: {GT_PATH}")
    print(f"✅ Raw数据保存到: {RAW_PATH}")
