#!/usr/bin/env python3
# gendata/gen_data.py
# 生成 Ground-Truth 数据并派生脏乱原始数据
# --------------------------------------------------------------
import csv
import json
import os
import random
import re
import string
from datetime import datetime
from pathlib import Path

# --------------------------- 常量 ------------------------------
NUM_GT_ROWS = 100                       # GT 数据行数
GT_DIR      = Path("expected")
RAW_DIR     = Path("raw")
GT_CSV      = GT_DIR / "gt.csv"
RAW_CSV     = RAW_DIR / "customers.csv"
random.seed(42)

CHINESE_SURNAMES = """赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜戚谢邹喻柏水窦章云苏潘葛奚范彭郎鲁韦昌马苗凤花方俞任袁柳酆鲍史唐费廉岑薛雷贺倪汤滕殷罗毕郝安常乐于时傅皮卞齐康伍余元卜顾孟平黄和穆萧尹姚邵湛汪祁""".split(" ")
NAME_TAIL    = ["伟", "芳", "娜", "秀英", "敏", "静", "丽", "强", "磊", "军", "洋", "勇", "艳"]

GMAIL_DOT_POOL = ["", ".", "..", "..."]

# ------------------------ 工具函数 -----------------------------
def rand_name() -> str:
    return random.choice(CHINESE_SURNAMES) + random.choice(NAME_TAIL)

def rand_phone() -> str:
    """返回标准化后的 phone：+86135xxxxxxx（11 位）"""
    prefix = random.choice(["13", "15", "17", "18", "19"])
    number = prefix + "".join(random.choices(string.digits, k=9))
    return "+86" + number

def rand_email(name: str) -> str:
    """返回标准化后的 email，全小写、无 gmail dot"""
    local = (name[:3] + "".join(random.choices(string.ascii_lowercase + string.digits, k=4))).lower()
    domain = random.choice(["gmail.com", "qq.com", "outlook.com"])
    return f"{local}@{domain}"

def make_dirs():
    for d in (GT_DIR, RAW_DIR):
        d.mkdir(parents=True, exist_ok=True)

# --------------- 生成 GT 数据（标准化且已去重） -----------------
def generate_gt():
    rows = []
    keys = set()
    while len(rows) < NUM_GT_ROWS:
        name  = rand_name()
        phone = rand_phone()
        email = rand_email(name)
        key   = (phone, email)
        if key in keys:      # 防止重复
            continue
        keys.add(key)
        rows.append({"name": name, "phone": phone, "email": email})
    with GT_CSV.open("w", newline='', encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["name", "phone", "email"])
        writer.writeheader()
        writer.writerows(rows)
    return rows

# -------------- 制造脏乱数据（去掉标准化 + 引入重复） ------------
PHONE_NOISE = [
    lambda p: p.replace("+86", ""),                     # 去掉国家码
    lambda p: p[:3] + "-" + p[3:7] + "-" + p[7:],       # 加破折号
    lambda p: p.replace("+86", "+86 "),                 # +86 后空格
]

EMAIL_NOISE = [
    lambda e: e.upper(),                                # 大写
    lambda e: insert_gmail_dots(e),                     # gmail dot alias
]

def insert_gmail_dots(email: str) -> str:
    """仅对 gmail.com 插入 dot"""
    local, domain = email.split("@")
    if domain != "gmail.com":
        return email
    pieces = []
    for ch in local:
        pieces.append(ch)
        if random.random() < 0.25:
            pieces.append(".")
    return "".join(pieces) + "@gmail.com"

def degrade_record(r: dict) -> dict:
    """随机制造噪声、缺失值"""
    new = r.copy()

    # phone 噪声
    if random.random() < 0.7:
        new["phone"] = random.choice(PHONE_NOISE)(new["phone"])
    # email 噪声
    if random.random() < 0.7:
        new["email"] = random.choice(EMAIL_NOISE)(new["email"])
    # 随机缺失
    for field in ["phone", "email"]:
        if random.random() < 0.05:
            new[field] = ""
    return new

def generate_raw(gt_rows):
    raw_rows = []
    for r in gt_rows:
        # 每条 GT 至少产生 1~3 条变体
        for _ in range(random.randint(1, 5)):
            raw_rows.append(degrade_record(r))
    random.shuffle(raw_rows)
    with RAW_CSV.open("w", newline='', encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["name", "phone", "email"])
        writer.writeheader()
        writer.writerows(raw_rows)

# ----------------------------- 主程序 --------------------------
def main():
    make_dirs()
    gt_rows = generate_gt()
    generate_raw(gt_rows)
    print(f"[{datetime.now().isoformat(timespec='seconds')}] ✓ 已生成 {GT_CSV} 与 {RAW_CSV}")

if __name__ == "__main__":
    main()