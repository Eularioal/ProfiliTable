#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “电话 + 邮箱 标准化-去重算子（CSV 版）”

用法
----
python eval.py -o /path/to/your_output.csv

评价要点
--------
1. 黄金标准固定为同级目录 expected/gt.csv
2. -o 指向你的算子产出的 **去重结果**（CSV，顺序不限）
3. 仅考察 (phone,email) 复合键集合是否与 GT 完全一致
   · 输出含重复 / 多余键 → precision ↓
   · 缺失任何应保留键  → recall    ↓
4. 额外检查字段是否已标准化
   · phone  必须匹配 “+86” 加 11 位数字，无空格 / 破折号
   · email  必须全小写；若域是 gmail.com，本地部分不得含 “.”
   不合规行视为错误，计入 FP
5. 最终打印 {"eval_score": "<0~1>"}，值为行级 F1
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path
from typing import Dict, List, Set, Tuple

# ------------------------------------------------------------------ 常量
GT_PATH = Path(__file__).parent / "expected" / "gt.csv"

PHONE_RE = re.compile(r"^\+86\d{11}$")  # +86 开头，后跟 11 位数字
GMAIL_DOT_RE = re.compile(r"\.")

# ------------------------------------------------------------------ I/O
def read_csv_rows(path: Path) -> List[Dict[str, str]]:
    """
    读取带表头的 CSV，返回 dict 列表。
    字段必须包含 name / phone / email（允许额外字段）。
    """
    if not path.exists():
        raise FileNotFoundError(path)
    rows: List[Dict[str, str]] = []
    with path.open(encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for lineno, row in enumerate(reader, 2):  # header 行算 1
            for key in ("name", "phone", "email"):
                if key not in row:
                    raise ValueError(f"{path}:{lineno} 缺少字段 {key}")
            rows.append({k: (v or "").strip() for k, v in row.items()})
    if not rows:
        raise ValueError(f"{path} 为空文件")
    return rows


# ------------------------------------------------------------------ 规范性检查
def is_std_phone(p: str) -> bool:
    return bool(PHONE_RE.fullmatch(p))

def is_std_email(e: str) -> bool:
    if e != e.lower():
        return False
    try:
        local, domain = e.split("@", 1)
    except ValueError:
        return False
    return domain != "gmail.com" or not GMAIL_DOT_RE.search(local)


def compliant(row: Dict[str, str]) -> bool:
    return is_std_phone(row["phone"]) and is_std_email(row["email"])


# ------------------------------------------------------------------ 评分
def compute_f1(
    gt_keys: Set[Tuple[str, str]],
    pred_rows: List[Dict[str, str]],
) -> float:
    """
    行级 F1：
    • 复合键 = (phone,email)
    • 重复键多记 FP
    • 字段不符合标准化要求 → 计 FP
    """
    if not pred_rows:
        return 0.0

    tp_seen: Set[Tuple[str, str]] = set()
    tp = 0
    fp = 0

    for row in pred_rows:
        key = (row["phone"], row["email"])

        # 标准化校验
        if not compliant(row):
            fp += 1
            continue

        if key in gt_keys and key not in tp_seen:
            tp += 1
            tp_seen.add(key)
        else:
            fp += 1  # 多余键或重复键

    fn = len(gt_keys) - tp
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0

    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


# ------------------------------------------------------------------ 主流程
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate CSV deduplication output")
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Path to CSV produced by your deduplication operator",
    )
    args = parser.parse_args()

    # ---------- 读取 GT ----------
    gt_rows = read_csv_rows(GT_PATH)
    gt_keys: Set[Tuple[str, str]] = {(r["phone"], r["email"]) for r in gt_rows}

    # ---------- 读取预测 ----------
    pred_rows = read_csv_rows(Path(args.output))

    # ---------- 计算得分 ----------
    score = compute_f1(gt_keys, pred_rows)

    # ---------- 输出 ----------
    print(json.dumps({"eval_score": f"{score:.4f}"}))


if __name__ == "__main__":
    main()