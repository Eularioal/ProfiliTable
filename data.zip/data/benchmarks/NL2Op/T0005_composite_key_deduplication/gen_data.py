#!/usr/bin/env python3
"""
Generate data for composite-key deduplication benchmark.

Outputs (all paths are *relative* to this script):
  • expected/gt.csv      — ground-truth, 1 row per composite key
  • raw/customers.csv    — dirty data with duplicates / conflicts
"""

import csv
import os
import random
from datetime import datetime, timedelta

# -------------------- path configuration --------------------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
EXP_DIR    = os.path.join(SCRIPT_DIR, "expected")
RAW_DIR    = os.path.join(SCRIPT_DIR, "raw")
GT_PATH    = os.path.join(EXP_DIR, "gt.csv")
RAW_PATH   = os.path.join(RAW_DIR, "customers.csv")
os.makedirs(EXP_DIR, exist_ok=True)
os.makedirs(RAW_DIR, exist_ok=True)

# ----------------------- RNG & dictionaries -----------------
random.seed(42)

FIRST_NAMES = [
    "Alice", "Bob", "Carol", "Dave", "Eve",
    "Frank", "Grace", "Heidi", "Ivan", "Judy"
]
LAST_NAMES = [
    "Anderson", "Brown", "Clark", "Davis", "Evans",
    "Franklin", "Green", "Harris", "Iverson", "Jones"
]

def random_date(start_year=1970, end_year=2000):
    start = datetime(start_year, 1, 1)
    delta = datetime(end_year, 12, 31) - start
    return (start + timedelta(days=random.randint(0, delta.days))).date()

def random_ts(start_year=2010, end_year=2024):
    start = datetime(start_year, 1, 1)
    delta = datetime(end_year, 12, 31, 23, 59, 59) - start
    return (start + timedelta(seconds=random.randint(0, int(delta.total_seconds())))).isoformat(timespec="seconds")

EXTRA_HDRS = ["email", "phone", "city", "notes"]
HEADERS    = ["first_name", "last_name", "dob", "created_at"] + EXTRA_HDRS

# ---------------------- record factories --------------------
def make_clean_record(fn, ln, dob):
    """唯一基准行（GT 用）"""
    return {
        "first_name": fn,
        "last_name" : ln,
        "dob"       : dob.isoformat(),
        "created_at": random_ts(),
        "email"     : f"{fn.lower()}.{ln.lower()}@example.com",
        "phone"     : f"+1-202-{random.randint(100,999)}-{random.randint(1000,9999)}",
        "city"      : random.choice(["NY", "LA", "SF", "CHI", "HOU"]),
        "notes"     : ""
    }

def dirty_clone(rec, variant):
    """根据 GT 行制造有冲突 / 缺失的副本"""
    fn, ln = rec["first_name"], rec["last_name"]
    clone  = rec.copy()


    # --- 非键列冲突或缺失 -----------------------------------
    if variant in (0, 3):
        clone["email"] = ""
    if variant in (2, 4):
        clone["city"] = random.choice(["SEA", "DAL", "ATL"])
    if variant == 5:
        clone["notes"] = "manual import"

    # 随机前后偏移 created_at
    shift = random.randint(1, 1_000_000)
    clone["created_at"] = (datetime.fromisoformat(rec["created_at"]) +
                           timedelta(seconds=shift)).isoformat(timespec="seconds")
    return clone

# ------------------- assemble clean & raw data ------------------------
UNIQUE_PEOPLE = 40            # GT 行数
gt_rows  = []
raw_rows = []

for _ in range(UNIQUE_PEOPLE):
    fn, ln = random.choice(FIRST_NAMES), random.choice(LAST_NAMES)
    dob    = random_date()
    base   = make_clean_record(fn, ln, dob)
    gt_rows.append(base)

    dup_n  = random.randint(1, 4)          # raw 中该人 1-4 个重复
    clones = [dirty_clone(base, v) for v in range(dup_n)]
    raw_rows.append(base)          # 保留一个干净版本
    raw_rows.extend(clones)

assert raw_rows, "raw_rows 为空，请检查生成逻辑"
random.shuffle(raw_rows)

# ---------------------------- write CSV ------------------------------
def write_csv(path, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=HEADERS)
        w.writeheader()
        w.writerows(rows)

write_csv(GT_PATH,  gt_rows)
write_csv(RAW_PATH, raw_rows)

# ---------------------------- console log ----------------------------
print(f"✓ wrote GT  : {os.path.relpath(GT_PATH , SCRIPT_DIR)}  ({len(gt_rows)} rows)")
print(f"✓ wrote RAW : {os.path.relpath(RAW_PATH, SCRIPT_DIR)}  ({len(raw_rows)} rows)\n")

print("Absolute paths:")
print(f"  GT  → {os.path.abspath(GT_PATH)}")
print(f"  RAW → {os.path.abspath(RAW_PATH)}")

# Quick duplication stats
dup_stats = {}
for r in raw_rows:
    k = (r["first_name"].lower(), r["last_name"].lower(), r["dob"])
    dup_stats[k] = dup_stats.get(k, 0) + 1
dups = [c for c in dup_stats.values() if c > 1]
print(f"\nComposite-key groups with duplicates in RAW: {len(dups)}, "
      f"max dup per key: {max(dups) if dups else 1}")