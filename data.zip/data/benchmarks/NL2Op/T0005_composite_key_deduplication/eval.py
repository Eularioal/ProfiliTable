#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “复合键去重并合并” 算子

使用方法
--------
python eval.py -o /path/to/your_output.csv

说明
----
1. 基准文件固定为同级目录 expected/gt.csv
2. -o 指向算子输出或直接指向 expected/gt.csv（上限得分 1.0）
3. 评分范围 ∈ [0,1]，以 {"eval_score": "<score>"} 形式打印
"""

from __future__ import annotations
import argparse
import csv
from pathlib import Path
from typing import List, Tuple, Set, Sequence

# ------------------------------------------------------------------ 常量
GT_PATH = Path(__file__).parent / "expected" / "gt.csv"

# ------------------------------------------------------------------ I/O 工具
def read_header_and_rows(path: Path) -> Tuple[List[str], List[List[str]]]:
    """返回 header(list[str]) 与数据行(list[list[str]])"""
    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.reader(f)
        rows = list(reader)
        if not rows:
            raise ValueError(f"{path} 为空文件")
        header, data = rows[0], rows[1:]
        return header, data

def canonicalize_rows(
    header_ref: Sequence[str],
    header_pred: Sequence[str],
    pred_rows_raw: List[Sequence[str]],
) -> List[Tuple[str, ...]]:
    """
    把预测行映射/补列到与 GT 相同的列顺序，多余列丢弃，缺失列补 ""。
    返回 tuple 列表，便于哈希比较
    """
    idx_map = {col: i for i, col in enumerate(header_pred)}
    canon_rows: List[Tuple[str, ...]] = []
    for raw in pred_rows_raw:
        canon = tuple(
            raw[idx_map[col]].strip() if col in idx_map and idx_map[col] < len(raw) else ""
            for col in header_ref
        )
        canon_rows.append(canon)
    return canon_rows

# ------------------------------------------------------------------ 评分
def compute_f1(gt_rows: Set[Tuple[str, ...]], pred_rows: List[Tuple[str, ...]]) -> float:
    """整行匹配 F1。重复行惩罚 precision。"""
    if not pred_rows:
        return 0.0

    tp_seen: Set[Tuple[str, ...]] = set()
    tp = 0
    for r in pred_rows:          # 保留重复行的影响
        if r in gt_rows and r not in tp_seen:
            tp_seen.add(r)
            tp += 1

    precision = tp / len(pred_rows)
    recall    = tp / len(gt_rows)
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)

# ------------------------------------------------------------------ 主流程
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate composite-key deduplication output")
    parser.add_argument(
        "-o", "--output", required=True,
        help="Path to CSV produced by your deduplication operator"
    )
    args = parser.parse_args()

    # 读取 GT
    gt_header, gt_data = read_header_and_rows(GT_PATH)
    gt_rows_set: Set[Tuple[str, ...]] = {tuple(r_i.strip() for r_i in row) for row in gt_data}

    # 读取预测
    pred_path = Path(args.output)
    if not pred_path.exists():
        raise FileNotFoundError(pred_path)
    pred_header, pred_raw_rows = read_header_and_rows(pred_path)
    pred_rows = canonicalize_rows(gt_header, pred_header, pred_raw_rows)

    # 计算得分
    score = compute_f1(gt_rows_set, pred_rows)

    # 输出
    print({"eval_score": f"{score:.4f}"})


if __name__ == "__main__":
    main()