#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― UNPIVOT 算子评测
=========================

要求
  • 输入   : raw/customers.csv
  • 输出   : 至少包含列
        customer_id, region, metric, value
  • 行内容 : 与 expected/gt.csv 完全一致（行顺序忽略）
  • 保存为 : CSV

用法
  python eval.py -o <PATH_TO_OUTPUT_CSV>
"""

from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
from collections import Counter
from typing import Dict, List, Tuple

ROOT = Path(__file__).resolve().parent
GT   = ROOT / "expected" / "gt.csv"
REQ_COLS = ["customer_id", "region", "metric", "value"]

# ─────────── I/O ───────────
def load_csv(p: Path) -> Tuple[List[str], List[Dict[str, str]]]:
    with p.open(encoding="utf-8", newline="") as f:
        rdr = csv.DictReader(f)
        if rdr.fieldnames is None:
            raise ValueError(f"{p} 缺少表头")
        header = rdr.fieldnames
        rows   = [dict(r) for r in rdr]
    return header, rows

def rows_ctr(rows: List[Dict[str,str]], header: List[str]) -> Counter:
    return Counter(tuple(r.get(c,"") for c in header) for r in rows)

# ─────────── 评测逻辑 ───────────
def evaluate(gt_rows, pred_rows) -> float:
    if not pred_rows:
        print("[eval] 输出为空", file=sys.stderr)
        return 0.0
    # 必需列检查
    miss = [c for c in REQ_COLS if c not in pred_rows[0]]
    if miss:
        print(f"[eval] 缺少列: {miss}", file=sys.stderr)
        return 0.0
    gt_ctr  = rows_ctr(gt_rows,  REQ_COLS)
    pr_ctr  = rows_ctr(pred_rows, REQ_COLS)
    if gt_ctr != pr_ctr:
        lacking = gt_ctr - pr_ctr
        extra   = pr_ctr - gt_ctr
        if lacking:
            print(f"[eval] 缺失行示例: {list(lacking.elements())[:3]} …",  file=sys.stderr)
        if extra:
            print(f"[eval] 多余行示例: {list(extra.elements())[:3]} …", file=sys.stderr)
        return 0.0
    return 1.0

# ─────────── CLI ───────────
def main():
    ap = argparse.ArgumentParser(description="Evaluate UNPIVOT operator")
    ap.add_argument("-o","--output", required=True,
                    help="CSV file produced by operator")
    args = ap.parse_args()
    pred_path = Path(args.output)
    if not pred_path.exists():
        print(f"文件不存在: {pred_path}", file=sys.stderr)
        print(json.dumps({"eval_score":"0.0"})); sys.exit(1)

    try:
        _, gt_rows  = load_csv(GT)
        _, pr_rows  = load_csv(pred_path)
    except Exception as exc:
        print(f"[eval] CSV 读取失败: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score":"0.0"})); sys.exit(1)

    score = evaluate(gt_rows, pr_rows)
    print(json.dumps({"eval_score":f"{score:.1f}"}))

if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"[eval] 评测异常: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score":"0.0"})); sys.exit(1)