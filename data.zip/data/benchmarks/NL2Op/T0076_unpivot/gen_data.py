#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
gen_data.py ― 基准假数据 · UNPIVOT
----------------------------------
1. raw/customers.csv   – 宽表
2. expected/gt.csv     – 长表真值
"""

import os, random
import pandas as pd
from faker import Faker

ROWS = 120            # 原始行数（>100）
SEED = 2024
random.seed(SEED)
fake = Faker("en_US")
Faker.seed(SEED)

os.makedirs("raw", exist_ok=True)
os.makedirs("expected", exist_ok=True)

# ─────────── 生成宽表 ───────────
regions = ["NA", "EMEA", "APAC", "LATAM"]
data = []
for cid in range(1, ROWS + 1):
    data.append(
        {
            "customer_id": cid,
            "region": random.choice(regions),
            # 四个季度消费额，整数便于比较
            "spend_q1": random.randint(100, 1000),
            "spend_q2": random.randint(100, 1000),
            "spend_q3": random.randint(100, 1000),
            "spend_q4": random.randint(100, 1000),
        }
    )

wide = pd.DataFrame(data)
wide.to_csv("raw/customers.csv", index=False)

# ─────────── 生成真值 (UNPIVOT) ───────────
long = wide.melt(
    id_vars=["customer_id", "region"],
    value_vars=["spend_q1", "spend_q2", "spend_q3", "spend_q4"],
    var_name="metric",
    value_name="value",
).astype({"value": "string"})  # 转为字符串便于纯文本比较

long.to_csv("expected/gt.csv", index=False)
print("✅ 数据已生成：raw/customers.csv 与 expected/gt.csv")