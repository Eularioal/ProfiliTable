#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
gen_data.py ─ 生成 raw 与 expected/gt.csv（宽表构建：多表 join + 时间窗聚合）
======================================================================

功能
    • 生成三张表：
        - raw/users.csv     [user_id]
        - raw/orders.csv    [user_id, ts, amount]     （amount 为整数货币单位）
        - raw/clicks.csv    [user_id, ts]
    • 时间窗：ts ∈ (ref_ts - N 天, ref_ts]（左开右闭）
    • 聚合：orders_cnt、orders_gmv、clicks_cnt
    • 左连接到 users；缺失行为填 0
    • 输出 expected/gt.csv（含表头）
    • 注入少量“游离行为”（不在 users 中的 user_id）以校验左连接语义

数据规模与可复现性
    • 默认 users=300，每个用户 orders/clicks 数量在指定上限内均匀采样，总记录量 > 100
    • 使用 faker，支持 --seed 固定随机种子
"""

from __future__ import annotations

import argparse
import csv
import random
from datetime import date, timedelta
from pathlib import Path
from typing import Dict, List, Tuple

from faker import Faker

ROOT_DIR = Path(__file__).resolve().parent
RAW_DIR  = ROOT_DIR / "raw"
EXP_DIR  = ROOT_DIR / "expected"
GT_PATH  = EXP_DIR / "gt.csv"

USERS_PATH  = RAW_DIR / "users.csv"
ORDERS_PATH = RAW_DIR / "orders.csv"
CLICKS_PATH = RAW_DIR / "clicks.csv"

USERS_COLS  = ["user_id"]
ORDERS_COLS = ["user_id", "ts", "amount"]
CLICKS_COLS = ["user_id", "ts"]

GT_COLS = ["user_id", "orders_cnt", "orders_gmv", "clicks_cnt"]


def write_csv(path: Path, header: List[str], rows: List[Dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=header)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in header})


def parse_date(s: str) -> date:
    return date.fromisoformat(s)


def iso(d: date) -> str:
    return d.isoformat()  # YYYY-MM-DD


def in_window(ts: date, ref: date, days: int) -> bool:
    """
    窗口定义：ts ∈ (ref - days, ref]，即 ts > ref - days 且 ts <= ref
    """
    left_open = ref - timedelta(days=days)
    return (ts > left_open) and (ts <= ref)


def gen_users(n_users: int, rng: random.Random) -> List[Dict[str, str]]:
    """
    生成用户 ID：从 100000 开始递增。
    """
    return [{"user_id": str(100000 + i)} for i in range(n_users)]


def gen_behavior_for_user(user_id: str,
                          rng: random.Random,
                          ref_ts: date,
                          horizon_days: int,
                          orders_max: int,
                          clicks_max: int) -> Tuple[List[Dict[str, str]], List[Dict[str, str]]]:
    """
    在 [ref_ts - horizon_days, ref_ts] 区间内均匀采样行为。
    """
    start = ref_ts - timedelta(days=horizon_days)
    days_span = (ref_ts - start).days + 1  # 含 ref_ts

    n_orders = rng.randint(0, orders_max)
    n_clicks = rng.randint(max(0, n_orders // 2 - 2), clicks_max)  # 点击通常比订单多

    orders: List[Dict[str, str]] = []
    clicks: List[Dict[str, str]] = []

    for _ in range(n_orders):
        offset = rng.randrange(days_span)
        ts = start + timedelta(days=offset)
        amount = str(rng.randint(10, 500))  # 整数金额，避免浮点误差
        orders.append({"user_id": user_id, "ts": iso(ts), "amount": amount})

    for _ in range(n_clicks):
        offset = rng.randrange(days_span)
        ts = start + timedelta(days=offset)
        clicks.append({"user_id": user_id, "ts": iso(ts)})

    return orders, clicks


def compute_gt(users: List[Dict[str, str]],
               orders: List[Dict[str, str]],
               clicks: List[Dict[str, str]],
               ref_ts: date,
               window_days: int) -> List[Dict[str, str]]:
    """
    左连接到 users；在窗口内聚合行为，缺失填 0。
    """
    users_set = {u["user_id"] for u in users}

    # 预聚合（仅窗口内且 user 在 users_set 中）
    orders_cnt: Dict[str, int] = {}
    orders_sum: Dict[str, int] = {}
    clicks_cnt: Dict[str, int] = {}

    for o in orders:
        uid = o["user_id"]
        if uid not in users_set:
            continue
        ts = parse_date(o["ts"])
        if in_window(ts, ref_ts, window_days):
            amt = int(o["amount"])
            orders_cnt[uid] = orders_cnt.get(uid, 0) + 1
            orders_sum[uid] = orders_sum.get(uid, 0) + amt

    for c in clicks:
        uid = c["user_id"]
        if uid not in users_set:
            continue
        ts = parse_date(c["ts"])
        if in_window(ts, ref_ts, window_days):
            clicks_cnt[uid] = clicks_cnt.get(uid, 0) + 1

    # 生成宽表（每个用户一行）
    out_rows: List[Dict[str, str]] = []
    for u in users:
        uid = u["user_id"]
        out_rows.append({
            "user_id": uid,
            "orders_cnt": str(orders_cnt.get(uid, 0)),
            "orders_gmv": str(orders_sum.get(uid, 0)),
            "clicks_cnt": str(clicks_cnt.get(uid, 0)),
        })

    return out_rows


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate raw data and expected ground truth for user feature wide table (windowed aggregations)")
    parser.add_argument("--seed", type=int, default=42, help="随机种子")
    parser.add_argument("--n-users", type=int, default=300, help="用户数（>= 100）")
    parser.add_argument("--ref-ts", type=str, default="2024-08-31", help="参考日期 YYYY-MM-DD（窗口右端点，含）")
    parser.add_argument("--window-days", type=int, default=30, help="窗口大小 N 天（左开右闭）")
    parser.add_argument("--horizon-days", type=int, default=180, help="行为生成的时间范围（向前天数）")
    parser.add_argument("--orders-max", type=int, default=10, help="每用户生成的订单最大数量（均匀采样 [0, orders-max]）")
    parser.add_argument("--clicks-max", type=int, default=50, help="每用户生成的点击最大数量（均匀采样 [0, clicks-max]）")
    parser.add_argument("--noise-rate", type=float, default=0.05, help="游离行为比例（行为中属于非 users 的 user_id 比例）")

    args = parser.parse_args()

    if args.n_users < 1:  # guard
        raise ValueError("n-users 必须 >= 1")

    rng = random.Random(args.seed)
    faker = Faker()
    Faker.seed(args.seed)

    ref_ts = parse_date(args.ref_ts)

    # 1) 生成 users
    users = gen_users(args.n_users, rng)

    # 2) 生成行为（含少量游离行为）
    orders: List[Dict[str, str]] = []
    clicks: List[Dict[str, str]] = []

    for u in users:
        uid = u["user_id"]
        u_orders, u_clicks = gen_behavior_for_user(
            user_id=uid,
            rng=rng,
            ref_ts=ref_ts,
            horizon_days=args.horizon_days,
            orders_max=args.orders_max,
            clicks_max=args.clicks_max,
        )
        orders.extend(u_orders)
        clicks.extend(u_clicks)

    # 注入游离行为（不在 users 中）
    def random_noise_user_id() -> str:
        # 以 900000 开始的 ID 段，避免与 users 冲突
        return str(900000 + rng.randrange(max(1000, args.n_users)))

    n_noise_orders = int(len(orders) * args.noise_rate)
    n_noise_clicks = int(len(clicks) * args.noise_rate)

    for _ in range(n_noise_orders):
        uid = random_noise_user_id()
        # 在同一时间范围随机生成
        day = rng.randrange(args.horizon_days + 1)
        ts = ref_ts - timedelta(days=day)
        amount = str(rng.randint(10, 500))
        orders.append({"user_id": uid, "ts": iso(ts), "amount": amount})

    for _ in range(n_noise_clicks):
        uid = random_noise_user_id()
        day = rng.randrange(args.horizon_days + 1)
        ts = ref_ts - timedelta(days=day)
        clicks.append({"user_id": uid, "ts": iso(ts)})

    # 3) 写 raw
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    EXP_DIR.mkdir(parents=True, exist_ok=True)

    write_csv(USERS_PATH, USERS_COLS, users)
    write_csv(ORDERS_PATH, ORDERS_COLS, orders)
    write_csv(CLICKS_PATH, CLICKS_COLS, clicks)

    # 4) 计算 expected/gt.csv
    gt_rows = compute_gt(users, orders, clicks, ref_ts=ref_ts, window_days=args.window_days)

    if len(users) < 100:
        raise RuntimeError(f"users 数量过少：{len(users)}（请增大 --n-users）")

    write_csv(GT_PATH, GT_COLS, gt_rows)

    print("[gen_data] 已生成：")
    print(f"  - {USERS_PATH}  (rows={len(users)})")
    print(f"  - {ORDERS_PATH} (rows={len(orders)})")
    print(f"  - {CLICKS_PATH} (rows={len(clicks)})")
    print(f"  - {GT_PATH}     (rows={len(gt_rows)})")
    print(f"  - ref_ts={ref_ts}, window_days={args.window_days}")


if __name__ == "__main__":
    main()