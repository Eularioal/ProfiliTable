#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py – MDM Golden-Record 算子评测
===================================

要求
  1. 读取 raw/customer1.csv & raw/customer2.csv
  2. 以 email+phone 为对齐键，输出黄金记录
     (列集至少包含: email,phone,name,name_source,name_confidence)
  3. name 字段冲突解决策略:
        CRM 优先 → 置信度最高 → 并列取最先出现
     若 CRM 无记录则向 ERP 取值，规则同上
  4. 结果保存为 CSV；行顺序不作要求

评分
  • 输出缺列 / 行集合不等 → 0.0
  • 完全一致            → 1.0
"""

from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
from collections import Counter
from typing import Dict, List, Tuple

ROOT = Path(__file__).resolve().parent
GT   = ROOT / "expected" / "gt.csv"
REQ_COLS = ["email", "phone", "name", "name_source", "name_confidence"]

# ───────── IO ─────────
def load_csv(p: Path) -> Tuple[List[str], List[Dict[str, str]]]:
    with p.open(encoding="utf-8", newline="") as f:
        rdr = csv.DictReader(f)
        if rdr.fieldnames is None:
            raise ValueError(f"{p} 缺少表头")
        header = rdr.fieldnames
        rows   = [dict(r) for r in rdr]
    return header, rows

def rows_ctr(rows: List[Dict[str,str]], header: List[str]) -> Counter:
    return Counter(tuple(r.get(c,"") for c in header) for r in rows)

# ───────── 评测 ─────────
def evaluate(gt_hdr, gt_rows, pred_rows) -> float:
    if not pred_rows:
        print("[eval] 输出为空", file=sys.stderr)
        return 0.0
    for c in REQ_COLS:
        if c not in pred_rows[0]:
            print(f"[eval] 缺少必需列: {c}", file=sys.stderr)
            return 0.0
    gt_ctr  = rows_ctr(gt_rows,  REQ_COLS)
    pr_ctr  = rows_ctr(pred_rows, REQ_COLS)
    if gt_ctr != pr_ctr:
        miss  = gt_ctr - pr_ctr
        extra = pr_ctr - gt_ctr
        if miss:
            print(f"[eval] 缺失行示例: {list(miss.elements())[:3]} …",  file=sys.stderr)
        if extra:
            print(f"[eval] 多余行示例: {list(extra.elements())[:3]} …", file=sys.stderr)
        return 0.0
    return 1.0

# ───────── CLI ─────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate MDM golden-record operator")
    parser.add_argument("-o","--output",required=True,
                        help="CSV file produced by operator")
    args = parser.parse_args()
    pred_path = Path(args.output)
    if not pred_path.exists():
        print(f"文件不存在: {pred_path}", file=sys.stderr)
        print(json.dumps({"eval_score":"0.0"})); sys.exit(1)
    try:
        gt_hdr,  gt_rows  = load_csv(GT)
        _,      pr_rows   = load_csv(pred_path)
    except Exception as exc:
        print(f"[eval] 读取 CSV 失败: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score":"0.0"})); sys.exit(1)

    score = evaluate(gt_hdr, gt_rows, pr_rows)
    print(json.dumps({"eval_score":f"{score:.1f}"}))

if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"[eval] 评测异常: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score":"0.0"})); sys.exit(1)