#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
gen_data.py – 假数据生成 · MDM GOLDEN RECORD
------------------------------------------
1. raw/customer1.csv  (CRM)  – 150 行，含重复 email/phone
2. raw/customer2.csv  (ERP)  – 120 行，部分覆盖 CRM
3. expected/gt.csv    – 应用优先级/置信度规则后的黄金记录
"""

import os, random
import pandas as pd
from faker import Faker

SEED             = 2024
UNIQUE_ENTITIES  = 120     # 不同 email+phone 的实体数
CRM_EXTRA_ROWS   = 30      # 额外制造 CRM 内部冲突
ERP_ONLY_ROWS    = 30      # 只在 ERP 出现的实体
random.seed(SEED)
fake = Faker("en_US")
Faker.seed(SEED)

os.makedirs("raw", exist_ok=True)
os.makedirs("expected", exist_ok=True)

# ─────────── 1. 生成基础实体（email+phone） ───────────
base_entities = []
for _ in range(UNIQUE_ENTITIES):
    email = fake.unique.email()
    phone = fake.unique.msisdn()[:10]
    base_entities.append((email, phone))

# ─────────── 2. CRM (customer1.csv) ───────────
crm_rows = []
idx = 1
for email, phone in base_entities:
    crm_rows.append(
        {
            "row_id": idx,
            "email": email,
            "phone": phone,
            "name": fake.first_name(),
            "name_confidence": round(random.uniform(0.7, 0.99), 3),
            "source": "CRM",
        }
    )
    idx += 1

# 额外行 → 与前面随机实体键相同但 name/置信度不同
for _ in range(CRM_EXTRA_ROWS):
    email, phone = random.choice(base_entities)
    crm_rows.append(
        {
            "row_id": idx,
            "email": email,
            "phone": phone,
            "name": fake.first_name(),
            "name_confidence": round(random.uniform(0.5, 0.95), 3),
            "source": "CRM",
        }
    )
    idx += 1

crm_df = pd.DataFrame(crm_rows)
crm_df.to_csv("raw/customer1.csv", index=False)

# ─────────── 3. ERP (customer2.csv) ───────────
erp_rows = []
# 3-1 与 CRM 重叠的部分
for email, phone in random.sample(base_entities, int(UNIQUE_ENTITIES * 0.6)):
    erp_rows.append(
        {
            "email": email,
            "phone": phone,
            "name": fake.first_name(),
            "name_confidence": round(random.uniform(0.6, 0.98), 3),
            "source": "ERP",
        }
    )
# 3-2 仅在 ERP 出现的新增实体
for _ in range(ERP_ONLY_ROWS):
    erp_rows.append(
        {
            "email": fake.unique.email(),
            "phone": fake.unique.msisdn()[:10],
            "name": fake.first_name(),
            "name_confidence": round(random.uniform(0.6, 0.98), 3),
            "source": "ERP",
        }
    )

erp_df = pd.DataFrame(erp_rows)
erp_df.to_csv("raw/customer2.csv", index=False)

# ─────────── 4. 生成黄金记录 (gt.csv) ───────────
all_rows = pd.concat([crm_df, erp_df], ignore_index=True)

def pick_name(group: pd.DataFrame) -> pd.Series:
    """按优先级策略选出 name 相关列"""
    # 1) 先筛 CRM，再 ERP
    for source in ("CRM", "ERP"):
        sub = group[group["source"] == source]
        if sub.empty:
            continue
        # 2) 置信度最高
        max_conf = sub["name_confidence"].max()
        best = sub[sub["name_confidence"] == max_conf]
        # 3) 并列取最早 row_id / 原顺序
        idxmin = best.index.min()
        row = best.loc[idxmin]
        return pd.Series(
            {
                "name": row["name"],
                "name_source": source,
                "name_confidence": f"{row['name_confidence']:.3f}",
            }
        )
    # 两源都缺（极少出现）
    return pd.Series({"name": "", "name_source": "", "name_confidence": ""})

golden = (
    all_rows.sort_values("row_id", na_position="last")  # 保证行号可用
            .groupby(["email", "phone"], as_index=False)
            .apply(pick_name)
)

golden.to_csv("expected/gt.csv", index=False)

print("✅ 假数据生成完成：raw/*.csv 与 expected/gt.csv")