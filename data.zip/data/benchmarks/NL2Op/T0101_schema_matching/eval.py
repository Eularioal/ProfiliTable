#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “表格匹配” 算子

使用方法
--------
python eval.py -o /path/to/your_output.csv [-k 主键列1 主键列2]
"""

from __future__ import annotations
import argparse
import csv
from pathlib import Path
from typing import List, Tuple, Set, Sequence, Dict

# ------------------------------------------------------------------ 常量
GT_PATH = Path(__file__).parent / "expected" / "gt.csv"
COMPOSITE_KEY_SEP = "||"

# ------------------------------------------------------------------ 工具函数
def normalize_header(col: str) -> str:
    """列名规范化：全小写、去空格/下划线/**标记"""
    return col.strip().lower().replace(" ", "").replace("_", "").replace("**", "")

def normalize_cell(cell: str) -> str:
    """
    单元格规范化：
    - 纯 `-`/空/nan/NULL → 转为 ""（缺失值）
    - 含 `-` 的有效数据（如 A-123、-123）→ 保留并去空格
    """
    cell_stripped = cell.strip()
    if cell_stripped in ["", "-", "nan", "NULL", "null"]:
        return ""
    return cell_stripped

def read_header_and_rows(path: Path) -> Tuple[List[str], List[List[str]]]:
    """读取CSV，自动补全列数，避免行列数不匹配"""
    with path.open(encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        rows = list(reader)
        if not rows:
            raise ValueError(f"{path} 为空文件")
        header, data = rows[0], rows[1:]
        
        # 自动补全列数（按最长行对齐）
        max_cols = max(len(row) for row in rows)
        if len(header) < max_cols:
            header += [f"Unnamed_{i}" for i in range(len(header), max_cols)]
        data = [row + [""]*(max_cols - len(row)) for row in data]
        
        # 单元格规范化（处理-）
        data = [[normalize_cell(cell) for cell in row] for row in data]
        return header, data

def get_primary_keys(gt_header: List[str], manual_keys: List[str] = None) -> List[str]:
    """识别多主键列（优先手动指定，否则识别**列）"""
    gt_header_norm = [normalize_header(col) for col in gt_header]
    if manual_keys:
        manual_keys_norm = [normalize_header(k) for k in manual_keys]
        valid_keys = [gt_header[i] for i, norm_col in enumerate(gt_header_norm) if norm_col in manual_keys_norm]
        if not valid_keys:
            raise ValueError(f"手动指定的主键列 {manual_keys} 未在GT表头中找到")
        return valid_keys
    primary_keys = [col for col in gt_header if col.strip().endswith("**")]
    if not primary_keys:
        raise ValueError("未找到带**标记的主键列，请通过 -k 手动指定")
    return primary_keys

def generate_composite_key(row: List[str], header: List[str], primary_keys: List[str]) -> str:
    """生成复合键（保留有效-，统一小写）"""
    key_parts = []
    for pk in primary_keys:
        idx = header.index(pk) if pk in header else -1
        val = row[idx].lower() if idx >= 0 and idx < len(row) else ""
        key_parts.append(val)
    return COMPOSITE_KEY_SEP.join(key_parts)

def canonicalize_rows(
    header_ref: Sequence[str],
    header_pred: Sequence[str],
    pred_rows_raw: List[Sequence[str]],
) -> List[Tuple[str, ...]]:
    """预测行规范化：映射列顺序+处理-"""
    pred_header_norm = {normalize_header(col): i for i, col in enumerate(header_pred)}
    canon_rows: List[Tuple[str, ...]] = []
    for raw in pred_rows_raw:
        canon = tuple(
            normalize_cell(raw[pred_header_norm[normalize_header(col)]]) 
            if normalize_header(col) in pred_header_norm and pred_header_norm[normalize_header(col)] < len(raw) 
            else ""
            for col in header_ref
        )
        canon_rows.append(canon)
    return canon_rows

# ------------------------------------------------------------------ 评分
def compute_f1(
    gt_rows: Dict[str, Tuple[str, ...]],
    pred_rows: List[Tuple[str, ...]],
    pred_header: List[str],
    gt_header: List[str],
    primary_keys: List[str]
) -> float:
    """多主键F1计算"""
    if not pred_rows:
        return 0.0
    if not gt_rows:
        return 1.0 if not pred_rows else 0.0

    pred_key_to_rows: Dict[str, List[Tuple[str, ...]]] = {}
    for row in pred_rows:
        row_list = list(row)
        comp_key = generate_composite_key(row_list, gt_header, primary_keys)
        if comp_key not in pred_key_to_rows:
            pred_key_to_rows[comp_key] = []
        pred_key_to_rows[comp_key].append(row)

    tp_seen: Set[str] = set()
    tp = 0
    for comp_key, pred_row_list in pred_key_to_rows.items():
        if comp_key not in gt_rows:
            continue
        gt_row = gt_rows[comp_key]
        for pred_row in pred_row_list:
            if pred_row == gt_row and comp_key not in tp_seen:
                tp_seen.add(comp_key)
                tp += 1
                break

    precision = tp / len(pred_rows)
    recall = tp / len(gt_rows)
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)

# ------------------------------------------------------------------ 主流程
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate composite-key deduplication")
    parser.add_argument("-o", "--output", required=True, help="Path to predicted CSV")
    parser.add_argument("-k", "--keys", nargs="+", default=None, help="Multiple primary keys")
    args = parser.parse_args()

    # 读取GT
    gt_header, gt_data = read_header_and_rows(GT_PATH)
    primary_keys = get_primary_keys(gt_header, args.keys)
    print(f"识别到多主键列：{primary_keys}")

    # 生成GT复合键-行映射（去重）
    gt_rows_dict: Dict[str, Tuple[str, ...]] = {}
    for row in gt_data:
        comp_key = generate_composite_key(row, gt_header, primary_keys)
        if comp_key not in gt_rows_dict:
            gt_rows_dict[comp_key] = tuple(row)

    # 读取Pred
    pred_path = Path(args.output)
    if not pred_path.exists():
        raise FileNotFoundError(pred_path)
    pred_header, pred_raw_rows = read_header_and_rows(pred_path)
    pred_rows = canonicalize_rows(gt_header, pred_header, pred_raw_rows)

    # 计算得分
    score = compute_f1(gt_rows_dict, pred_rows, pred_header, gt_header, primary_keys)
    print({"eval_score": f"{score:.4f}"})

if __name__ == "__main__":
    main()