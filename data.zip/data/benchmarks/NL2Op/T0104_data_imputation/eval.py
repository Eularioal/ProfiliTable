#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “数据补全 (Imputation)” 算子

使用方法
--------
python eval.py -o /path/to/your_output.csv

说明
----
1. 基准文件固定为同级目录 expected/gt.csv
2. -o 指向数据补全算子的输出CSV文件（预测结果）
3. 核心规则：
   - 仅评测GT表中带**标注的「填补缺失单元格」
   - GT单元格值去除**后归一化，Pred对应单元格正常归一化
   - 非填补单元格不参与计算
4. 归一化规则：
   - 缺失值（nan/null/na等）统一标记为"MISSING"
   - 数值型自动标准化（整数去小数点，小数去冗余后缀0）
   - 文本型转小写+去空格
5. 评测指标：Accuracy（正确数/总填补单元格数）
6. 指标范围 ∈ [0,1]，输出格式：{"eval_score": 准确率（保留4位小数）}
"""

from __future__ import annotations
import argparse
import warnings
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Tuple, Optional, List, Dict

# ------------------------------------------------------------------ 常量
GT_PATH = Path(__file__).parent / "expected" / "gt.csv"  # 固定基准文件路径
MISSING_LABEL = "MISSING"  # 缺失值统一标记
FILL_MARKER = "**"  # 填补单元格的标注符
warnings.filterwarnings('ignore', category=UserWarning, module='sklearn')

# ------------------------------------------------------------------ 工具函数
def normalize(val: str | int | float, is_gt: bool = False) -> str:
    """
    归一化单元格值（区分GT/Pred处理）
    参数：
        val - 原始单元格值
        is_gt - 是否为GT数据（True则先去除**标注）
    返回：归一化后的字符串
    """
    # 1. GT数据先去除**标注
    if is_gt:
        val = str(val).replace(FILL_MARKER, "")
    
    # 2. 转换为字符串并预处理
    s = str(val).strip().lower()
    
    # 3. 定义缺失值集合
    missing_tokens = {'nan', 'none', 'null', 'na', '', 'n/a', '<na>'}
    if s in missing_tokens:
        return MISSING_LABEL

    # 4. 尝试数值化处理
    try:
        f_val = float(s)
        # 如果是整数 (例如 5.0, 5.00, 5)，转为不带小数点的字符串 "5"
        if f_val.is_integer():
            return str(int(f_val))
        # 如果是真正的小数 (例如 5.2, 0.01)，去除多余的后缀0并保留
        else:
            return str(f_val)
    except (ValueError, TypeError):
        # 5. 如果无法转为数字，则按普通文本处理
        return s

def read_and_align_data(gt_path: str | Path, pred_path: str | Path) -> Tuple[Optional[pd.DataFrame], Optional[pd.DataFrame], List[str]]:
    """
    读取GT和Pred数据并完成结构对齐
    逻辑：保留共有列，截断到最小行数
    返回：对齐后的GT数据、Pred数据、共有列列表（读取失败返回None）
    """
    # 读取数据
    try:
        df_gt = pd.read_csv(gt_path)
        df_pred = pd.read_csv(pred_path)
    except Exception as e:
        print(f"文件读取失败: {e}")
        return None, None, []
    
    # 筛选共有列
    common_cols = df_gt.columns.intersection(df_pred.columns)
    if len(common_cols) == 0:
        print("错误: 两个 CSV 没有相同的列名，无法对比。")
        return None, None, []
    
    # 截断到最小行数
    min_len = min(len(df_gt), len(df_pred))
    
    # 筛选对齐后的数据
    df_gt_aligned = df_gt.loc[:min_len-1, common_cols].copy()
    df_pred_aligned = df_pred.loc[:min_len-1, common_cols].copy()
    
    print(f"有效评测形状: {df_gt_aligned.shape} (列: {list(common_cols)})")
    return df_gt_aligned, df_pred_aligned, list(common_cols)

def get_fill_cell_mask(df_gt: pd.DataFrame) -> np.ndarray:
    """
    识别GT表中带**标注的填补缺失单元格，生成掩码矩阵
    返回：布尔矩阵（True=填补单元格，False=非填补单元格）
    """
    # 逐单元格检查是否包含**标注
    fill_mask = df_gt.applymap(lambda x: FILL_MARKER in str(x))
    # 转换为numpy布尔矩阵
    fill_mask_np = fill_mask.values
    # 统计填补单元格数量
    total_fill_cells = np.sum(fill_mask_np)
    print(f"GT表中需评测的填补缺失单元格总数: {total_fill_cells}")
    
    if total_fill_cells == 0:
        print("警告: GT表中未发现带**标注的填补缺失单元格，Accuracy=0")
    
    return fill_mask_np

def compute_fill_accuracy(df_gt: pd.DataFrame, df_pred: pd.DataFrame, fill_mask: np.ndarray) -> Dict[str, float]:
    """
    计算仅填补缺失单元格的Accuracy
    返回：包含accuracy的指标字典
    """
    # 1. 对GT和Pred分别归一化（GT先去**，Pred正常）
    df_gt_norm = df_gt.apply(lambda col: col.map(lambda x: normalize(x, is_gt=True)))
    df_pred_norm = df_pred.apply(lambda col: col.map(lambda x: normalize(x, is_gt=False)))
    
    # 2. 扁平化数据
    gt_vals = df_gt_norm.values.flatten()
    pred_vals = df_pred_norm.values.flatten()
    fill_mask_flat = fill_mask.flatten()
    
    # 3. 仅提取填补单元格的数据
    gt_fill_vals = gt_vals[fill_mask_flat]
    pred_fill_vals = pred_vals[fill_mask_flat]
    
    # 4. 计算Accuracy
    if len(gt_fill_vals) == 0:
        accuracy = 0.0
    else:
        correct = np.sum(gt_fill_vals == pred_fill_vals)
        accuracy = correct / len(gt_fill_vals)
    
    return {
        "accuracy": round(accuracy, 4),
        "correct": int(correct) if len(gt_fill_vals) > 0 else 0,
        "total": len(gt_fill_vals)
    }

# ------------------------------------------------------------------ 主流程
def main() -> None:
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="Evaluate Data Imputation output (Fill Cell Only)")
    parser.add_argument(
        "-o", "--output", required=True,
        help="Path to CSV produced by your data imputation operator (prediction result)"
    )
    args = parser.parse_args()

    # 1. 检查基准文件是否存在
    if not GT_PATH.exists():
        print(f"错误：基准文件不存在，请先创建 {GT_PATH}")
        return

    # 2. 读取并对齐数据
    pred_path = Path(args.output)
    if not pred_path.exists():
        print(f"错误：预测文件不存在 {pred_path}")
        return
    
    df_gt_aligned, df_pred_aligned, _ = read_and_align_data(GT_PATH, pred_path)
    if df_gt_aligned is None or df_pred_aligned is None:
        return

    # 3. 识别GT中的填补缺失单元格掩码
    fill_mask = get_fill_cell_mask(df_gt_aligned)

    # 4. 计算仅填补单元格的Accuracy
    metrics = compute_fill_accuracy(df_gt_aligned, df_pred_aligned, fill_mask)

    # 5. 输出结果
    print({"eval_score": f"{metrics['accuracy']:.4f}"})

if __name__ == "__main__":
    main()