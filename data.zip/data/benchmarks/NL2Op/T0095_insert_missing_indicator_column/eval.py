#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eval.py
=======

评测脚本 —— 检查选手是否正确生成缺失指示列

用法:
    python eval.py -o <candidate.csv>

成功: {"eval_score":"1.0"}
失败: {"eval_score":"0.0"} 并把原因写到 stderr
"""

from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import pandas as pd
import numpy as np

# ───────── 配置 (需与 gen_data.py 保持一致) ─────────
ROOT       = Path(__file__).resolve().parent
RAW_CSV    = ROOT / "raw" / "customers.csv"
GT_CSV     = ROOT / "expected" / "gt.csv"
IND_COLS   = ["age", "city"]
IND_SUFFIX = "_missing"
ATOL       = 1e-8      # 数值比较容忍
# ────────────────────────────────────────────────


def fail(msg: str, code: int = 1) -> None:
    print(f"[eval] {msg}", file=sys.stderr)
    print(json.dumps({"eval_score": "0.0"}))
    sys.exit(code)


def read_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, na_values=["", "NA"])


def evaluate(cand: pd.DataFrame,
             gt:   pd.DataFrame,
             raw:  pd.DataFrame) -> float:
    # 1) 行列数与列顺序
    if cand.shape != gt.shape:
        fail(f"行列数不一致: 期望 {gt.shape}, 实际 {cand.shape}")
    if set(cand.columns) != set(gt.columns):
        fail("列名与基准不一致")

    # 2) 检查每个缺失指示列
    for col in IND_COLS:
        ind = f"{col}{IND_SUFFIX}"
        if ind not in cand.columns:
            fail(f"缺失指示列不存在: {ind}")

        if cand[ind].isna().any():
            fail(f"指示列 {ind} 存在缺失值")

        # 值必须是 0/1
        if not set(cand[ind].unique()) <= {0, 1}:
            fail(f"指示列 {ind} 包含非 0/1 值")

        # 与基准比较
        if not np.allclose(cand[ind].astype(float), gt[ind].astype(float), atol=ATOL):
            fail(f"指示列 {ind} 与基准不一致")

    # 3) 原列不得被修改
    orig_cols = [c for c in raw.columns]
    if not cand[orig_cols].equals(raw[orig_cols]):
        fail("原始列被修改")

    return 1.0


def main() -> None:
    ap = argparse.ArgumentParser(description="Evaluate missing-indicator operator")
    ap.add_argument("-o", "--output", required=True, help="candidate CSV file")
    args = ap.parse_args()

    cand_path = Path(args.output)
    if not cand_path.exists():
        fail(f"文件不存在: {cand_path}")

    try:
        raw = read_csv(RAW_CSV)
        gt  = read_csv(GT_CSV)
        cand = read_csv(cand_path)
    except Exception as exc:
        fail(f"读取 CSV 失败: {exc}")

    score = evaluate(cand, gt, raw)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        fail(f"评测脚本异常: {exc}", code=2)