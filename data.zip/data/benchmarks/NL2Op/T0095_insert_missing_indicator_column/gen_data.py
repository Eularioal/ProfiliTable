#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py
===========

1. 生成 raw/customers.csv（包含缺失）
2. 为指定列添加缺失指示列，写 expected/gt.csv

编码：UTF-8（无 BOM）
依赖：pandas、numpy
"""

from pathlib import Path
import numpy as np
import pandas as pd

# ────────── 参数区 ──────────
RAW_PATH = Path("raw/customers.csv")
GT_PATH  = Path("expected/gt.csv")

N_ROWS     = 25
RAND_SEED  = 666
MISS_RATE  = 0.30          # 缺失占比
IND_COLS   = ["age", "city"]      # 需要生成缺失指示列的原列
IND_SUFFIX = "_missing"           # 指示列后缀
# ──────────────────────────

rng = np.random.default_rng(RAND_SEED)


def make_raw() -> pd.DataFrame:
    """构造含缺失值的示例数据集"""
    df = pd.DataFrame(
        {
            "customer_id": range(1, N_ROWS + 1),
            "age": rng.integers(18, 70, size=N_ROWS).astype(float),
            "income": rng.normal(55_000, 17_000, size=N_ROWS),
            "city": rng.choice(["Beijing", "Shanghai", "Shenzhen"], size=N_ROWS),
        }
    )

    # 制造缺失: age 与 city 随机 MISS_RATE
    for col in IND_COLS:
        mask = rng.random(N_ROWS) < MISS_RATE
        # 其中一半填 NaN, 一半填字符串 "NA"
        half = mask & (rng.random(N_ROWS) < 0.5)
        df.loc[mask &  half, col] = np.nan
        df.loc[mask & ~half, col] = "NA"

    return df


def add_indicator(df: pd.DataFrame) -> pd.DataFrame:
    """为 IND_COLS 生成缺失指示列并返回新 DataFrame"""
    out = df.copy()
    for col in IND_COLS:
        ind_name = f"{col}{IND_SUFFIX}"
        out[ind_name] = out[col].isna() | (out[col] == "") | (out[col] == "NA")
        out[ind_name] = out[ind_name].astype(int)
        # 将指示列插入到原列之后，保持可读性
        col_pos = out.columns.get_loc(col)
        cols = out.columns.tolist()
        cols.insert(col_pos + 1, cols.pop(cols.index(ind_name)))
        out = out[cols]
    return out


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8")   # 无 BOM


def main() -> None:
    raw_df = make_raw()
    write_csv(raw_df, RAW_PATH)
    print(f"✅ raw 数据已写出: {RAW_PATH}")

    gt_df = add_indicator(raw_df)
    write_csv(gt_df, GT_PATH)
    print(f"✅ 缺失指示列已写出: {GT_PATH}")


if __name__ == "__main__":
    main()