#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 最近时间戳连接 (AS-OF) 算子评测
========================================
要求
    • 读取 raw/customer1.csv 与 raw/customer2.csv
    • 在 customer_id 分组内，找出 right_ts ≤ left_ts & 最近 的记录
    • 若 (left_ts - right_ts) > 7 天，视为无匹配 → 右表列空字符串
    • 结果保存为 CSV，至少包含 expected/gt.csv 的全部列

评分
    1. 输出缺列       → 0.0
    2. 在 expected 列集合上比较行多重集合(忽略顺序) → 完全一致得 1.0，否则 0.0
"""

from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
from collections import Counter
from typing import Dict, List, Tuple

ROOT = Path(__file__).resolve().parent
GT   = ROOT / "expected" / "gt.csv"

# ───────── IO ─────────
def load_csv(path: Path) -> Tuple[List[str], List[Dict[str, str]]]:
    with path.open(encoding="utf-8", newline="") as f:
        rdr = csv.DictReader(f)
        if rdr.fieldnames is None:
            raise ValueError(f"{path} 缺少表头")
        header = rdr.fieldnames
        rows   = [dict(r) for r in rdr]
    return header, rows

def rows2ctr(rows: List[Dict[str, str]], header: List[str]) -> Counter:
    return Counter(tuple(r.get(c, "") for c in header) for r in rows)

# ───────── 核心评测 ─────────
def evaluate(gt_hdr, gt_rows, pred_rows) -> float:
    if not pred_rows:
        print("[eval] 输出为空", file=sys.stderr)
        return 0.0
    miss_cols = [c for c in gt_hdr if c not in pred_rows[0]]
    if miss_cols:
        print(f"[eval] 输出缺少列: {miss_cols}", file=sys.stderr)
        return 0.0
    gt_ctr   = rows2ctr(gt_rows,  gt_hdr)
    pr_ctr   = rows2ctr(pred_rows, gt_hdr)
    if gt_ctr != pr_ctr:
        lack  = gt_ctr - pr_ctr
        extra = pr_ctr - gt_ctr
        if lack:
            print(f"[eval] 缺失行示例: {list(lack.elements())[:3]} …",  file=sys.stderr)
        if extra:
            print(f"[eval] 多余行示例: {list(extra.elements())[:3]} …", file=sys.stderr)
        return 0.0
    return 1.0

# ───────── CLI ─────────
def main():
    p = argparse.ArgumentParser(description="Evaluate as-of join operator")
    p.add_argument("-o", "--output", required=True,
                   help="CSV produced by operator")
    args = p.parse_args()

    pred = Path(args.output)
    if not pred.exists():
        print(f"文件不存在: {pred}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"})); sys.exit(1)

    try:
        gt_hdr,  gt_rows  = load_csv(GT)
        _,      pr_rows   = load_csv(pred)
    except Exception as e:
        print(f"[eval] CSV 读取失败: {e}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"})); sys.exit(1)

    score = evaluate(gt_hdr, gt_rows, pr_rows)
    print(json.dumps({"eval_score": f"{score:.1f}"}))

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"[eval] 评测异常: {e}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"})); sys.exit(1)