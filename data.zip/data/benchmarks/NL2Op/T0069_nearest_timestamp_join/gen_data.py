#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
gen_data.py ― 基准假数据 · 最近时间戳连接 (AS-OF) 版
---------------------------------------------------
目标:
    1. raw/customer1.csv  左表 (≈200 行)
    2. raw/customer2.csv  右表 (≈600 行)
    3. expected/gt.csv    按 customer_id 分组, 取
          right_ts ≤ left_ts 且距离最近, 且
          (left_ts - right_ts) ≤ 7 天
       的连接结果; 否则右表列为空
"""

import os, random
from datetime import datetime, timedelta
import pandas as pd
from faker import Faker

# —──────── 参数 —────────
N_CUSTOMERS  = 25        # 分组个数
LEFT_ROWS    = 200       # 左表行数
RIGHT_ROWS   = 600       # 右表行数
MAX_LAG      = timedelta(days=7)
SEED         = 2024

fake = Faker()
random.seed(SEED)
Faker.seed(SEED)

os.makedirs("raw", exist_ok=True)
os.makedirs("expected", exist_ok=True)

# —──────── 生成左表 —────────
start_date = datetime.now() - timedelta(days=30)

def rand_left_ts():
    return start_date + timedelta(minutes=random.randint(0, 30*24*60))

left_rows = []
for _ in range(LEFT_ROWS):
    cid = random.randint(1, N_CUSTOMERS)
    ts  = rand_left_ts()
    left_rows.append(
        {
            "customer_id": cid,
            "left_ts":     ts.isoformat(timespec="seconds"),
            "left_note":   fake.word(),
        }
    )
customer1 = pd.DataFrame(left_rows).sort_values(["customer_id", "left_ts"])
customer1.to_csv("raw/customer1.csv", index=False)

# —──────── 生成右表 —────────
def rand_right_ts():
    return start_date + timedelta(minutes=random.randint(0, 30*24*60))

right_rows = []
for _ in range(RIGHT_ROWS):
    cid = random.randint(1, N_CUSTOMERS)
    ts  = rand_right_ts()
    right_rows.append(
        {
            "customer_id": cid,
            "right_ts":    ts.isoformat(timespec="seconds"),
            "event_type":  random.choice(["view", "click", "purchase"]),
        }
    )
customer2 = pd.DataFrame(right_rows).sort_values(["customer_id", "right_ts"])
customer2.to_csv("raw/customer2.csv", index=False)

# —──────── 构造真值 gt.csv —────────
# 先将时间列转为 datetime
c1 = customer1.copy()
c2 = customer2.copy()
c1["left_ts_dt"]  = pd.to_datetime(c1["left_ts"])
c2["right_ts_dt"] = pd.to_datetime(c2["right_ts"])

# 在同 customer_id 分组内执行 “不晚于且最近” 匹配
def asof_join(group_left, group_right):
    out = group_left.copy()
    # Pandas merge_asof 要求排序
    out = pd.merge_asof(
        out.sort_values("left_ts_dt"),
        group_right.sort_values("right_ts_dt"),
        left_on="left_ts_dt",
        right_on="right_ts_dt",
        direction="backward",
        tolerance=MAX_LAG,
        suffixes=("", "_r"),
    )
    return out

gt = (
    c1.groupby("customer_id", group_keys=False)
      .apply(lambda g: asof_join(g, c2[c2["customer_id"] == g.name]))
)

# 填补空列为 "" 而不是 NaN
gt["event_type"] = gt["event_type"].fillna("")
gt["right_ts"]   = gt["right_ts"].fillna("")

# 去掉辅助列
gt = gt.drop(columns=["left_ts_dt", "right_ts_dt"])

# 保持与左表同一列顺序 + 右表列
gt = gt[["customer_id", "left_ts", "left_note", "right_ts", "event_type"]]

gt.to_csv("expected/gt.csv", index=False)
print("✅ 数据已生成：raw/*.csv 与 expected/gt.csv")