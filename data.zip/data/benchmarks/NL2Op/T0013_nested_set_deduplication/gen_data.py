#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py
生成 ≥100 条去重后(GT)数据，以及 ≥200 条原始(raw)数据
目录结构：
T0009_nested_set_deduplication/
├── gen_data.py  ← 本脚本
├── raw/
│   ├── customers.jsonl
│   └── customers.csv
└── expected/
    ├── gt.jsonl
    └── gt.csv

✅ 关键修正：raw 与 gt 共享 set_id，保证去重后可严格还原 GT
"""

import json
import csv
import random
from pathlib import Path

# 可调整数量
NUM_GT = 120          # 期望保留的最终集合数 (≥100)
DUP_PER_GT = 2        # 为每个 GT 额外生成多少条“重复记录”
RANDOM_SEED = 42      # 保证复现

random.seed(RANDOM_SEED)

BASE_DIR      = Path(__file__).resolve().parent
RAW_DIR       = BASE_DIR / "raw"
EXPECTED_DIR  = BASE_DIR / "expected"
RAW_DIR.mkdir(parents=True, exist_ok=True)
EXPECTED_DIR.mkdir(parents=True, exist_ok=True)

# ───────────────────────────────────────────────────────────
# 1. 生成 GT（不会互为子集）
#    每个集合带有独一无二的前缀元素，天然避免子集关系
# ───────────────────────────────────────────────────────────
gt_records = []
for i in range(NUM_GT):
    size = random.randint(3, 8)               # 3~8 个元素
    prefix = f"g{i:03d}_"                     # 独特前缀
    elems  = [f"{prefix}{j}" for j in range(size)]
    random.shuffle(elems)                     # 打乱顺序
    gt_records.append({"elements": elems})

# ───────────────────────────────────────────────────────────
# 2. 为 GT 分配唯一 set_id（S001, S002, ..., S120）
# ───────────────────────────────────────────────────────────
for idx, rec in enumerate(gt_records, 1):
    rec["set_id"] = f"S{idx:03d}"

# ───────────────────────────────────────────────────────────
# 3. 生成 raw：每条 GT + 其噪声版本（permutation / subset），共享同一 set_id
# ───────────────────────────────────────────────────────────
raw_records = []

for rec in gt_records:
    # ① 加入 GT 原始记录（去重后应保留的真值）
    raw_records.append({
        "set_id": rec["set_id"],
        "elements": rec["elements"].copy(),
        "kind": "gt"
    })

    # ② 生成噪声版本（重复/子集），复用同一 set_id
    for _ in range(DUP_PER_GT):
        if random.random() < 0.5:
            # permutation duplicate：元素全同，顺序不同
            dup_elems = rec["elements"].copy()
            random.shuffle(dup_elems)
        else:
            # subset duplicate：真子集（至少少1个，至多剩1个）
            k = random.randint(1, len(rec["elements"]) - 1)
            dup_elems = random.sample(rec["elements"], len(rec["elements"]) - k)

        raw_records.append({
            "set_id": rec["set_id"],  # ← 关键：复用 GT 的 set_id！
            "elements": dup_elems,
            "kind": "dup"
        })

# ───────────────────────────────────────────────────────────
# 4. 写入 raw 文件（JSONL + CSV）
# ───────────────────────────────────────────────────────────
jsonl_path = RAW_DIR / "customers.jsonl"
csv_path   = RAW_DIR / "customers.csv"

with jsonl_path.open("w", encoding="utf-8") as jf, \
     csv_path.open("w", encoding="utf-8", newline="") as cf:
    csv_writer = csv.writer(cf)
    csv_writer.writerow(["set_id", "elements"])

    for rec in raw_records:
        # JSONL 标准格式
        json.dump({"set_id": rec["set_id"], "elements": rec["elements"]}, jf, ensure_ascii=False)
        jf.write("\n")

        # CSV：elements 存为 Python 字面量字符串（如 "['a','b']")
        csv_writer.writerow([rec["set_id"], str(rec["elements"])])

# ───────────────────────────────────────────────────────────
# 5. 写入 expected / GT 文件（按 set_id 升序）
# ───────────────────────────────────────────────────────────
gt_sorted = sorted(gt_records, key=lambda r: r["set_id"])

gt_jsonl_path = EXPECTED_DIR / "gt.jsonl"
gt_csv_path   = EXPECTED_DIR / "gt.csv"

with gt_jsonl_path.open("w", encoding="utf-8") as jf, \
     gt_csv_path.open("w", encoding="utf-8", newline="") as cf:
    csv_writer = csv.writer(cf)
    csv_writer.writerow(["set_id", "elements"])

    for rec in gt_sorted:
        payload = {"set_id": rec["set_id"], "elements": rec["elements"]}
        json.dump(payload, jf, ensure_ascii=False)
        jf.write("\n")
        csv_writer.writerow([rec["set_id"], str(rec["elements"])])

# ───────────────────────────────────────────────────────────
print(f"✅ 生成完毕：GT {len(gt_records)} 条（set_id: S001~S{NUM_GT:03d}）")
print(f"   RAW {len(raw_records)} 条（每 GT 有 1 原始 + {DUP_PER_GT} 噪声）")
print(f"   验证建议：对 raw 按 set_id 分组，取 len(elements) 最大者 → 应等于 GT")