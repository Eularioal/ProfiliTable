#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “嵌套集合去重算子”

评测目标
--------
算子应输出 *去重后的集合列表*（JSONL / CSV 均可），
字段至少包含
    • set_id   唯一标识
    • elements 无序集合（list / JSON 字符串）

评测标准
--------
1. 黄金标准固定为 expected/gt.jsonl
2. 行级 F1 计算  
   · TP：set_id 与 GT 相同，且 elements 作为 **集合** 完全一致  
   · 重复行 / 额外 set_id / elements 不一致 → FP  
   · 缺失任何应输出 set_id               → FN
3. 终端仅打印一行 JSON： {"eval_score": "<score>"}

用法
----
python eval.py -o /path/to/your_output.jsonl   # 或 .csv
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Dict, List, Set, Any


# ----------------------------- 常量 ------------------------------
GT_PATH = Path(__file__).parent / "expected" / "gt.jsonl"


# --------------------------- 读文件工具 ---------------------------
def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open(encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                raise ValueError(f"{path}:{lineno} 不是合法 JSON: {e}") from e
    if not rows:
        raise ValueError(f"{path} 为空文件")
    return rows


def parse_elements(raw: Any) -> List[str]:
    """
    将 elements 字段统一转换为 list[str]，允许：
      • 直接为 list
      • 为形如 "['a', 'b']" 或 '["a","b"]' 的字符串
    """
    if isinstance(raw, list):
        return [str(x) for x in raw]

    if raw is None:
        return []

    s = str(raw).strip()
    # 尝试用 json 解析
    try:
        j = json.loads(s)
        if isinstance(j, list):
            return [str(x) for x in j]
    except Exception:
        pass

    # 尝试 eval 形式的列表字符串
    if s.startswith("[") and s.endswith("]"):
        try:
            return [str(x) for x in eval(s, {"__builtins__": {}})]  # nosec
        except Exception:
            pass

    raise ValueError(f"无法解析 elements 字段: {raw!r}")


def read_csv(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open(encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if "set_id" not in reader.fieldnames or "elements" not in reader.fieldnames:
            raise ValueError(f"{path}: CSV 必须包含 set_id 与 elements 字段")
        for lineno, row in enumerate(reader, 2):
            rows.append({k: v for k, v in row.items()})
    if not rows:
        raise ValueError(f"{path} 为空文件")
    return rows


def read_rows(path: Path) -> List[Dict[str, Any]]:
    if path.suffix.lower() == ".jsonl":
        return read_jsonl(path)
    elif path.suffix.lower() == ".csv":
        return read_csv(path)
    else:
        raise ValueError(f"仅支持 .jsonl / .csv，收到 {path.name}")


# ----------------------------- 评分 ------------------------------
def compute_f1(
    gt_map: Dict[str, Set[str]],
    pred_rows: List[Dict[str, Any]],
) -> float:
    if not pred_rows:
        return 0.0  
    tp_ids: Set[str] = set()
    fp = 0

    seen_pred_ids: Set[str] = set()

    for row in pred_rows:
        rid = str(row.get("set_id", "")).strip()
        if not rid:
            fp += 1
            continue

        # 重复行
        if rid in seen_pred_ids:
            fp += 1
            continue
        seen_pred_ids.add(rid)

        try:
            elems = set(parse_elements(row.get("elements")))
        except Exception:
            fp += 1
            continue

        gt_elems = gt_map.get(rid)
        if gt_elems is None:
            fp += 1  # 额外 set_id
            continue

        if elems == gt_elems:
            tp_ids.add(rid)
        else:
            fp += 1  # elements 不一致

    fn = len(gt_map) - len(tp_ids)
    precision = len(tp_ids) / (len(tp_ids) + fp) if tp_ids or fp else 0.0
    recall = len(tp_ids) / (len(tp_ids) + fn) if tp_ids or fn else 0.0
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


# ----------------------------- 主流程 -----------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate nested-set deduplication output")
    parser.add_argument(
        "-o", "--output", required=True, help="Path to JSONL/CSV produced by your operator"
    )
    args = parser.parse_args()

    # ---------- 读取 GT ----------
    gt_rows = read_jsonl(GT_PATH)
    gt_map: Dict[str, Set[str]] = {
        str(r["set_id"]): set(parse_elements(r["elements"])) for r in gt_rows
    }

    # ---------- 读取预测 ----------
    pred_path = Path(args.output)
    if not pred_path.exists():
        print(f"文件不存在: {pred_path}", file=sys.stderr)
        sys.exit(1)
    pred_rows = read_rows(pred_path)

    # ---------- 评估 ----------
    score = compute_f1(gt_map, pred_rows)

    # ---------- 输出 ----------
    print(json.dumps({"eval_score": f"{score:.4f}"}))


if __name__ == "__main__":
    main()