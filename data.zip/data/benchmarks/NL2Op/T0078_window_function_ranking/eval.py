#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ─ 分区排序排名 + 移动平均 算子评测
======================================

要求
    • 输入为 CSV：raw/customers.csv（供算子读取）
    • 分区列：country, segment
    • 排序列：order_ts（并列按输入顺序稳定）
    • 生成列：rank（1 基）、moving_avg（固定行数窗口，默认 3；与 expected/gt.csv 保持一致）
    • 你的程序输出到 -o 指定路径（CSV，含表头）

评测规则
    1. 输出必须是合法 CSV，且至少包含 expected/gt.csv 的全部列。允许出现多余列。
    2. 在 expected/gt.csv 的列集合上，比较“行多重集合”，忽略行顺序。
    3. 全部一致得分 1.0，否则 0.0。
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, List, Tuple

ROOT_DIR = Path(__file__).resolve().parent
GT_PATH  = ROOT_DIR / "expected" / "gt.csv"


def load_csv(path: Path) -> Tuple[List[str], List[Dict[str, str]]]:
    with path.open(encoding="utf-8", newline="") as f:
        rdr = csv.DictReader(f)
        if rdr.fieldnames is None:
            raise ValueError(f"{path} 缺少表头")
        header = rdr.fieldnames
        rows = [dict(r) for r in rdr]
    return header, rows


def rows_to_counter(rows: List[Dict[str, str]], header: List[str]) -> Counter:
    return Counter(tuple(r.get(col, "") for col in header) for r in rows)


def evaluate(gt_hdr: List[str],
             gt_rows: List[Dict[str, str]],
             pred_rows: List[Dict[str, str]]) -> float:
    if not pred_rows:
        print("[eval] 输出为空", file=sys.stderr)
        return 0.0

    missing = [c for c in gt_hdr if c not in pred_rows[0]]
    if missing:
        print(f"[eval] 缺少列: {missing}", file=sys.stderr)
        return 0.0

    gt_counter   = rows_to_counter(gt_rows,   gt_hdr)
    pred_counter = rows_to_counter(pred_rows, gt_hdr)

    if gt_counter != pred_counter:
        lack  = gt_counter - pred_counter
        extra = pred_counter - gt_counter
        if lack:
            print(f"[eval] 缺失行示例: {list(lack.elements())[:3]} ...",  file=sys.stderr)
        if extra:
            print(f"[eval] 多余行示例: {list(extra.elements())[:3]} ...", file=sys.stderr)
        return 0.0

    return 1.0


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate partitioned ranking + moving average operator")
    parser.add_argument("-o", "--output", required=True, help="CSV file produced by the operator")
    args = parser.parse_args()

    pred_path = Path(args.output)
    if not pred_path.exists():
        print(f"文件不存在: {pred_path}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)

    try:
        gt_hdr,  gt_rows  = load_csv(GT_PATH)
        _,      pred_rows = load_csv(pred_path)
    except Exception as exc:
        print(f"[eval] 读取 CSV 失败: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)

    score = evaluate(gt_hdr, gt_rows, pred_rows)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"[eval] 评测异常: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)