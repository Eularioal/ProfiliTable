#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
gen_data.py ─ 生成 raw 与 expected/gt.csv（分区内排序排名 + 移动平均）
==================================================================

功能
    • 生成 raw/customers.csv：
        列：[country, segment, order_ts, value]
    • 规则：
        - 分区列：country, segment
        - 排序列：order_ts（日期，YYYY-MM-DD）
        - rank：分区内按 order_ts 升序排序的 1 基排名；并列时间按“输入顺序”稳定排序
        - moving_avg：固定行数窗口（默认 3），在分区内按排序对 value 计算移动平均，保留两位小数
    • 输出 expected/gt.csv：
        列：[country, segment, order_ts, value, rank, moving_avg]

数据规模与可复现性
    • 默认国家×分群 = 6×3，共 ~180–360 行（>100）
    • 使用 Faker 并支持 --seed 固定随机种子

实现说明
    • “并列时间按输入顺序稳定排序”：用原始输入文件中的行序打破 order_ts 并列的相对顺序。
      生成时先打乱全局行序，随后计算 gt 时使用该输入序号作为稳定次关键字。
"""

from __future__ import annotations

import argparse
import csv
import random
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path
from typing import Dict, List, Tuple

from faker import Faker


ROOT_DIR = Path(__file__).resolve().parent
RAW_DIR  = ROOT_DIR / "raw"
EXP_DIR  = ROOT_DIR / "expected"
RAW_PATH = RAW_DIR / "customers.csv"
GT_PATH  = EXP_DIR / "gt.csv"

# 输入与输出列
RAW_COLS = ["country", "segment", "order_ts", "value"]
GT_COLS  = ["country", "segment", "order_ts", "value", "rank", "moving_avg"]

COUNTRIES = ["US", "CN", "DE", "FR", "GB", "IN", "JP", "BR", "CA", "AU"]
SEGMENTS  = ["A", "B", "C", "D", "E"]


def write_csv(path: Path, header: List[str], rows: List[Dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=header)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in header})


def parse_date(s: str) -> date:
    return date.fromisoformat(s)


def iso(d: date) -> str:
    return d.isoformat()


def gen_partition_rows(country: str,
                       segment: str,
                       rng: random.Random,
                       date_end: date,
                       date_span: int,
                       rows_min: int,
                       rows_max: int,
                       value_min: int,
                       value_max: int) -> List[Dict[str, str]]:
    """
    生成单个分区内的多行。order_ts 在 [date_end - (date_span-1), date_end] 均匀采样，
    自然会产生并列日期以检验稳定排序。
    """
    n_rows = rng.randint(rows_min, rows_max)
    rows: List[Dict[str, str]] = []
    for _ in range(n_rows):
        offset = rng.randrange(date_span)  # 0..date_span-1
        ts = date_end - timedelta(days=offset)
        val = rng.randint(value_min, value_max)
        rows.append({
            "country": country,
            "segment": segment,
            "order_ts": iso(ts),
            "value": str(val),
        })
    return rows


def compute_gt(rows_with_idx: List[Tuple[int, Dict[str, str]]], window: int) -> List[Dict[str, str]]:
    """
    rows_with_idx: 列表项为 (input_index, row_dict)
    在每个 (country, segment) 分区内，按 (order_ts 升序, input_index 升序) 排序，
    计算 rank 与移动平均（窗口行数 window，含当前，保留两位小数）。
    """
    # 按分区分组
    buckets: Dict[Tuple[str, str], List[Tuple[int, Dict[str, str]]]] = defaultdict(list)
    for idx, r in rows_with_idx:
        key = (r["country"], r["segment"])
        buckets[key].append((idx, r))

    out_rows: List[Dict[str, str]] = []

    for key, items in buckets.items():
        # 稳定排序：先按 order_ts，再按输入序（input_index）
        items.sort(key=lambda x: (x[1]["order_ts"], x[0]))

        # 滑动窗口累加
        values: List[int] = [int(x[1]["value"]) for x in items]
        prefix = [0]
        for v in values:
            prefix.append(prefix[-1] + v)

        for i, (_, r) in enumerate(items):
            # 1 基排名
            rank = i + 1

            # 移动平均：最近 window 行（包含当前）
            start = max(0, i - window + 1)
            cnt = i - start + 1
            ssum = prefix[i + 1] - prefix[start]
            avg = ssum / cnt
            moving_avg = f"{avg:.2f}"

            out_rows.append({
                "country": r["country"],
                "segment": r["segment"],
                "order_ts": r["order_ts"],
                "value": r["value"],
                "rank": str(rank),
                "moving_avg": moving_avg,
            })

    return out_rows


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate raw data and expected ground truth for partitioned ranking and moving average")
    parser.add_argument("--seed", type=int, default=42, help="随机种子")
    parser.add_argument("--n-countries", type=int, default=6, help="国家维度数量（1..10）")
    parser.add_argument("--n-segments", type=int, default=3, help="分群维度数量（1..5）")
    parser.add_argument("--rows-min", type=int, default=8, help="每分区最少行数")
    parser.add_argument("--rows-max", type=int, default=20, help="每分区最多行数")
    parser.add_argument("--date-end", type=str, default="2024-08-31", help="日期上界（含），YYYY-MM-DD")
    parser.add_argument("--date-span", type=int, default=45, help="order_ts 落在 [date_end-(span-1), date_end] 范围内")
    parser.add_argument("--value-min", type=int, default=1, help="value 最小值（整数）")
    parser.add_argument("--value-max", type=int, default=100, help="value 最大值（整数）")
    parser.add_argument("--window", type=int, default=3, help="移动平均的窗口行数（>=1）")
    args = parser.parse_args()

    if not (1 <= args.n_countries <= len(COUNTRIES)):
        raise ValueError(f"n-countries 必须在 1..{len(COUNTRIES)}")
    if not (1 <= args.n_segments <= len(SEGMENTS)):
        raise ValueError(f"n-segments 必须在 1..{len(SEGMENTS)}")
    if args.rows_min < 1 or args.rows_max < args.rows_min:
        raise ValueError("rows-min 必须 >=1 且 rows-max >= rows-min")
    if args.window < 1:
        raise ValueError("window 必须 >= 1")

    rng = random.Random(args.seed)
    faker = Faker()
    Faker.seed(args.seed)

    date_end = parse_date(args.date_end)

    # 生成各分区行
    selected_countries = COUNTRIES[:args.n_countries]
    selected_segments  = SEGMENTS[:args.n_segments]

    rows: List[Dict[str, str]] = []
    for c in selected_countries:
        for s in selected_segments:
            rows.extend(gen_partition_rows(
                country=c,
                segment=s,
                rng=rng,
                date_end=date_end,
                date_span=args.date_span,
                rows_min=args.rows_min,
                rows_max=args.rows_max,
                value_min=args.value_min,
                value_max=args.value_max,
            ))

    # 打乱以形成“输入顺序”
    rng.shuffle(rows)

    # 带输入序号的视图
    rows_with_idx = list(enumerate(rows))  # (input_index, row)

    # 写 raw
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    EXP_DIR.mkdir(parents=True, exist_ok=True)
    write_csv(RAW_PATH, RAW_COLS, rows)

    # 计算 expected/gt.csv
    gt_rows = compute_gt(rows_with_idx, window=args.window)

    # 规模校验
    if len(rows) <= 100:
        raise RuntimeError(f"生成的行数过少：{len(rows)}（请增大分区数或每分区行数）")

    write_csv(GT_PATH, GT_COLS, gt_rows)

    print("[gen_data] 已生成：")
    print(f"  - {RAW_PATH} (rows={len(rows)})")
    print(f"  - {GT_PATH}  (rows={len(gt_rows)})")
    print(f"  - partitions={args.n_countries}x{args.n_segments}, window={args.window}")


if __name__ == "__main__":
    main()