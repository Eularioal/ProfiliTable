#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py
===========

1. 生成 raw/customers.csv（包含缺失值）
2. 对目标列做线性插值，生成 expected/gt.csv

输出均为 UTF-8 无 BOM。
"""

from pathlib import Path

import numpy as np
import pandas as pd


# --------------------------- 可自行修改的参数 --------------------------- #
RAW_PATH = Path("raw/customers.csv")
GT_PATH = Path("expected/gt.csv")
TIME_COL = "event_time"
VALUE_COL = "amount"
N_ROWS = 10  # 生成的行数
START_DATE = "2025-01-01"
MISSING_IDX = [2, 5, 8]  # 在这些行制造缺失值
# --------------------------------------------------------------------- #


def generate_raw() -> pd.DataFrame:
    """构造带缺失值的示例数据集"""
    dates = pd.date_range(START_DATE, periods=N_ROWS, freq="D")
    amount = np.linspace(10, 65, N_ROWS)  # 一条简单的递增曲线
    amount[MISSING_IDX] = np.nan          # 指定位置设为缺失
    df_raw = pd.DataFrame(
        {
            "customer_id": range(1, N_ROWS + 1),
            TIME_COL: dates,
            VALUE_COL: amount,
        }
    )
    return df_raw


def write_csv(df: pd.DataFrame, path: Path) -> None:
    """以 UTF-8 无 BOM 写出 CSV，并确保父目录存在"""
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8")  # pandas 默认无 BOM


def interpolate(df: pd.DataFrame) -> pd.DataFrame:
    """按照时间顺序对 VALUE_COL 做线性插值"""
    df_sorted = df.sort_values(TIME_COL).copy()
    df_sorted[VALUE_COL] = df_sorted[VALUE_COL].interpolate(
        method="linear", limit_direction="both"
    )
    return df_sorted


def main() -> None:
    # 1. 生成 & 写出原始数据
    df_raw = generate_raw()
    write_csv(df_raw, RAW_PATH)
    print(f"✅ raw 数据已生成: {RAW_PATH}")

    # 2. 数据治理（线性插值）
    df_gt = interpolate(df_raw)
    write_csv(df_gt, GT_PATH)
    print(f"✅ 线性插值结果已生成: {GT_PATH}")


if __name__ == "__main__":
    main()