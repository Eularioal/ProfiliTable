#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eval.py
=======

评测脚本 —— 检查选手是否正确对指定数值列做了线性插值

用法:
    python eval.py -o <candidate.csv>

成功: {"eval_score":"1.0"}
失败: {"eval_score":"0.0"}   并把具体原因写到 stderr
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# ───────────── 配置区（须与 gen_data.py 保持一致） ─────────────
ROOT = Path(__file__).resolve().parent
RAW_CSV = ROOT / "raw" / "customers.csv"
GT_CSV = ROOT / "expected" / "gt.csv"

TIME_COL = "event_time"
VALUE_COL = "amount"
ATOL = 1e-8  # 数值比较绝对误差容忍
# ────────────────────────────────────────────────────────────


# ----------------------------- 工具 -----------------------------
def _fail(msg: str, code: int = 1) -> None:
    print(f"[eval] {msg}", file=sys.stderr)
    print(json.dumps({"eval_score": "0.0"}))
    sys.exit(code)


def _read_csv(path: Path) -> pd.DataFrame:
    """强制把空字符串和 NA 视为缺失，以防选手写入奇怪占位符"""
    return pd.read_csv(path, na_values=["", "NA"])


# -------------------------- 评测主逻辑 --------------------------
def _evaluate(
    cand: pd.DataFrame,
    gt: pd.DataFrame,
    raw: pd.DataFrame,
) -> float:
    # 1) 行列检查
    if cand.shape != gt.shape:
        _fail(f"行列数不一致: 期望 {gt.shape}, 实际 {cand.shape}")
    if list(cand.columns) != list(gt.columns):
        _fail("列名或列顺序与基准不一致")

    # 2) 数值列: 不能再有缺失 & 必须等于基准 (±ATOL)
    if cand[VALUE_COL].isna().any():
        _fail(f"目标列 {VALUE_COL} 仍包含缺失值")
    diff = np.abs(cand[VALUE_COL].astype(float) - gt[VALUE_COL].astype(float))
    if (diff > ATOL).any():
        _fail(f"目标列 {VALUE_COL} 与基准结果不一致")

    # 3) 其他列内容不得被修改
    other_cols = [c for c in cand.columns if c != VALUE_COL]
    raw_other = raw[other_cols].reset_index(drop=True)
    cand_other = cand[other_cols].reset_index(drop=True)

    # 时间列允许类型不同（str vs datetime），统一转字符串比较即可
    raw_other[TIME_COL] = raw_other[TIME_COL].astype(str)
    cand_other[TIME_COL] = cand_other[TIME_COL].astype(str)

    if not cand_other.equals(raw_other):
        _fail("除目标列外的其他列被不必要地修改")

    return 1.0


# ------------------------------ CLI -----------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate linear-interpolation operator")
    parser.add_argument("-o", "--output", required=True, help="candidate CSV file")
    args = parser.parse_args()

    cand_path = Path(args.output)
    if not cand_path.exists():
        _fail(f"文件不存在: {cand_path}")

    try:
        raw_df = _read_csv(RAW_CSV)
        gt_df = _read_csv(GT_CSV)
        cand_df = _read_csv(cand_path)
    except Exception as exc:  # noqa: BLE001
        _fail(f"读取 CSV 失败: {exc}")

    score = _evaluate(cand_df, gt_df, raw_df)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:  # noqa: BLE001
        _fail(f"评测脚本异常: {exc}", code=2)