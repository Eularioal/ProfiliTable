import json
import uuid
import random
from pathlib import Path
from utils.llm_serving import LLMServing

def generate_gold_data(llm, topics, per_topic=1):
    system_prompt = "You are an AI that writes formal English."
    user_inputs = [f"Write a short formal sentence about {topic}." for topic in topics for _ in range(per_topic)]
    results = llm.generate_from_input(user_inputs, system_prompt)
    gold_data = []
    for topic, text in zip(topics, results):
        gold_data.append({
            "id": str(uuid.uuid4()),
            "text": text.strip()
        })
    return gold_data

def generate_dirty_data(n=80):
    symbols = ["@", "#", "$", "%", "&", "*", "!", "~", "^"]
    dirty_data = []
    for _ in range(n):
        symbol_tokens = random.choices(symbols, k=random.randint(10, 20))
        word_tokens = random.choices(["lorem", "ipsum", "dolor", "sit", "amet", "consectetur"], k=random.randint(3, 5))
        if random.random() < 0.5:
            text = " ".join(symbol_tokens + word_tokens)
        else:
            text = " ".join(word_tokens + symbol_tokens)
        dirty_data.append({
            "id": str(uuid.uuid4()),
            "text": text
        })
    return dirty_data

def main():
    task_id = "T0016"
    base_dir = Path(f"data/benchmarks/NL2Op/{task_id}_")
    expected_path = base_dir / "expected" / "gt.jsonl"
    raw_path = base_dir / "raw" / "customers.jsonl"
    expected_path.parent.mkdir(parents=True, exist_ok=True)
    raw_path.parent.mkdir(parents=True, exist_ok=True)

    # Step 1: Gold data
    topics = [
        "education", "health", "technology", "science", "environment",
        "sports", "finance", "travel", "art", "history",
        "law", "business", "engineering", "space", "culture",
        "literature", "economics", "mathematics", "politics", "agriculture"
    ]
    llm = LLMServing()
    gold_data = generate_gold_data(llm, topics)

    with open(expected_path, "w", encoding="utf-8") as f:
        for entry in gold_data:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    # Step 2: Dirty data
    dirty_data = generate_dirty_data(n=80)

    with open(raw_path, "w", encoding="utf-8") as f:
        for entry in gold_data + dirty_data:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

if __name__ == "__main__":
    main()
