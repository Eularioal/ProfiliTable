#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eval.py
=======

评测脚本 —— 检查选手是否按指定常量替换缺失

用法:
    python eval.py -o <candidate.csv>

成功: {"eval_score":"1.0"}
失败: {"eval_score":"0.0"} 并把原因写到 stderr
"""

from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import pandas as pd
import numpy as np

# ─────────── 配置 (需与 gen_data.py 一致) ───────────
ROOT      = Path(__file__).resolve().parent
RAW_CSV   = ROOT / "raw" / "customers.csv"
GT_CSV    = ROOT / "expected" / "gt.csv"
FILL_MAP  = {"age": 0, "city": "unknown"}          # 评测依据
ATOL      = 1e-8                                   # 数值常量误差
# ────────────────────────────────────────────────


def fail(msg: str, code: int = 1) -> None:
    print(f"[eval] {msg}", file=sys.stderr)
    print(json.dumps({"eval_score": "0.0"}))
    sys.exit(code)


def read_csv(path: Path) -> pd.DataFrame:
    # 将 "" 与 NA 识别为缺失
    return pd.read_csv(path, na_values=["", "NA"])


def evaluate(cand: pd.DataFrame,
             gt:   pd.DataFrame,
             raw:  pd.DataFrame) -> float:
    # 1) 行列检查
    if cand.shape != gt.shape:
        fail(f"行列数不一致: 期望 {gt.shape}, 实际 {cand.shape}")
    if list(cand.columns) != list(gt.columns):
        fail("列名或顺序与基准不一致")

    # 2) 指定列: 无缺失 且 与 gt 完全一致
    for col, const in FILL_MAP.items():
        if cand[col].isna().any():
            fail(f"{col} 仍含缺失")
        if pd.api.types.is_numeric_dtype(gt[col]):
            diff = np.abs(cand[col].astype(float) - gt[col].astype(float))
            if (diff > ATOL).any():
                fail(f"{col} 常量填补结果不一致")
        else:
            if not cand[col].astype(str).equals(gt[col].astype(str)):
                fail(f"{col} 常量填补结果不一致")

    # 3) 其它列 (未要求填补) 必须与原始数据保持一致
    other_cols = [c for c in cand.columns if c not in FILL_MAP]
    if not cand[other_cols].equals(raw[other_cols]):
        fail("非指定列被不必要地修改")

    return 1.0


def main() -> None:
    ap = argparse.ArgumentParser(description="Evaluate constant-imputation operator")
    ap.add_argument("-o", "--output", required=True, help="candidate CSV file")
    args = ap.parse_args()

    cand_path = Path(args.output)
    if not cand_path.exists():
        fail(f"文件不存在: {cand_path}")

    try:
        raw = read_csv(RAW_CSV)
        gt  = read_csv(GT_CSV)
        cand = read_csv(cand_path)
    except Exception as exc:
        fail(f"读取 CSV 失败: {exc}")

    score = evaluate(cand, gt, raw)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        fail(f"评测脚本异常: {exc}", code=2)