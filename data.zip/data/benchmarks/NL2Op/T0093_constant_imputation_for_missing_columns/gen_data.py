#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py
===========

1. 生成 raw/customers.csv（含缺失值）
2. 将指定列缺失统一替换为常量，写 expected/gt.csv

编码：UTF-8（无 BOM）
依赖：pandas, numpy
"""

from pathlib import Path
import numpy as np
import pandas as pd

# ───────────── 可调参数 ─────────────
RAW_PATH  = Path("raw/customers.csv")
GT_PATH   = Path("expected/gt.csv")

N_ROWS    = 20
RAND_SEED = 123
MISS_RATE = 0.25                 # 缺失占比

# 要替换的列 及 其对应常量
FILL_MAP = {
    "age": 0,                    # 数值常量
    "city": "unknown",           # 字符串常量
}
# ──────────────────────────────────

rng = np.random.default_rng(RAND_SEED)


def make_dataset() -> pd.DataFrame:
    """构造含缺失值的示例数据集"""
    df = pd.DataFrame(
        {
            "customer_id": range(1, N_ROWS + 1),
            "age": rng.integers(18, 70, size=N_ROWS).astype(float),
            "income": rng.normal(60_000, 18_000, size=N_ROWS),        # 不参与填补
            "city": rng.choice(["Beijing", "Shanghai", "Shenzhen"], size=N_ROWS),
        }
    )

    # 制造缺失 (customer_id 不造缺失)
    mask = rng.random(df.shape) < MISS_RATE
    mask[:, 0] = False
    df = df.mask(mask)

    return df


def constant_fill(df: pd.DataFrame) -> pd.DataFrame:
    """按 FILL_MAP 替换缺失"""
    df_filled = df.copy()
    for col, const in FILL_MAP.items():
        if col not in df_filled.columns:
            raise KeyError(f"列不存在: {col}")
        df_filled[col] = df_filled[col].fillna(const)
    return df_filled


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8")   # 无 BOM


def main() -> None:
    raw_df = make_dataset()
    write_csv(raw_df, RAW_PATH)
    print(f"✅ raw 数据写出: {RAW_PATH}")

    gt_df = constant_fill(raw_df)
    write_csv(gt_df, GT_PATH)
    print(f"✅ 常量填补结果写出: {GT_PATH}")


if __name__ == "__main__":
    main()