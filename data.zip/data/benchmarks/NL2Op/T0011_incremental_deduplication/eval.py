#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测“增量去重算子（历史 JSONL + 增量 CSV）”

用法
----
python eval.py -o /path/to/your_output.jsonl   # 或 .csv

评价要点
--------
1. 黄金标准固定为 expected/gt.jsonl
2. 只考察 id 级别去重 + “取 updated_at 最新版本” 是否正确
3. 行级 F1 计算：
   · 真阳 TP = 第一次出现且与 GT 记录 *全字段* 完全一致
   · 输出含重复 / 额外 id / 字段值错误 → FP
   · 缺失任何应输出 id               → FN
4. 结果打印 {"eval_score": "<score>"}，范围 [0,1]
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Dict, List, Set

# ----------------------------- 常量 ------------------------------
GT_PATH = Path(__file__).parent / "expected" / "gt.jsonl"


# --------------------------- 读文件工具 ---------------------------
def read_jsonl(path: Path) -> List[Dict]:
    rows: List[Dict] = []
    with path.open(encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                raise ValueError(f"{path}:{lineno} 不是合法 JSON: {e}") from e
    if not rows:
        raise ValueError(f"{path} 为空文件")
    return rows


def read_csv(path: Path) -> List[Dict]:
    rows: List[Dict] = []
    with path.open(encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if "id" not in reader.fieldnames:
            raise ValueError(f"{path}: CSV 必须包含 id 字段")
        for lineno, row in enumerate(reader, 2):
            rows.append({k: (v or "").strip() for k, v in row.items()})
    if not rows:
        raise ValueError(f"{path} 为空文件")
    return rows


def read_rows(path: Path) -> List[Dict]:
    if path.suffix.lower() == ".jsonl":
        return read_jsonl(path)
    elif path.suffix.lower() == ".csv":
        return read_csv(path)
    else:
        raise ValueError(f"仅支持 .jsonl / .csv，收到 {path.name}")


# ----------------------------- 评分 ------------------------------
def compute_f1(
    gt_map: Dict[str, Dict],
    pred_rows: List[Dict],
) -> float:
    if not pred_rows:
        return 0.0

    tp_ids: Set[str] = set()
    fp = 0

    for row in pred_rows:
        rid = str(row.get("id", ""))
        if not rid:
            fp += 1
            continue

        # 重复行
        if rid in tp_ids:
            fp += 1
            continue

        gt_row = gt_map.get(rid)
        if gt_row is None:
            fp += 1  # 额外 id
            continue

        # 与 GT 全字段比较（顺序不限）
        if row == gt_row:
            tp_ids.add(rid)
        else:
            fp += 1  # 字段值不一致

    fn = len(gt_map) - len(tp_ids)
    precision = len(tp_ids) / (len(tp_ids) + fp) if tp_ids or fp else 0.0
    recall = len(tp_ids) / (len(tp_ids) + fn) if tp_ids or fn else 0.0
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


# ----------------------------- 主流程 -----------------------------
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate incremental deduplication output")
    parser.add_argument(
        "-o", "--output", required=True, help="Path to JSONL/CSV produced by your operator"
    )
    args = parser.parse_args()

    # ---------- 读取 GT ----------
    gt_rows = read_jsonl(GT_PATH)
    gt_map: Dict[str, Dict] = {str(r["id"]): r for r in gt_rows}

    # ---------- 读取预测 ----------
    pred_path = Path(args.output)
    if not pred_path.exists():
        print(f"文件不存在: {pred_path}", file=sys.stderr)
        sys.exit(1)
    pred_rows = read_rows(pred_path)

    # ---------- 评估 ----------
    score = compute_f1(gt_map, pred_rows)

    # ---------- 输出 ----------
    print(json.dumps({"eval_score": f"{score:.4f}"}))


if __name__ == "__main__":
    main()