#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成两份“增量去重”评测用原始数据：
  • raw/customers.jsonl  历史基准（干净快照，无重复，统一旧时间）
  • raw/customers.csv    新增增量（含新/旧/重复/乱序）

✅ 保证：理想去重后严格等于 expected/gt.jsonl
"""

from __future__ import annotations

import csv
import json
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List

ROOT = Path(__file__).resolve().parent
GT_PATH   = ROOT / "expected" / "gt.jsonl"
RAW_DIR   = ROOT / "raw"
HIST_PATH = RAW_DIR / "customers.jsonl"
INCR_PATH = RAW_DIR / "customers.csv"

random.seed(2024)

def load_gt() -> List[Dict]:
    rows: List[Dict] = []
    with GT_PATH.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows

def jitter(ts: str, days: int) -> str:
    base = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    return (base + timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")

def make_dirs() -> None:
    RAW_DIR.mkdir(parents=True, exist_ok=True)

# 🔧 修改点 1：历史快照统一时间，且无重复
def build_history(gt: List[Dict]) -> List[Dict]:
    """
    • 80% 的 id 进入历史文件（代表它们在 T₀ 时刻已存在）
    • 所有历史记录统一设为旧时间（如 2024-01-01）
    • 不再随机改 updated_at —— 保证历史是同一时刻快照
    • ❌ 移除重复插入（历史必须干净）
    """
    sample = random.sample(gt, k=int(len(gt) * 0.8))
    hist: List[Dict] = []
    HIST_TS = "2024-01-01T00:00:00Z"  # 统一历史时间点，早于所有 gt 时间
    
    for row in sample:
        r = row.copy()
        r["updated_at"] = HIST_TS
        # 历史字段可部分旧（模拟未更新状态）
        if random.random() < 0.4:  # 40% 概率 tier 是旧值
            old_tier = random.choice([t for t in ["gold", "silver", "bronze"] if t != r["tier"]])
            r["tier"] = old_tier
        hist.append(r)
    
    # 确保同一 ID 只出现一次（快照一致性）
    seen = set()
    clean_hist = []
    for r in hist:
        if r["id"] not in seen:
            clean_hist.append(r)
            seen.add(r["id"])
    return clean_hist

# 🔧 修改点 2：增量 = 重建 gt 所需的变更事件（+噪声）
def build_increment(gt: List[Dict], hist_ids: set) -> List[Dict]:
    """
    • 对 hist 中存在的 ID：放入 gt 中对应记录（作为更新事件）
    • 对 gt 中新 ID：放入 gt 中对应记录（作为新增事件）
    • 额外注入：重复、过期更新、乱序（测试鲁棒性）
    """
    incr: List[Dict] = []
    gt_map = {r["id"]: r for r in gt}
    
    # 1. 更新事件：hist 有，gt 也有（绝大多数）
    for rid in hist_ids:
        if rid in gt_map:
            # 正确更新：用 gt 中最新状态
            incr.append(gt_map[rid].copy())
    
    # 2. 新增事件：gt 有，但 hist 没有
    new_ids = [r["id"] for r in gt if r["id"] not in hist_ids]
    for rid in new_ids:
        incr.append(gt_map[rid].copy())
    
    # 3. 注入噪声（不影响最终收敛到 gt）
    
    # 3.1 重复：对 20% 的增量记录重复一次
    dup_candidates = random.sample(incr, k=min(len(incr), int(len(incr) * 0.2)))
    incr.extend([r.copy() for r in dup_candidates])
    
    # 3.2 过期更新：对 10% 的历史 ID，注入一条比 hist 还旧的记录（应被忽略）
    outdated_ids = random.sample(list(hist_ids), k=min(len(hist_ids), int(len(hist_ids) * 0.1)))
    for rid in outdated_ids:
        if rid in gt_map:
            older = gt_map[rid].copy()
            older["updated_at"] = "2023-12-01T00:00:00Z"  # 比 hist (2024-01-01) 更旧
            older["tier"] = random.choice(["gold", "silver", "bronze"])
            incr.append(older)
    
    # 3.3 乱序：打乱顺序（真实场景）
    random.shuffle(incr)
    return incr

def write_history(rows: List[Dict]) -> None:
    with HIST_PATH.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

def write_increment(rows: List[Dict]) -> None:
    # 字段乱序写入 CSV（测试 reader 鲁棒性）✅
    # fieldnames = ["tier", "id", "updated_at", "name"]  # 故意乱序
    with INCR_PATH.open("w", newline='', encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames= list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

# 🔍 新增：验证逻辑闭环（可选，用于调试）
def verify_dedup(hist: List[Dict], incr: List[Dict], gt: List[Dict]) -> bool:
    merged = {}
    for r in hist + incr:
        rid = r["id"]
        if rid not in merged or r["updated_at"] > merged[rid]["updated_at"]:
            merged[rid] = r
    result = sorted(merged.values(), key=lambda x: x["id"])
    gt_sorted = sorted(gt, key=lambda x: x["id"])
    return result == gt_sorted

def main() -> None:
    make_dirs()
    gt_rows = load_gt()
    hist_rows = build_history(gt_rows)
    hist_ids = {r["id"] for r in hist_rows}
    incr_rows = build_increment(gt_rows, hist_ids)
    
    # ✅ 验证：理想去重后应等于 gt
    assert verify_dedup(hist_rows, incr_rows, gt_rows), "❌ Data generation logic is broken!"
    
    write_history(hist_rows)
    write_increment(incr_rows)
    print(f"✔ raw files generated (verified: dedup(hist+incr) == gt):\n  - {HIST_PATH}\n  - {INCR_PATH}")

if __name__ == "__main__":
    main()