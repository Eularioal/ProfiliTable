#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Generate raw (un-deduplicated) customers.jsonl from GT unique file.

"""

import json
import os
import random
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict

# ---------------------------------------------------------------------
GT_FILE   = Path("") # 修改为 GT 文件路径
RAW_FILE  = Path("") # 修改为生成的 RAW 文件路径

# Reproducibility
RANDOM_SEED = 2025
random.seed(RANDOM_SEED)

# How many extra copies per record (inclusive range) ------------------
MIN_COPIES = 0          # each GT row will appear at least once (the GT copy itself)
MAX_COPIES = 3          # plus up to 3 obsolete copies
# ---------------------------------------------------------------------


def iso2dt(iso: str) -> datetime:
    """Parse ISO-8601 (with 'Z') -> datetime (UTC)."""
    return datetime.strptime(iso, "%Y-%m-%dT%H:%M:%SZ")


def dt2iso(dt: datetime) -> str:
    """Datetime -> ISO-8601 UTC string with 'Z' suffix."""
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def make_obsolete_copy(rec: Dict) -> Dict:
    """Return a slightly older & noisy duplicate of `rec`."""
    dup = rec.copy()

    # ① update_time 往前推 1-120 分钟
    delta_minutes = random.randint(1, 120)
    newer_dt = iso2dt(rec["update_time"]) - timedelta(minutes=delta_minutes)
    dup["update_time"] = dt2iso(newer_dt)

    # ② 20% 概率给 age 加 / 减 1
    if random.random() < 0.2:
        dup["age"] = max(18, dup["age"] + random.choice([-1, 1]))

    # ③ 30% 概率把 name 转小写，模拟大小写差异
    if random.random() < 0.3:
        dup["name"] = dup["name"].lower()

    return dup


def load_gt(path: Path) -> List[Dict]:
    with path.open("r", encoding="utf-8") as f:
        return [json.loads(line) for line in f]


def write_raw(recs: List[Dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for rec in recs:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def main() -> None:
    gt_records = load_gt(GT_FILE)
    raw_records: List[Dict] = []

    for rec in gt_records:
        # 原始（最新）版本
        raw_records.append(rec)

        # 随机生成 0-3 份旧副本
        copies = random.randint(MIN_COPIES, MAX_COPIES)
        for _ in range(copies):
            raw_records.append(make_obsolete_copy(rec))

    # 打乱顺序
    random.shuffle(raw_records)

    # 写文件
    write_raw(raw_records, RAW_FILE)

    print(f"✅ Generated {len(raw_records)} rows to {RAW_FILE}")


if __name__ == "__main__":
    main()