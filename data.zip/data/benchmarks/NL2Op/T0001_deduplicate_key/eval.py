#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Evaluate the result of the “single-key (id) dedup” operator (只根据id，不比较内容).

Usage
-----
python eval.py -o /path/to/your_output.jsonl
"""

import argparse
import json
from pathlib import Path

GT_PATH = Path(__file__).parent / "expected" / "gt.jsonl"

def load_ids(path: Path) -> set:
    """
    Load all `id` values from a jsonl file as a set.
    """
    ids = set()
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            obj = json.loads(line)
            ids.add(obj["id"])
    return ids

def compute_f1(gt_ids: set, pred_ids: set) -> float:
    """
    Compute F1-score based only on id presence.
    """
    if not pred_ids:
        return 0.0

    tp = len(gt_ids & pred_ids)
    precision = tp / len(pred_ids) if pred_ids else 0
    recall = tp / len(gt_ids) if gt_ids else 0

    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)

def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate single-key-dedup output (id only)")
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Path to the deduplicated jsonl produced by your operator",
    )
    args = parser.parse_args()

    gt_ids = load_ids(GT_PATH)
    # pred_ids = load_ids(Path(args.output))
    pred_ids = load_ids(Path(args.output))

    f1 = compute_f1(gt_ids, pred_ids)

    result = {
        "eval_score": f"{f1:.4f}",
    }
    print(result)

if __name__ == "__main__":
    main()