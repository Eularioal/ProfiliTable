from utils.llm_serving import LLMServing
from pathlib import Path
import random, json
from datetime import datetime, timedelta

# 配置路径
task_id = "T0018"
base_dir = Path(f"data/benchmarks/NL2Op/{task_id}_")
expected_path = base_dir / "expected" / "gt.jsonl"
raw_path = base_dir / "raw" / "customers.jsonl"
expected_path.parent.mkdir(parents=True, exist_ok=True)
raw_path.parent.mkdir(parents=True, exist_ok=True)

# 生成符合规则的身份证号
def generate_china_id():
    addr_code = str(random.randint(110000, 110229))
    birth_date = datetime.now() - timedelta(days=random.randint(0, 365 * 100))
    birth_str = birth_date.strftime("%Y%m%d")
    seq = random.randint(100, 999)
    id17 = addr_code + birth_str + str(seq)
    weights = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
    check_map = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2']
    s = sum(int(id17[i]) * weights[i] for i in range(17))
    return id17 + check_map[s % 11]

# 生成 gold 数据（20条）
llm = LLMServing()
topics = [
    "data privacy", "account login", "email updates", "billing info",
    "transaction success", "customer support", "password reset",
    "terms agreement", "security protocols", "delivery confirmation"
]
user_inputs = [f"Write a short customer service sentence about {topic}." for topic in topics for _ in range(2)]
system_prompt = "You are a helpful assistant that writes clean, professional customer service statements without any personal identifiers."
results = llm.generate_from_input(user_inputs, system_prompt)

gold_data = [{"id": f"gold_{i:03d}", "text": text.strip()} for i, text in enumerate(results)]
with open(expected_path, "w", encoding="utf-8") as f:
    for item in gold_data:
        f.write(json.dumps(item, ensure_ascii=False) + "\n")

# 构造 dirty 数据（80条，包含身份证号）
dirty_data = []
for i in range(80):
    fake_id = generate_china_id()
    text = f"用户身份已验证，身份证号码为 {fake_id}，请妥善保管。"
    dirty_data.append({
        "id": f"dirty_{i:03d}",
        "text": text
    })

# 合并写入 raw/customers.jsonl
combined = dirty_data + gold_data
random.shuffle(combined)
with open(raw_path, "w", encoding="utf-8") as f:
    for item in combined:
        f.write(json.dumps(item, ensure_ascii=False) + "\n")
