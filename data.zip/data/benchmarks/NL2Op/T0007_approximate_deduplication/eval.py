#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “文本近似去重算子（JSONL 版）”

使用方法
--------
python eval.py -o /path/to/your_output.jsonl

说明
----
1. 黄金标准文件固定为同级目录 expected/gt.jsonl
2. -o 指向你的算子产出的 **去重结果**（JSONL，顺序不限）
3. 仅考察 review_id 集合是否与 GT 完全一致  
   - 若输出包含重复行 / 额外行 → precision 下降  
   - 若缺失任何应保留行       → recall    下降
4. 输出形如 {"eval_score": "<score>"}，范围 [0,1]，分数 = 行级 F1
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import List, Set, Tuple

# ------------------------------------------------------------------ 常量
GT_PATH = Path(__file__).parent / "expected" / "gt.jsonl"

# ------------------------------------------------------------------ I/O 工具
def read_review_ids(path: Path) -> List[str]:
    """
    读取 jsonl 文件，返回 review_id 列表（按出现顺序，字符串形式）。
    若某行解析失败则抛异常并指出行号。
    """
    ids: List[str] = []
    with path.open(encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                rid = obj.get("review_id")
                if rid is None:
                    raise ValueError("缺少 review_id 字段")
                ids.append(str(rid))
            except Exception as e:
                raise ValueError(f"{path}:{lineno} 行无法解析为合法 JSON 或缺字段: {e}") from e
    if not ids:
        raise ValueError(f"{path} 为空文件")
    return ids


# ------------------------------------------------------------------ 评分
def compute_f1(gt_ids: Set[str], pred_ids: List[str]) -> float:
    """
    行级 F1：
    • 真阳 TP = 与 GT 匹配且第一次出现的行数
    • 精确度 precision = TP / 预测行总数（包含重复行→惩罚）
    • 召回率 recall    = TP / GT 行数
    """
    if not pred_ids:
        return 0.0

    tp_seen: Set[str] = set()
    tp = 0
    for rid in pred_ids:
        if rid in gt_ids and rid not in tp_seen:
            tp_seen.add(rid)
            tp += 1

    precision = tp / len(pred_ids)
    recall = tp / len(gt_ids)
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


# ------------------------------------------------------------------ 主流程
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate text-near-deduplication output (JSONL)")
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Path to JSONL produced by your deduplication operator",
    )
    args = parser.parse_args()

    # ---------- 读取 GT ----------
    gt_ids_set: Set[str] = set(read_review_ids(GT_PATH))

    # ---------- 读取预测 ----------
    pred_path = Path(args.output)
    if not pred_path.exists():
        raise FileNotFoundError(pred_path)
    pred_ids_ordered: List[str] = read_review_ids(pred_path)

    # ---------- 计算得分 ----------
    score = compute_f1(gt_ids_set, pred_ids_ordered)

    # ---------- 输出 ----------
    print({"eval_score": f"{score:.4f}"})


if __name__ == "__main__":
    main()