#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成 raw/customers.jsonl 与 customers.csv，
其中包含 expected/gt.jsonl 中的记录以及 1~3 条近似重复记录。
近似重复通过在末尾追加少量词语或符号来保证 Jaccard ≥ 0.9。
"""

import json
import random
import os
import csv
from pathlib import Path
from typing import List, Dict

random.seed(42)  # 可复现

# ---------- 路径 ----------
ROOT = Path(__file__).parent                # 项目根目录
GT_PATH = ROOT / "expected" / "gt.jsonl"
RAW_DIR = ROOT / "raw"
RAW_DIR.mkdir(parents=True, exist_ok=True)
RAW_JSONL = RAW_DIR / "customers.jsonl"
RAW_CSV = RAW_DIR / "customers.csv"

# ---------- 载入 GT ----------
def load_gt(path: Path) -> List[Dict]:
    data = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            data.append(json.loads(line))
    return data

# ---------- 生成重复变体 ----------
SUFFIXES = [
    "Highly recommended!",
    "Would buy again.",
    "⭐️⭐️⭐️⭐️⭐️",
    "Thanks for reading my review.",
    "Super happy with this purchase.",
]

def make_variant(content: str) -> str:
    """
    在原文本末尾追加少量 token，保持 Jaccard 相似度 ≥0.9。
    """
    suffix = random.choice(SUFFIXES)
    return content + " " + suffix

def gen_duplicates(record: Dict, next_review_id: int) -> List[Dict]:
    """为单条记录生成 1~3 个近似重复"""
    dup_count = random.randint(1, 3)
    dups = []
    for _ in range(dup_count):
        variant = make_variant(record["content"])
        dups.append({
            "review_id": next_review_id,
            "user_id": record["user_id"],  # 用户保持一致以增加真实感
            "content": variant
        })
        next_review_id += 1
    return dups, next_review_id

# ---------- 主流程 ----------
def main():
    gt_records = load_gt(GT_PATH)
    all_records = []
    next_id = 200001  # 为生成的重复起一个新段

    for rec in gt_records:
        # 先加入原始记录
        all_records.append(rec)
        # 再加入重复
        dups, next_id = gen_duplicates(rec, next_id)
        all_records.extend(dups)

    # 打乱顺序
    random.shuffle(all_records)

    # 写 JSONL
    with RAW_JSONL.open("w", encoding="utf-8") as f_jsonl:
        for r in all_records:
            f_jsonl.write(json.dumps(r, ensure_ascii=False) + "\n")

    # 写 CSV
    with RAW_CSV.open("w", encoding="utf-8", newline="") as f_csv:
        writer = csv.DictWriter(f_csv, fieldnames=["review_id", "user_id", "content"])
        writer.writeheader()
        writer.writerows(all_records)

    print(f"生成完成：{RAW_JSONL.relative_to(ROOT)} 以及 {RAW_CSV.relative_to(ROOT)}")

if __name__ == "__main__":
    main()