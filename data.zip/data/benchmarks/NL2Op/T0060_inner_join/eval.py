#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 两表内连接算子 · Evaluation
====================================

目录结构
└─ T00XX_inner_join/
   ├─ expected/gt.csv          # 真值
   ├─ raw/left.csv             # 仅供说明，评测不读取
   ├─ raw/right.csv            # 仅供说明，评测不读取
   └─ eval.py                  # 本脚本

算子任务（供参考）
    • 读取两份 CSV
    • 依据指定键执行等值内连接（允许多重匹配 → 笛卡尔行）
    • 列冲突策略由算子自行实现
    • 生成结果文件（含表头）交给本脚本评分

评测规则
    1. 输出文件必须为 CSV，且包含 expected/gt.csv 中全部列。
       允许出现其它额外列。
    2. 仅比较 expected/gt.csv 中的列，行顺序忽略。
    3. 输出应与真值形成同一“行多重集合”
       （即行内容 + 重复次数完全一致）。
    4. 任一点不符得分 0.0。

得分
    满足全部规则 ⇒ 1.0  
    否则         ⇒ 0.0

用法
    python eval.py -o ./my_join_result.csv
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, List, Tuple

# ─────────── 配置 ───────────
ROOT_DIR = Path(__file__).resolve().parent
GT_PATH  = ROOT_DIR / "expected" / "gt.csv"

# ─────────── IO ───────────
def load_csv(path: Path) -> Tuple[List[str], List[Dict[str, str]]]:
    """读取 CSV→(header, rows)；所有值保持字符串。"""
    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"{path} 缺少表头")
        header = reader.fieldnames
        rows   = [dict(r) for r in reader]
    return header, rows


def rows_to_counter(rows: List[Dict[str, str]], header: List[str]) -> Counter:
    """
    将行列表按指定 header 投影为可哈希元组，构造成 Counter，
    方便比较“行多重集合”是否一致。
    """
    return Counter(tuple(r.get(c, "") for c in header) for r in rows)


# ─────────── 评测逻辑 ───────────
def evaluate(gt_hdr: List[str],
             gt_rows: List[Dict[str, str]],
             pred_rows: List[Dict[str, str]]) -> float:
    # 1. header 检查
    missing_cols = [c for c in gt_hdr if c not in pred_rows[0]]
    if missing_cols:
        print(f"[eval] 输出缺少列: {missing_cols}", file=sys.stderr)
        return 0.0

    # 2. 多重集合比较
    gt_counter   = rows_to_counter(gt_rows,   gt_hdr)
    pred_counter = rows_to_counter(pred_rows, gt_hdr)

    if gt_counter != pred_counter:
        diff_gt   = gt_counter - pred_counter
        diff_pred = pred_counter - gt_counter
        if diff_gt:
            print(f"[eval] 输出缺失行: {list(diff_gt.elements())[:3]} ...", file=sys.stderr)
        if diff_pred:
            print(f"[eval] 输出多余行: {list(diff_pred.elements())[:3]} ...", file=sys.stderr)
        return 0.0

    return 1.0


# ─────────── CLI ───────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate inner-join operator")
    parser.add_argument("-o", "--output", required=True,
                        help="CSV file produced by operator")
    args = parser.parse_args()

    pred_path = Path(args.output)
    if not pred_path.exists():
        print(f"文件不存在: {pred_path}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)

    try:
        gt_hdr,  gt_rows   = load_csv(GT_PATH)
        _,      pred_rows  = load_csv(pred_path)
    except Exception as exc:
        print(f"[eval] CSV 读取失败: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)

    # 空文件保护
    if not pred_rows:
        print("[eval] 输出为空", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)

    score = evaluate(gt_hdr, gt_rows, pred_rows)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"[eval] 评测异常: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)