#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
gen_data.py – 为“CSV 内连接算子”构造伪造数据
================================================

目录结构生成示例
.
├── gen_data.py
├── raw
│   ├── left.csv                 # 待连接的左表
│   └── right.csv                # 待连接的右表
└── expected
    └── gt.csv                   # 内连接的真值
"""

from pathlib import Path
import csv
import random
import sys

try:
    from faker import Faker
except ImportError:
    sys.exit("请先安装 faker： pip install faker")

fake = Faker("en_US")
random.seed(42)
Faker.seed(42)

# ────────────────────────── 配置区域 ──────────────────────────
LEFT_ROWS_BASE  = 100   # 基础 id 数量，之后还会随机复制行形成多重匹配
RIGHT_ROWS_BASE = 100

ONLY_IN_LEFT    = 5     # 仅出现在左表的 id 数量
ONLY_IN_RIGHT   = 5     # 仅出现在右表的 id 数量

LEFT_DUP_RANGE  = (1, 3)   # 每个 id 在左表出现 1~3 次
RIGHT_DUP_RANGE = (1, 2)   # 每个 id 在右表出现 1~2 次

JOIN_KEY        = "cust_id"

LEFT_FIELDS     = [JOIN_KEY, "first_name", "email"]
RIGHT_FIELDS    = [JOIN_KEY, "phone", "city"]

GT_FIELDS       = [
    JOIN_KEY,             # 公共列放前面
    "first_name", "email",
    "phone", "city",
]

RAW_DIR = Path("raw")
EXP_DIR = Path("expected")
RAW_DIR.mkdir(exist_ok=True)
EXP_DIR.mkdir(exist_ok=True)

# ────────────────────────── 造左表 ──────────────────────────
def make_left_rows():
    rows = []
    # id 1..LEFT_ROWS_BASE
    for cid in range(1, LEFT_ROWS_BASE + 1):
        dup_times = random.randint(*LEFT_DUP_RANGE)
        for _ in range(dup_times):
            rows.append({
                JOIN_KEY:    str(cid),
                "first_name": fake.first_name(),
                "email":      fake.email(),
            })

    # 仅在左表出现的 id（测试 inner join 过滤）
    start = LEFT_ROWS_BASE + 1
    for cid in range(start, start + ONLY_IN_LEFT):
        rows.append({
            JOIN_KEY:    str(cid),
            "first_name": fake.first_name(),
            "email":      fake.email(),
        })
    return rows

# ────────────────────────── 造右表 ──────────────────────────
def make_right_rows():
    rows = []
    # 与左表重合的 id
    for cid in range(1, RIGHT_ROWS_BASE + 1):
        dup_times = random.randint(*RIGHT_DUP_RANGE)
        for _ in range(dup_times):
            rows.append({
                JOIN_KEY: str(cid),
                "phone":  fake.phone_number(),
                "city":   fake.city(),
            })

    # 仅在右表出现的 id
    start = RIGHT_ROWS_BASE + 1
    for cid in range(start, start + ONLY_IN_RIGHT):
        rows.append({
            JOIN_KEY: str(cid),
            "phone":  fake.phone_number(),
            "city":   fake.city(),
        })
    return rows

# ────────────────────────── 真值内连接 ──────────────────────────
def build_gt(left_rows, right_rows):
    # 先把右表按 key 归组，方便做笛卡尔
    right_map = {}
    for r in right_rows:
        right_map.setdefault(r[JOIN_KEY], []).append(r)

    gt_rows = []
    for l in left_rows:
        matches = right_map.get(l[JOIN_KEY])
        if not matches:
            continue                      # inner join：左行无匹配跳过
        for r in matches:                 # 笛卡尔
            gt_rows.append({
                JOIN_KEY: l[JOIN_KEY],
                "first_name": l["first_name"],
                "email":      l["email"],
                "phone":      r["phone"],
                "city":       r["city"],
            })
    return gt_rows

# ────────────────────────── 写 CSV ──────────────────────────
def write_csv(path: Path, rows, fieldnames):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

# ────────────────────────── main ──────────────────────────
def main():
    left_rows  = make_left_rows()
    right_rows = make_right_rows()
    gt_rows    = build_gt(left_rows, right_rows)

    write_csv(RAW_DIR / "customer1.csv",  left_rows,  LEFT_FIELDS)
    write_csv(RAW_DIR / "customer2.csv", right_rows, RIGHT_FIELDS)
    write_csv(EXP_DIR / "gt.csv",    gt_rows,    GT_FIELDS)

    print(f"[OK] raw/customer1.csv   行数: {len(left_rows)}")
    print(f"[OK] raw/customer2.csv  行数: {len(right_rows)}")
    print(f"[OK] expected/gt.csv行数: {len(gt_rows)}")

if __name__ == "__main__":
    main()