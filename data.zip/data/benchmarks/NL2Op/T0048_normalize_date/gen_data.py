import csv
import random
from datetime import datetime

# Function to change the date format to 'DD-MM-YYYY'
def to_dd_mm_yyyy(date):
    try:
        return datetime.strptime(date, "%Y-%m-%d").strftime("%d-%m-%Y")
    except ValueError:
        return date

# Function to change the date format to 'Month Day, Year'
def to_month_day_year(date):
    try:
        return datetime.strptime(date, "%Y-%m-%d").strftime("%B %d, %Y")
    except ValueError:
        return date

# Read the original CSV data
input_file = 'data/benchmarks/NL2Op/T0024_/expected/gt.csv'  # Replace with the path to your CSV file
output_file = 'data/benchmarks/NL2Op/T0024_/raw/customers.csv'  # Output file for modified data

modified_data = []

# Read and modify the data
with open(input_file, 'r', newline='', encoding='utf-8') as file:
    reader = csv.DictReader(file)
    for row in reader:
        # For 80 random rows, change the date format
        if random.random() < 0.8:  # 80% chance to change the date format
            date = row['date']
            # Choose a random format to change the date
            if random.random() < 0.5:
                row['date'] = to_dd_mm_yyyy(date)
            else:
                row['date'] = to_month_day_year(date)
        modified_data.append(row)

# Write the modified data to a new CSV file
with open(output_file, 'w', newline='', encoding='utf-8') as file:
    fieldnames = ['id', 'date']
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(modified_data)

print(f"Modified CSV data has been saved to {output_file}")
