import pandas as pd
import numpy as np
import random
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import json

# Helper function to generate GT data
def generate_gt_data(num_entries):
    gt_data = []
    for i in range(num_entries):
        patient_id = f"patient_{i}"
        age = random.randint(18, 80)  # Random age between 18 and 80
        systolic = random.randint(90, 140)  # Systolic pressure between 90 and 140
        diastolic = random.randint(60, 90)  # Diastolic pressure between 60 and 90
        medication = random.choice(["A", "B", "C", "D"])  # Random medication type
        
        gt_data.append({
            "id": patient_id,
            "age": age,
            "systolic": systolic,
            "diastolic": diastolic,
            "medication": medication
        })
    
    return pd.DataFrame(gt_data)

# Helper function to introduce dirty data (outliers)
def introduce_dirty_data(df, num_dirty):
    df = df.copy()
    df['dirty'] = False  # 默认全部为干净数据

    # 随机选取索引改成脏数据
    dirty_indices = random.sample(range(len(df)), num_dirty)
    for idx in dirty_indices:
        # 对脏数据做修改，比如血压值大幅修改
        df.at[idx, 'systolic'] += random.randint(100,120)
        df.at[idx, 'diastolic'] += random.randint(80,100)
        df.at[idx, 'dirty'] = True  # 标记为脏数据

    return df

# Helper function to clean the data using Random Forest Regressor
def clean_blood_pressure(df):
    df_cleaned = df.copy()
    
    # Prepare features: age and medication (encoded as numbers)
    df['medication'] = df['medication'].map({"A": 0, "B": 1, "C": 2, "D": 3})
    
    # Train a Random Forest model to predict systolic and diastolic separately
    X = df[['age', 'medication']]  # Features
    y_systolic = df['systolic']
    y_diastolic = df['diastolic']
    
    # Train the Random Forest model for systolic and diastolic pressure separately
    rf_systolic = RandomForestRegressor(n_estimators=100, random_state=42)
    rf_diastolic = RandomForestRegressor(n_estimators=100, random_state=42)
    
    # Train-test split for systolic and diastolic
    X_train, X_test, y_train_systolic, y_test_systolic = train_test_split(X, y_systolic, test_size=0.2, random_state=42)
    X_train, X_test, y_train_diastolic, y_test_diastolic = train_test_split(X, y_diastolic, test_size=0.2, random_state=42)
    
    rf_systolic.fit(X_train, y_train_systolic)
    rf_diastolic.fit(X_train, y_train_diastolic)
    
    # Predict systolic and diastolic pressure for the entire dataset
    df_cleaned['predicted_systolic'] = rf_systolic.predict(X).astype(int)
    df_cleaned['predicted_diastolic'] = rf_diastolic.predict(X).astype(int)
    
    # Replace values greater than 180/120 with predicted values
    df_cleaned.loc[df_cleaned['systolic'] > 180, 'systolic'] = df_cleaned['predicted_systolic']
    df_cleaned.loc[df_cleaned['diastolic'] > 120, 'diastolic'] = df_cleaned['predicted_diastolic']

    return df_cleaned

# Function to generate GT and dirty data and save to CSV
def generate_data(gt_size, dirty_size):
    # Generate GT data
    df_gt = generate_gt_data(gt_size)
    
    # Introduce dirty data (outliers)
    df_dirty = introduce_dirty_data(df_gt, dirty_size)
    
    # Clean the dirty data using Random Forest model
    df_cleaned = clean_blood_pressure(df_dirty)
    
    # Save GT data (unmodified and modified)
    gt_data = df_cleaned.copy()
    gt_data['id'] = range(len(gt_data))
    
    # Save dirty data and cleaned data to CSV
    df_cleaned.to_csv('data/benchmarks/NL2Op/T0037_bloodpressure_outlier/expected/gt.csv', index=False, encoding='utf-8')
    df_dirty.to_csv('data/benchmarks/NL2Op/T0037_bloodpressure_outlier/raw/customers.csv', index=False, encoding='utf-8')

# Example of running the script
if __name__ == "__main__":
    generate_data(1000, 100)
