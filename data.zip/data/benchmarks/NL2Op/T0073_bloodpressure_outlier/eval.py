import pandas as pd
import argparse
from pathlib import Path
import json

def load_csv(path):
    return pd.read_csv(path)

def compare_records(expected_df, processed_df, columns, tolerance=20):
    matched = 0
    total = 0

    # 只对 dirty=True 的数据进行计算
    dirty_rows = expected_df['dirty'] == True
    dirty_indices = expected_df[dirty_rows].index

    for i in dirty_indices:
        expected_systolic = expected_df.loc[i, 'systolic']
        expected_diastolic = expected_df.loc[i, 'diastolic']
        
        processed_systolic = processed_df.loc[i, 'systolic']
        processed_diastolic = processed_df.loc[i, 'diastolic']
        
        systolic_diff = abs(expected_systolic - processed_systolic)
        diastolic_diff = abs(expected_diastolic - processed_diastolic)

        if systolic_diff <= tolerance and diastolic_diff <= tolerance:
            matched += 1
        total += 1

    accuracy = matched / total if total > 0 else 0
    return accuracy

def evaluate(expected_path, processed_path, columns, tolerance=20):
    expected_data = load_csv(expected_path)
    processed_data = load_csv(processed_path)

    score = compare_records(expected_data, processed_data, columns, tolerance)
    
    print(json.dumps({"eval_score": f"{score:.4f}"}))
    return score

def get_gt():
    current_dir = Path(__file__).resolve().parent
    expected_dir = (current_dir / "expected").resolve()
    csv_files = list(expected_dir.glob("*.csv"))
    if not csv_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")
    return csv_files[0]

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate data consistency on dirty records with tolerance (CSV)")
    parser.add_argument("-o", "--output", required=True, help="Path to processed csv file")
    parser.add_argument("-t", "--tolerance", type=int, default=20, help="Tolerance for matching values")
    args = parser.parse_args()

    expected_path = get_gt()
    processed_path = Path(args.output)

    columns_to_compare = ['systolic', 'diastolic']

    evaluate(expected_path, processed_path, columns_to_compare, args.tolerance)
