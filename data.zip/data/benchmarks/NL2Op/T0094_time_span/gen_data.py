import pandas as pd
import numpy as np
import random
from datetime import timedelta

def generate_gt_data():
    """生成没有缺失值的GT数据"""
    shipment_data = []
    shipment_types = ["Type1", "Type2", "Type3", "Type4"]
    
    for i in range(1, 101):
        shipment_id = f"shipment_{i}"
        departure_time = pd.Timestamp("2023-01-01") + timedelta(days=random.randint(0, 30))
        # 随机运输时间（1~30天）
        duration = timedelta(days=random.randint(1, 30))
        arrival_time = departure_time + duration  
        shipment_type = random.choice(shipment_types)  # 随机选择运输类型
        shipment_data.append({
            "shipment_id": shipment_id,
            "departure_time": departure_time,
            "arrival_time": arrival_time,
            "shipment_type": shipment_type,
        })
    return pd.DataFrame(shipment_data)

def introduce_missing_values(df, missing_ratio=0.2):
    """随机引入缺失的arrival_time，并添加empty标记"""
    df_missing = df.copy()
    num_missing = int(len(df) * missing_ratio)
    
    # 随机选择缺失的行
    missing_indices = np.random.choice(df.index, num_missing, replace=False)
    df_missing.loc[missing_indices, "arrival_time"] = pd.NaT  # 时间缺失
    
    # 生成empty列，标记哪些记录需要补全
    df_missing["empty"] = df_missing["arrival_time"].isna()
    
    return df_missing

def fill_missing_values(df):
    """填补缺失值：使用相同shipment_type的平均运输时长"""
    df_filled = df.copy()
    
    # 计算每个类型的平均运输时长
    df["duration"] = (df["arrival_time"] - df["departure_time"]).dt.days
    avg_durations = df.groupby("shipment_type")["duration"].mean()
    
    # 遍历缺失值并填补
    for idx, row in df_filled[df_filled["arrival_time"].isna()].iterrows():
        stype = row["shipment_type"]
        departure_time = row["departure_time"]
        if stype in avg_durations and not pd.isna(avg_durations[stype]):
            est_duration = timedelta(days=int(round(avg_durations[stype])))
            df_filled.at[idx, "arrival_time"] = departure_time + est_duration
    
    return df_filled

def save_data(df, path):
    """将数据保存到csv文件"""
    df.to_csv(path, index=False, encoding="utf-8")

def main():
    Task_id = "T0094_time_span"
    # 生成GT数据
    gt_data = generate_gt_data()

    # 引入缺失值 → raw 数据
    raw_data = introduce_missing_values(gt_data, missing_ratio=0.2)

    # raw 保存
    save_data(raw_data, f"data/benchmarks/NL2Op/{Task_id}/raw/customers.csv")
    
    # 用平均时长填补 → gt 数据
    gt_filled = fill_missing_values(raw_data)
    save_data(gt_filled, f"data/benchmarks/NL2Op/{Task_id}/expected/gt.csv")

if __name__ == "__main__":
    main()
