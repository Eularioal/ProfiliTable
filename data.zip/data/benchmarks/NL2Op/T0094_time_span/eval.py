import pandas as pd
import argparse
from pathlib import Path

TOLERANCE = 1  # 允许误差 ±0.1天，具体可以根据需求调整

def load_csv(path):
    """读取CSV文件并返回DataFrame"""
    return pd.read_csv(path, encoding='utf-8')

def calculate_duration(row):
    """计算运输时长（天数）"""
    departure_time = pd.to_datetime(row.departure_time)
    arrival_time = pd.to_datetime(row.arrival_time)
    return (arrival_time - departure_time).days

def evaluate(gt_path, pred_path):
    """评估补全的运输时长准确度"""
    # 加载GT和预测数据
    gt_data = load_csv(gt_path)
    pred_data = load_csv(pred_path)

    # 确保数据根据 shipment_id 对齐
    gt_data = gt_data.sort_values('shipment_id').reset_index(drop=True)
    pred_data = pred_data.sort_values('shipment_id').reset_index(drop=True)

    correct_count = 0
    total_count = 0

    # 按shipment_type分组，计算每种类型的运输时长平均值
    shipment_type_avg_duration = gt_data.groupby('shipment_type')['shipment_id'].apply(
        lambda x: (gt_data.loc[gt_data['shipment_id'].isin(x), 'arrival_time'].apply(pd.to_datetime) -
                   gt_data.loc[gt_data['shipment_id'].isin(x), 'departure_time'].apply(pd.to_datetime)).dt.days.mean()
    )

    # 遍历数据并比较运输时长
    for gt_row, pred_row in zip(gt_data.itertuples(), pred_data.itertuples()):
        if pred_row.empty == True:
            if pd.notna(gt_row.arrival_time) and pd.notna(pred_row.arrival_time):  # 只对比有到达时间的记录
                # 计算实际运输时长
                # gt_duration = calculate_duration(gt_row)
                pred_duration = calculate_duration(pred_row)

                gt_duration = calculate_duration(gt_row)

                # print(avg_duration)
                # 如果平均值存在且误差在容忍范围内，则认为预测正确
                if gt_duration is not None and abs(pred_duration - gt_duration) <= TOLERANCE:
                    correct_count += 1
            total_count += 1

    # 计算准确度
    accuracy = correct_count / total_count if total_count > 0 else 0.0
    return accuracy

def get_gt():
    current_dir = Path(__file__).resolve().parent
    expected_dir = (current_dir / "expected").resolve()
    csv_files = list(expected_dir.glob("*.csv"))
    if not csv_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")
    return csv_files[0]

import json

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate the accuracy of the missing arrival_time completion.")
    # parser.add_argument("-gt", "--gt_file", required=True, help="GT CSV file path")
    parser.add_argument("-o", "--output", required=True, help="Predicted CSV file path")
    
    args = parser.parse_args()
    
    # 读取GT文件和预测文件
    gt_file = get_gt()
    pred_file = args.output

    # 计算准确度
    accuracy = evaluate(gt_file, pred_file)
    print(json.dumps({"eval_score": f"{accuracy:.4f}"}))
