#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py ― 按主键去重（latest_ts）算子 · 测试数据生成
"""

from __future__ import annotations
import csv
import random
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Tuple

from faker import Faker

# ────────────────────────── 配置 ──────────────────────────
PRIMARY_KEY   = ("user_id", "product_id")   # 复合主键
TIE_BREAK_COL = "updated_at"                # 时间列
STRATEGY      = "latest_ts"                 # 取最新

FILE1_ROWS_UNIQUE   = 70   # 仅在 orders1 出现
DUPLICATE_KEY_COUNT = 30   # 两文件均出现（产生冲突）
FILE2_ONLY_ROWS     = 20   # 仅在 orders2 出现

RANDOM_SEED = 2025

# ────────────────────────── 路径 ──────────────────────────
ROOT_DIR      = Path(__file__).resolve().parent
RAW_DIR       = ROOT_DIR / "raw"
EXPECTED_DIR  = ROOT_DIR / "expected"
RAW_DIR.mkdir(exist_ok=True)
EXPECTED_DIR.mkdir(exist_ok=True)

RAW1 = RAW_DIR / "customers1.csv"
RAW2 = RAW_DIR / "customers2.csv"
GT   = EXPECTED_DIR / "gt.csv"

# ────────────────────────── Faker ──────────────────────────
random.seed(RANDOM_SEED)
fake = Faker()
Faker.seed(RANDOM_SEED)

HEADER = ["user_id", "product_id", "quantity", "price", "updated_at"]

# ─────────────────────── 生成工具函数 ───────────────────────
def rand_ts(start: datetime) -> str:
    """生成 start 之后 0~6 天随机时间，返回 ISO8601"""
    ts = start + timedelta(seconds=random.randint(0, 6 * 24 * 3600))
    return ts.strftime("%Y-%m-%dT%H:%M:%SZ")

def make_record(uid: int, pid: str, ts: str) -> List[str]:
    quantity = random.randint(1, 10)
    price    = f"{random.uniform(10, 500):.2f}"
    return [str(uid), pid, str(quantity), price, ts]

# ─────────────────────── 生成原始两文件 ─────────────────────
rows_f1: List[List[str]] = []
rows_f2: List[List[str]] = []

base_date = datetime(2024, 1, 1, 8, 0, 0)

# 1) 文件1独有键
for i in range(1, FILE1_ROWS_UNIQUE + 1):
    user_id = i
    product = fake.word().title()
    ts      = rand_ts(base_date)
    rows_f1.append(make_record(user_id, product, ts))

# 2) 冲突键：两文件均出现
for i in range(1, DUPLICATE_KEY_COUNT + 1):
    user_id = 10_000 + i      # 避免与上面重复
    product = fake.word().title()

    ts1 = rand_ts(base_date)                    # 时间早
    ts2 = rand_ts(base_date + timedelta(days=7))# 时间晚

    # 交替让 file1 或 file2 拿到最新时间
    if i % 2 == 0:
        newer, older = ts1, ts2
    else:
        newer, older = ts2, ts1

    rows_f1.append(make_record(user_id, product, older))
    rows_f2.append(make_record(user_id, product, newer))

# 3) 文件2独有键
for i in range(1, FILE2_ONLY_ROWS + 1):
    user_id = 20_000 + i
    product = fake.word().title()
    ts      = rand_ts(base_date + timedelta(days=3))
    rows_f2.append(make_record(user_id, product, ts))

# 保留文件内原顺序
random.shuffle(rows_f1)
random.shuffle(rows_f2)

# ───────────────────────── 写入 raw CSV ─────────────────────────
def write_csv(path: Path, rows: List[List[str]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(HEADER)
        w.writerows(rows)

write_csv(RAW1, rows_f1)
write_csv(RAW2, rows_f2)

# ─────────────────────── 生成去重后 GT ───────────────────────
# 按文件顺序遍历，使用 latest_ts 胜出；相同时保留先出现
def parse_key(row: List[str]) -> Tuple[str, ...]:
    col_idx = {col: idx for idx, col in enumerate(HEADER)}
    return tuple(row[col_idx[c]] for c in PRIMARY_KEY)

def build_gt(rows_a: List[List[str]], rows_b: List[List[str]]) -> List[List[str]]:
    cmp_idx = HEADER.index(TIE_BREAK_COL)
    winners: Dict[Tuple[str, ...], List[str]] = {}
    seen_order: List[Tuple[str, ...]] = []  # 保证输出顺序可控（按 first seen）

    for row in [*rows_a, *rows_b]:  # 文件1→文件2
        key = parse_key(row)
        ts  = row[cmp_idx]

        if key not in winners:
            winners[key] = row
            seen_order.append(key)
            continue

        # 比较时间
        if ts > winners[key][cmp_idx]:
            winners[key] = row
        elif ts == winners[key][cmp_idx]:
            # 时间相同：保留已有（先出现）
            continue

    # 按首次出现顺序输出
    return [winners[k] for k in seen_order]

gt_rows = build_gt(rows_f1, rows_f2)

with GT.open("w", newline="", encoding="utf-8") as f_gt:
    w = csv.writer(f_gt)
    w.writerow(HEADER)
    w.writerows(gt_rows)

# ─────────────────────────── 日志 ───────────────────────────
print(
    "✅ 数据生成完毕\n"
    f"• {RAW1.relative_to(ROOT_DIR)} ({len(rows_f1)} 行)\n"
    f"• {RAW2.relative_to(ROOT_DIR)} ({len(rows_f2)} 行)\n"
    f"• {GT.relative_to(ROOT_DIR)}  ({len(gt_rows)} 行 + 表头)"
)