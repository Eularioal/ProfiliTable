#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 主键去重算子 · Evaluation
==================================

数据目录
└─ T00XX_deduplicate_by_pk/
   ├─ expected/gt.csv          # latest_ts 规则下的唯一真值
   ├─ raw/orders1.csv
   ├─ raw/orders2.csv
   └─ eval.py                  # 本脚本

算子任务
    • 合并多份 CSV
    • 以 PRIMARY_KEY 去重
    • 冲突行用 TIE_BREAK_COL 根据 latest_ts 决胜；
      若时间相同 → 保留最先出现的记录（文件顺序 + 行序）

评测规则
    1. 输出文件必须为 CSV，含表头。
    2. 复合主键集合必须与 gt.csv 完全一致且无重复键。
    3. 对于每个主键，所有字段值必须与 gt.csv 完全相同
       （允许输出含有额外列；只比对 gt 列）。
    4. 行顺序和额外列不计入评分。

得分
    全部满足 ⇒ 1.0  
    否则     ⇒ 0.0

使用
    python eval.py -o path/to/output.csv
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Dict, List, Tuple

# ────────────────────────── 配置 ──────────────────────────
PRIMARY_KEY   = ("user_id", "product_id")
TIE_BREAK_COL = "updated_at"         # 仅用于构造数据，这里无需使用
ROOT_DIR      = Path(__file__).resolve().parent
GT_FILE       = ROOT_DIR / "expected" / "gt.csv"

# ──────────────────────── IO 辅助函数 ────────────────────────
def load_csv(path: Path) -> Tuple[List[str], List[Dict[str, str]]]:
    """
    读取 CSV，返回 (header, rows)
    header 按文件中顺序，不做 lower/strip
    rows 为字段原样字符串
    """
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        header = reader.fieldnames
        if not header:
            raise ValueError(f"{path} 缺少表头")
        rows = [dict(r) for r in reader]
    return header, rows


def pk_tuple(row: Dict[str, str]) -> Tuple[str, ...]:
    """从行字典提取复合主键"""
    try:
        return tuple(row[col] for col in PRIMARY_KEY)
    except KeyError as exc:
        raise KeyError(f"缺少主键字段 {exc} 于行: {row}") from exc


def build_pk_map(rows: List[Dict[str, str]]) -> Dict[Tuple[str, ...], Dict[str, str]]:
    """构造 {pk → row}，若出现重复主键立即报错"""
    pk_map: Dict[Tuple[str, ...], Dict[str, str]] = {}
    for r in rows:
        key = pk_tuple(r)
        if key in pk_map:
            raise ValueError(f"输出含重复主键 {key}")
        pk_map[key] = r
    return pk_map


# ────────────────────────── 主评测逻辑 ──────────────────────────
def evaluate(gt_rows: List[Dict[str, str]],
             pred_rows: List[Dict[str, str]],
             gt_header: List[str]) -> float:
    """返回 1.0 / 0.0"""
    try:
        gt_map   = build_pk_map(gt_rows)
        pred_map = build_pk_map(pred_rows)
    except ValueError as exc:
        # 重复键
        print(f"[eval] {exc}", file=sys.stderr)
        return 0.0

    # 主键集合必须一致
    if set(gt_map) != set(pred_map):
        return 0.0

    # 字段值比较（仅检查 gt 中的列，忽略预测额外列）
    for key, gt_row in gt_map.items():
        pred_row = pred_map[key]
        for col in gt_header:
            if pred_row.get(col, "") != gt_row[col]:
                return 0.0

    return 1.0


# ────────────────────────────── CLI ──────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate primary-key deduplication operator")
    parser.add_argument("-o", "--output", required=True,
                        help="CSV file produced by operator")
    args = parser.parse_args()

    pred_path = Path(args.output)
    if not pred_path.exists():
        print(f"文件不存在: {pred_path}", file=sys.stderr)
        sys.exit(1)

    try:
        gt_header, gt_rows   = load_csv(GT_FILE)
        _,         pred_rows = load_csv(pred_path)
    except Exception as exc:
        print(f"[eval] CSV 读取失败: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)

    score = evaluate(gt_rows, pred_rows, gt_header)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"[eval] 评测异常: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)