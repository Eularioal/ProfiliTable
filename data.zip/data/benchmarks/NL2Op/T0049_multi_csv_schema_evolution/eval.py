#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― CSV “列并集合并”算子 · Evaluation
==========================================

目录结构
└─ T00XX_data_column_union/
   ├─ expected/gt.csv           # 规范化 + 列并集 + 缺值补空 的黄金标准
   ├─ raw/orders1.csv
   ├─ raw/orders2.csv
   └─ eval.py                   # 本脚本

使用
    python eval.py -o path/to/output.csv

算子输出要求
    1. 文件类型：CSV（UTF-8），包含表头
    2. 列名需经过规范化：trim → lower → 空格/连字符 ➜ “_” → 连续 “_” 压缩
       （示例：“Order ID” ➜ “order_id”）
    3. 列集合 = 所有输入文件规范化列名的并集；缺失列填空串
    4. 列顺序可为：
         a) 字典序   （本脚本生成的 gt.csv 采用此顺序）  or
         b) “首文件列顺序 + 其余字典序”
       评测对二者均容忍
    5. 行顺序必须：文件 1 全部行 → 文件 2 全部行，且各文件内部原顺序不变
    6. 记录不去重、不改值

评分标准
    所有行内容、行顺序均正确，且列集合完整 ⇒ 1.0  
    否则 ⇒ 0.0

输出
    仅打印一行 JSON：{"eval_score": "<score>"}
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path
from typing import Dict, List

ROOT_DIR = Path(__file__).resolve().parent
GT_FILE  = ROOT_DIR / "expected" / "gt.csv"

# ────────────────────────── 工具函数 ──────────────────────────
def norm(col: str) -> str:
    """trim → lower → 空格 / 连字符 → '_' → 连续 '_' 压缩"""
    col = col.strip().lower()
    col = re.sub(r"[ \-]+", "_", col)
    col = re.sub(r"_+", "_", col)
    return col

def load_csv(path: Path) -> List[Dict[str, str]]:
    """
    读取 CSV 为 List[Dict]，键为规范化后的列名，值保持原样（不 strip）
    同时返回 header 列顺序（规范化后）做列顺序检查
    """
    rows: List[Dict[str, str]] = []
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        try:
            raw_header = next(reader)
        except StopIteration:
            raise ValueError(f"{path} 为空文件")

        header_norm = [norm(h) for h in raw_header]

        for r in reader:
            rows.append({norm(h): v for h, v in zip(raw_header, r)})

    return header_norm, rows

def canonicalize(
    header_norm: List[str],
    rows: List[Dict[str, str]],
    gt_cols: List[str]
) -> List[List[str]]:
    """
    将行按照给定列顺序（gt_cols）展开成二维列表，缺失列填 ""
    """
    return [[row.get(col, "") for col in gt_cols] for row in rows]

# ─────────────────────────── 主函数 ─────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate column-union CSV operator")
    parser.add_argument(
        "-o", "--output", required=True,
        help="CSV file produced by operator (e.g., output.csv)"
    )
    args = parser.parse_args()
    pred_path = Path(args.output)

    # ---------- 加载 GT ----------
    gt_header, gt_rows_dict = load_csv(GT_FILE)
    # GT 已保证 header 字典序
    gt_matrix = canonicalize(gt_header, gt_rows_dict, gt_header)

    # ---------- 加载预测 ----------
    try:
        pred_header, pred_rows_dict = load_csv(pred_path)
    except Exception as exc:
        print(f"[eval.py] 读取输出文件失败: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)

    # ---------- 列集合检查 ----------
    if set(pred_header) != set(gt_header):
        # 缺列 / 多列
        print(json.dumps({"eval_score": "0.0"}))
        return

    # ---------- 行数检查 ----------
    if len(pred_rows_dict) != len(gt_rows_dict):
        print(json.dumps({"eval_score": "0.0"}))
        return

    # ---------- 行内容 & 顺序检查 ----------
    # 为容忍列顺序不同，把预测行展开为 GT 列顺序再比较
    pred_matrix = canonicalize(pred_header, pred_rows_dict, gt_header)

    score = 1.0 if pred_matrix == gt_matrix else 0.0
    print(json.dumps({"eval_score": f"{score:.1f}"}))

if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"[eval.py] 评测失败: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)