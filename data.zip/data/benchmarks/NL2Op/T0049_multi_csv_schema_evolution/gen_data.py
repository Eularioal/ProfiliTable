#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py — 构造列集不完全相同的 CSV 及合并后 GT
"""

from __future__ import annotations
import csv
import random
import re
from pathlib import Path
from typing import List, Dict, Any

from faker import Faker

# ────────────────────────── 配置 ──────────────────────────
ROW_CNT_FILE1 = 60         # orders1.csv 行数
ROW_CNT_FILE2 = 50         # orders2.csv 行数
RANDOM_SEED   = 2024

# ────────────────────────── 路径 ──────────────────────────
ROOT_DIR     = Path(__file__).resolve().parent
RAW_DIR      = ROOT_DIR / "raw"
EXPECTED_DIR = ROOT_DIR / "expected"
RAW_DIR.mkdir(exist_ok=True)
EXPECTED_DIR.mkdir(exist_ok=True)

RAW1_PATH = RAW_DIR / "orders1.csv"
RAW2_PATH = RAW_DIR / "orders2.csv"
GT_PATH   = EXPECTED_DIR / "gt.csv"

# ────────────────────────── Faker ──────────────────────────
random.seed(RANDOM_SEED)
fake = Faker()
Faker.seed(RANDOM_SEED)

# ────────────────── 表头（保持“不规范”） ──────────────────
HEADER_F1 = ["Order ID", "Customer Name", "Product - Name",
             "Quantity", "Ship Country"]
HEADER_F2 = ["order id", "customer_email", "product_name",
             "quantity", "price", "ship-country"]

# ────────────────── 规范化工具 ──────────────────
def norm(col: str) -> str:
    """trim → lower → 空格/连字符→下划线 → 连续下划线压缩"""
    col = col.strip().lower()
    col = re.sub(r"[ \-]+", "_", col)
    col = re.sub(r"_+", "_", col)
    return col

# ────────────────── 生成原始数据行 ──────────────────
def make_row_f1(order_id: int) -> List[str]:
    return [
        str(order_id),
        fake.name(),
        fake.word().title(),
        str(random.randint(1, 10)),
        fake.country_code(representation="alpha-2")
    ]

def make_row_f2(order_id: int) -> List[str]:
    price = f"{random.uniform(5, 500):.2f}"
    return [
        str(order_id),
        fake.email(),
        fake.word().title(),
        str(random.randint(1, 10)),
        price,
        fake.country_code(representation="alpha-2")
    ]

rows_f1 = [make_row_f1(i) for i in range(1, ROW_CNT_FILE1 + 1)]
rows_f2 = [make_row_f2(i + 1000) for i in range(1, ROW_CNT_FILE2 + 1)]

# 可添加几条跨文件重复行（演示“不去重”）
rows_f2 += rows_f1[:3]            # 将文件1前 3 行复制到文件2
random.shuffle(rows_f2)

# ────────────────── 写入 raw/*.csv ──────────────────
def write_csv(path: Path, header: List[str], rows: List[List[str]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)

write_csv(RAW1_PATH, HEADER_F1, rows_f1)
write_csv(RAW2_PATH, HEADER_F2, rows_f2)

# ────────────────── 生成 GT ──────────────────
# 1) 计算全集列（规范化后）并按字典序排序
all_cols_norm: List[str] = sorted({*map(norm, HEADER_F1), *map(norm, HEADER_F2)})

def row_to_dict(header: List[str], row: List[str]) -> Dict[str, Any]:
    """把一行转换为 {规范化列: 值}"""
    return {norm(h): v for h, v in zip(header, row)}

# 2) 合并行：先文件1后文件2，行内保持顺序
merged_rows: List[Dict[str, Any]] = (
    [row_to_dict(HEADER_F1, r) for r in rows_f1] +
    [row_to_dict(HEADER_F2, r) for r in rows_f2]
)

# 3) 写出 GT，缺失列填 ""
with GT_PATH.open("w", newline="", encoding="utf-8") as f_gt:
    w = csv.writer(f_gt)
    w.writerow(all_cols_norm)             # 规范化后的表头
    for r in merged_rows:
        w.writerow([r.get(col, "") for col in all_cols_norm])

# ────────────────────────── 日志 ──────────────────────────
print(
    "✅ 数据生成完毕\n"
    f"• {RAW1_PATH.relative_to(ROOT_DIR)} ({len(rows_f1)} 行)\n"
    f"• {RAW2_PATH.relative_to(ROOT_DIR)} ({len(rows_f2)} 行)\n"
    f"• {GT_PATH.relative_to(ROOT_DIR)}  ({len(merged_rows)} 行 + 表头)"
)