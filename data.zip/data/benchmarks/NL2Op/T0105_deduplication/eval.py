#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “去重” 算子

使用方法
--------
python eval.py -o /path/to/your_output.csv

说明
----
1. 基准文件固定为同级目录 expected/gt.csv
2. -o 指向去重算子的输出CSV文件（预测结果）
3. 评测逻辑：
   - 自动识别GT表中列名带**的关键列（去重判定列）
   - 保留预测文件原始数据（含重复行），不自动去重
   - 基于关键列拼接唯一键，仅首次出现的基准键算去重成功
4. 数据预处理：关键列值转字符串、去空格，拼接唯一键
5. 评测指标：Binary Precision/Recall/F1-score（零除法时指标为0）
6. 指标范围 ∈ [0,1]，输出格式：{"eval_score": F1值（保留4位小数）}
"""

from __future__ import annotations
import argparse
import pandas as pd
from sklearn.metrics import precision_recall_fscore_support
from pathlib import Path
from typing import List, Set, Tuple, Optional, Dict

# ------------------------------------------------------------------ 常量
GT_PATH = Path(__file__).parent / "expected" / "gt.csv"  # 固定基准文件路径
KEY_MARKER = "**"  # 关键列的标注符
KEY_SEP = "|||"    # 拼接关键列的分隔符（避免内容冲突）

# ------------------------------------------------------------------ 工具函数
def extract_core_cols(df: pd.DataFrame) -> Tuple[List[str], List[str]]:
    """
    提取GT表中带**的关键列，返回（原始关键列名，清洗后核心列名）
    示例：["CustomerID**", "FeedbackContent**"] → ["CustomerID", "FeedbackContent"]
    """
    # 筛选带**的列名
    raw_core_cols = [col for col in df.columns if KEY_MARKER in col]
    # 去除**得到清洗后的核心列名
    clean_core_cols = [col.replace(KEY_MARKER, "") for col in raw_core_cols]
    
    if not raw_core_cols:
        print(f"错误: GT表中未发现带{KEY_MARKER}标注的关键列，当前列名：{df.columns.tolist()}")
    
    return raw_core_cols, clean_core_cols

def read_and_validate_data(gt_path: str | Path, pred_path: str | Path) -> Tuple[Optional[pd.DataFrame], Optional[pd.DataFrame], List[str]]:
    """
    读取GT和Pred数据，验证核心列，返回对齐后的数据
    返回：(GT数据, Pred数据, 清洗后的核心列名)
    """
    # 1. 读取GT文件
    try:
        df_gt = pd.read_csv(gt_path)
    except Exception as e:
        print(f"GT文件读取失败: {e}")
        return None, None, []
    
    # 2. 提取GT的关键列并清洗
    raw_core_cols, clean_core_cols = extract_core_cols(df_gt)
    if not clean_core_cols:
        return None, None, []
    
    # 3. 读取Pred文件
    try:
        df_pred = pd.read_csv(pred_path)
    except Exception as e:
        print(f"预测文件读取失败: {e}")
        return None, None, []
    
    # 4. 验证Pred文件是否包含核心列
    missing_cols = [col for col in clean_core_cols if col not in df_pred.columns]
    if missing_cols:
        print(f"错误: 预测文件缺失核心列 {missing_cols}，当前列名：{df_pred.columns.tolist()}")
        return None, None, []
    
    # 6. 填充空值（避免拼接时出现NaN）
    df_gt[raw_core_cols] = df_gt[raw_core_cols].fillna("")
    df_pred[clean_core_cols] = df_pred[clean_core_cols].fillna("")
    
    return df_gt, df_pred, clean_core_cols

def generate_core_key(df: pd.DataFrame, core_cols: List[str], is_gt: bool = False) -> Tuple[List[str], Set[str]]:
    """
    基于核心列生成唯一键
    参数：
        df - 数据框
        core_cols - 核心列名（GT用原始带**列，Pred用清洗后列）
        is_gt - 是否为GT数据
    返回：(键列表, 键集合) → GT返回(去重后列表, 集合)，Pred返回(原始列表, 集合)
    """
    # 核心列值清洗：转字符串、去空格
    for col in core_cols:
        df[col] = df[col].astype(str).str.strip()
    
    # 拼接核心列生成唯一键
    df["core_key"] = df[core_cols].apply(
        lambda row: KEY_SEP.join(row.tolist()), axis=1
    )
    
    if is_gt:
        # GT数据：去重，保留首次出现的键（作为标准答案）
        df_gt_deduped = df.drop_duplicates(subset=["core_key"], keep="first")
        key_list = df_gt_deduped["core_key"].tolist()
        key_set = set(key_list)
    else:
        # Pred数据：保留原始键列表（含重复），不自动去重
        key_list = df["core_key"].tolist()
        key_set = set(key_list)
        duplicate_count = len(key_list) - len(key_set)
    
    return key_list, key_set

def build_duplication_labels(gt_key_set: Set[str], pred_key_list: List[str]) -> Tuple[list, list]:
    """
    构建去重任务标签序列：
    - y_true: 键是否属于GT基准集合（1=是，0=否）
    - y_pred: 键属于GT且首次出现（1=是，0=否）→ 仅此时算去重成功
    """
    y_true = []
    y_pred = []
    seen_keys = set()  # 记录已出现的预测键
    
    for key in pred_key_list:
        # 真实标签：是否为基准键
        true_label = 1 if key in gt_key_set else 0
        y_true.append(true_label)
        
        # 预测标签：基准键且首次出现 → 1（去重成功），否则0
        if key in gt_key_set and key not in seen_keys:
            pred_label = 1
            seen_keys.add(key)
        else:
            pred_label = 0
        y_pred.append(pred_label)
    
    return y_true, y_pred

def compute_metrics(y_true: list, y_pred: list) -> Dict[str, float]:
    """计算Binary Precision/Recall/F1-score"""
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average='binary', zero_division=0
    )
    return {
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4)
    }

# ------------------------------------------------------------------ 主流程
def main() -> None:
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="Evaluate Deduplication output (Core Cols with **)")
    parser.add_argument(
        "-o", "--output", required=True,
        help="Path to CSV produced by your deduplication operator (prediction result)"
    )
    args = parser.parse_args()

    # 1. 读取并验证数据（识别关键列+对齐）
    df_gt, df_pred, clean_core_cols = read_and_validate_data(GT_PATH, args.output)
    if df_gt is None or df_pred is None:
        return
    
    # 2. 提取GT的原始关键列（带**）
    raw_core_cols_gt = [col for col in df_gt.columns if KEY_MARKER in col]
    
    # 3. 生成核心键：GT去重（基准），Pred保留原始（含重复）
    _, gt_key_set = generate_core_key(df_gt, raw_core_cols_gt, is_gt=True)
    pred_key_list, _ = generate_core_key(df_pred, clean_core_cols, is_gt=False)
    
    # 4. 构建标签并计算指标
    y_true, y_pred = build_duplication_labels(gt_key_set, pred_key_list)
    metrics = compute_metrics(y_true, y_pred)
    
    # 5. 输出结果
    print({"eval_score": f"{metrics['f1']:.4f}"})

if __name__ == "__main__":
    main()