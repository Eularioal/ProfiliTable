#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 交叉列重复检测 · 评测脚本
-----------------------------------------------------------
算子需输出去重后的 CSV / JSONL，至少包含字段:
    id, name, old_name, nick_name

判定标准
    1. 固定黄金标准 expected/gt.jsonl
    2. 只考察 “被保留的 id 是否正确”
       · TP : 首次出现且 id ∈ GT
       · FP : 预测 id 重复 / 不在 GT
       · FN : GT 中遗漏 id
    3. 行级 F1 = 2·P·R / (P+R)
    4. 仅打印 {"eval_score": "<score>"}，4 位小数
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Dict, List, Set, Any

GT_PATH = Path(__file__).parent / "expected" / "gt.csv"


# ─────────────────── 读文件工具 ────────────────────
def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open(encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                raise ValueError(f"{path}:{lineno} 不是合法 JSON: {e}") from e
    if not rows:
        raise ValueError(f"{path} 为空文件")
    return rows


def read_csv(path: Path) -> List[Dict[str, Any]]:
    with path.open(encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = [{k: v for k, v in row.items()} for row in reader]
    if not rows:
        raise ValueError(f"{path} 为空文件")
    return rows


def read_rows(path: Path) -> List[Dict[str, Any]]:
    if path.suffix.lower() == ".jsonl":
        return read_jsonl(path)
    if path.suffix.lower() == ".csv":
        return read_csv(path)
    raise ValueError(f"仅支持 .jsonl / .csv，收到 {path.name}")


# ─────────────────────── 评分逻辑 ───────────────────────
def compute_f1(gt_ids: Set[str], pred_rows: List[Dict[str, Any]]) -> float:
    if not pred_rows:
        return 0.0

    tp_ids: Set[str] = set()
    seen_pred: Set[str] = set()
    fp = 0

    for row in pred_rows:
        rid = str(row.get("id", "")).strip()
        if not rid:
            fp += 1
            continue
        if rid in seen_pred:  # 重复行
            fp += 1
            continue
        seen_pred.add(rid)

        if rid in gt_ids:
            tp_ids.add(rid)
        else:
            fp += 1  # 额外 id

    fn = len(gt_ids) - len(tp_ids)
    precision = len(tp_ids) / (len(tp_ids) + fp) if tp_ids or fp else 0.0
    recall    = len(tp_ids) / (len(tp_ids) + fn) if tp_ids or fn else 0.0
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


# ──────────────────────── 主流程 ────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate cross-column duplicate detection output")
    parser.add_argument("-o", "--output", required=True,
                        help="Path to JSONL/CSV produced by your operator")
    args = parser.parse_args()

    # ---------- 黄金标准 ----------
    gt_rows = read_csv(GT_PATH)
    gt_ids: Set[str] = {str(r["id"]).strip() for r in gt_rows}

    # ---------- 读取预测 ----------
    pred_path = Path(args.output)
    if not pred_path.exists():
        print(f"文件不存在: {pred_path}", file=sys.stderr)
        sys.exit(1)
    pred_rows = read_rows(pred_path)

    # ---------- 计算 F1 ----------
    score = compute_f1(gt_ids, pred_rows)

    # ---------- 输出 ----------
    print(json.dumps({"eval_score": f"{score:.4f}"}))


if __name__ == "__main__":
    main()