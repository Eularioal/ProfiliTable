#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py ― 交叉列重复检测 · 数据生成器（faker 版本）
------------------------------------------------------------------
字段
    id, name, old_name, nick_name

重复规则
    A = {name}
    B = {old_name, nick_name}
    若 A 中任一值 == B 中任一值（忽略大小写 & 前后空格）则两行互为重复
    每组仅保留 id 最小的那行

数据规模
    NUM_GT      : 去重后应剩多少条记录        (≥100)
    DUPS_PER_GT : 每条 GT 额外生成几条脏副本  (raw 行数 = GT×(1+N))
"""

from pathlib import Path
import csv
import json
import random
from faker import Faker

# ────────────────── 可自由调节 ───────────────────
NUM_GT = 120       # 黄金标准行数
DUPS_PER_GT = 3    # 每条 GT 生成几条脏副本
SEED = 2024        # 保证可复现
# ────────────────────────────────────────────────

random.seed(SEED)
fake = Faker("en_US")
fake.seed_instance(SEED)

BASE_DIR = Path(__file__).resolve().parent
RAW_DIR = BASE_DIR / "raw"
EXP_DIR = BASE_DIR / "expected"
RAW_DIR.mkdir(parents=True, exist_ok=True)
EXP_DIR.mkdir(parents=True, exist_ok=True)

# ───────────────────── 1. 生成 GT ─────────────────────
def gen_clean_name() -> str:
    """用 faker 生成较像商品/品牌的名称"""
    word1 = fake.unique.word().title()
    word2 = fake.unique.word().title()
    # 30% 概率带连字符，70% 空格
    sep = "-" if random.random() < 0.3 else " "
    return f"{word1}{sep}{word2}"

gt_records = []
for i in range(1, NUM_GT + 1):
    rid = 1000 + i
    name = gen_clean_name()
    gt_records.append(
        {"id": rid, "name": name, "old_name": "", "nick_name": ""}
    )

# ───────────────────── 2. 生成 RAW ─────────────────────
raw_records = []
dup_id_auto = 60000  # 脏数据 id 起始

def blank() -> dict[str, str]:
    return {"id": "", "name": "", "old_name": "", "nick_name": ""}

def add_noise_spaces(text: str) -> str:
    # 随机在前后插入空格
    return f"{' ' * random.randint(0, 1)}{text}{' ' * random.randint(0, 1)}"

for rec in gt_records:
    raw_records.append(rec.copy())   # ① 原始“干净”行

    base_name = rec["name"]

    for k in range(DUPS_PER_GT):
        row = blank()
        row["id"] = dup_id_auto
        dup_id_auto += 1

        # ---- 生成 name / old_name / nick_name 的脏变体 ----
        variant = base_name

        # 大小写扰动
        style = random.choice(["lower", "upper", "title", "mixed"])
        if style == "lower":
            variant = variant.lower()
        elif style == "upper":
            variant = variant.upper()
        elif style == "title":
            variant = variant.title()
        else:  # mixed
            variant = "".join(
                c.upper() if random.random() < 0.5 else c.lower() for c in variant
            )

        # 随机插入/删除空格
        variant = add_noise_spaces(variant.replace("-", " " if random.random() < 0.5 else "-"))

        mode = k % 3
        if mode == 0:
            row["name"] = variant
            row["old_name"] = base_name
        elif mode == 1:
            row["name"] = variant
            row["nick_name"] = base_name
        else:
            row["name"] = variant + "_v2"
            row["old_name"] = base_name
            row["nick_name"] = add_noise_spaces(base_name.title())

        raw_records.append(row)

# ───────────────────── 3. 写 RAW 文件 ────────────────────
csv_headers = ["id", "name", "old_name", "nick_name"]
raw_csv   = RAW_DIR / "customers.csv"
raw_jsonl = RAW_DIR / "customers.jsonl"

with raw_csv.open("w", encoding="utf-8", newline="") as cf, \
     raw_jsonl.open("w", encoding="utf-8") as jf:
    writer = csv.DictWriter(cf, fieldnames=csv_headers)
    writer.writeheader()
    for r in raw_records:
        writer.writerow(r)
        json.dump(r, jf, ensure_ascii=False)
        jf.write("\n")

# ───────────────────── 4. 写 GT 文件 ─────────────────────
gt_csv   = EXP_DIR / "gt.csv"
gt_jsonl = EXP_DIR / "gt.jsonl"

with gt_csv.open("w", encoding="utf-8", newline="") as cf, \
     gt_jsonl.open("w", encoding="utf-8") as jf:
    writer = csv.writer(cf)
    writer.writerow(csv_headers)
    for r in gt_records:
        writer.writerow([r[c] for c in csv_headers])
        json.dump(r, jf, ensure_ascii=False)
        jf.write("\n")

print(f"✅ 数据生成完毕：GT {len(gt_records)} 行，RAW {len(raw_records)} 行")