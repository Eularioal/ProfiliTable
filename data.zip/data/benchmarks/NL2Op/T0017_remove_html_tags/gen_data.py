import json
import random
import os
from utils.llm_serving import LLMServing
import re

def remove_html_tags(text):
    """简单的html标签删除，用于验证示例。"""
    clean = re.compile(r'<.*?>')
    return re.sub(clean, '', text)

def gen_gt_data(topics, per_topic=10):
    llm = LLMServing()
    user_inputs = [f"Write a short formal sentence about {topic} without using contractions." for topic in topics for _ in range(per_topic)]
    system_prompt = "You are an AI that writes formal English without contractions."
    results = llm.generate_from_input(user_inputs, system_prompt)
    return results

def build_records(texts, topics):
    records = []
    for i, txt in enumerate(texts):
        rec = {
            "id": f"id_{i+1:04d}",
            "topic": topics[i // per_topic],
            "text": txt.strip()
        }
        records.append(rec)
    return records

def add_dirty_data(gt_records, dirty_rate=0.3):
    """
    随机替换部分gt文本为带html标签的文本，模拟脏数据。
    html标签样例包括：<p>, <a href='url'>, <b>, <i>等
    """
    dirty_html_tags = [
        ("<p>{}</p>", "paragraph"),
        ("<a href='https://example.com'>{}</a>", "link"),
        ("<b>{}</b>", "bold"),
        ("<i>{}</i>", "italic"),
        ("<div>{}</div>", "div"),
        ("<span style='color:red'>{}</span>", "span"),
    ]

    new_records = []
    for rec in gt_records:
        if random.random() < dirty_rate:
            tag_tpl, _ = random.choice(dirty_html_tags)
            dirty_text = tag_tpl.format(rec["text"])
            dirty_rec = rec.copy()
            dirty_rec["text"] = dirty_text
            new_records.append(dirty_rec)
        else:
            new_records.append(rec)
    return new_records

if __name__ == "__main__":
    # 任务配置
    topics = [
        "climate change",
        "artificial intelligence",
        "global economy",
        "health and wellness",
        "space exploration",
        "education reform",
        "renewable energy",
        "cybersecurity",
        "quantum computing",
        "sustainable agriculture",
    ]
    per_topic = 10  # 10 topics * 8 = 80条数据

    # 生成干净的GT数据
    clean_texts = gen_gt_data(topics, per_topic)
    gt_records = build_records(clean_texts, topics)

    # 构造带脏数据的raw数据
    raw_records = add_dirty_data(gt_records, dirty_rate=0.8)  # 35%数据带html标签脏数据

    # 保存路径
    gt_path = "data/benchmarks/NL2Op/T0009_/expected/gt.jsonl"
    raw_path = "data/benchmarks/NL2Op/T0009_/raw/customers.jsonl"

    os.makedirs(os.path.dirname(gt_path), exist_ok=True)
    os.makedirs(os.path.dirname(raw_path), exist_ok=True)

    # 写文件，utf-8编码
    with open(gt_path, "w", encoding="utf-8") as f_gt, open(raw_path, "w", encoding="utf-8") as f_raw:
        for rec in gt_records:
            f_gt.write(json.dumps(rec, ensure_ascii=False) + "\n")
        for rec in raw_records:
            f_raw.write(json.dumps(rec, ensure_ascii=False) + "\n")

    print(f"GT data saved to {gt_path} ({len(gt_records)} records)")
    print(f"Raw data with dirty samples saved to {raw_path} ({len(raw_records)} records)")
