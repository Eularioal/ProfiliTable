import pandas as pd
import numpy as np
import random
import json
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# Helper function to simulate transaction data
def generate_transaction_data(num_entries):
    transaction_data = []
    transaction_types = ['Deposit', 'Withdrawal', 'Transfer']
    for i in range(num_entries):
        transaction_id = i
        account_number = f'ACC{random.randint(1000, 9999)}'
        transaction_type = random.choice(transaction_types)
        transaction_amount = random.randint(1000, 1500)  # Random amount between 10 and 10,000
        transaction_date = f"2025-08-{random.randint(1, 31):02d}"
        
        transaction_data.append({
            "transaction_id": transaction_id,
            "account_number": account_number,
            "transaction_type": transaction_type,
            "transaction_amount": transaction_amount,
            "transaction_date": transaction_date
        })
    
    return pd.DataFrame(transaction_data)

# Helper function to introduce dirty data (outliers)
def introduce_dirty_data(df, num_dirty_entries):
    dirty_df = df.copy()
    dirty_indices = random.sample(range(len(df)), num_dirty_entries)
    
    for idx in dirty_indices:
        # Randomly increase the transaction_amount to introduce outliers (abnormal transactions)
        original_amount = dirty_df.loc[idx, 'transaction_amount']
        transaction_type = dirty_df.loc[idx, 'transaction_type']
        
        # Make the abnormal value larger than the 95th percentile
        if transaction_type == 'Deposit':
            dirty_df.loc[idx, 'transaction_amount'] = original_amount * random.uniform(5, 10)
        elif transaction_type == 'Withdrawal':
            dirty_df.loc[idx, 'transaction_amount'] = original_amount * random.uniform(2, 5)
        else:
            dirty_df.loc[idx, 'transaction_amount'] = original_amount * random.uniform(3, 7)
    
    return dirty_df

# Helper function to clean the data using machine learning model
def clean_transaction_amounts(df):
    # Using transaction type and amount to predict and clean anomalies
    df_cleaned = df.copy()
    
    # Prepare the dataset
    df_grouped = df.groupby('transaction_type').agg({'transaction_amount': ['mean', 'std']}).reset_index()
    
    # We will use decision tree or any regression model to predict and clean abnormal amounts
    model = DecisionTreeRegressor()
    
    # Train the model (predicting the transaction amount based on type)
    X = pd.get_dummies(df[['transaction_type']], drop_first=True)  # Encoding transaction_type
    y = df['transaction_amount']
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    model.fit(X_train, y_train)
    
    # Predict transaction amounts
    y_pred = model.predict(X_test)
    
    # Calculate the mean squared error to evaluate
    mse = mean_squared_error(y_test, y_pred)
    print(f'Mean Squared Error of the model: {mse}')
    
    # Cleaning anomalies in the dataset (replace with mean for the same type)
    for transaction_type in df['transaction_type'].unique():
        type_data = df[df['transaction_type'] == transaction_type]
        type_mean = type_data['transaction_amount'].mean()
        
        # Identify anomalies (values higher than 95th percentile)
        type_95th_percentile = np.percentile(type_data['transaction_amount'], 80)
        df_cleaned.loc[(df_cleaned['transaction_type'] == transaction_type) & 
                       (df_cleaned['transaction_amount'] > type_95th_percentile), 
                       'transaction_amount'] = type_mean
        
    return df_cleaned

# Function to generate GT and dirty data and save to CSV
def generate_data(gt_size, dirty_size):
    # Generate GT data
    df_gt = generate_transaction_data(gt_size)
    
    # Introduce dirty data (outliers)
    df_dirty = introduce_dirty_data(df_gt, dirty_size)
    
    # Clean the dirty data using ML model
    df_cleaned = clean_transaction_amounts(df_dirty)
    
    # Save GT data (unmodified and modified)
    gt_data = df_cleaned.copy()
    gt_data['id'] = range(len(gt_data))
    
    # Save dirty data and cleaned data to CSV
    df_cleaned.to_csv('data/benchmarks/NL2Op/T0036_/expected/gt.csv', index=False, encoding='utf-8')
    df_dirty.to_csv('data/benchmarks/NL2Op/T0036_/raw/customers.csv', index=False, encoding='utf-8')

# Example of running the script
if __name__ == "__main__":
    generate_data(1000, 100)
