import csv
import json
import argparse
import numpy as np
from pathlib import Path

def load_csv(path):
    data = {}
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            id_ = row.get("transaction_id", "").strip()
            if id_:
                data[id_] = row
    return data

def calculate_variance(data, field):
    values = [float(record.get(field, 0)) for record in data.values()]
    if len(values) < 2:
        return 0.0
    return np.var(values)

def evaluate(expected_path, processed_path):
    expected_data = load_csv(expected_path)
    processed_data = load_csv(processed_path)

    # Calculate variance for 'transaction_amount' in both datasets
    expected_variance = calculate_variance(expected_data, "transaction_amount")
    processed_variance = calculate_variance(processed_data, "transaction_amount")

    # Calculate the score based on the difference in variances
    if expected_variance == 0 and processed_variance == 0:
        score = 1.0  # Perfect match if both variances are zero
    elif expected_variance == 0 or processed_variance == 0:
        score = 0.0  # If one variance is zero, but the other is not, it's a mismatch
    else:
        score = 1 - abs(expected_variance - processed_variance) / max(expected_variance, processed_variance)
    
    print(json.dumps({"eval_score": f"{score:.4f}"}))
    return score

def get_gt():
    current_dir = Path(__file__).resolve().parent
    expected_dir = (current_dir / "expected").resolve()
    csv_files = list(expected_dir.glob("*.csv"))
    if not csv_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")
    return csv_files[0]

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate transaction amount correction (CSV) using variance")
    parser.add_argument("-o", "--output", required=True, help="Path to processed csv file")
    args = parser.parse_args()

    expected_path = get_gt()
    processed_path = Path(args.output)
    evaluate(expected_path, processed_path)
