#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py -- Mean-Imputation 算子评测脚本
=====================================

目录结构
.
├── raw/customers.csv     # 原始数据，缺失值为 "" 或 "NA"
├── expected/gt.csv       # 参考答案（数值列已按列均值填补）
└── <candidate.csv>       # 选手输出，作为 -o 参数传入

规则
  1. 选手输出必须包含与 gt.csv 完全相同的列集合和行数
  2. 所有数值列缺失值必须被消除，并且每个填补结果需与 gt.csv
     内的均值填补结果在 1e-6 绝对误差内一致
  3. 非数值列内容需与原始数据保持一致
  4. 通过则得分 1.0，否则 0.0
"""

from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd


ROOT      = Path(__file__).resolve().parent
RAW_PATH  = ROOT / "raw" / "customers.csv"
GT_PATH   = ROOT / "expected" / "gt.csv"
ATOL      = 1e-6              # 允许的浮点误差


# ────────────────────────── 工具函数 ──────────────────────────
def fail(msg: str, code: int = 1) -> None:
    """打印错误信息至 stderr 并输出 0 分结果"""
    print(f"[eval] {msg}", file=sys.stderr)
    print(json.dumps({"eval_score": "0.0"}))
    sys.exit(code)


def load_csv(path: Path, *, na: bool = False) -> pd.DataFrame:
    """
    读取 CSV
    na=True  -> 将 "" 和 "NA" 当作缺失值
    """
    if na:
        return pd.read_csv(path, na_values=["", "NA"], keep_default_na=True)
    return pd.read_csv(path)


# ────────────────────────── 主评测逻辑 ──────────────────────────
def evaluate(cand: pd.DataFrame, gt: pd.DataFrame, raw: pd.DataFrame) -> float:
    # 1) 行列检查
    if cand.shape != gt.shape:
        fail(f"行列数不一致，期望 {gt.shape}，实际 {cand.shape}")
    if set(cand.columns) != set(gt.columns):
        miss = set(gt.columns) - set(cand.columns)
        extra = set(cand.columns) - set(gt.columns)
        if miss:
            fail(f"缺少列: {', '.join(miss)}")
        if extra:
            fail(f"多余列: {', '.join(extra)}")
        # 如果只是顺序不同，下面会重新排序
    cand = cand[gt.columns]   # 重排列顺序，便于直接比较

    # 2) 识别数值列
    num_cols = gt.select_dtypes(include=[np.number]).columns.tolist()
    if not num_cols:
        fail("未能识别到任何数值列")

    # 3) 针对每个数值列做两步校验
    for col in num_cols:
        # 3-1) 不应再有缺失
        if cand[col].isna().any():
            fail(f"列 {col} 仍包含缺失值")

        # 3-2) 必须与均值填补结果一致
        if not np.allclose(
            cand[col].astype(float).values,
            gt[col].astype(float).values,
            atol=ATOL,
            equal_nan=False,
        ):
            fail(f"列 {col} 不是均值填补或数值误差超出 {ATOL}")

    # 4) 非数值列内容应保持一致（可接受字符串 / 分类 dtype 差异）
    cat_cols = [c for c in gt.columns if c not in num_cols]
    cat_diff = ~(cand[cat_cols].astype(str) == raw[cat_cols].astype(str)).all(axis=1)
    if cat_diff.any():
        idx = cat_diff[cat_diff].index[0]
        fail(f"非数值列第 {idx} 行与原始数据不一致")

    return 1.0


# ────────────────────────── CLI ──────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate mean-imputation operator")
    parser.add_argument("-o", "--output", required=True, help="CSV file produced by operator")
    args = parser.parse_args()

    cand_path = Path(args.output)
    if not cand_path.exists():
        fail(f"文件不存在: {cand_path}")

    try:
        raw = load_csv(RAW_PATH, na=True)
        gt  = load_csv(GT_PATH)
        cand = load_csv(cand_path)
    except Exception as exc:
        fail(f"读取 CSV 失败: {exc}")

    score = evaluate(cand, gt, raw)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        fail(f"评测异常: {exc}", code=2)