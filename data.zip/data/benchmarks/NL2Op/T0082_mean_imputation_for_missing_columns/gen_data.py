#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py
===========

生成两份 CSV：
1. raw/customers.csv  —— 数值列包含缺失值("" 或 "NA")
2. expected/gt.csv   —— 数值列已按列均值填补

执行:
    python gen_data.py
"""

from pathlib import Path
import random
import numpy as np
import pandas as pd

# ---------- 可复现随机数 ----------
random.seed(42)
np.random.seed(42)

# ---------- 参数 ----------
N_ROWS         = 150                       # 行数
NUMERIC_COLS   = ["age", "income", "score"]
CATEGORIC_COLS = ["gender", "region"]
NA_RATIO       = 0.12                      # 每个数值列缺失占比

RAW_DIR = Path("raw")
EXP_DIR = Path("expected")
RAW_FILE = RAW_DIR / "customers.csv"
GT_FILE  = EXP_DIR / "gt.csv"
# ----------------------------

def main() -> None:
    # 1) 目录
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    EXP_DIR.mkdir(parents=True, exist_ok=True)

    # 2) 构造初始 DataFrame
    data = {
        "age":    np.random.randint(18, 65, size=N_ROWS),
        "income": np.round(np.random.normal(8e4, 2e4, size=N_ROWS), 2),
        "score":  np.round(np.random.uniform(200, 850, size=N_ROWS), 1),
        "gender": np.random.choice(["M", "F"], size=N_ROWS),
        "region": np.random.choice(["North", "South", "East", "West"], size=N_ROWS),
    }
    df_raw = pd.DataFrame(data)

    # 3) 注入缺失值（"" / "NA" 混合）
    for col in NUMERIC_COLS:
        # 先把列转成 object，后续才能放入字符串
        df_raw[col] = df_raw[col].astype(object)

        miss_idx = np.random.choice(N_ROWS, size=int(N_ROWS * NA_RATIO),
                                    replace=False)
        for i in miss_idx:
            df_raw.at[i, col] = random.choice(["", "NA"])

    # 4) 保存 raw（默认行结束符 \n，避免旧版 pandas 无 line_terminator 参数）
    df_raw.to_csv(RAW_FILE, index=False, encoding="utf-8")

    # 5) 计算均值并填补 -> gt
    df_gt = df_raw.replace({"": np.nan, "NA": np.nan})
    for col in NUMERIC_COLS:
        mean_val = df_gt[col].astype(float).mean()       # 跳过 NaN
        df_gt[col] = df_gt[col].astype(float).fillna(mean_val)

    # 6) 保存 gt
    df_gt.to_csv(
        GT_FILE,
        index=False,
        encoding="utf-8",
        float_format="%.6f",   # 便于评测的确定性
    )

    print("✓ 数据已生成：")
    print(f"  RAW -> {RAW_FILE.resolve()}")
    print(f"  GT  -> {GT_FILE.resolve()}")

if __name__ == "__main__":
    main()