import pandas as pd
import argparse
from pathlib import Path

TOLERANCE = 0  # 允许误差范围，填补时没有误差

# 加载CSV文件
def load_csv(path):
    """读取CSV文件并返回DataFrame"""
    return pd.read_csv(path, encoding='utf-8')

# 评估补全准确度
def evaluate(gt_path, pred_path):
    """评估补全的支付方式准确度"""
    # 加载GT和预测数据
    gt_data = load_csv(gt_path)
    pred_data = load_csv(pred_path)

    # 确保数据根据 shipment_id 对齐
    gt_data = gt_data.sort_values('transaction_id').reset_index(drop=True)
    pred_data = pred_data.sort_values('transaction_id').reset_index(drop=True)

    correct_count = 0
    total_count = 0

    # 计算支付状态为“成功”时最常见的支付方式
    successful_transactions = gt_data[gt_data["payment_status"] == "成功"]
    most_common_method = successful_transactions["payment_method"].mode()[0]

    # 遍历数据并评估补全情况
    for gt_row, pred_row in zip(gt_data.itertuples(), pred_data.itertuples()):
        if pred_row.empty == True:
            if pd.notna(gt_row.payment_method):  # 确保有补全值的记录
                # 判断补全值是否与最常见支付方式一致
                if pred_row.payment_method == most_common_method:
                    correct_count += 1
            total_count += 1

    # 计算准确度
    accuracy = correct_count / total_count if total_count > 0 else 0.0
    return accuracy

def get_gt():
    current_dir = Path(__file__).resolve().parent
    expected_dir = (current_dir / "expected").resolve()
    csv_files = list(expected_dir.glob("*.csv"))
    if not csv_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")
    return csv_files[0]

import json

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate the accuracy of the missing payment_method completion.")
    parser.add_argument("-o", "--output", required=True, help="Predicted CSV file path")
    
    args = parser.parse_args()
    
    # 读取GT文件和预测文件
    gt_file = get_gt()
    pred_file = args.output

    # 计算准确度
    accuracy = evaluate(gt_file, pred_file)
    print(json.dumps({"eval_score": f"{accuracy:.4f}"}))
