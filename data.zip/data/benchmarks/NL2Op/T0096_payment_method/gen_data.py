import pandas as pd
import numpy as np
import random
from pathlib import Path

# 构建GT数据
def generate_gt_data():
    # 创建 GT 数据：没有缺失值
    data = {
        "transaction_id": [f"txn_{i}" for i in range(1, 101)],
        "payment_status": np.random.choice(["成功", "失败", "处理中"], size=100, p=[0.6, 0.3, 0.1]),
        "payment_method": np.random.choice(["信用卡", "支付宝", "微信", "银行转账"], size=100)
    }
    return pd.DataFrame(data)

# 引入缺失值并添加 empty 标记
def introduce_missing_values(df, missing_ratio=0.2):
    df_missing = df.copy()
    num_missing = int(len(df) * missing_ratio)

    # 随机选择需要缺失的记录
    missing_indices = np.random.choice(df.index, num_missing, replace=False)
    df_missing.loc[missing_indices, "payment_method"] = np.nan

    # 添加 empty 列标识缺失
    df_missing["empty"] = df_missing["payment_method"].isna()
    return df_missing

# 填补缺失的 payment_method
def fill_missing_payment_method(df):
    # 获取支付状态为 "成功" 时最常见的支付方式
    df_filled = df.copy()
    successful_transactions = df[df["payment_status"] == "成功"]
    most_common_method = successful_transactions["payment_method"].mode()[0]
    
    # 对缺失值进行填补
    df_filled["payment_method"] = df["payment_method"].fillna(most_common_method)
    return df_filled

# 保存GT和Raw数据
def save_data(df_gt, df_raw, task_id):
    expected_dir = Path(f"data/benchmarks/NL2Op/{task_id}/expected")
    raw_dir = Path(f"data/benchmarks/NL2Op/{task_id}/raw")

    # 确保目录存在
    expected_dir.mkdir(parents=True, exist_ok=True)
    raw_dir.mkdir(parents=True, exist_ok=True)

    # 保存数据
    df_gt.to_csv(expected_dir / "gt.csv", index=False, encoding="utf-8")
    df_raw.to_csv(raw_dir / "customers.csv", index=False, encoding="utf-8")

if __name__ == "__main__":
    task_id = "T0096_payment_method"  # 可以根据任务的ID进行修改

    # 构建GT数据
    df_gt = generate_gt_data()
    
    # 引入缺失值
    df_raw = introduce_missing_values(df_gt, missing_ratio=0.2)
    # df_gt["empty"] = df_raw["empty"]

    df_filled = fill_missing_payment_method(df_raw)

    # 保存GT和Raw数据
    save_data(df_filled, df_raw, task_id)

    # 对Raw数据中的缺失值进行填补
    
    # df_filled.to_csv(f"data/benchmarks/NL2Op/{task_id}/raw/customers_filled.csv", index=False, encoding="utf-8")
