#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “行指纹 (Sorted-tokens Hash) 去重算子”

评测目标
--------
算子应输出 *去重后的行列表*（.jsonl 或 .csv 均可），
且每行的业务字段内容必须与黄金标准 expected/gt.jsonl 完全一致，
不受「列顺序」以及可能附加的调试列 (row_fingerprint …) 影响。

评测指标
--------
行级 F1
• 先对每行构造 canonical fingerprint ：
    ① 排序所有字段名  
    ② 拼接为  "col=value"  
    ③ 使用 “|” 连接成长字符串（无需再做 SHA-1）  
   - 若字段名为 "row_fingerprint" 则忽略  
• TP  : 预测 fingerprint ∈ GT fingerprint 集合  
• FP  : 预测 fingerprint ∉ GT  或 同一 fingerprint 重复出现  
• FN  : GT 中缺失的 fingerprint
最终输出到 stdout 仅一行 JSON：{"eval_score": "<score>"}

用法
----
python eval.py -o /path/to/your_output.{jsonl|csv}
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from hashlib import sha1
from pathlib import Path
from typing import Any, Dict, List, Set

# ────────────────────────── 常量 ──────────────────────────
GT_PATH = Path(__file__).parent / "expected" / "gt.jsonl"
IGNORED_COLS = {"row_fingerprint"}           # 评测时会丢弃的列名


# ────────────────────────── 工具 ──────────────────────────
def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open(encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                raise ValueError(f"{path}:{lineno} 不是合法 JSON: {e}") from e
    if not rows:
        raise ValueError(f"{path} 为空文件")
    return rows


def read_csv(path: Path) -> List[Dict[str, Any]]:
    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        rows = [dict(r) for r in reader]
    if not rows:
        raise ValueError(f"{path} 为空文件")
    return rows


def load_rows(path: Path) -> List[Dict[str, Any]]:
    if path.suffix.lower() == ".jsonl":
        return read_jsonl(path)
    if path.suffix.lower() == ".csv":
        return read_csv(path)
    raise ValueError(f"仅支持 .jsonl / .csv，收到 {path.name}")


def canonical_fingerprint(row: Dict[str, Any]) -> str:
    """
    根据『列名排序 + "k=v" 拼接』生成可比对的 fingerprint。
    不再做哈希，避免不同实现导致的大小写 / 编码差异。
    """
    items = [
        f"{k}={str(v).strip()}"
        for k, v in row.items()
        if k not in IGNORED_COLS
    ]
    items.sort()  # 列名排序
    return "|".join(items)


# ────────────────────────── 评分 ──────────────────────────
def compute_f1(pred_rows: List[Dict[str, Any]]) -> float:
    # 读取并构造 GT 指纹集合
    gt_rows = read_jsonl(GT_PATH)
    gt_fps: Set[str] = {canonical_fingerprint(r) for r in gt_rows}

    # 预测集指纹
    seen_pred: Set[str] = set()
    tp = 0
    fp = 0

    for row in pred_rows:
        fp_str = canonical_fingerprint(row)
        # 重复行 → FP
        if fp_str in seen_pred:
            fp += 1
            continue
        seen_pred.add(fp_str)

        if fp_str in gt_fps:
            tp += 1
        else:
            fp += 1

    fn = len(gt_fps) - tp

    if tp == 0 and (fp > 0 or fn > 0):
        return 0.0
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


# ────────────────────────── 主入口 ──────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate Sorted-tokens Hash deduplication output")
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Path to operator output (.jsonl / .csv)",
    )
    args = parser.parse_args()

    out_path = Path(args.output)
    if not out_path.exists():
        print(f"文件不存在: {out_path}", file=sys.stderr)
        sys.exit(1)

    pred_rows = load_rows(out_path)
    score = compute_f1(pred_rows)

    print(json.dumps({"eval_score": f"{score:.4f}"}))


if __name__ == "__main__":
    main()