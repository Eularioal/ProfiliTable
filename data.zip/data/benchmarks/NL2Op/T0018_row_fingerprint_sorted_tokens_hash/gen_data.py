#!/usr/bin/env python3
"""
生成 raw/customers.(jsonl|csv) 以验证“行指纹(列排序无关)去重”算子
"""
import json, random, csv, pathlib, itertools, os

BASE_DIR = pathlib.Path(__file__).resolve().parent
EXPECTED = BASE_DIR / "expected"
RAW       = BASE_DIR / "raw"
RAW.mkdir(exist_ok=True)

GT_JSON = EXPECTED / "gt.jsonl"
GT_CSV  = EXPECTED / "gt.csv"

RAW_JSON = RAW / "customers.jsonl"
RAW_CSV  = RAW / "customers.csv"

# 读取 GT
with GT_JSON.open() as f:
    gt_rows = [json.loads(l) for l in f]

# 1. 写入原始顺序的 100 行
raw_rows = list(gt_rows)

# 2. 随机挑 30% 的行 → 生成“列顺序随机”重复副本 1~3 份
dup_candidates = random.sample(gt_rows, k=int(len(gt_rows)*0.3))
for row in dup_candidates:
    copies = random.randint(1, 3)
    for _ in range(copies):
        shuffled_items = list(row.items())
        random.shuffle(shuffled_items)          # 打乱列顺序
        raw_rows.append(dict(shuffled_items))   # id 相同，值相同，只是顺序不同

# 3. 再造一些完全相同的行（保持顺序不变）
for row in random.sample(gt_rows, k=10):
    raw_rows.append(row)

# 4. 额外脏：把 10 行 email 末尾随机大小写
for row in random.sample(raw_rows, k=10):
    row["email"] = row["email"].upper() if random.random() < 0.5 else row["email"].lower()

# -- 输出 JSONL ---------------------------------------------------------------
with RAW_JSON.open("w") as f:
    for r in raw_rows:
        json.dump(r, f, ensure_ascii=False)
        f.write("\n")

# -- 输出 CSV ------------------------------------------------------------------
csv_columns = ["id","first_name","last_name","city","email"]
with RAW_CSV.open("w", newline='') as f:
    writer = csv.DictWriter(f, fieldnames=csv_columns)
    writer.writeheader()
    for r in raw_rows:
        writer.writerow(r)

print(f"✅ 生成完成：{len(raw_rows)} 行 (含重复)")
print(f"  • {RAW_JSON.relative_to(BASE_DIR)}")
print(f"  • {RAW_CSV.relative_to(BASE_DIR)}")