import json
import random
import os
from utils.llm_serving import LLMServing

# 每个主题生成 per_topic 条英文段落
def generate_english_texts(topics, per_topic=10):
    llm = LLMServing()
    
    user_inputs = []
    topic_labels = []

    for topic in topics:
        for _ in range(per_topic):
            user_inputs.append(f"Generate a short English paragraph about {topic}.")
            topic_labels.append(topic)
    
    system_prompt = "You are an AI that writes fluent English paragraphs."
    results = llm.generate_from_input(user_inputs, system_prompt)
    
    return [{"text": text, "topic": topic} for text, topic in zip(results, topic_labels)]

# 非英文数据
non_english_texts = [
    "这是一个中文句子，用于测试。",
    "这是另一个中文句子，包含不同的词语。",
    "这个测试用例展示了中文的多样性。",
    "我们可以用中文表达复杂的思想。",
    "中文支持多种语法结构和用法。",
    
    "Este es un texto en español para verificar la detección de idioma.",
    "Este documento contiene una variedad de frases en español.",
    "La lengua española es rica y diversa.",
    "¿Cómo podemos utilizar el español en este experimento?",
    "Las oraciones en español pueden ser muy complejas.",

    "これは日本語の文です。",
    "これは別の日本語の例文です。",
    "日本語の文章は複雑な文法を持っています。",
    "多くの日本人はこのように書きます。",
    "テストのために日本語の文章を使います。",

    "Ceci est une phrase en français.",
    "C'est un autre exemple de texte en français.",
    "La langue française a beaucoup de règles grammaticales.",
    "Nous utilisons le français pour ce test.",
    "Il est important de tester plusieurs langues.",

    "Это предложение на русском языке。",
    "Русский язык использует кириллицу.",
    "Это другой пример русского текста.",
    "Русские предложения могут быть длинными.",
    "Для тестирования важно использовать русский язык.",

    "Dies ist ein deutscher Beispielsatz.",
    "Die deutsche Sprache hat viele zusammengesetzte Wörter.",
    "Wir testen die Spracherkennung mit Deutsch.",
    "Das ist ein weiterer deutscher Satz.",
    "Grammatikalisch ist Deutsch sehr anspruchsvoll.",

    "이것은 한국어 문장입니다.",
    "한국어는 고유한 문법 체계를 가지고 있습니다.",
    "이 문장은 한국어 감지를 테스트하기 위한 것입니다.",
    "우리는 다양한 한국어 문장을 사용할 수 있습니다.",
    "이 테스트는 다국어 인식을 포함합니다.",

    "هذا نص باللغة العربية لاختبار الكشف عن اللغة.",
    "اللغة العربية تكتب من اليمين إلى اليسار.",
    "تحتوي العربية على تراكيب نحوية معقدة.",
    "نستخدم هذا النص لتجربة العربية.",
    "اللغة العربية غنية بالمفردات.",

    "यह एक हिंदी वाक्य है, जो परीक्षण के लिए उपयोग किया जाता है।",
    "हिंदी में कई प्रकार की वाक्य संरचनाएँ होती हैं।",
    "यह उदाहरण हिंदी भाषा की पहचान के लिए है।",
    "हिंदी भारत की प्रमुख भाषाओं में से एक है।",
    "हिंदी में कविता और साहित्य की समृद्ध परंपरा है।",

    "นี่คือประโยคภาษาไทยสำหรับทดสอบการตรวจจับภาษา",
    "ภาษาไทยมีโครงสร้างประโยคที่แตกต่างจากภาษาอื่น",
    "นี่เป็นอีกตัวอย่างหนึ่งในภาษาไทย",
    "การทดสอบนี้ใช้ภาษาไทยเพื่อความหลากหลาย",
    "ภาษาไทยเป็นภาษาทางการของประเทศไทย",

    "Bu, dil algılama testi için Türkçe bir cümledir.",
    "Türkçe, eklemeli bir dildir.",
    "Bu metin Türkçe dil tanımayı test etmek içindir.",
    "Türkçede cümle yapısı esnektir.",
    "Bu örnekler çeşitli Türkçe cümleler içerir.",

    "Αυτή είναι μια ελληνική πρόταση για δοκιμή.",
    "Η ελληνική γλώσσα έχει αρχαία ιστορία.",
    "Αυτό το κείμενο είναι στα ελληνικά.",
    "Η αναγνώριση της γλώσσας περιλαμβάνει και τα ελληνικά.",
    "Χρησιμοποιούμε τα ελληνικά για να δοκιμάσουμε τη λειτουργία.",

    "这是用粤语写的一句话，用于检测语言。",
    "呢句係廣東話嘅例子。",
    "粤语与普通话有很大区别。",
    "好多香港人都讲粤语。",
    "粤语同样可以用于写作和测试。",
    "विज्ञान और तकनीक के क्षेत्र में हिंदी का उपयोग बढ़ रहा है।",  # Hindi
    "日本では春に桜の花が咲きます。",  # Japanese
    "在中国，春节是一年中最重要的节日。",  # Chinese
    "Los niños juegan en el parque durante el verano.",  # Spanish
    "Les montagnes sont magnifiques en hiver.",  # French
    "Русская литература известна во всем мире.",  # Russian
    "독립운동은 한국 역사에서 중요한 부분입니다.",  # Korean
    "القراءة مفيدة لتنمية المهارات اللغوية.",  # Arabic
    "ภาษาเวียดนามใช้ตัวอักษรละตินที่ดัดแปลงแล้ว",  # Thai
    "Ich liebe es, neue Sprachen zu lernen.",  # German
    "Το καλοκαίρι στην Ελλάδα είναι πολύ ζεστό.",  # Greek
    "C'est l'heure du déjeuner à Paris.",  # French
    "Este computador não está funcionando corretamente.",  # Portuguese
    "Я люблю гулять по парку вечером.",  # Russian
    "這部電影非常感人，我哭了好幾次。",  # Chinese Traditional
]


# 写入 JSONL
def write_jsonl(path, items):
    with open(path, "w", encoding="utf-8") as f:
        for item in items:
            json.dump(item, f, ensure_ascii=False)
            f.write("\n")

def main():
    os.makedirs("data/benchmarks/NL2Op/T0002/raw", exist_ok=True)
    os.makedirs("data/benchmarks/NL2Op/T0002/expected", exist_ok=True)

    # 合成英文记录
    topics = [
        "climate change", "artificial intelligence", "the future of education",
        "space exploration", "mental health awareness", "renewable energy",
        "ancient civilizations", "global economics", "ocean pollution", "quantum computing"
    ]
    english_entries = generate_english_texts(topics, per_topic=2)  # 10×10=100条

    # 构造非英文记录
    non_english_entries = [{"text": text} for text in non_english_texts]

    # 合并并打乱（此时还未加 id）
    raw_entries = english_entries + non_english_entries
    random.shuffle(raw_entries)

    # 加 id 字段
    for idx, entry in enumerate(raw_entries):
        entry["id"] = idx

    # 写入原始文件（包含英文和非英文）
    write_jsonl("data/benchmarks/NL2Op/T0002/raw/customers.jsonl", raw_entries)

    # 过滤英文记录（原始数据中存在 topic 字段即可判断是英文）
    expected_entries = [entry for entry in raw_entries if "topic" in entry]
    write_jsonl("data/benchmarks/NL2Op/T0002/expected/gt.jsonl", expected_entries)

    print("✅ Data generation complete. Files saved to raw/input.jsonl and expected/output.jsonl.")

if __name__ == "__main__":
    main()
