#!/usr/bin/env python3
# gen_data.py
# ------------------------------------------------------------
# 生成两份 CSV：
#   1. raw/customers.csv               ─ 原始数据
#   2. expected/gt.csv                 ─ 拆分后的期望结果
# ------------------------------------------------------------

import csv
import random
import re
import sys
from pathlib import Path

try:
    from faker import Faker
except ImportError:
    sys.exit("请先运行:  pip install faker")

fake = Faker("en_US")

# ------------------------------------------------------------
# 配置
# ------------------------------------------------------------

TOTAL_ROWS    = 120                       # > 100  行
SOURCE_COL    = "full_name"
NEW_COLS      = ["first_name", "last_name"]
SPLIT_REGEX   = r"(\w+)\s+(\w+)"          # 与算子保持一致

RAW_DIR       = Path("raw")
EXP_DIR       = Path("expected")
RAW_DIR.mkdir(exist_ok=True)
EXP_DIR.mkdir(exist_ok=True)

# ------------------------------------------------------------
# 造 raw 数据
# ------------------------------------------------------------

def make_raw_records(n: int):
    """返回 length==n 的 dict 列表"""
    records = []
    for idx in range(1, n + 1):
        rtype = random.choices(
            ["normal", "single", "cn", "multi_space"],
            weights=[0.7, 0.1, 0.1, 0.1],
        )[0]

        if rtype == "normal":
            name = fake.name()                       # John Doe / John A. Doe …
        elif rtype == "single":
            name = fake.first_name()                 # 只有一个单词 → 匹配失败
        elif rtype == "cn":
            name = random.choice(
                ["张伟", "王芳", "李秀英", "刘强", "陈磊"]
            )                                        # 无空格 → 匹配失败
        else:  # multi_space
            parts = fake.name().split()
            if len(parts) < 2:
                parts.append(fake.last_name())
            name = f"{parts[0]}     {parts[1]}"      # 多空格 → 仍应匹配成功

        records.append(
            {
                "id": idx,
                SOURCE_COL: name,
            }
        )
    return records


def write_csv(path: Path, rows, fieldnames):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


# ------------------------------------------------------------
# 依据正则拆分新列，生成 ground-truth
# ------------------------------------------------------------

def split_cols(val: str):
    m = re.match(SPLIT_REGEX, val.strip())
    if m:
        return list(m.groups())
    return [""] * len(NEW_COLS)


def build_gt_rows(raw_rows):
    gt = []
    for r in raw_rows:
        first, last = split_cols(r[SOURCE_COL])
        gt.append(
            {
                **r,
                NEW_COLS[0]: first,
                NEW_COLS[1]: last,
            }
        )
    return gt


# ------------------------------------------------------------
# 主流程
# ------------------------------------------------------------

def main():
    raw_rows = make_raw_records(TOTAL_ROWS)
    gt_rows  = build_gt_rows(raw_rows)

    raw_csv_path = RAW_DIR / "customers.csv"
    gt_csv_path  = EXP_DIR / "gt.csv"

    write_csv(raw_csv_path, raw_rows, fieldnames=["id", SOURCE_COL])
    write_csv(gt_csv_path,  gt_rows,  fieldnames=["id", SOURCE_COL] + NEW_COLS)

    print(f"[OK] raw  CSV written → {raw_csv_path}")
    print(f"[OK] gt   CSV written → {gt_csv_path}")


if __name__ == "__main__":
    main()