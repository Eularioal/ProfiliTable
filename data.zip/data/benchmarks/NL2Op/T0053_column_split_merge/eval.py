#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 正则拆分算子 · Evaluation
==================================

数据目录
└─ T00XX_regex_split/
   ├─ expected/gt.csv          # 真值
   ├─ raw/customers.csv
   └─ eval.py                  # 本脚本

算子任务
    • 读取 raw/customers.csv
    • 将 full_name 按正则 (\w+)\s+(\w+) 拆成 first_name / last_name
    • 保留原列，生成结果 CSV

评测规则
    1. 输出文件必须为 CSV，含表头。
    2. 主键 id 集合必须与 gt.csv 完全一致，无重复键。
    3. 比对列：
         id, full_name, first_name, last_name
       这些列的值需与 gt.csv 完全相同
       （允许输出包含额外列，行顺序不计）。
    4. 若违反任一条，得分 0.0；全部满足得分 1.0。

使用
    python eval.py -o path/to/output.csv
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Dict, List, Tuple

# ──────────────── 配置 ────────────────
PRIMARY_KEY     = ("id",)
COMPARE_COLUMNS = ["id", "full_name", "first_name", "last_name"]

ROOT_DIR        = Path(__file__).resolve().parent
GT_PATH         = ROOT_DIR / "expected" / "gt.csv"

# ──────────────── IO ────────────────
def load_csv(path: Path) -> List[Dict[str, str]]:
    """读取 CSV 并返回行列表（每行保持字符串）。"""
    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"{path} 缺少表头")
        rows: List[Dict[str, str]] = [dict(r) for r in reader]
    return rows


def pk(row: Dict[str, str]) -> Tuple[str, ...]:
    try:
        return tuple(row[k] for k in PRIMARY_KEY)
    except KeyError as exc:
        raise KeyError(f"缺少主键字段 {exc} 于行: {row}") from exc


def to_pk_map(rows: List[Dict[str, str]]) -> Dict[Tuple[str, ...], Dict[str, str]]:
    """构建 {pk → row}，若出现重复键则抛异常。"""
    m: Dict[Tuple[str, ...], Dict[str, str]] = {}
    for r in rows:
        k = pk(r)
        if k in m:
            raise ValueError(f"重复主键 {k}")
        m[k] = r
    return m


# ──────────────── 评测逻辑 ────────────────
def evaluate(gt_rows: List[Dict[str, str]],
             pred_rows: List[Dict[str, str]]) -> float:
    try:
        gt_map   = to_pk_map(gt_rows)
        pred_map = to_pk_map(pred_rows)
    except ValueError as exc:
        print(f"[eval] {exc}", file=sys.stderr)
        return 0.0

    # 主键集合必须一致
    if set(gt_map) != set(pred_map):
        missing = set(gt_map) - set(pred_map)
        extra   = set(pred_map) - set(gt_map)
        if missing:
            print(f"[eval] 缺少主键: {missing}", file=sys.stderr)
        if extra:
            print(f"[eval] 多余主键: {extra}", file=sys.stderr)
        return 0.0

    # 字段值比较（仅关注 COMPARE_COLUMNS）
    for k in gt_map:
        g = gt_map[k]
        p = pred_map[k]
        for col in COMPARE_COLUMNS:
            if p.get(col, "") != g[col]:
                print(f"[eval] 主键{k} 列{col} 不一致 gt={g[col]!r} pred={p.get(col,'')!r}",
                      file=sys.stderr)
                return 0.0
    return 1.0


# ──────────────── CLI ────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate regex-split operator")
    parser.add_argument("-o", "--output", required=True,
                        help="CSV file produced by operator")
    args = parser.parse_args()

    pred_path = Path(args.output)
    if not pred_path.exists():
        print(f"文件不存在: {pred_path}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)

    try:
        gt_rows   = load_csv(GT_PATH)
        pred_rows = load_csv(pred_path)
    except Exception as exc:
        print(f"[eval] 读取 CSV 失败: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)

    score = evaluate(gt_rows, pred_rows)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        # 捕获任何未预料错误，返回 0 分
        print(f"[eval] 评测异常: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)