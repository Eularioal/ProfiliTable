import json
from pathlib import Path
from utils.llm_serving import LLMServing

Task_id = "T0013"

# 路径
gt_path = Path(f"data/benchmarks/NL2Op/{Task_id}_/expected/gt.jsonl")
raw_path = Path(f"data/benchmarks/NL2Op/{Task_id}_/raw/customers.jsonl")

gt_path.parent.mkdir(parents=True, exist_ok=True)
raw_path.parent.mkdir(parents=True, exist_ok=True)

llm = LLMServing()

def count_sentences(text):
    # 简单用标点切分句子，后续可换更强的分句库
    import re
    sentences = re.split(r'[.!?]+', text.strip())
    # 过滤空句子
    return len([s for s in sentences if s.strip()])

def generate_gold_data(num_samples=20):
    topics = [
        "technology", "education", "health", "finance", "sports",
        "travel", "science", "environment", "history", "culture"
    ]
    per_topic = num_samples // len(topics)
    user_inputs = [f"Write a formal paragraph about {topic} with 5 to 10 sentences." for topic in topics for _ in range(per_topic)]
    system_prompt = "You are an AI that writes formal English paragraphs containing between 5 and 10 sentences."

    outputs = llm.generate_from_input(user_inputs, system_prompt)

    samples = []
    id_counter = 0
    for text in outputs:
        sent_count = count_sentences(text)
        if 5 <= sent_count <= 10:
            samples.append({"id": f"gt_{id_counter}", "text": text})
            id_counter += 1
        if len(samples) >= num_samples:
            break
    return samples

def generate_dirty_data(num_samples=80):
    # 生成部分句子数不合规（<5 或 >10）的“脏数据”
    topics = [
        "technology", "education", "health", "finance", "sports",
        "travel", "science", "environment", "history", "culture"
    ]
    per_topic = num_samples // len(topics)

    user_inputs = []
    # 生成句子过少 (<5)
    for topic in topics:
        user_inputs += [f"Write a formal paragraph about {topic} with 1 to 4 sentences." for _ in range(per_topic // 2)]
    # 生成句子过多 (>10)
    for topic in topics:
        user_inputs += [f"Write a formal paragraph about {topic} with 11 to 15 sentences." for _ in range(per_topic // 2)]

    system_prompt = "You are an AI that writes formal English paragraphs with specified number of sentences."

    outputs = llm.generate_from_input(user_inputs, system_prompt)

    samples = []
    id_counter = 0
    for text in outputs:
        sent_count = count_sentences(text)
        if sent_count < 5 or sent_count > 10:
            samples.append({"id": f"dirty_{id_counter}", "text": text})
            id_counter += 1
        if len(samples) >= num_samples:
            break
    return samples

def save_jsonl(data, path: Path):
    with path.open("w", encoding="utf-8") as f:
        for entry in data:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

if __name__ == "__main__":
    print("Generating gold data (20 samples)...")
    gt_samples = generate_gold_data(20)
    save_jsonl(gt_samples, gt_path)
    print(f"Saved gold data to {gt_path}")

    print("Generating dirty data (80 samples)...")
    dirty_samples = generate_dirty_data(80)
    save_jsonl(dirty_samples, raw_path)
    print(f"Saved dirty data to {raw_path}")
