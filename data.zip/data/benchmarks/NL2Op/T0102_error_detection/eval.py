#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― 评测 “基于坐标的稀疏错误检测” 算子

使用方法
--------
python eval.py -o /path/to/your_output.csv

说明
----
1. 基准文件固定为同级目录 expected/gt.csv
2. -o 指向错误检测算子的输出CSV文件（预测结果）
3. CSV格式要求：第一列为错误位置（如 "3-5"），第二列为错误类型
4. 数据清洗规则：坐标/错误类型去空格，同一坐标仅保留第一条记录
5. 评测指标：Weighted Precision/Recall/F1-score（零除法时指标为0）
6. 指标范围 ∈ [0,1]，依次打印 Precision、Recall、F1-score（保留4位小数）
"""

from __future__ import annotations
import argparse
import pandas as pd
from sklearn.metrics import precision_recall_fscore_support
from pathlib import Path
from typing import Tuple, Optional

# ------------------------------------------------------------------ 常量
GT_PATH = Path(__file__).parent / "expected" / "gt.csv"  # 固定基准文件路径
NO_ERROR_LABEL = "NORMAL"  # 无错误标签（背景类）

# ------------------------------------------------------------------ 工具函数
def read_and_normalize_error_csv(path: str | Path) -> Optional[pd.DataFrame]:
    """
    读取错误检测CSV文件并完成数据规范化
    步骤：读取文件→保留前两列→重命名列→去空格→去重
    参数：path - CSV文件路径
    返回：规范化后的DataFrame（列：pos, type），读取失败返回None
    """
    # 1. 读取数据
    try:
        df = pd.read_csv(path)
    except Exception as e:
        print(f"文件读取失败: {e}")
        return None

    # 2. 规范化列名 (强制重命名，确保 merge 键名一致)
    df = df.iloc[:, [0, 1]]
    df.columns = ['pos', 'type']

    # 3. 数据清洗：去除空格严格匹配
    df['pos'] = df['pos'].astype(str).str.strip()
    df['type'] = df['type'].astype(str).str.strip()

    # 4. 去除重复项 (防止同一个坐标多条记录导致评测报错)
    df = df.drop_duplicates(subset=['pos'], keep='first')

    return df

def merge_and_fill_labels(df_gt: pd.DataFrame, df_pred: pd.DataFrame) -> Tuple[pd.Series, pd.Series]:
    """
    外连接GT和Pred数据，并填充无错误标签
    逻辑：GT有Pred无→Pred标签填NORMAL；GT无Pred有→GT标签填NORMAL
    返回：y_true, y_pred 标签序列（pd.Series类型）
    """
    # 1. 核心步骤：外连接 (Outer Join) 取并集
    merged = pd.merge(
        df_gt.rename(columns={'type': 'true_type'}),
        df_pred.rename(columns={'type': 'pred_type'}),
        on='pos',
        how='outer'
    )

    # 2. 填充无错误标签
    merged['true_type'] = merged['true_type'].fillna(NO_ERROR_LABEL)
    merged['pred_type'] = merged['pred_type'].fillna(NO_ERROR_LABEL)

    return merged['true_type'], merged['pred_type']

# ------------------------------------------------------------------ 评分
def compute_error_detection_metrics(y_true: pd.Series, y_pred: pd.Series) -> Tuple[float, float, float]:
    """
    计算稀疏错误检测的加权Precision、Recall、F1-score
    参数：y_true - 真实标签，y_pred - 预测标签
    返回：(precision, recall, f1) 均保留4位小数
    """
    p, r, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average='weighted', zero_division=0
    )
    return round(p, 4), round(r, 4), round(f1, 4)

# ------------------------------------------------------------------ 主流程
def main() -> None:
    # 解析命令行参数（仅保留-o/--output指定预测文件路径）
    parser = argparse.ArgumentParser(description="Evaluate sparse error detection output")
    parser.add_argument(
        "-o", "--output", required=True,
        help="Path to CSV produced by your error detection operator (prediction result)"
    )
    args = parser.parse_args()

    # 1. 读取并规范化基准文件（GT）
    if not GT_PATH.exists():
        print(f"错误：基准文件不存在，请先创建 {GT_PATH}")
        return
    
    df_gt = read_and_normalize_error_csv(GT_PATH)
    if df_gt is None:
        return

    # 2. 读取并规范化预测文件（Pred）
    pred_path = Path(args.output)
    if not pred_path.exists():
        print(f"错误：预测文件不存在 {pred_path}")
        return
    
    df_pred = read_and_normalize_error_csv(pred_path)
    if df_pred is None:
        return

    # 3. 外连接并填充标签
    y_true, y_pred = merge_and_fill_labels(df_gt, df_pred)

    # 4. 计算评测指标
    precision, recall, f1 = compute_error_detection_metrics(y_true, y_pred)

    # 5. 输出结果
    print({"eval_score": f"{f1:.4f}"})

if __name__ == "__main__":
    main()