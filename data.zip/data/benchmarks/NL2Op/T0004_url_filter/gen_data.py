import json
import os
import random
from utils.llm_serving import LLMServing

def contains_url(text):
    text_lower = text.lower()
    return "http://" in text_lower or "https://" in text_lower or "www." in text_lower

def generate_clean_texts(topics, per_topic=5):
    llm = LLMServing()
    user_inputs = [f"Write a short sentence about {topic} without any URLs or links." for topic in topics for _ in range(per_topic)]
    system_prompt = "You are an AI that writes short English sentences without any URLs or links."
    results = llm.generate_from_input(user_inputs, system_prompt)

    entries = []
    for idx, (text, prompt) in enumerate(zip(results, user_inputs)):
        topic = prompt.split("about")[1].split("without")[0].strip()
        entries.append({
            "id": idx,
            "text": text,
            "topic": topic
        })
    return entries

def generate_invalid_entries(start_id=100):
    raw_invalid = [
        ("Learn more at https://example.com.", "education"),
        ("Visit our site: http://coolnews.org", "news"),
        ("Check out www.travelblog.net for more.", "travel"),
        ("Get support at https://helpdesk.company.com", "support"),
        ("Our homepage is http://home.example.org", "about"),
        ("Book now at www.bookingportal.com", "travel"),
        ("For more info, go to https://university.edu/faq", "education"),
        ("Follow updates on http://blog.techspace.net", "technology"),
        ("Apply here: https://jobs.company.io", "career"),
        ("Click here: www.salespage.biz/promo", "marketing"),
        ("Submit feedback at http://feedback.form.io", "feedback"),
        ("Official site: www.government.gov/info", "politics"),
        ("Try it online: https://demo.app.test", "software"),
        ("Browse more at http://archive.web.org", "history"),
        ("Reach us at https://contact.service.com", "contact"),
        ("Learn more at https://example.com.", "education"),
        ("Visit our site: http://coolnews.org", "news"),
        ("Check out www.travelblog.net for more.", "travel"),
        ("Get support at https://helpdesk.company.com", "support"),
        ("Our homepage is http://home.example.org", "about"),
        ("Book now at www.bookingportal.com", "travel"),
        ("For more info, go to https://university.edu/faq", "education"),
        ("Follow updates on http://blog.techspace.net", "technology"),
        ("Apply here: https://jobs.company.io", "career"),
        ("Click here: www.salespage.biz/promo", "marketing"),
        ("Submit feedback at http://feedback.form.io", "feedback"),
        ("Official site: www.government.gov/info", "politics"),
        ("Try it online: https://demo.app.test", "software"),
        ("Browse more at http://archive.web.org", "history"),
        ("Reach us at https://contact.service.com", "contact"),

        ("Details at https://sciencehub.org/articles", "education"),
        ("Watch live on www.sportschannel.tv", "sports"),
        ("Live scores: http://matchupdates.net", "sports"),
        ("Read the blog: www.fashiontrends.io", "fashion"),
        ("Get recipes at https://foodie.site", "food"),
        ("Donate now at http://charity.gives", "nonprofit"),
        ("Volunteer at www.helptoday.org", "nonprofit"),
        ("Find a mentor at https://careerboost.net", "career"),
        ("Explore courses at http://learnhub.co", "education"),
        ("Report bugs at www.issue-tracker.dev", "software"),
        
        ("Contact sales: https://salesportal.biz", "sales"),
        ("Streaming now: http://musicflow.fm", "music"),
        ("Get the app: www.mobileapps.store", "technology"),
        ("User guide: https://docs.platform.com", "documentation"),
        ("FAQ: http://questions.answers.org", "support"),
        ("Breaking news: www.latestdaily.com", "news"),
        ("Join our forum at https://community.talk", "community"),
        ("View photos: http://gallery.imghub.com", "media"),
        ("Free tools at www.devtools.space", "developer"),
        ("Get your quote: https://insurance.io", "finance"),

        ("Marketplace: http://shoponline.store", "ecommerce"),
        ("Our events: www.conference2025.com", "events"),
        ("Product tour: https://productdemo.com", "software"),
        ("Pre-order now at http://prelaunch.biz", "marketing"),
        ("Contact editor at www.pressroom.org", "media"),
        ("Pet adoption info: https://adopt.petplace.net", "animal"),
        ("Webinar access: http://training.webinars.live", "education"),
        ("Investor info: www.stocksdata.pro", "finance"),
        ("Pay your bill: https://pay.portal.com", "billing"),
        ("Software download: http://downloads.techhub.org", "software"),

        ("Hackathon details: www.codefest.dev", "developer"),
        ("View rankings: https://leaderboard.games", "gaming"),
        ("Stream your game at http://liveplay.tv", "gaming"),
        ("Health advice: www.clinicguide.org", "health"),
        ("Subscribe now: https://newsletter.media.net", "marketing"),
        ("Check symptoms: http://symptomchecker.health", "health"),
        ("Register here: www.signupevent.org", "events"),
        ("Submit proposal: https://grantportal.gov", "nonprofit"),
        ("Try our calculator: http://financecalc.io", "finance"),
        ("Data explorer: www.opendata.stats", "research"),

        ("Legal info: https://lawresources.net", "legal"),
        ("Online portfolio: http://mywork.design", "portfolio"),
        ("Test API: www.api-sandbox.io", "developer"),
        ("Code examples: https://codebase.dev", "developer"),
        ("View our roadmap: http://roadmap.teamapp.io", "technology"),
        ("Email us: www.contactme.now", "contact"),
        ("Podcast archive: https://episodes.soundsite.fm", "media"),
        ("Weather forecast: http://weatherlive.info", "weather"),
        ("See offers: www.discountzone.shop", "ecommerce"),
        ("Investor call details: https://investornews.biz", "finance"),

        ("Speaker list: http://talks2025.events", "events"),
        ("Read whitepaper: www.researchdocs.ai", "research"),
        ("Start trial: https://freetrial.tech", "software"),
        ("Travel guide: http://destination.travel", "travel"),
        ("Policy info: www.termsnprivacy.com", "legal"),
    ]


    return [
        {"id": start_id + i, "text": text, "topic": topic}
        for i, (text, topic) in enumerate(raw_invalid)
    ]

def write_jsonl(path, entries):
    with open(path, "w", encoding="utf-8") as f:
        for entry in entries:
            json.dump(entry, f, ensure_ascii=False)
            f.write("\n")

def main():
    topics = ["technology", "health", "environment", "science", "sports"]
    clean_entries = generate_clean_texts(topics, per_topic=4)   # 25 条合法
    invalid_entries = generate_invalid_entries()                # 5 条非法

    all_entries = clean_entries + invalid_entries
    random.shuffle(all_entries)

    # 写入 raw/input.jsonl（包含链接的 + 合法数据）
    write_jsonl("data/benchmarks/NL2Op/T0004_/raw/customers.jsonl", all_entries)

    # 写入 expected/output.jsonl（仅保留不含链接的记录）
    expected_entries = [e for e in all_entries if not contains_url(e["text"])]
    write_jsonl("data/benchmarks/NL2Op/T0004_/expected/gt.jsonl", expected_entries)

    print("✅ JSONL data generated for T0004 at raw/input.jsonl and expected/output.jsonl")

if __name__ == "__main__":
    main()
