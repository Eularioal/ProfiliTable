#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eval.py
=======

评测脚本 —— 检查选手是否正确使用三次样条插值填补缺失

调用:
    python eval.py -o <candidate.csv>

成功: {"eval_score":"1.0"}
失败: {"eval_score":"0.0"} 并把原因写到 stderr
"""

from __future__ import annotations

import argparse, json, sys
from pathlib import Path

import numpy as np
import pandas as pd

# ───────── 配置（需与 gen_data.py 保持一致） ─────────
ROOT      = Path(__file__).resolve().parent
RAW_CSV   = ROOT / "raw" / "customers.csv"
GT_CSV    = ROOT / "expected" / "gt.csv"
TIME_COL  = "event_time"
VALUE_COL = "amount"
ATOL      = 1e-8           # 误差容忍
# ────────────────────────────────────────────────


def fail(msg: str, code: int = 1) -> None:
    print(f"[eval] {msg}", file=sys.stderr)
    print(json.dumps({"eval_score": "0.0"}))
    sys.exit(code)


def read_csv(path: Path) -> pd.DataFrame:
    """把空串/NA 视作缺失"""
    return pd.read_csv(path, na_values=["", "NA"])


def evaluate(cand: pd.DataFrame,
             gt:   pd.DataFrame,
             raw:  pd.DataFrame) -> float:
    # 1. 行列一致性
    if cand.shape != gt.shape:
        fail(f"行列数不一致: 期望 {gt.shape}, 实际 {cand.shape}")
    if list(cand.columns) != list(gt.columns):
        fail("列名或顺序与基准不一致")

    # 2. 目标列：无缺失 & 与基准一致
    if cand[VALUE_COL].isna().any():
        fail(f"{VALUE_COL} 仍有缺失")
    diff = np.abs(cand[VALUE_COL].astype(float) - gt[VALUE_COL].astype(float))
    if (diff > ATOL).any():
        fail(f"{VALUE_COL} 与基准不一致（不是三次样条结果）")

    # 3. 其他列不得被修改
    other_cols = [c for c in cand.columns if c != VALUE_COL]
    raw_other  = raw[other_cols].reset_index(drop=True)
    cand_other = cand[other_cols].reset_index(drop=True)

    raw_other[TIME_COL]  = raw_other[TIME_COL].astype(str)
    cand_other[TIME_COL] = cand_other[TIME_COL].astype(str)

    if not cand_other.equals(raw_other):
        fail("非插值列内容被修改")

    return 1.0


def main() -> None:
    ap = argparse.ArgumentParser(description="Evaluate cubic-spline imputation operator")
    ap.add_argument("-o", "--output", required=True, help="candidate CSV file")
    args = ap.parse_args()

    cand_path = Path(args.output)
    if not cand_path.exists():
        fail(f"文件不存在: {cand_path}")

    try:
        raw = read_csv(RAW_CSV)
        gt  = read_csv(GT_CSV)
        cand = read_csv(cand_path)
    except Exception as exc:
        fail(f"读取 CSV 失败: {exc}")

    score = evaluate(cand, gt, raw)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        fail(f"评测脚本异常: {exc}", code=2)