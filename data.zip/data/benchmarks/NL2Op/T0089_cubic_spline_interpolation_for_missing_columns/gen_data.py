#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py
===========

1. 生成 raw/customers.csv（包含缺失值）
2. 使用三次样条插值填补缺失，生成 expected/gt.csv

输出编码：UTF-8 无 BOM
依赖：pandas>=1.5  ，SciPy>=1.10（pandas spline 插值需要）
"""

from pathlib import Path

import numpy as np
import pandas as pd

# --------------------------- 参数区 --------------------------- #
RAW_PATH   = Path("raw/customers.csv")
GT_PATH    = Path("expected/gt.csv")
TIME_COL   = "event_time"
VALUE_COL  = "amount"
N_ROWS     = 10
START_DATE = "2025-01-01"
MISSING_IDX = [2, 5, 8]          # 制造缺失的位置
SPLINE_ORDER = 3                 # 三次样条
# ------------------------------------------------------------- #


def generate_raw() -> pd.DataFrame:
    """构造含缺失值的示例数据集"""
    dates  = pd.date_range(START_DATE, periods=N_ROWS, freq="D")
    amount = np.linspace(10, 65, N_ROWS)          # 10 → 65 线性递增
    amount[MISSING_IDX] = np.nan                  # 指定行缺失
    return pd.DataFrame(
        {"customer_id": range(1, N_ROWS + 1),
         TIME_COL: dates,
         VALUE_COL: amount}
    )


def write_csv(df: pd.DataFrame, path: Path) -> None:
    """写 CSV（UTF-8 无 BOM）"""
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8")   # pandas 默认无 BOM


def spline_interpolate(df: pd.DataFrame) -> pd.DataFrame:
    """按时间排序，对 VALUE_COL 使用三次样条插值"""
    df2 = df.sort_values(TIME_COL).copy()
    df2[VALUE_COL] = df2[VALUE_COL].interpolate(
        method="spline",
        order=SPLINE_ORDER,
        limit_direction="both"
    )
    return df2


def main() -> None:
    # 1. raw
    raw_df = generate_raw()
    write_csv(raw_df, RAW_PATH)
    print(f"✅ raw 数据已写出: {RAW_PATH}")

    # 2. gt
    gt_df = spline_interpolate(raw_df)
    write_csv(gt_df, GT_PATH)
    print(f"✅ 样条插值结果已写出: {GT_PATH}")


if __name__ == "__main__":
    main()