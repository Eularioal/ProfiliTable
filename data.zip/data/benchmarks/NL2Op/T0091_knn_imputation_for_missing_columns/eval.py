#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eval.py
=======

评测脚本 —— 检查选手是否按 KNNImputer(同 gen_data.py) 填补缺失

用法:
    python eval.py -o <candidate.csv>
成功: {"eval_score":"1.0"}
失败: {"eval_score":"0.0"} 并将原因写入 stderr
"""

from __future__ import annotations
import argparse, json, sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT      = Path(__file__).resolve().parent
RAW_CSV   = ROOT / "raw" / "customers.csv"
GT_CSV    = ROOT / "expected" / "gt.csv"
ATOL      = 1e-8               # 数值比较误差

# ────────── 工具 ──────────
def fail(msg: str, code: int = 1) -> None:
    print(f"[eval] {msg}", file=sys.stderr)
    print(json.dumps({"eval_score": "0.0"}))
    sys.exit(code)


def read_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, na_values=["", "NA"])


# ────────── 核心评测 ──────────
def evaluate(cand: pd.DataFrame,
             gt: pd.DataFrame,
             raw: pd.DataFrame) -> float:
    # 1) 行列一致
    if cand.shape != gt.shape:
        fail(f"行列数不一致: 期望 {gt.shape}, 实际 {cand.shape}")
    if list(cand.columns) != list(gt.columns):
        fail("列名或顺序与基准不一致")

    # 2) 缺失位置必须被填补且与 gt 相同
    
    # miss_mask = raw.isna()

    # # 2-a 原缺失处不得再缺失
    # if cand[miss_mask].isna().any().any():
    #     fail("存在未填补的缺失值")

    # # 2-b 原缺失处与 gt 比较
    # diff = np.abs(cand[miss_mask].astype(float) - gt[miss_mask].astype(float))
    # if (diff > ATOL).any().any():
    #     fail("填补结果与基准不一致 (非 KNN 插补)")

    # # 3) 原非缺失位置不得被修改
    # if not cand[~miss_mask].astype(float).equals(raw[~miss_mask].astype(float)):
    #     fail("修改了原本完整的数据")
    
    miss_mask = raw.isna()

    # 2-a 原缺失处不得再缺失
    for col in cand.columns:
        orig_missing_idx = miss_mask[col]
        if cand.loc[orig_missing_idx, col].isna().any():
            fail(f"列 {col} 中存在未填补的缺失值")

    # 2-b 原缺失处与 gt 比较
    for col in cand.columns:
        orig_missing_idx = miss_mask[col]
        diff = (cand.loc[orig_missing_idx, col].astype(float) -
                gt.loc[orig_missing_idx, col].astype(float)).abs()
        if (diff > ATOL).any():
            fail(f"列 {col} 的填补结果与基准不一致 (非 KNN 插补)")

    # 3) 原非缺失位置不得被修改
    for col in cand.columns:
        non_missing_idx = ~miss_mask[col]
        if not cand.loc[non_missing_idx, col].astype(float).equals(
            raw.loc[non_missing_idx, col].astype(float)
        ):
            fail(f"列 {col} 修改了原本完整的数据")

    return 1.0


# ────────── CLI ──────────
def main() -> None:
    ap = argparse.ArgumentParser(description="Evaluate KNN-imputation operator")
    ap.add_argument("-o", "--output", required=True, help="candidate CSV file")
    args = ap.parse_args()

    cand_path = Path(args.output)
    if not cand_path.exists():
        fail(f"文件不存在: {cand_path}")

    try:
        raw = read_csv(RAW_CSV)
        gt  = read_csv(GT_CSV)
        cand = read_csv(cand_path)
    except Exception as exc:
        fail(f"读取 CSV 失败: {exc}")

    score = evaluate(cand, gt, raw)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        fail(f"评测异常: {exc}", code=2)