#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py
===========

1. 生成 raw/customers.csv      —— 含缺失值
2. 使用 KNNImputer 填补缺失   —— 写 expected/gt.csv

编码：UTF-8 无 BOM
依赖：pandas  • numpy  • scikit-learn
"""

from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.impute import KNNImputer

# ────────── 可调整参数 ──────────
RAW_PATH  = Path("raw/customers.csv")
GT_PATH   = Path("expected/gt.csv")
N_ROWS    = 30          # 数据行数
N_NEIGH   = 3           # KNN k 值
RAND_SEED = 42
MISS_RATE = 0.15        # 缺失占比
# ──────────────────────────────

rng = np.random.default_rng(RAND_SEED)


def make_dataset() -> pd.DataFrame:
    """构造含缺失值的数据 (数值列 + 已独热的分类列)"""
    customer_id = np.arange(1, N_ROWS + 1)

    # 数值特征
    age = rng.integers(18, 70, size=N_ROWS).astype(float)
    income = rng.normal(50_000, 15_000, size=N_ROWS)

    # 颜色类别 (one-hot)
    colors = rng.choice(["red", "green", "blue"], size=N_ROWS)
    color_df = pd.get_dummies(colors, prefix="color")  # → 三个 0/1 列

    df = pd.DataFrame(
        {
            "customer_id": customer_id,
            "age": age,
            "income": income,
        }
    ).join(color_df)

    # 制造缺失（除 customer_id 外）
    mask = rng.random(df.shape) < MISS_RATE
    mask[:, 0] = False  # 不给 id 造缺失
    df = df.mask(mask)

    return df


def knn_impute(df: pd.DataFrame) -> pd.DataFrame:
    """对缺失值进行 KNN 插补(id 列除外)"""
    id_col = ["customer_id"]
    feat_cols = [c for c in df.columns if c not in id_col]

    imputer = KNNImputer(n_neighbors=N_NEIGH, weights="uniform")
    imputed = imputer.fit_transform(df[feat_cols])

    df_imputed = pd.concat(
        [df[id_col].reset_index(drop=True),
         pd.DataFrame(imputed, columns=feat_cols)],
        axis=1,
    )
    return df_imputed[df.columns]  # 保持原始列顺序


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8")  # pandas 默认无 BOM


def main() -> None:
    raw_df = make_dataset()
    write_csv(raw_df, RAW_PATH)
    print(f"✅ raw 数据写出: {RAW_PATH}")

    gt_df = knn_impute(raw_df)
    write_csv(gt_df, GT_PATH)
    print(f"✅ KNN 插补结果写出: {GT_PATH}")


if __name__ == "__main__":
    main()