
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
from pathlib import Path


def generate_gt_data(num_records=100):
    """生成GT数据"""
    data = []
    for i in range(num_records):
        record = {
            "record_id": i + 1,
            "timestamp": (datetime.now() - timedelta(days=random.randint(0, 100))).strftime('%Y-%m-%d %H:%M:%S'),
            "sensor_id": f"sensor_{random.randint(1, 10)}",
            "temperature": round(random.uniform(18, 30), 2),
            "humidity": round(random.uniform(30, 80), 2),
            "pressure": round(random.uniform(950, 1050), 2),
            "value": round(random.uniform(1, 100), 2),
            "location": f"Location_{random.randint(1, 5)}",
            "status": "valid",  # 假设所有数据最初都是有效的
            "measurement_unit": "Celsius"
        }
        data.append(record)

    df = pd.DataFrame(data)
    return df


def introduce_missing_values(df, missing_ratio=0.2):
    """仅在temperature列引入缺失值，并添加empty标记"""
    df_copy = df.copy()

    num_missing = int(len(df) * missing_ratio)
    missing_indices_temperature = random.sample(range(5, len(df)), num_missing)  # 从第6条记录开始

    df_copy.loc[missing_indices_temperature, "temperature"] = np.nan

    # 添加empty标记
    df_copy["empty"] = df_copy["temperature"].isna()

    return df_copy


def fill_missing_with_rolling_mean(df, window_size=5):
    """按时间顺序，用最近 window_size 条有效观测的均值填补缺失的 temperature"""
    df_copy = df.copy()
    df_copy["timestamp"] = pd.to_datetime(df_copy["timestamp"])
    df_copy = df_copy.sort_values("timestamp").reset_index(drop=True)

    filled_temps = []
    history = []

    for idx, row in df_copy.iterrows():
        temp = row["temperature"]
        if pd.notna(temp):
            history.append(temp)
            if len(history) > window_size:
                history.pop(0)
            filled_temps.append(temp)
        else:
            if history:  # 用历史均值填充
                filled_value = np.mean(history)
                filled_temps.append(filled_value)
                # history.append(filled_value)
                # if len(history) > window_size:
                #     history.pop(0)
            else:
                filled_temps.append(np.nan)  # 没有历史值时保持 NaN

    df_copy["temperature"] = filled_temps
    return df_copy


def save_data(df, output_path):
    """保存数据为CSV文件"""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False, encoding="utf-8")


def generate_gt_and_dirty_data(gt_output_path, dirty_output_path, num_records=100, missing_ratio=0.2):
    """生成GT数据和带缺失值的脏数据"""
    # 生成原始GT
    gt_df = generate_gt_data(num_records)

    # 生成脏数据（含缺失）
    dirty_df = introduce_missing_values(gt_df, missing_ratio)

    # 生成补全后的GT
    gt_filled_df = fill_missing_with_rolling_mean(dirty_df, window_size=5)

    # 保存
    save_data(gt_filled_df, gt_output_path)
    save_data(dirty_df, dirty_output_path)


if __name__ == "__main__":
    task_id = "T0088_window_avg_imputation"
    gt_output_path = Path(f"data/benchmarks/NL2Op/{task_id}/expected/gt.csv")
    dirty_output_path = Path(f"data/benchmarks/NL2Op/{task_id}/raw/customers.csv")

    generate_gt_and_dirty_data(gt_output_path, dirty_output_path)
    print(f"GT data saved to: {gt_output_path}")
    print(f"Dirty data saved to: {dirty_output_path}")
