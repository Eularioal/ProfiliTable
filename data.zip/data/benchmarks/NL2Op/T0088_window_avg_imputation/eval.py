import pandas as pd
import numpy as np
import argparse
import json
from pathlib import Path

TOLERANCE = 0.01  # 允许误差 ±0.01

def load_csv(path):
    """加载 CSV 文件"""
    return pd.read_csv(path)

def load_jsonl(path):
    """加载 JSONL 文件"""
    data = {}
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            obj = json.loads(line)
            data[obj["id"]] = obj
    return data

def get_gt():
    current_dir = Path(__file__).resolve().parent
    expected_dir = (current_dir / "expected").resolve()
    jsonl_files = list(expected_dir.glob("*.csv"))
    if not jsonl_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")
    return jsonl_files[0]

def evaluate(gt_df, pred_df):
    """对比补全值和最近 5 条有效观测的平均值，只计算 empty 为 True 的记录"""
    correct_count = 0
    total_count = 0

    for i in range(5, len(pred_df)):  # 从第六条记录开始计算
        # 只对 empty 为 True 且 temperature 不为空的记录进行计算
        if pred_df.loc[i, "empty"] == True and pd.notna(pred_df.loc[i, "temperature"]):
            if abs(pred_df.loc[i, "temperature"] - gt_df.loc[i, "temperature"]) <= TOLERANCE:
                correct_count += 1
     
            total_count += 1    

    print(f"total: {total_count}. correct: {correct_count}")
    accuracy = correct_count / total_count if total_count > 0 else 0
    return accuracy

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate temperature completion accuracy.")
    parser.add_argument("-o", "--output", required=True, help="预测结果 CSV 文件路径")
    args = parser.parse_args()

    # 从文件中加载 GT 数据和预测数据
    gt_file = get_gt()  # 这里设置实际 GT 文件路径
    pred_file = args.output

    gt_df = load_csv(gt_file)
    pred_df = load_csv(pred_file)

    score = evaluate(gt_df, pred_df)
    print(json.dumps({"eval_score": f"{score:.4f}"}))
