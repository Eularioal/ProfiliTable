import csv
import random
from datetime import datetime, timedelta
from pathlib import Path
import json

def random_date(start, end):
    delta = end - start
    random_days = random.randint(0, delta.days)
    return (start + timedelta(days=random_days)).strftime("%Y-%m-%d")

def gen_all_data(num=100):
    data = []
    base_start = datetime(2020, 1, 1)
    base_end = datetime(2023, 12, 31)
    for i in range(1, num + 1):
        start_date = random_date(base_start, base_end)
        # end_date 有一定概率是早于 start_date
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        if random.random() < 0.8:  # 80% 脏数据，end_date < start_date
            end_dt = start_dt - timedelta(days=random.randint(1, 30))
        else:
            end_dt = start_dt + timedelta(days=random.randint(0, 365))
        end_date = end_dt.strftime("%Y-%m-%d")

        data.append({
            "id": str(i),
            "policy_id": f"P{i:06d}",
            "insured_name": f"Insured_{i}",
            "start_date": start_date,
            "end_date": end_date,
        })
    return data

def filter_gt(data, gt_num=20):
    # 筛选出end_date >= start_date的记录
    filtered = []
    for rec in data:
        start_dt = datetime.strptime(rec["start_date"], "%Y-%m-%d")
        end_dt = datetime.strptime(rec["end_date"], "%Y-%m-%d")
        if end_dt >= start_dt:
            filtered.append(rec)
    # 取前gt_num条作为GT
    return filtered[:gt_num]

def save_jsonl(data, path):
    with open(path, "w", encoding="utf-8") as f:
        for rec in data:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

def save_csv(data, path):
    keys = data[0].keys()
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(data)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--task_id", type=str, required=True)
    parser.add_argument("--format", choices=["jsonl", "csv"], default="jsonl")
    args = parser.parse_args()

    task_dir = Path(f"data/benchmarks/NL2Op/{args.task_id}_")
    expected_dir = task_dir / "expected"
    raw_dir = task_dir / "raw"
    expected_dir.mkdir(parents=True, exist_ok=True)
    raw_dir.mkdir(parents=True, exist_ok=True)

    all_data = gen_all_data(num=100)
    gt_data = filter_gt(all_data, gt_num=20)

    if args.format == "jsonl":
        save_jsonl(gt_data, expected_dir / "gt.jsonl")
        save_jsonl(all_data, raw_dir / "customers.jsonl")
    else:
        save_csv(gt_data, expected_dir / "gt.csv")
        save_csv(all_data, raw_dir / "customers.csv")

    print(f"生成完成：脏数据共100条，符合要求的GT数据20条")
