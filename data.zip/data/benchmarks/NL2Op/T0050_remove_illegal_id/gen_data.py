import os
import csv
import random
import string
from datetime import datetime, timedelta
# from utils.llm_serving import LLMServing  # Optional

TASK_ID = "T0025"  # 替换为具体 Task_id
BASE_DIR = f"data/benchmarks/NL2Op/{TASK_ID}_"
GT_PATH = os.path.join(BASE_DIR, "expected", "gt.csv")
RAW_PATH = os.path.join(BASE_DIR, "raw", "customers.csv")

os.makedirs(os.path.dirname(GT_PATH), exist_ok=True)
os.makedirs(os.path.dirname(RAW_PATH), exist_ok=True)


def random_account_number(valid=True):
    if valid:
        return ''.join(random.choices(string.digits, k=16))
    else:
        err_type = random.choice(["short", "long", "alpha", "special", "space", "empty"])
        if err_type == "short":
            return ''.join(random.choices(string.digits, k=random.randint(10, 15)))
        elif err_type == "long":
            return ''.join(random.choices(string.digits, k=random.randint(17, 20)))
        elif err_type == "alpha":
            s = ''.join(random.choices(string.digits, k=15))
            pos = random.randint(0, len(s)-1)
            return s[:pos] + random.choice(string.ascii_uppercase) + s[pos:]
        elif err_type == "special":
            s = ''.join(random.choices(string.digits, k=15))
            pos = random.randint(0, len(s)-1)
            return s[:pos] + random.choice("!@#$%^&*") + s[pos:]
        elif err_type == "space":
            s = ''.join(random.choices(string.digits, k=16))
            pos = random.randint(1, len(s)-2)
            return s[:pos] + " " + s[pos:]
        elif err_type == "empty":
            return ""
        else:
            return ''.join(random.choices(string.digits, k=16))

def random_amount():
    return round(random.uniform(1, 10000), 2)

def random_currency():
    return random.choice(["USD", "EUR", "GBP", "JPY", "CNY"])

def random_timestamp():
    start_date = datetime(2020, 1, 1)
    end_date = datetime(2025, 1, 1)
    delta = end_date - start_date
    random_days = random.randint(0, delta.days)
    random_time = timedelta(seconds=random.randint(0, 86399))
    return (start_date + timedelta(days=random_days) + random_time).strftime("%Y-%m-%d %H:%M:%S")

def generate_gt_data(n=20):
    data = []
    for i in range(1, n+1):
        data.append({
            "id": i,
            "transaction_id": f"TX{i:06d}",
            "account_number": random_account_number(valid=True),
            "amount": random_amount(),
            "currency": random_currency(),
            "timestamp": random_timestamp()
        })
    return data

def generate_raw_data(gt_data, total=100, dirty_count=80):
    raw_data = gt_data.copy()
    start_id = len(gt_data) + 1
    for i in range(start_id, total+1):
        raw_data.append({
            "id": i,
            "transaction_id": f"TX{i:06d}",
            "account_number": random_account_number(valid=False),
            "amount": random_amount(),
            "currency": random_currency(),
            "timestamp": random_timestamp()
        })
    random.shuffle(raw_data)
    return raw_data

def save_csv(path, data):
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=data[0].keys())
        writer.writeheader()
        writer.writerows(data)

if __name__ == "__main__":
    gt_data = generate_gt_data(20)
    raw_data = generate_raw_data(gt_data, total=100, dirty_count=80)

    save_csv(GT_PATH, gt_data)
    save_csv(RAW_PATH, raw_data)

    print(f"GT data saved to {GT_PATH}")
    print(f"Raw data saved to {RAW_PATH}")
