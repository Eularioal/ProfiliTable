from pathlib import Path
import json
import random
import re
from utils.llm_serving import LLMServing

TASK_ID = "T0020"
BASE_DIR = Path(f"data/benchmarks/NL2Op/{TASK_ID}_")
RAW_PATH = BASE_DIR / "raw" / "customers.jsonl"
EXPECTED_PATH = BASE_DIR / "expected" / "gt.jsonl"

BASE_DIR.joinpath("raw").mkdir(parents=True, exist_ok=True)
BASE_DIR.joinpath("expected").mkdir(parents=True, exist_ok=True)

# 推荐用于识别邮箱的正则（覆盖常见合法邮箱格式）：
EMAIL_REGEX = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b')

def generate_fake_email():
    users = ["alice", "bob", "user123", "test.user", "contact"]
    domains = ["example.com", "service.net", "domain.org", "mail.co"]
    return f"{random.choice(users)}{random.randint(1,99)}@{random.choice(domains)}"

def mask_email(text: str) -> str:
    return EMAIL_REGEX.sub(lambda m: "*" * len(m.group(0)), text)

def main():
    raw = []
    gt = []

    # 生成 80 条含邮箱的样本
    for i in range(80):
        email = generate_fake_email()
        text = f"请联系邮箱 {email} 获取更多信息。"
        eid = f"clean_{i:03d}"
        raw.append({"id": eid, "text": text})
        gt.append({"id": eid, "text": mask_email(text)})

    # 生成 20 条不含邮箱的样本
    for i in range(20):
        eid = f"dirty_{i:03d}"
        text = f"客户编号 {random.randint(1000,9999)} 的服务记录，不包含邮箱。"
        raw.append({"id": eid, "text": text})
        gt.append({"id": eid, "text": text})

    # 写入文件
    with RAW_PATH.open("w", encoding="utf-8") as f:
        for item in raw:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")
    with EXPECTED_PATH.open("w", encoding="utf-8") as f:
        for item in gt:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")

    print(f"✅ 写入原始数据：{len(raw)} 条 → {RAW_PATH}")
    print(f"✅ 写入 GT 数据：{len(gt)} 条（80 条邮箱被掩码）→ {EXPECTED_PATH}")

if __name__ == "__main__":
    main()
