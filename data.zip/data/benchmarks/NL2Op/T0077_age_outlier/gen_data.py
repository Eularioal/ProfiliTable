import json
import random
from pathlib import Path
import numpy as np

TASK_ID = "T0039_age_outlier"
BASE_DIR = Path(f"data/benchmarks/NL2Op/{TASK_ID}")
RAW_DIR = BASE_DIR / "raw"
EXPECTED_DIR = BASE_DIR / "expected"
RAW_DIR.mkdir(parents=True, exist_ok=True)
EXPECTED_DIR.mkdir(parents=True, exist_ok=True)

MODALITIES = ["CT", "MRI", "X-ray", "Ultrasound"]

def generate_clean_entry(image_id):
    age = int(np.random.normal(loc=50, scale=15))  # 大致成人年龄分布
    age = max(1, min(age, 90))  # 限制范围1-90
    entry = {
        "image_id": image_id,
        "patient_age": age,
        "modality": random.choice(MODALITIES),
        "scan_date": f"2023-{random.randint(1,12):02d}-{random.randint(1,28):02d}",
        "dirty": False
    }
    return entry

def generate_dirty_entry(image_id):
    # 异常年龄小于1岁，含0或者负数，也有极端大数（异常值）
    # 这里以0岁或负数为异常
    abnormal_ages = [0, -1, -5, 150, 200]
    age = random.choice(abnormal_ages)
    entry = {
        "image_id": image_id,
        "patient_age": age,
        "modality": random.choice(MODALITIES),
        "scan_date": f"2023-{random.randint(1,12):02d}-{random.randint(1,28):02d}",
        "dirty": True
    }
    return entry

def main():
    total = 100
    gold_count = 20
    dirty_count = total - gold_count

    clean_entries = [generate_clean_entry(f"IMG_{i:05d}") for i in range(gold_count)]
    dirty_entries = [generate_dirty_entry(f"IMG_{gold_count + i:05d}") for i in range(dirty_count)]

    all_data = clean_entries + dirty_entries
    random.shuffle(all_data)

    raw_path = RAW_DIR / "customers.jsonl"
    with open(raw_path, "w", encoding="utf-8") as f:
        for entry in all_data:
            json.dump(entry, f, ensure_ascii=False)
            f.write("\n")

    # Filtering任务，GT数据只保留干净数据，即patient_age>=1的记录
    expected_path = EXPECTED_DIR / "gt.jsonl"
    with open(expected_path, "w", encoding="utf-8") as f:
        for entry in all_data:
            if not entry["dirty"]:  # 只保留干净数据
                json.dump(entry, f, ensure_ascii=False)
                f.write("\n")

    print(f"Raw data saved to: {raw_path}")
    print(f"GT data saved to: {expected_path}")

if __name__ == "__main__":
    main()
