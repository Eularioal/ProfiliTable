import json
import argparse
def load_jsonl(path):
    entries = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            entries.append(json.loads(line))
    return entries
def evaluate(expected_path, processed_path):
    expected = load_jsonl(expected_path)
    processed = load_jsonl(processed_path)

    # 构造 ID 集合
    expected_ids = set(entry['image_id'] for entry in expected)
    processed_ids = set(entry['image_id'] for entry in processed)

    # 指标计算
    true_positives = len(expected_ids & processed_ids)
    predicted_total = len(processed_ids)
    gold_total = len(expected_ids)

    precision = true_positives / predicted_total if predicted_total > 0 else 0.0
    recall = true_positives / gold_total if gold_total > 0 else 0.0
    f1 = (2 * precision * recall) / (precision + recall) if precision + recall > 0 else 0.0

    # print(f"✅ Eval Result:")
    # print(f"  - True Positives: {true_positives}")
    # print(f"  - Expected Total (Gold): {gold_total}")
    # print(f"  - Predicted Total: {predicted_total}")
    # print(f"  - Precision: {precision:.4f}")
    # print(f"  - Recall:    {recall:.4f}")
    # print(f"  - F1 Score:  {f1:.4f}")

    result = {"eval_score": f"{f1:.4f}"}
    print(result)

def get_gt():
    from pathlib import Path

    # 获取 gen_data.py 所在目录
    current_dir = Path(__file__).resolve().parent

    # 找到 expected 目录
    expected_dir = (current_dir / "./expected").resolve()

    # 查找第一个 .jsonl 文件
    jsonl_files = list(expected_dir.glob("*.jsonl"))

    if not jsonl_files:
        raise FileNotFoundError(f"No .jsonl file found in {expected_dir}")

    # 取第一个文件作为 expected_path
    expected_path = jsonl_files[0]

    return expected_path

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="filter non-english data")
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Path to the deduplicated jsonl produced by your operator",
    )
    args = parser.parse_args()
    expected_path = get_gt()
    processed_path = args.output
    evaluate(expected_path, processed_path)
