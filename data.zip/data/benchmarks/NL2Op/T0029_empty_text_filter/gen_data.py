from pathlib import Path
import json
import random
from datetime import datetime, timedelta

# 路径配置
TASK_ID = "T0019"
BASE_DIR = Path(f"data/benchmarks/NL2Op/{TASK_ID}_")
EXPECTED_PATH = BASE_DIR / "expected" / "gt.jsonl"
RAW_PATH = BASE_DIR / "raw" / "customers.jsonl"

BASE_DIR.joinpath("expected").mkdir(parents=True, exist_ok=True)
BASE_DIR.joinpath("raw").mkdir(parents=True, exist_ok=True)

def generate_valid_cn_id():
    area_code = random.choice(["110101", "310101", "440101", "330101", "510101"])
    birth_date = datetime.now() - timedelta(days=random.randint(18*365, 99*365))
    birth_str = birth_date.strftime("%Y%m%d")
    seq_code = f"{random.randint(100, 999)}"
    checksum = random.choice("0123456789X")
    return f"{area_code}{birth_str}{seq_code}{checksum}"

def mask_id(text, id_number):
    return text.replace(id_number, "*" * len(id_number))

def main():
    raw_data = []
    gt_data = []

    # 1. 构造前 20 条合法身份证数据
    for i in range(20):
        id_number = generate_valid_cn_id()
        text = f"客户身份证号是 {id_number}，请注意保护个人信息。"
        raw_data.append({"id": f"clean_{i:03d}", "text": text})
        gt_data.append({"id": f"clean_{i:03d}", "text": mask_id(text, id_number)})

    # 2. 构造 80 条其他原样保留数据
    for i in range(80):
        if i < 40:
            fake_id = f"{random.randint(100000, 999999)}18000101{random.randint(100, 999)}Z"
            text = f"客户身份证号是 {fake_id}，请审核。"
        elif i < 60:
            text = f"这是客户编号 {random.randint(1000, 9999)} 的服务记录。"
        else:
            text = "客户身份证号为 110101180001017890。"
        sample = {"id": f"dirty_{i:03d}", "text": text}
        raw_data.append(sample)
        gt_data.append(sample)  # 不处理，直接保留

    # 写入文件
    with RAW_PATH.open("w", encoding="utf-8") as f:
        for entry in raw_data:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    with EXPECTED_PATH.open("w", encoding="utf-8") as f:
        for entry in gt_data:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    print(f"✅ RAW 文件写入 {len(raw_data)} 条数据 → {RAW_PATH}")
    print(f"✅ GT 文件写入 {len(gt_data)} 条数据 → {EXPECTED_PATH}")

if __name__ == "__main__":
    main()
