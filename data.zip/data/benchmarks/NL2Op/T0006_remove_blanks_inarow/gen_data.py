import json
import os
import random
import re
from utils.llm_serving import LLMServing

def normalize_spaces(text):
    return re.sub(r"\s+", " ", text).strip()

def generate_clean_texts(topics, per_topic=5):
    llm = LLMServing()
    user_inputs = [f"Write a grammatically correct sentence about {topic}." for topic in topics for _ in range(per_topic)]
    system_prompt = "You are an AI that writes fluent English sentences with clean spacing (no extra spaces)."
    results = llm.generate_from_input(user_inputs, system_prompt)

    entries = []
    for idx, (text, prompt) in enumerate(zip(results, user_inputs)):
        topic = prompt.split("about")[1].strip().strip(".")
        entries.append({
            "id": idx,
            "text": text,
            "topic": topic
        })
    return entries

def generate_dirty_entries(start_id=100):
    raw_dirty = [
        ("This   sentence   has   too    many    spaces.", "spacing"),
        ("Fix   the   formatting   of   this   text.", "format"),
        ("Multiple     spaces    are     not   okay.", "cleaning"),
        ("Extra   spaces  between   words.", "nlp"),
        ("This text  has  some      inconsistent spacing.", "data"),
        
        ("Remove    extra     spaces     now.", "preprocessing"),
        ("Bad     spacing   ruins    readability.", "quality"),
        ("Too    many    spaces     in   this   sentence.", "editor"),
        ("Normalize     the     text    properly.", "text-cleaning"),
        ("Unnecessary   gaps   must   be   removed.", "normalization"),
        
        ("Data    needs    to   be     cleaned   first.", "pipeline"),
        ("Proper     formatting   is     essential.", "standards"),
        ("Avoid    multiple      spaces   in   input.", "guidelines"),
        ("Sentences   like   this   are   messy.", "error"),
        ("Extra     spacing    should     be     avoided.", "correction"),

        ("This   sentence   has   too    many    spaces.", "spacing"),
        ("Fix   the   formatting   of   this   text.", "format"),
        ("Multiple     spaces    are     not   okay.", "cleaning"),
        ("Extra   spaces  between   words.", "nlp"),
        ("This text  has  some      inconsistent spacing.", "data"),
        
        ("Remove    extra     spaces     now.", "preprocessing"),
        ("Bad     spacing   ruins    readability.", "quality"),
        ("Too    many    spaces     in   this   sentence.", "editor"),
        ("Normalize     the     text    properly.", "text-cleaning"),
        ("Unnecessary   gaps   must   be   removed.", "normalization"),
        
        ("Data    needs    to   be     cleaned   first.", "pipeline"),
        ("Proper     formatting   is     essential.", "standards"),
        ("Avoid    multiple      spaces   in   input.", "guidelines"),
        ("Sentences   like   this   are   messy.", "error"),
        ("Extra     spacing    should     be     avoided.", "correction"),

        ("Please    remove    all    extra    spaces.", "request"),
        ("This  text   needs     normalization.", "nlp"),
        ("Extra    white   space   detected.", "detection"),
        ("Incorrect   spacing    is    common.", "issue"),
        ("Watch  out     for   double   spaces.", "warning"),
        
        ("Some   words     are    too    far    apart.", "layout"),
        ("Inconsistent     spacing     everywhere.", "messy"),
        ("Check    for     trailing      spaces.", "cleaning"),
        ("Whitespace   errors    must     be    fixed.", "validation"),
        ("Fix    gaps     between     tokens.", "tokenization"),
        
        ("Text     analysis    begins   with    cleaning.", "preprocessing"),
        ("Even    spacing   improves    clarity.", "style"),
        ("Random   spaces     hurt     models.", "ml"),
        ("There   are   irregular    gaps   here.", "review"),
        ("Don't     let   spacing    ruin    quality.", "editorial"),
        
        ("This    should    be    a    simple    fix.", "task"),
        ("Spacing    issues   affect   alignment.", "visual"),
        ("Normalize     all     whitespace     now.", "rules"),
        ("Handle    spacing    before     training.", "ml"),
        ("Stop     using    five    spaces    randomly.", "warning"),
        
        ("Do     not    allow    double     tabs.", "format"),
        ("Too    much     space     in   this   text.", "error"),
        ("Standardize     the     sentence     spacing.", "standard"),
        ("Train     models     on     clean     data.", "practice"),
        ("Messy   input    slows    down     processing.", "optimization"),
        
        ("Text    with     extra     gaps    is     bad.", "opinion"),
        ("Many     users     forget     about    spacing.", "human-error"),
        ("It    looks    wrong     with     extra     space.", "ux"),
        ("Remove     every    extra     whitespace.", "text"),
        ("Excessive    spacing     causes    bugs.", "debugging"),

        ("Such    issues     break    downstream    tasks.", "pipeline"),
        ("Fix    this     one     before     release.", "deployment"),
        ("Nothing     should     have     random    spaces.", "standard"),
        ("Always    trim    the    inputs.", "best-practice"),
        ("Spacing     is     not     consistent.", "review"),

        ("Your     model    will     suffer    from    this.", "ml"),
        ("Clean    it    before     logging.", "logging"),
        ("These     are     simple     errors.", "qa"),
        ("Multiple      spaces      break      rules.", "rules"),
        ("Bad    input     equals     bad     output.", "warning"),
        
        ("Stop    the     pipeline     and     clean     data.", "automation"),
        ("Spaces     can     hide     bugs.", "observation"),
        ("Validation    failed    due     to    whitespace.", "validation"),
        ("Such    formatting     is     unacceptable.", "report"),
        ("A    clean    sentence     is     easier    to     read.", "usability"),
        
        ("Don't     ignore    spacing     problems.", "caution"),
        ("This   would    not    pass    code    review.", "dev"),
        ("Whitespace    normalization    is     essential.", "data"),
        ("Extra     lines    and     spaces     ruin     docs.", "documentation"),
        ("You    must     fix     this     before     merging.", "workflow"),
        
        ("Gaps     like    this    are    not    acceptable.", "compliance"),
        ("Text     parsing     fails     on     messy    input.", "parser"),
        ("Why     are     there     so     many    spaces?", "question"),
        ("Remove      weird     spacing     now.", "order"),
        ("Document     must     be     consistent.", "consistency"),
    ]

    return [
        {"id": start_id + i, "text": text, "topic": topic}
        for i, (text, topic) in enumerate(raw_dirty)
    ]

def write_jsonl(path, entries):
    with open(path, "w", encoding="utf-8") as f:
        for entry in entries:
            json.dump(entry, f, ensure_ascii=False)
            f.write("\n")

def main():

    topics = ["history", "science", "economy", "environment", "communication"]
    clean_entries = generate_clean_texts(topics, per_topic=4)   # 25 合法记录
    dirty_entries = generate_dirty_entries()                   # 5 脏记录

    all_entries = clean_entries + dirty_entries
    random.shuffle(all_entries)

    # 写入 raw/input.jsonl（原始数据，含干净+多余空格）
    write_jsonl("data/benchmarks/NL2Op/T0006_/raw/customers.jsonl", all_entries)

    # 写入 expected/output.jsonl（text 清理后的数据）
    cleaned_entries = []
    for entry in all_entries:
        entry_cleaned = entry.copy()
        entry_cleaned["text"] = normalize_spaces(entry["text"])
        cleaned_entries.append(entry_cleaned)
    write_jsonl("data/benchmarks/NL2Op/T0006_/expected/gt.jsonl", cleaned_entries)

    print("✅ JSONL data generated for T0006 at raw/input.jsonl and expected/output.jsonl")

if __name__ == "__main__":
    main()
