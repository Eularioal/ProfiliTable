import json
import re

def load_jsonl(path):
    data = {}
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            record = json.loads(line)
            data[str(record['id'])] = record['text']
    return data

def normalize(text):
    # 去除前后空格，并把多个空格替换为一个
    return re.sub(r'\s+', ' ', text.strip())

def evaluate(expected_path, processed_path, show_diff=5):
    expected = load_jsonl(expected_path)
    processed = load_jsonl(processed_path)

    total = len(expected)
    matched = 0
    mismatches = []

    for id_, exp_text in expected.items():
        proc_text = processed.get(id_)
        if proc_text is None:
            mismatches.append((id_, "missing", exp_text, ""))
        else:
            if proc_text == exp_text:
                matched += 1
            else:
                mismatches.append((id_, "mismatch", exp_text, proc_text))

    accuracy = matched / total if total > 0 else 0.0

    # print(f"✅ Eval Result:")
    # print(f"  - True Positives: {true_positives}")
    # print(f"  - Expected Total (Gold): {gold_total}")
    # print(f"  - Predicted Total: {predicted_total}")
    # print(f"  - Precision: {precision:.4f}")
    # print(f"  - Recall:    {recall:.4f}")
    # print(f"  - F1 Score:  {f1:.4f}")

    result = {"eval_score": f"{accuracy:.4f}"}
    print(result)
def get_gt():
    from pathlib import Path

    # 获取 gen_data.py 所在目录
    current_dir = Path(__file__).resolve().parent

    # 找到 expected 目录
    expected_dir = (current_dir / "./expected").resolve()

    # 查找第一个 .jsonl 文件
    jsonl_files = list(expected_dir.glob("*.jsonl"))

    if not jsonl_files:
        raise FileNotFoundError(f"No .jsonl file found in {expected_dir}")

    # 取第一个文件作为 expected_path
    expected_path = jsonl_files[0]

    return expected_path

import argparse
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="filter non-english data")
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Path to the processed jsonl produced by your operator",
    )
    args = parser.parse_args()
    expected_path = get_gt()
    processed_path = args.output
    evaluate(expected_path, processed_path)