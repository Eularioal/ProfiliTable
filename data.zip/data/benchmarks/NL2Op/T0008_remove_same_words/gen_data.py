import json
import os
import random
import re
from utils.llm_serving import LLMServing

def remove_repeated_words(text):
    return re.sub(r'\b(\w+)(\s+\1\b)+', r'\1', text, flags=re.IGNORECASE)

def generate_clean_texts(topics, per_topic=5):
    llm = LLMServing()
    user_inputs = [f"Write a clean sentence about {topic} without repeating words." for topic in topics for _ in range(per_topic)]
    system_prompt = "You are an AI that writes English sentences without repeating the same word consecutively."
    results = llm.generate_from_input(user_inputs, system_prompt)

    entries = []
    for idx, (text, prompt) in enumerate(zip(results, user_inputs)):
        topic = prompt.split("about")[1].split("without")[0].strip()
        entries.append({
            "id": idx,
            "text": text,
            "topic": topic
        })
    return entries

def generate_dirty_entries(start_id=1000):
    dirty = [
        ("This is is a great example.", "writing"),
        ("I love love this product.", "review"),
        ("No no no way!", "reaction"),
        ("She said said she was tired.", "dialogue"),
        ("It's really really cold outside.", "weather"),

        ("He he didn't even show up.", "story"),
        ("They were were just leaving.", "narration"),
        ("I I think we should go.", "speech"),
        ("That was was unexpected.", "reaction"),
        ("Yes yes I agree.", "agreement"),

        ("It's just just not fair.", "emotion"),
        ("We had had enough.", "past-tense"),
        ("You you need to listen.", "instruction"),
        ("I saw saw him at the store.", "observation"),
        ("Don't don't do that.", "warning"),

        ("We we should stay together.", "relationship"),
        ("Time time is running out.", "urgency"),
        ("He said said it again.", "dialogue"),
        ("I want want more.", "desire"),
        ("This this can't be real.", "confusion"),

        ("They they never learn.", "criticism"),
        ("I tried tried everything.", "effort"),
        ("You know know what I mean?", "conversation"),
        ("It's better better this way.", "preference"),
        ("So so boring!", "complaint"),

        ("I told told you already.", "reminder"),
        ("Stop stop right there.", "command"),
        ("That was was amazing!", "reaction"),
        ("He is is always late.", "habit"),
        ("I just just can't believe it.", "emotion"),

        ("Make make it stop.", "frustration"),
        ("They they won the game.", "sports"),
        ("She cried cried all night.", "drama"),
        ("I remember remember that day.", "memory"),
        ("No one one said a word.", "silence"),

        ("You lied lied to me.", "accusation"),
        ("He works works all the time.", "work"),
        ("We met met last year.", "past"),
        ("It's over over now.", "closure"),
        ("Please please help me.", "plea"),

        ("This changes changes everything.", "drama"),
        ("You told told me that already.", "argument"),
        ("I gave gave him a chance.", "regret"),
        ("Let let me do it.", "control"),
        ("I will will fix it.", "promise"),

        ("Don't don't touch that.", "warning"),
        ("He can't can't hear you.", "concern"),
        ("We know know what's going on.", "awareness"),
        ("She ran ran away.", "action"),
        ("That guy guy is strange.", "description"),

        ("He left left without saying a word.", "betrayal"),
        ("It's not not your fault.", "reassurance"),
        ("We waited waited all day.", "patience"),
        ("Everyone everyone was shocked.", "news"),
        ("She disappeared disappeared into the night.", "mystery"),

        ("Why why did this happen?", "question"),
        ("He laughed laughed so hard.", "humor"),
        ("This won't won't end well.", "prediction"),
        ("You promised promised to help.", "trust"),
        ("We walked walked for hours.", "travel"),

        ("They screamed screamed for help.", "emergency"),
        ("He kept kept repeating it.", "obsession"),
        ("Nothing nothing makes sense.", "confusion"),
        ("She said said yes!", "celebration"),
        ("I forgot forgot my keys.", "daily-life"),

        ("We're we're not going anywhere.", "disagreement"),
        ("You're you're right.", "agreement"),
        ("They followed followed us.", "suspense"),
        ("Everyone everyone left early.", "event"),
        ("He's he's the one.", "decision"),

        ("I made made a mistake.", "apology"),
        ("We couldn't couldn't stop them.", "helplessness"),
        ("She chose chose to stay.", "choice"),
        ("I found found the answer.", "discovery"),
        ("He broke broke the rules.", "violation"),
    ]

    return [
        {"id": start_id + i, "text": text, "topic": topic}
        for i, (text, topic) in enumerate(dirty)
    ]

def write_jsonl(path, entries):
    with open(path, "w", encoding="utf-8") as f:
        for entry in entries:
            json.dump(entry, f, ensure_ascii=False)
            f.write("\n")

def main():

    topics = ["feedback", "product", "science", "teamwork", "exploration"]
    clean_entries = generate_clean_texts(topics, per_topic=4)   # 25条干净数据
    dirty_entries = generate_dirty_entries()                    # 5条重复词数据

    all_entries = clean_entries + dirty_entries
    random.shuffle(all_entries)

    # raw/input.jsonl：原始混合数据
    write_jsonl("data/benchmarks/NL2Op/T0008_/raw/customers.jsonl", all_entries)

    # expected/output.jsonl：清洗重复词后的数据
    cleaned_entries = []
    for entry in all_entries:
        entry_cleaned = entry.copy()
        entry_cleaned["text"] = remove_repeated_words(entry["text"])
        cleaned_entries.append(entry_cleaned)
    write_jsonl("data/benchmarks/NL2Op/T0008_/expected/gt.jsonl", cleaned_entries)

    print("✅ Data generated for T0008: input.jsonl + output.jsonl")

if __name__ == "__main__":
    main()
