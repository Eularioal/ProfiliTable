#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ― CSV Union Operator · Evaluation
=========================================
目录结构
└─ T00XX_data_csv_union/
   ├─ expected/gt.csv           # 合并后的黄金标准
   ├─ raw/customers1.csv        # 原始输入 1
   ├─ raw/customers2.csv        # 原始输入 2
   └─ eval.py                   # 本脚本

使用
    python eval.py -o path/to/output.csv

算子输出要求
    • 文件类型：CSV（UTF-8）
    • 必须包含表头
    • 表头与行顺序必须与 expected/gt.csv 完全一致
    • 不允许缺行、错行、增行、改值

评价指标
    如果算子输出与 gt.csv “字节级一致”（解析后逐行逐列完全相同） ⇒ 得分 1.0  
    其余情况 ⇒ 得分 0.0  

脚本仅打印一行 JSON：{"eval_score": "<score>"}
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import List

ROOT_DIR = Path(__file__).resolve().parent
GT_FILE  = ROOT_DIR / "expected" / "gt.csv"

# ────────────────────────── IO 工具 ──────────────────────────
def load_csv_rows(path: Path) -> List[List[str]]:
    """
    以列表形式返回 CSV 的全部行（含表头），每行是 List[str]。
    使用 csv.reader 可以避免不同平台换行或多余空白导致的字面差异。
    """
    rows: List[List[str]] = []
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        for r in reader:
            # 不做 strip，保持字段原样
            rows.append(r)
    return rows

# ─────────────────────────── 主函数 ─────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate CSV union operator")
    parser.add_argument(
        "-o", "--output", required=True,
        help="CSV file produced by operator (e.g., output.csv)"
    )
    args = parser.parse_args()

    output_path = Path(args.output)
    if not output_path.exists():
        print(f"文件不存在: {output_path}", file=sys.stderr)
        sys.exit(1)

    if output_path.suffix.lower() != ".csv":
        print("评测只接受 CSV 输出文件", file=sys.stderr)
        sys.exit(1)

    try:
        gt_rows   = load_csv_rows(GT_FILE)
        pred_rows = load_csv_rows(output_path)
    except Exception as exc:
        print(f"[eval.py] 读文件失败: {exc}", file=sys.stderr)
        sys.exit(1)

    # ──────────────── 逐行逐列严格比较 ────────────────
    score = 1.0 if gt_rows == pred_rows else 0.0

    # 仅输出一行 JSON
    print(json.dumps({"eval_score": f"{score:.1f}"}))

if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        # 出现任何未捕获异常，评测失败，得分 0
        print(f"[eval.py] 评测失败: {exc}", file=sys.stderr)
        print(json.dumps({"eval_score": "0.0"}))
        sys.exit(1)