#!/usr/bin/env python3
# gen_data.py ─ 生成测试数据
import csv
import random
from pathlib import Path
from faker import Faker

# ────────────────── 可调参数 ──────────────────
UNIQUE_ROWS = 110   # 唯一记录数
DUP_ROWS    = 10    # 额外重复行数（随机抽样）
AGE_RANGE   = (18, 70)

# ────────────────── 路径 ──────────────────
ROOT_DIR      = Path(__file__).resolve().parent
EXPECTED_DIR  = ROOT_DIR / "expected"
RAW_DIR       = ROOT_DIR / "raw"
EXPECTED_DIR.mkdir(exist_ok=True)
RAW_DIR.mkdir(exist_ok=True)

GT_PATH   = EXPECTED_DIR / "gt.csv"
RAW1_PATH = RAW_DIR / "customers1.csv"
RAW2_PATH = RAW_DIR / "customers2.csv"

# ────────────────── 初始化 Faker ──────────────────
fake = Faker()
Faker.seed(42)
random.seed(42)

header = [
    "customer_id",
    "first_name",
    "last_name",
    "age",
    "email",
    "country"
]

# ────────────────── 生成唯一记录 ──────────────────
rows = []
for cid in range(1, UNIQUE_ROWS + 1):
    first = fake.first_name()
    last  = fake.last_name()
    age   = str(random.randint(*AGE_RANGE))
    email = f"{first.lower()}.{last.lower()}@{fake.free_email_domain()}"
    country = fake.country_code(representation="alpha-2")
    rows.append([str(cid), first, last, age, email, country])

# ────────────────── 追加重复记录 ──────────────────
rows += random.choices(rows, k=DUP_ROWS)

# 现在 rows 长度 >=120
assert len(rows) >= 120

# ────────────────── 写入 Ground-Truth CSV ──────────────────
with GT_PATH.open("w", newline="", encoding="utf-8") as f_gt:
    writer = csv.writer(f_gt)
    writer.writerow(header)
    writer.writerows(rows)

# ────────────────── 拆分为两份原始 CSV ──────────────────
# 方案：60% → customers1.csv，40% → customers2.csv，保持原行顺序
split_idx = int(len(rows) * 0.6)
rows1 = rows[:split_idx]
rows2 = rows[split_idx:]

def write_raw(path: Path, data):
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(data)

write_raw(RAW1_PATH, rows1)
write_raw(RAW2_PATH, rows2)

# ────────────────── 日志 ──────────────────
print(
    "✅ 数据已生成\n"
    f"• {GT_PATH.relative_to(ROOT_DIR)}  (总 {len(rows)} 行, 含表头 {len(rows)+1})\n"
    f"• {RAW1_PATH.relative_to(ROOT_DIR)} (行数 {len(rows1)})\n"
    f"• {RAW2_PATH.relative_to(ROOT_DIR)} (行数 {len(rows2)})"
)