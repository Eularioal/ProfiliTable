#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
eval.py
=======

评测脚本 —— 校验选手是否仅删除了缺失率 > THRESH 的列，且保留列内容未改动

用法:
    python eval.py -o <candidate.csv>

通过: {"eval_score":"1.0"}
失败: {"eval_score":"0.0"} 并写原因到 stderr
"""

from __future__ import annotations
import argparse, json, sys
from pathlib import Path

import numpy as np
import pandas as pd

# ───── 配置 (须与 gen_data.py 保持一致) ─────
ROOT      = Path(__file__).resolve().parent
RAW_CSV   = ROOT / "raw" / "customers.csv"
GT_CSV    = ROOT / "expected" / "gt.csv"
THRESH    = 0.30
ATOL      = 1e-8
# ───────────────────────────────────────────


def fail(msg: str, code: int = 1) -> None:
    print(f"[eval] {msg}", file=sys.stderr)
    print(json.dumps({"eval_score": "0.0"}))
    sys.exit(code)


def read_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, na_values=["", "NA"])


def evaluate(cand: pd.DataFrame,
             gt:   pd.DataFrame,
             raw:  pd.DataFrame) -> float:
    # 1) 行数必须一致
    if cand.shape[0] != raw.shape[0]:
        fail(f"行数不一致: 期望 {raw.shape[0]}, 实际 {cand.shape[0]}")

    # 2) 列集合必须与基准一致
    if list(cand.columns) != list(gt.columns):
        miss  = set(gt.columns) - set(cand.columns)
        extra = set(cand.columns) - set(gt.columns)
        if miss:
            fail(f"缺少列: {', '.join(miss)}")
        if extra:
            fail(f"多余列: {', '.join(extra)}")
        # 顺序也要求一致
        fail("列顺序与基准不一致")

    # 3) 校验应删除列集合
    na_mask = raw.isna() | (raw == "") | (raw == "NA")
    ratio = na_mask.mean(axis=0)
    should_drop = set(ratio[ratio > THRESH].index)
    kept_cols   = set(raw.columns) - should_drop

    if set(cand.columns) != kept_cols:
        fail("删除列集合与阈值规则不符")

    # 4) 保留列内容不得修改
    for col in kept_cols:
        sr_raw = raw[col]
        sr_cand = cand[col]

        # 类型区分
        if pd.api.types.is_numeric_dtype(sr_raw):
            # numeric: 同为 NaN 或数值差 ≤1e-8
            raw_nan = sr_raw.isna()
            cand_nan = sr_cand.isna()
            if not raw_nan.equals(cand_nan):
                fail(f"列 {col} 的缺失分布被修改")
            diff = np.abs(sr_raw.astype(float) - sr_cand.astype(float))
            if (diff[~raw_nan] > ATOL).any():
                fail(f"列 {col} 的数值被修改")
        else:
            # 非数值：直接转字符串比较 (NaN→'<NA>')
            if not sr_raw.astype(str).fillna("<NA>").equals(
                sr_cand.astype(str).fillna("<NA>")
            ):
                fail(f"列 {col} 的内容被修改")

    return 1.0


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate column-removal by missing-rate operator")
    parser.add_argument("-o", "--output", required=True, help="candidate CSV file")
    args = parser.parse_args()

    cand_path = Path(args.output)
    if not cand_path.exists():
        fail(f"文件不存在: {cand_path}")

    try:
        raw = read_csv(RAW_CSV)
        gt  = read_csv(GT_CSV)
        cand = read_csv(cand_path)
    except Exception as exc:
        fail(f"读取 CSV 失败: {exc}")

    score = evaluate(cand, gt, raw)
    print(json.dumps({"eval_score": f"{score:.1f}"}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        fail(f"评测脚本异常: {exc}", code=2)