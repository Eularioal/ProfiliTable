#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_data.py
===========

1. 生成 raw/customers.csv（含缺失）
2. 删除缺失率 > THRESH 的列，写 expected/gt.csv

编码：UTF-8 无 BOM
依赖：pandas、numpy
"""

from pathlib import Path
import numpy as np
import pandas as pd

# ────────────── 配置 ──────────────
RAW_PATH = Path("raw/customers.csv")
GT_PATH  = Path("expected/gt.csv")
N_ROWS   = 40
RAND_SEED = 7
THRESH   = 0.30          # 缺失率阈值 (strictly greater than)
# ────────────────────────────────

rng = np.random.default_rng(RAND_SEED)


def make_raw() -> pd.DataFrame:
    """构造带缺失的数据集"""
    df = pd.DataFrame(
        {
            "customer_id": range(1, N_ROWS + 1),
            "age": rng.integers(18, 70, size=N_ROWS).astype(float),
            "income": rng.normal(60_000, 15_000, size=N_ROWS),
            "city": rng.choice(["Beijing", "Shanghai", "Shenzhen"], size=N_ROWS),
            "gender": rng.choice(["M", "F"], size=N_ROWS),
        }
    )

    # 制造缺失:
    #   age     → 0.10 缺失   (保留)
    #   income  → 0.35 缺失   (删除)
    #   city    → 0.45 缺失   (删除)
    #   gender  → 0.05 缺失   (保留)
    miss_rates = {"age": 0.10, "income": 0.35, "city": 0.45, "gender": 0.05}

    for col, rate in miss_rates.items():
        mask = rng.random(N_ROWS) < rate
        half = mask & (rng.random(N_ROWS) < 0.5)
        df.loc[mask &  half, col] = np.nan     # 用 NaN
        df.loc[mask & ~half, col] = "NA"       # 用字符串 "NA"

    return df


def drop_high_missing(df: pd.DataFrame) -> pd.DataFrame:
    """删除缺失率 > THRESH 的列"""
    na_mask = df.isna() | (df == "") | (df == "NA")
    ratio = na_mask.mean(axis=0)
    cols_to_drop = ratio[ratio > THRESH].index.tolist()
    return df.drop(columns=cols_to_drop)


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8")   # 无 BOM


def main() -> None:
    raw_df = make_raw()
    write_csv(raw_df, RAW_PATH)
    print(f"✅ raw 数据写出: {RAW_PATH}")

    gt_df = drop_high_missing(raw_df)
    write_csv(gt_df, GT_PATH)
    print(f"✅ 缺失率过滤结果写出: {GT_PATH}")


if __name__ == "__main__":
    main()