import argparse
import json
import os


def load_jsonl(path):
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            data.append(json.loads(line.strip()))
    return data


def is_valid_record(record):
    """检查记录是否符合任务要求"""
    # 条件1: items 数组无重复
    items = record.get("items", [])
    if len(items) != len(set(items)):
        return False

    text = record.get("text", "").strip()

    # 条件2: 脏话是否被屏蔽 (简单检查有没有未屏蔽的典型脏话)
    badwords = ["fuck", "shit", "bitch", "asshole"]
    for w in badwords:
        if w in text.lower():
            return False
    # # 至少要包含屏蔽符号
    # if "****" not in text:
    #     return False

    # 条件3: 20–100 词
    word_count = len(text.split())
    if word_count < 20 or word_count > 100:
        return False

    return True

def get_gt():
    from pathlib import Path

    # 获取 gen_data.py 所在目录
    current_dir = Path(__file__).resolve().parent

    # 找到 expected 目录
    expected_dir = (current_dir / "./expected").resolve()

    # 查找第一个 .jsonl 文件
    jsonl_files = list(expected_dir.glob("*.jsonl"))

    if not jsonl_files:
        raise FileNotFoundError(f"No .jsonl file found in {expected_dir}")

    # 取第一个文件作为 expected_path
    expected_path = jsonl_files[0]

    return expected_path

def evaluate(processed_path):
    expected_path = get_gt()
    expected = load_jsonl(expected_path)
    processed = load_jsonl(processed_path)

    # 构造映射方便比对
    expected_map = {entry["id"]: entry for entry in expected}
    processed_map = {entry["id"]: entry for entry in processed}

    # 只评估交集部分
    common_ids = set(expected_map.keys()) & set(processed_map.keys())

    true_positives = len(common_ids)
    # for cid in common_ids:
    #     gt = expected_map[cid]
    #     pred = processed_map[cid]

    #     # text 相同(去掉首尾空格对比)
    #     if gt["text"].strip() == pred["text"].strip():
    #         true_positives += 1

    predicted_total = len(processed_map)
    gold_total = len(expected_map)

    precision = true_positives / predicted_total if predicted_total > 0 else 0.0
    recall = true_positives / gold_total if gold_total > 0 else 0.0
    f1 = (2 * precision * recall) / (precision + recall) if precision + recall > 0 else 0.0

    result = {"eval_score": f"{f1:.4f}"}
    print(result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-o", "--output", help="Optional output file for processed results")
    args = parser.parse_args()

    # if args.output:
    #     os.makedirs(os.path.dirname(args.output), exist_ok=True)

    evaluate(args.output)
