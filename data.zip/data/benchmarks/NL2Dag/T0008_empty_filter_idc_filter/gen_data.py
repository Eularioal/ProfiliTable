import os
import json
import random
import argparse
import csv
from pathlib import Path

try:
    from utils.llm_serving import LLMServing
except ImportError:
    LLMServing = None

# 脏话列表（可扩展）
BAD_WORDS = ["fuck", "shit", "bitch", "asshole", "damn", "bitches", "bitchy", "fucked", "fucking"]

def mask_profanity(text):
    """将脏话替换为 ****"""
    words = text.split()
    masked_words = []
    for w in words:
        lw = w.lower().strip(".,!?")
        if lw in BAD_WORDS:
            masked_words.append("****")
        else:
            masked_words.append(w)
    return " ".join(masked_words)

def generate_items(unique=True):
    """生成 items 数组，若 unique=False 则可能包含重复"""
    candidates = ["apple", "banana", "pear", "grape", "orange",
                  "book", "pen", "paper", "computer", "phone"]
    items = random.sample(candidates, k=random.randint(3, 6))
    if not unique:  # 引入重复
        items.append(random.choice(items))
    return items

def generate_text(topics, llm=None, mask=True, length="normal"):
    """
    生成文本
    mask=True -> 屏蔽脏话
    mask=False -> 保留脏话
    length 控制长度: "normal"(30-80), "short"(<20), "long"(>100)
    """
    topic_pair = random.sample(topics, 2)
    topic_str = " and ".join(topic_pair)

    if llm:
        user_input = f"Write a paragraph about {topic_str}. Insert at least one of these words: {', '.join(BAD_WORDS)}.You can only use the dirty words that I mentioned and don't use any participle of them."
        system_prompt = "You are an AI that writes English paragraphs and may insert mild profanities."
        results = llm.generate_from_input([user_input], system_prompt)
        text = results[0]
    else:
        text = (
            f"This text is about {topic_str}. "
            f"It describes ideas in a clear manner but sometimes people say shit or fuck in casual speech. "
            f"Nevertheless, the main content remains formal and informative."
        )

    words = text.split()
    if len(words) < 30:
        words = words * 2

    if length == "normal":
        text = " ".join(words[:random.randint(30, 80)])
    elif length == "short":
        text = " ".join(words[:random.randint(5, 15)])
    elif length == "long":
        text = " ".join(words * 5)  # >100
    else:
        text = " ".join(words[:random.randint(30, 80)])

    if mask:
        text = mask_profanity(text)

    return text

def generate_sources():
    """随机选择来源"""
    candidates = ["dataset_a.jsonl", "dataset_b.jsonl", "dataset_c.jsonl"]
    return random.sample(candidates, k=random.randint(1, 2))

    # === 保存文件 ===
    def save_records(records, filepath, fmt):
        if fmt == "jsonl":
            with open(filepath, "w", encoding="utf-8") as f:
                for r in records:
                    f.write(json.dumps(r, ensure_ascii=False) + "\n")
        elif fmt == "csv":
            keys = records[0].keys()
            with open(filepath, "w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=keys)
                writer.writeheader()
                writer.writerows(records)
        else:
            raise ValueError("Unsupported format: choose jsonl or csv")

def save_records(records, filepath, fmt):
    if fmt == "jsonl":
        with open(filepath, "w", encoding="utf-8") as f:
            for r in records:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    elif fmt == "csv":
        keys = records[0].keys()
        with open(filepath, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            writer.writerows(records)
    else:
        raise ValueError("Unsupported format: choose jsonl or csv")

def unmask_profanity(text, badwords=None):
    """把 **** 替换成随机脏话"""
    if badwords is None:
        badwords = ["fuck", "shit", "bitch", "asshole", "damn"]
    while "****" in text:
        text = text.replace("****", random.choice(badwords), 1)  # 每次替换一个
    return text


def main(task_id, output_format="jsonl", use_llm=False):
    output_dir = Path(f"data/benchmarks/NL2Dag/{task_id}")
    output_dir.mkdir(parents=True, exist_ok=True)

    gt_file = output_dir / f"expected/gt.{output_format}"
    noisy_file = output_dir / f"raw/customers.{output_format}"

    topics = ["technology", "education", "environment", "health", "science",
              "culture", "economy", "art", "history", "sports"]

    llm = LLMServing() if (use_llm and LLMServing) else None

    # ✅ 生成 GT 数据
    gt_records = []
    for i in range(30):
        record = {
            "id": i + 1,
            "items": generate_items(unique=True),
            "text": generate_text(topics, llm=llm, mask=True, length="normal"),
            "sources": generate_sources()
        }
        gt_records.append(record)

    save_records(gt_records, gt_file, output_format)

    # start of modification

    import copy

    noisy_records = copy.deepcopy(gt_records)

    # ① 插入 text 为空的记录
    for i in range(30):
        record = copy.deepcopy(random.choice(gt_records))
        record["id"] = f"empty_{i+1}"
        record["text"] = "" if i % 2 == 0 else "   "  # 空 or 全空格
        noisy_records.append(record)

    # ② 插入包含大陆身份证号的记录
    def generate_id_card():
        """生成一个18位大陆身份证号（简单规则，不保证校验位正确）"""
        addr_code = str(random.randint(110000, 659004)).zfill(6)  # 地址码
        birth = str(random.randint(1950, 2005)) + \
                str(random.randint(1, 12)).zfill(2) + \
                str(random.randint(1, 28)).zfill(2)  # 出生日期
        seq = str(random.randint(100, 299)).zfill(3)  # 顺序码
        check = str(random.randint(0, 9))  # 校验位（此处随便给）
        return addr_code + birth + seq + check

    for i in range(50):
        record = copy.deepcopy(random.choice(gt_records))
        record["id"] = f"idcard_{i+1}"
        record["text"] = f"My Chinese ID number is {generate_id_card()}."
        noisy_records.append(record)

    # end of modification

    save_records(noisy_records, noisy_file, output_format)

    # print(f"✅ GT data generated at: {gt_file}")
    print(f"⚠️ Noisy data generated at: {noisy_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--task_id", type=str, required=True, help="Task ID, e.g., T0001")
    parser.add_argument("-f", "--format", type=str, default="jsonl", choices=["jsonl", "csv"], help="Output format")
    parser.add_argument("--use_llm", action="store_true", help="Whether to use LLM to generate texts")
    args = parser.parse_args()

    main(args.task_id, output_format=args.format, use_llm=args.use_llm)
