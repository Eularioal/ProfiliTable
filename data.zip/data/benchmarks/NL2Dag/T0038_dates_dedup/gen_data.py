
import pandas as pd
import random

# 读取原始CSV文件
input_file = ''  # 修改为你的文件路径
df = pd.read_csv(input_file)



# 读取gt文件
gt_file = '' # 修改为你的gt文件路径
gt_df = pd.read_csv(gt_file)

df_truncated = df.iloc[:len(gt_df)]

# 找到 payment_status 为 'success' 时对应的 most common p`ayment_method
success_payment_methods = df[df['payment_status'] == 'success']['payment_method']
most_common_method = success_payment_methods.mode().iloc[0]  # 众数

# 创建 gt_df 并填充数据
gt_df['payment_status'] = df_truncated['payment_status']
gt_df['payment_method'] = df_truncated['payment_method']
gt_df['empty'] = df_truncated['empty']

# 替换 empty 为 True 的行中的 payment_method 为众数
gt_df.loc[gt_df['empty'] == True, 'payment_method'] = most_common_method

# 保存修改后的CSV文件
output_file = ''  # 修改为保存文件路径
gt_df.to_csv(output_file, index=False)

print(f"CSV 文件已更新并保存为 {output_file}")
