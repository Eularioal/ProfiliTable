#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1. 生成 raw/customers.jsonl   —— 原始数据，可能包含
      • HTML 标签
      • HTML 实体 (&amp; 等)
      • 英文缩写 (AI、USA、HTML、CPU、GPU)
      • 屏蔽词
2. 对 raw 数据按任务要求进行
      (a) 屏蔽词过滤 → (b) 去 HTML + 实体解码 → (c) 缩写替换
   保存为 expected/gt.jsonl
"""

from __future__ import annotations

import html
import json
import os
import random
import re
from pathlib import Path

from faker import Faker

fake = Faker("en_US")
random.seed(2025)
Faker.seed(2025)

# ------------------------------- 配置 -------------------------------- #
N_RECORDS = 150                         # >100 条

BLOCKED_PATTERNS = [
    r"badword",          # 英文
    r"(?i)\bsecret\b",   # 大小写不敏感
    r"敏感词",            # 中文
]

ABBR_MAP = {            # 英文缩写 → 全称
    "AI":   "Artificial Intelligence",
    "USA":  "United States of America",
    "HTML": "HyperText Markup Language",
    "CPU":  "Central Processing Unit",
    "GPU":  "Graphics Processing Unit",
}

# Regex 预编译
BLOCK_RE  = re.compile("|".join(BLOCKED_PATTERNS), flags=re.IGNORECASE)
TAG_RE    = re.compile(r"<[^>]+>")
ABBR_RE   = re.compile(r"\b(" + "|".join(ABBR_MAP.keys()) + r")\b")

RAW_DIR   = Path("raw")
EXP_DIR   = Path("expected")
RAW_DIR.mkdir(exist_ok=True)
EXP_DIR.mkdir(exist_ok=True)

RAW_PATH  = RAW_DIR / "customers.jsonl"
GT_PATH   = EXP_DIR / "gt.jsonl"


# --------------------------- 工具函数 --------------------------- #
def random_html_sentence() -> str:
    """构造一条可能含 HTML/实体/缩写/屏蔽词的句子"""
    txt = fake.sentence(nb_words=random.randint(6, 12))
    # 随机注入英文缩写
    if random.random() < 0.8:
        txt += " " + random.choice(list(ABBR_MAP.keys()))
    # 随机注入屏蔽词
    if random.random() < 0.2:
        txt += " " + random.choice(["badword", "SeCrEt", "敏感词"])
    # 将句号替换为 &amp;nbsp;.
    txt = txt.replace(".", "&amp;nbsp;.")
    # 包一层 HTML
    txt = f"<p><em>{txt}</em></p>"
    return txt


def has_block_words(text: str) -> bool:
    """大小写不敏感、词边界匹配屏蔽词"""
    return bool(BLOCK_RE.search(text))


def strip_html_and_entities(text: str) -> str:
    text = TAG_RE.sub("", text)       # 去 HTML
    text = html.unescape(text)        # 实体解码
    return text


def replace_abbr(text: str) -> str:
    return ABBR_RE.sub(lambda m: ABBR_MAP[m.group(0)], text)


def clean(text: str) -> str:
    text = strip_html_and_entities(text)
    text = replace_abbr(text)
    return text.strip()


# --------------------------- 生成数据 --------------------------- #
def main() -> None:
    with RAW_PATH.open("w", encoding="utf-8") as raw_f, \
         GT_PATH.open("w",  encoding="utf-8") as gt_f:
        for idx in range(1, N_RECORDS + 1):
            rec = {"id": idx, "text": random_html_sentence()}
            raw_f.write(json.dumps(rec, ensure_ascii=False) + "\n")

            if has_block_words(rec["text"]):
                continue  # 过滤掉含屏蔽词的记录

            rec_clean = {"id": rec["id"], "text": clean(rec["text"])}
            gt_f.write(json.dumps(rec_clean, ensure_ascii=False) + "\n")

    print(f"✓ raw 生成完毕 -> {RAW_PATH} ({RAW_PATH.stat().st_size} bytes)")
    print(f"✓ gt  生成完毕 -> {GT_PATH}  ({GT_PATH.stat().st_size} bytes)")


if __name__ == "__main__":
    main()