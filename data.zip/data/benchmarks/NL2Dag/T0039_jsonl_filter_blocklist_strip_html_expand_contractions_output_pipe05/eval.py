#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Evaluate the "filter + clean + abbreviations" task.

评测逻辑
--------
1. 读取 expected/gt.jsonl (基准) 形成 {id: text}。
2. 读取选手输出文件：
   * JSONL，每行必须存在 id 和 text 字段
   * 不允许 id 重复
3. 对   (id, text) 完全匹配   计作 TP
   id 存在但 text 不同        计作 FP + FN
   id 不存在基准集            计作 FP
   基准集中缺失的 id          计作 FN
4. 计算 F1 = 2PR/(P+R)。如 P+R=0，则得分 0。
5. 输出 {"eval_score": "0.xxxx"}
"""

from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from typing import Dict, Tuple

GT_PATH = Path(__file__).parent / "expected" / "gt.jsonl"


# --------------------------- 工具 --------------------------- #
def load(path: Path) -> Dict[int, str]:
    if not path.exists():
        sys.exit(f"[ERR] File not found: {path}")
    mapping: Dict[int, str] = {}
    with path.open(encoding="utf-8") as fh:
        for ln, line in enumerate(fh, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                sys.exit(f"[ERR] {path}:{ln} 不是合法 JSON -> {e}")
            if "id" not in obj or "text" not in obj:
                sys.exit(f"[ERR] {path}:{ln} 缺少 id/text 字段")
            _id = obj["id"]
            if _id in mapping:
                sys.exit(f"[ERR] {path}:{ln} id {_id} 重复出现")
            mapping[_id] = obj["text"]
    return mapping


def calc_f1(gt: Dict[int, str], pred: Dict[int, str]) -> Tuple[float, int, int, int]:
    tp = fp = fn = 0
    for pid, ptext in pred.items():
        if pid in gt and ptext == gt[pid]:
            tp += 1
        else:
            fp += 1
    for gid, gtext in gt.items():
        if gid not in pred:
            fn += 1
        elif pred[gid] != gtext:
            fn += 1  # text 不一致 -> fn
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall    = tp / (tp + fn) if (tp + fn) else 0.0
    if precision + recall == 0:
        return 0.0, tp, fp, fn
    return 2 * precision * recall / (precision + recall), tp, fp, fn


# --------------------------- 主程序 --------------------------- #
def main() -> None:
    ap = argparse.ArgumentParser(description="Evaluate clean-filter task")
    ap.add_argument("-o", "--output", required=True,
                    help="Your submission jsonl path")
    args = ap.parse_args()

    gt_map   = load(GT_PATH)
    pred_map = load(Path(args.output).expanduser())

    score, tp, fp, fn = calc_f1(gt_map, pred_map)
    print({"eval_score": f"{score:.4f}"})
    # 调试信息，可按需注释
    # print(f"[DBG] tp={tp} fp={fp} fn={fn} | gt={len(gt_map)} pred={len(pred_map)}")


if __name__ == "__main__":
    main()