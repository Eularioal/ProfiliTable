import csv
import re
import random
import os
from typing import List, Dict, Any
from datasketch import MinHashLSH, MinHash

def generate_raw_data() -> List[Dict[str, Any]]:
    """生成包含各种问题的原始数据"""
    
    # 正常的文本内容
    clean_texts = [
        "This is a great product with excellent quality.",
        "The service was amazing and staff very helpful.",
        "I really enjoyed the experience and would recommend it.",
        "The design is beautiful and functional.",
        "Great value for money and fast delivery.",
        "Outstanding customer support and quick response.",
        "The interface is user friendly and intuitive.",
        "High quality materials and excellent craftsmanship.",
        "Perfect solution for our business needs.",
        "Innovative features and reliable performance.",
        "Exceptional quality and attention to detail.",
        "Smooth operation and easy maintenance.",
        "Professional service and timely delivery.",
        "Creative design and practical functionality.",
        "Efficient workflow and improved productivity.",
        "Reliable system with consistent performance.",
        "Advanced technology and modern features.",
        "Comprehensive solution for complex problems.",
        "Effective strategy and successful implementation.",
        "Positive impact on our business operations."
    ]
    
    clean_contents = [
        "The product exceeded my expectations in every way.",
        "Wonderful experience with excellent customer service.",
        "High quality and great attention to detail.",
        "Fast shipping and perfect packaging.",
        "Easy to use with clear instructions.",
        "Great design and solid construction.",
        "Excellent value and reliable performance.",
        "Professional support team was very helpful.",
        "Outstanding quality and beautiful finish.",
        "Perfect fit for our specific requirements.",
        "Innovative solution that works perfectly.",
        "Reliable service with consistent quality.",
        "Efficient delivery and careful handling.",
        "Creative approach to solving problems.",
        "Effective communication throughout the process.",
        "Positive results and measurable improvement.",
        "Advanced features that enhance productivity.",
        "Comprehensive support and detailed documentation.",
        "Successful project completion on schedule.",
        "Excellent collaboration and teamwork."
    ]
    
    # 包含连续重复单词的文本
    repeated_word_texts = [
        "This is is a great great product with quality.",
        "The service was was amazing and and very helpful.",
        "I really really enjoyed the the experience.",
        "The design design is beautiful and and functional.",
        "Great great value for for money and delivery.",
        "Outstanding customer customer support and and response.",
        "The interface interface is user user friendly.",
        "High quality quality materials and and craftsmanship.",
        "Perfect perfect solution for for our needs.",
        "Innovative innovative features and and performance."
    ]
    
    # 相似的文本（用于测试去重）
    similar_text_groups = [
        [
            "The product quality is excellent and delivery was fast.",
            "Product quality is excellent and the delivery was fast.",
            "Excellent product quality and fast delivery service."
        ],
        [
            "Customer service was very helpful and responsive.",
            "Very helpful and responsive customer service team.",
            "The customer service team was helpful and responsive."
        ],
        [
            "Great value for money with outstanding features.",
            "Outstanding features and great value for money.",
            "Excellent value for money and outstanding features."
        ],
        [
            "Easy to use interface with intuitive design.",
            "Intuitive design and easy to use interface.",
            "The interface is easy to use with intuitive design."
        ]
    ]
    
    # 包含恶意语言或消极情感的内容
    negative_contents = [
        "This product is terrible and waste of money.",
        "Worst customer service I have ever experienced.",
        "Complete garbage and totally useless product.",
        "Awful quality and poor design choices.",
        "Hate this product and regret buying it.",
        "Terrible experience and would not recommend.",
        "Poor quality materials and sloppy construction.",
        "Disappointing results and wasted investment.",
        "Unreliable service and frequent problems.",
        "Bad experience with unresponsive support team.",
        "This is fucking terrible and piece of shit.",
        "Damn awful service and stupid design.",
        "What a piece of crap and total waste.",
        "Absolutely hate this garbage product.",
        "This sucks and is completely worthless."
    ]
    
    raw_data = []
    review_id = 1
    
    # 添加正常数据
    for i in range(len(clean_texts)):
        raw_data.append({
            "review_id": str(review_id),
            "text": clean_texts[i],
            "content": clean_contents[i],
            "category": "clean"
        })
        review_id += 1
    
    # 添加包含重复单词的数据
    for text in repeated_word_texts:
        raw_data.append({
            "review_id": str(review_id),
            "text": text,
            "content": random.choice(clean_contents),
            "category": "repeated_words"
        })
        review_id += 1
    
    # 添加相似文本组（用于测试去重）
    for group in similar_text_groups:
        for text in group:
            raw_data.append({
                "review_id": str(review_id),
                "text": text,
                "content": random.choice(clean_contents),
                "category": "similar"
            })
            review_id += 1
    
    # 添加包含消极内容的数据
    for content in negative_contents:
        raw_data.append({
            "review_id": str(review_id),
            "text": random.choice(clean_texts),
            "content": content,
            "category": "negative"
        })
        review_id += 1
    
    # 添加更多正常数据以达到150+条记录
    additional_clean_texts = [
        "Remarkable performance and excellent reliability.",
        "Superior quality and innovative design features.",
        "Exceptional service and professional support team.",
        "Outstanding results and measurable improvements.",
        "Efficient solution and cost effective approach.",
        "Reliable performance and consistent quality standards.",
        "Advanced functionality and user friendly interface.",
        "Comprehensive features and detailed documentation.",
        "Effective implementation and successful deployment.",
        "Professional service and expert technical support.",
        "Innovative technology and cutting edge features.",
        "Excellent communication and responsive support.",
        "High performance and scalable architecture.",
        "Robust system and reliable performance metrics.",
        "Creative solutions and practical implementation.",
        "Quality assurance and thorough testing procedures.",
        "Streamlined process and improved efficiency.",
        "Customizable options and flexible configuration.",
        "Integrated solution and seamless compatibility.",
        "Enhanced productivity and improved workflow.",
        "Strategic planning and successful execution.",
        "Collaborative approach and team coordination.",
        "Continuous improvement and ongoing optimization.",
        "Best practices and industry standard compliance.",
        "Innovation driven and technology focused.",
        "Performance oriented and result driven approach.",
        "Customer focused and service oriented mindset.",
        "Quality commitment and excellence standards.",
        "Professional expertise and technical competence.",
        "Sustainable solutions and long term benefits.",
        "Competitive advantage and market leadership.",
        "Operational efficiency and cost optimization.",
        "Strategic partnership and mutual cooperation.",
        "Technical excellence and innovative solutions.",
        "Business value and measurable return on investment.",
        "Market leading and industry recognized standards.",
        "Customer satisfaction and positive feedback.",
        "Continuous learning and skill development.",
        "Process improvement and operational excellence.",
        "Technology advancement and digital transformation.",
        "Partnership collaboration and shared success.",
        "Innovation culture and creative thinking.",
        "Performance measurement and quality metrics.",
        "Strategic objectives and business alignment.",
        "Competitive positioning and market differentiation.",
        "Customer experience and service excellence.",
        "Operational effectiveness and process optimization.",
        "Technology integration and system compatibility.",
        "Business intelligence and data driven decisions.",
        "Market expansion and growth opportunities."
    ]
    
    additional_clean_contents = [
        "Highly recommended for professional applications.",
        "Excellent investment with significant returns.",
        "Perfect solution that meets all requirements.",
        "Outstanding performance in demanding environments.",
        "Reliable choice for critical business operations.",
        "Innovative approach that delivers real value.",
        "Comprehensive solution with excellent support.",
        "Strategic advantage for competitive markets.",
        "Efficient workflow and improved productivity.",
        "Professional grade quality and performance.",
        "Advanced capabilities for complex requirements.",
        "Scalable solution that grows with business.",
        "Integrated platform with seamless operation.",
        "Flexible system that adapts to changing needs.",
        "Robust architecture with reliable performance.",
        "User centric design with intuitive interface.",
        "Cost effective solution with proven results.",
        "Industry leading technology and innovation.",
        "Professional service with expert guidance.",
        "Comprehensive training and ongoing support.",
        "Proven methodology with successful outcomes.",
        "Strategic implementation for maximum impact.",
        "Quality assurance with rigorous testing.",
        "Performance optimization for better results.",
        "Collaborative platform for team productivity.",
        "Automated processes for operational efficiency.",
        "Data driven insights for informed decisions.",
        "Secure platform with enterprise grade protection.",
        "Customizable features for specific requirements.",
        "Professional consulting and implementation services.",
        "Continuous monitoring and proactive maintenance.",
        "Best in class performance and reliability.",
        "Innovation leadership and market recognition.",
        "Customer success and satisfaction guarantee.",
        "Competitive pricing with exceptional value.",
        "Rapid deployment and quick time to value.",
        "Comprehensive documentation and training resources.",
        "Expert support team with technical expertise.",
        "Proven track record and customer testimonials.",
        "Scalable architecture for future growth needs.",
        "Integration capabilities with existing systems.",
        "Performance analytics and reporting dashboards.",
        "Security compliance and regulatory standards.",
        "Disaster recovery and business continuity.",
        "Mobile accessibility and cross platform support.",
        "Real time monitoring and alert notifications.",
        "Automated backup and data protection features.",
        "Performance tuning and optimization services.",
        "Professional training and certification programs.",
        "Strategic roadmap and future development plans."
    ]
    
    for i in range(len(additional_clean_texts)):
        raw_data.append({
            "review_id": str(review_id),
            "text": additional_clean_texts[i],
            "content": additional_clean_contents[i],
            "category": "clean"
        })
        review_id += 1
    
    # 随机打乱数据顺序
    random.shuffle(raw_data)
    
    return raw_data

def remove_repeated_words(text: str) -> str:
    """删除连续重复的单词"""
    words = text.split()
    result = []
    prev_word = None
    
    for word in words:
        if word.lower() != (prev_word.lower() if prev_word else ""):
            result.append(word)
            prev_word = word
    
    return " ".join(result)

def get_minhash(text: str, num_perm: int = 128) -> MinHash:
    """计算文本的MinHash"""
    # 简单的shingle生成（2-gram）
    shingles = set()
    words = text.lower().split()
    for i in range(len(words) - 1):
        shingle = f"{words[i]} {words[i+1]}"
        shingles.add(shingle)
    
    # 如果文本太短，使用单词作为shingle
    if len(shingles) == 0:
        shingles = set(words)
    
    minhash = MinHash(num_perm=num_perm)
    for shingle in shingles:
        minhash.update(shingle.encode('utf8'))
    return minhash

def deduplicate_similar_texts(data: List[Dict[str, Any]], threshold: float = 0.9) -> List[Dict[str, Any]]:
    """使用MinHash进行近似文本去重"""
    lsh = MinHashLSH(threshold=threshold, num_perm=128)
    
    # 构建LSH索引
    minhashes = {}
    for record in data:
        text = record['text']
        minhash = get_minhash(text)
        minhashes[record['review_id']] = minhash
        lsh.insert(record['review_id'], minhash)
    
    # 找到相似文本组
    similar_groups = []
    processed_ids = set()
    
    for record in data:
        review_id = record['review_id']
        if review_id in processed_ids:
            continue
        
        # 查找相似的文档
        similar_ids = lsh.query(minhashes[review_id])
        
        if len(similar_ids) > 1:
            # 按review_id排序，保留最小的
            similar_ids = sorted(similar_ids, key=int)
            similar_groups.append(similar_ids)
            processed_ids.update(similar_ids)
    
    # 构建要保留的ID集合
    keep_ids = set()
    for record in data:
        keep_ids.add(record['review_id'])
    
    for group in similar_groups:
        # 保留review_id最小的，移除其他的
        keep_id = group[0]
        for remove_id in group[1:]:
            keep_ids.discard(remove_id)
    
    # 返回去重后的数据
    return [record for record in data if record['review_id'] in keep_ids]

def has_negative_content(content: str) -> bool:
    """检查内容是否包含恶意语言或消极情感"""
    # 恶意语言列表
    bad_words = [
        "fuck", "shit", "damn", "crap", "suck", "hate", "awful", "terrible", 
        "worst", "garbage", "useless", "waste", "stupid", "sloppy", "disappointing"
    ]
    
    content_lower = content.lower()
    
    # 检查恶意语言
    for word in bad_words:
        if word in content_lower:
            return True
    
    # 检查消极情感词汇
    negative_phrases = [
        "not recommend", "regret buying", "poor quality", "bad experience",
        "unreliable", "frequent problems", "unresponsive", "piece of shit"
    ]
    
    for phrase in negative_phrases:
        if phrase in content_lower:
            return True
    
    return False

def process_data(raw_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """处理数据，应用所有清洗规则"""
    # 第一步：删除连续重复的单词
    for record in raw_data:
        record['text'] = remove_repeated_words(record['text'])
    
    # 第二步：使用MinHash进行去重
    deduplicated_data = deduplicate_similar_texts(raw_data, threshold=0.9)
    
    # 第三步：删除包含恶意语言或消极情感的记录
    clean_data = []
    for record in deduplicated_data:
        if not has_negative_content(record['content']):
            clean_data.append(record)
    
    return clean_data

def save_to_csv(data: List[Dict[str, Any]], filepath: str):
    """保存数据到CSV文件"""
    if not data:
        return
    
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = data[0].keys()
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)

def main():
    """主函数，生成测试数据"""
    print("生成原始数据...")
    raw_data = generate_raw_data()
    print(f"生成了 {len(raw_data)} 条原始记录")
    
    print("处理数据...")
    gt_data = process_data(raw_data)
    print(f"处理后保留了 {len(gt_data)} 条记录")
    
    # 保存原始数据到 raw/customers.csv
    print("保存原始数据到 raw/customers.csv...")
    save_to_csv(raw_data, 'raw/customers.csv')
    
    # 保存处理后的数据到 expected/gt.csv
    print("保存GT数据到 expected/gt.csv...")
    save_to_csv(gt_data, 'expected/gt.csv')
    
    print("数据生成完成！")
    print(f"原始数据: {len(raw_data)} 条记录")
    print(f"GT数据: {len(gt_data)} 条记录")
    print(f"清洗率: {(len(raw_data) - len(gt_data)) / len(raw_data) * 100:.1f}%")

if __name__ == "__main__":
    main()