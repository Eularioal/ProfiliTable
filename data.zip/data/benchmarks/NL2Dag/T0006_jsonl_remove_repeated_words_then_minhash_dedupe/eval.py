import argparse
import csv
import os
import re
from typing import List, Dict, Any
from datasketch import MinHashLSH, MinHash


def load_csv(path):
    data = []
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data


def has_repeated_words(text: str) -> bool:
    """检查文本是否包含连续重复的单词"""
    words = text.split()
    for i in range(len(words) - 1):
        if words[i].lower() == words[i + 1].lower():
            return True
    return False


def get_minhash(text: str, num_perm: int = 128) -> MinHash:
    """计算文本的MinHash"""
    # 简单的shingle生成（2-gram）
    shingles = set()
    words = text.lower().split()
    for i in range(len(words) - 1):
        shingle = f"{words[i]} {words[i+1]}"
        shingles.add(shingle)
    
    # 如果文本太短，使用单词作为shingle
    if len(shingles) == 0:
        shingles = set(words)
    
    minhash = MinHash(num_perm=num_perm)
    for shingle in shingles:
        minhash.update(shingle.encode('utf8'))
    return minhash


def calculate_similarity(text1: str, text2: str) -> float:
    """计算两个文本的相似度"""
    minhash1 = get_minhash(text1)
    minhash2 = get_minhash(text2)
    return minhash1.jaccard(minhash2)


def has_duplicate_texts(data: List[Dict[str, Any]], threshold: float = 0.9) -> bool:
    """检查是否存在高相似度的重复文本"""
    texts = [record['text'] for record in data]
    
    for i in range(len(texts)):
        for j in range(i + 1, len(texts)):
            similarity = calculate_similarity(texts[i], texts[j])
            if similarity >= threshold:
                return True
    return False


def has_negative_content(content: str) -> bool:
    """检查内容是否包含恶意语言或消极情感"""
    # 恶意语言列表
    bad_words = [
        "fuck", "shit", "damn", "crap", "suck", "hate", "awful", "terrible", 
        "worst", "garbage", "useless", "waste", "stupid", "sloppy", "disappointing"
    ]
    
    content_lower = content.lower()
    
    # 检查恶意语言
    for word in bad_words:
        if word in content_lower:
            return True
    
    # 检查消极情感词汇
    negative_phrases = [
        "not recommend", "regret buying", "poor quality", "bad experience",
        "unreliable", "frequent problems", "unresponsive", "piece of shit"
    ]
    
    for phrase in negative_phrases:
        if phrase in content_lower:
            return True
    
    return False


def is_valid_record(record):
    """检查记录是否符合任务要求"""
    text = record.get("text", "")
    content = record.get("content", "")
    
    # 条件1: 不应有连续重复的单词
    if has_repeated_words(text):
        return False
    
    # 条件2: 不应包含恶意语言或消极情感
    if has_negative_content(content):
        return False
    
    return True


def is_valid_dataset(data: List[Dict[str, Any]]) -> bool:
    """检查整个数据集是否有效（无高相似度重复）"""
    return not has_duplicate_texts(data, threshold=0.9)


def get_gt():
    from pathlib import Path

    # 获取 eval.py 所在目录
    current_dir = Path(__file__).resolve().parent

    # 找到 expected 目录
    expected_dir = (current_dir / "./expected").resolve()

    # 查找第一个 .csv 文件
    csv_files = list(expected_dir.glob("*.csv"))

    if not csv_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")

    # 取第一个文件作为 expected_path
    expected_path = csv_files[0]

    return expected_path


def evaluate(processed_path):
    expected_path = get_gt()
    expected = load_csv(expected_path)
    processed = load_csv(processed_path)

    # 构造映射方便比对
    expected_map = {entry["review_id"]: entry for entry in expected}
    processed_map = {entry["review_id"]: entry for entry in processed}

    # 只评估交集部分
    common_ids = set(expected_map.keys()) & set(processed_map.keys())

    true_positives = 0
    failed_ids = []
    
    for review_id in common_ids:
        gt = expected_map[review_id]
        pred = processed_map[review_id]

        # text 和 content 都相同且记录有效
        if (gt["text"].strip() == pred["text"].strip() and 
            gt["content"].strip() == pred["content"].strip() and
            is_valid_record(pred) and 
            gt.get("category") == pred.get("category")):
            true_positives += 1
        else:
            failed_ids.append(review_id)

    # 检查是否有不应该出现的记录（在processed中但不在expected中）
    unexpected_ids = set(processed_map.keys()) - set(expected_map.keys())
    
    # 检查是否有遗漏的记录（在expected中但不在processed中）
    missing_ids = set(expected_map.keys()) - set(processed_map.keys())

    # 检查整个数据集的去重效果
    dataset_valid = is_valid_dataset(processed)

    predicted_total = len(processed_map)
    gold_total = len(expected_map)

    precision = true_positives / predicted_total if predicted_total > 0 else 0.0
    recall = true_positives / gold_total if gold_total > 0 else 0.0
    f1 = (2 * precision * recall) / (precision + recall) if precision + recall > 0 else 0.0

    # 如果数据集中存在高相似度重复，降低F1分数
    if not dataset_valid:
        f1 *= 0.5  # 惩罚因子
        print("警告: 检测到高相似度重复文本，F1分数已降低")

    # 输出详细信息用于调试
    if failed_ids:
        print(f"Failed IDs: {failed_ids[:10]}...")  # 只显示前10个
    if unexpected_ids:
        print(f"Unexpected records (should be filtered): {len(unexpected_ids)}")
    if missing_ids:
        print(f"Missing records (should be kept): {len(missing_ids)}")
    
    result = {"eval_score": f"{f1:.4f}"}
    print(result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-o", "--output", help="Path to processed results file", required=True)
    args = parser.parse_args()

    evaluate(args.output)