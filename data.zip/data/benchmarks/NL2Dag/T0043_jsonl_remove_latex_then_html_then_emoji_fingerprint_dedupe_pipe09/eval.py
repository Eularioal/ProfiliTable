#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Evaluate submissions for the 'LaTeX+HTML+Emoji cleansing & dedup' task.

Usage
-----
python eval.py -o /path/to/your_output.jsonl
"""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
import sys
from pathlib import Path
from typing import Dict, Tuple

ROOT = Path(__file__).resolve().parent
GT_PATH = ROOT / "expected" / "gt.jsonl"

# --------------------------------------------------------------------------- #
# 1. Official cleansing pipeline                                              #
# --------------------------------------------------------------------------- #
RE_LATEX = re.compile(r"(\\[a-zA-Z]+(\{.*?\})*)|(\$[^$]*\$)")
RE_HTML  = re.compile(r"<[^>]+>")
RE_EMOJI = re.compile(
    "["
    "\U0001F300-\U0001F6FF"
    "\U0001F700-\U0001F77F"
    "\U0001F780-\U0001F7FF"
    "\U0001F800-\U0001F8FF"
    "\U0001F900-\U0001F9FF"
    "\U0001FA00-\U0001FA6F"
    "]+", flags=re.UNICODE,
)

def clean(text: str) -> str:
    text = RE_LATEX.sub("", text)
    text = RE_HTML.sub("", text)
    text = html.unescape(text)
    text = RE_EMOJI.sub("", text)
    return " ".join(text.split())          # squash blanks & trim

def fp(text: str) -> str:
    """SHA-1 fingerprint of cleaned text (hex str)."""
    return hashlib.sha1(text.encode("utf-8")).hexdigest()

# --------------------------------------------------------------------------- #
# 2. Helpers                                                                  #
# --------------------------------------------------------------------------- #
def load_jsonl(path: Path, *, must_have: Tuple[str, ...] = ("id", "text")) -> Dict[str, dict]:
    """Return dict indexed by line number (for duplicate checking)."""
    if not path.is_file():
        sys.exit(f"[Eval] File not found: {path}")

    data: Dict[str, dict] = {}
    with path.open(encoding="utf-8") as f:
        for ln, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                sys.exit(f"[Eval] {path} L{ln}: invalid JSON — {e}")
            for k in must_have:
                if k not in obj:
                    sys.exit(f"[Eval] {path} L{ln}: missing '{k}'")

            data[str(ln)] = obj   # keep raw order reference
    return data

def build_fp_index(records: Dict[str, dict]) -> Dict[str, dict]:
    """
    Convert {ln: obj} -> {fingerprint: {'id': id_min, 'text': cleaned_text}}
    keeping the *minimal* id per fingerprint.
    """
    idx: Dict[str, dict] = {}
    for obj in records.values():
        ctext = clean(obj["text"])
        h = fp(ctext)
        cid = obj["id"]
        if isinstance(cid, (int, float)):
            cid = int(cid)
        if h not in idx or cid < idx[h]["id"]:
            idx[h] = {"id": cid, "text": ctext}
    return idx

def precision_recall_f1(gt: Dict[str, dict], pred: Dict[str, dict]) -> Tuple[float, float, float]:
    if not pred:
        return 0.0, 0.0, 0.0
    tp = sum(
        1
        for h, v in pred.items()
        if h in gt and v["id"] == gt[h]["id"] and v["text"] == gt[h]["text"]
    )
    p = tp / len(pred)
    r = tp / len(gt)
    f1 = 0.0 if p + r == 0 else 2 * p * r / (p + r)
    return p, r, f1

# --------------------------------------------------------------------------- #
# 3. Main                                                                     #
# --------------------------------------------------------------------------- #
def main() -> None:
    ap = argparse.ArgumentParser(description="Evaluator for cleansing-dedup task")
    ap.add_argument("-o", "--output", required=True, help="Your result jsonl")
    args = ap.parse_args()

    # load & index
    gt_raw   = load_jsonl(GT_PATH)
    pred_raw = load_jsonl(Path(args.output))

    gt_idx   = build_fp_index(gt_raw)
    pred_idx = build_fp_index(pred_raw)

    # metric
    _, _, f1 = precision_recall_f1(gt_idx, pred_idx)
    print({"eval_score": f"{f1:.4f}"})

if __name__ == "__main__":
    main()