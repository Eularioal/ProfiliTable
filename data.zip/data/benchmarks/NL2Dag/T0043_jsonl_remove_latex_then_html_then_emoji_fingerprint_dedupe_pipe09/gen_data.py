#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成带噪声的 raw/customers.jsonl 与清洗去重后的 expected/gt.jsonl
"""
import json, os, random, re, html, hashlib, pathlib, string

ROOT = pathlib.Path(__file__).parent
RAW_FILE = ROOT / "raw" / "customers.jsonl"
GT_FILE  = ROOT / "expected" / "gt.jsonl"
RAW_FILE.parent.mkdir(parents=True, exist_ok=True)
GT_FILE.parent.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------------------------
# 1. 构造噪声文本
# ------------------------------------------------------------------------------
EMOJIS   = ["😊", "🚀", "💡", "🔥", "📚", "🧪", "🎉"]
HTML_TAG = ["<b>{}</b>", "<i>{}</i>", "<span style='color:red'>{}</span>"]
LATEX    = [r"$E=mc^2$", r"\alpha+\beta=\gamma", r"\frac{1}{2}\pi r^2"]
ENTITIES = ["&amp;", "&lt;", "&gt;", "&quot;", "&#39;"]

def noisy_sentence(idx: int) -> str:
    base = f"Sample text number {idx}"
    # 随机插入组件
    pieces = [
        base,
        random.choice(EMOJIS),
        random.choice(HTML_TAG).format("bold"),
        random.choice(LATEX),
        random.choice(ENTITIES),
    ]
    random.shuffle(pieces)
    return " ".join(pieces)

# ------------------------------------------------------------------------------
# 2. 清洗管线
# ------------------------------------------------------------------------------
RE_LATEX       = re.compile(r"(\\[a-zA-Z]+(\{.*?\})*)|(\$[^$]*\$)")
RE_HTML_TAG    = re.compile(r"<[^>]+>")
RE_EMOJI       = re.compile(
    "["
    "\U0001F300-\U0001F6FF"  # symbols & pictographs
    "\U0001F700-\U0001F77F"  # alchemical
    "\U0001F780-\U0001F7FF"
    "\U0001F800-\U0001F8FF"
    "\U0001F900-\U0001F9FF"
    "\U0001FA00-\U0001FA6F"
    "]+", flags=re.UNICODE)

def clean(text: str) -> str:
    text = RE_LATEX.sub("", text)          # 去 LaTeX
    text = RE_HTML_TAG.sub("", text)       # 去 HTML
    text = html.unescape(text)             # 解码实体
    text = RE_EMOJI.sub("", text)          # 去 emoji
    return " ".join(text.split())          # 标准化空白

def fingerprint(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8")).hexdigest()

# ------------------------------------------------------------------------------
# 3. 生成 customers（带噪声）
# ------------------------------------------------------------------------------
N = 150  # ≥100
raw_records = []
for idx in range(1, N + 1):
    record = {
        "id": idx,
        "text": noisy_sentence(idx),
        "meta": {"rand": random.random()}
    }
    raw_records.append(record)

with RAW_FILE.open("w", encoding="utf-8") as f:
    for rec in raw_records:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")

# ------------------------------------------------------------------------------
# 4. 生成 gt（清洗＋指纹去重，保留最小 id）
# ------------------------------------------------------------------------------
fp_seen = {}
for rec in raw_records:
    cleaned = clean(rec["text"])
    fp = fingerprint(cleaned)
    if fp not in fp_seen or rec["id"] < fp_seen[fp]["id"]:
        fp_seen[fp] = {"id": rec["id"], "text": cleaned}

# 排序输出（按 id）
gt_records = sorted(fp_seen.values(), key=lambda x: x["id"])
with GT_FILE.open("w", encoding="utf-8") as f:
    for rec in gt_records:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")

print(f"✔  Generated {len(raw_records)} raw lines → {len(gt_records)} GT lines")