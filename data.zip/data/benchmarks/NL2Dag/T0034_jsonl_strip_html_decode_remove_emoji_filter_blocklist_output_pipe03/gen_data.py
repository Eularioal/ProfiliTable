#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成测试数据：
1. raw/customers.jsonl      —— 原始(未清洗)数据
2. expected/gt.jsonl        —— 清洗+过滤后的 GT 数据
"""
from __future__ import annotations
import json, random, re, os, html
from pathlib import Path
from faker import Faker

fake = Faker("zh_CN")
random.seed(42)
Faker.seed(42)

# ==== 配置 ====
N_RECORDS           = 150                         # >100 条
BLOCKED_PATTERNS    = [
    r"坏词", r"(?i)\bforbidden\b", r"敏感\d+",   # 示例; 支持正则+大小写不敏感
]
EMOJI_RE = re.compile(
    "[\U0001F600-\U0001F64F"  # emoticons
    "\U0001F300-\U0001F5FF"   # symbols & pictographs
    "\U0001F680-\U0001F6FF"   # transport & map symbols
    "\U0001F1E0-\U0001F1FF"   # flags
    "]+", flags=re.UNICODE
)
TAG_RE       = re.compile(r"<[^>]+>")
BLOCK_RE     = re.compile("|".join(BLOCKED_PATTERNS))

RAW_DIR      = Path("raw")
EXPECT_DIR   = Path("expected")
RAW_DIR.mkdir(exist_ok=True)
EXPECT_DIR.mkdir(exist_ok=True)

raw_path = RAW_DIR / "customers.jsonl"
gt_path  = EXPECT_DIR / "gt.jsonl"

def random_html_sentence() -> str:
    """拼接带有 HTML、实体、Emoji、可能的屏蔽词的随机句子"""
    txt = fake.sentence(nb_words=random.randint(4,10))
    # 随机插入一个屏蔽词
    if random.random() < 0.2:
        txt += " " + random.choice(["坏词", "ForBidden", f"敏感{random.randint(1,9)}"])
    # 随机加实体
    txt = txt.replace("。", "&amp;nbsp;。")
    # 随机加 HTML 标签
    txt = f"<p><strong>{txt}</strong></p>"
    # 随机加 Emoji
    if random.random() < 0.3:
        txt += random.choice(["😊", "🚀", "👍"])
    return txt

def strip_html(text:str) -> str:
    text = TAG_RE.sub("", text)          # 去标签
    text = html.unescape(text)           # 解码实体
    text = EMOJI_RE.sub("", text)        # 去 Emoji
    return text.strip()

def blocked(text:str) -> bool:
    return bool(BLOCK_RE.search(text))

def main() -> None:
    with raw_path.open("w", encoding="utf-8") as raw_f, \
         gt_path.open("w", encoding="utf-8")  as gt_f:
        for idx in range(N_RECORDS):
            rec = {
                "id": idx + 1,
                "text": random_html_sentence()
            }
            raw_f.write(json.dumps(rec, ensure_ascii=False) + "\n")

            cleaned = strip_html(rec["text"])
            if not blocked(cleaned):
                gt_f.write(json.dumps({"id": rec["id"], "text": cleaned}, ensure_ascii=False) + "\n")

    print(f"✓ 生成完成：{raw_path} ({raw_path.stat().st_size} bytes)")
    print(f"✓ 生成完成：{gt_path}  ({gt_path.stat().st_size} bytes)")

if __name__ == "__main__":
    main()