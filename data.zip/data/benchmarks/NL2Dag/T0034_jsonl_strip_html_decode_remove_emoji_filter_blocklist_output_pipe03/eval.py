#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Evaluate the “HTML/Emoji clean + block-word filter” task.

与参考脚本不同，本评测不仅比较 **id 覆盖**，还要检验 **text 内容是否与基准完全一致**，
因此采用「逐行比对的 F1-score」作为最终得分，范围 0-1。

评测流程
--------
1. 读取 expected/gt.jsonl 作为基准集，得到 {id -> text} 映射。
2. 读取参赛选手的结果文件：
   • 必须是合法 JSONL，每行包含 id 与 text 字段。  
   • 同一 id 出现多次将报错。
3. 逐条比对：只当 (id 存在且 text 完全一致) 时记为 TP；  
   id 存在但 text 不一致视为 FP + FN 同时计入。
4. 计算
        precision = TP / (TP + FP)
        recall    = TP / (TP + FN)
        F1        = 2 * P * R / (P + R)
   若分母为 0，相关指标记 0。
5. 输出形如：{"eval_score": "0.8734"}

用法
----
python eval.py -o /path/to/your_submission.jsonl
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, Tuple

# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #
GT_PATH = Path(__file__).parent / "expected" / "gt.jsonl"


# --------------------------------------------------------------------------- #
# Utils
# --------------------------------------------------------------------------- #
def load_id2text(path: Path) -> Dict[int, str]:
    """
    Read a JSONL file -> {id: text}.  Raise on malformed lines / duplicate ids.
    """
    if not path.is_file():
        sys.exit(f"[ERR] File not found: {path}")

    id2text: Dict[int, str] = {}
    with path.open(encoding="utf-8") as fh:
        for ln, raw in enumerate(fh, 1):
            if not raw.strip():      # 跳过空行
                continue
            try:
                obj = json.loads(raw)
            except json.JSONDecodeError as e:
                sys.exit(f"[ERR] {path}:{ln} 不是合法 JSON -> {e}")
            if "id" not in obj or "text" not in obj:
                sys.exit(f"[ERR] {path}:{ln} 缺少 id / text 字段")
            _id = obj["id"]
            if _id in id2text:
                sys.exit(f"[ERR] {path}:{ln} id {_id} 重复出现")
            id2text[_id] = obj["text"]
    return id2text


def compute_f1(
    gt_map: Dict[int, str], pred_map: Dict[int, str]
) -> Tuple[float, int, int, int]:
    """
    Return F1 plus (tp, fp, fn) counts.
    """
    tp = fp = fn = 0

    for pid, ptext in pred_map.items():
        if pid in gt_map and ptext == gt_map[pid]:
            tp += 1
        else:
            fp += 1

    for gid in gt_map:
        if gid not in pred_map:
            fn += 1
        elif pred_map[gid] != gt_map[gid]:
            fn += 1  # text mismatch already counted fp↑, 这里再计 fn

    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall    = tp / (tp + fn) if (tp + fn) else 0.0

    if precision + recall == 0:
        return 0.0, tp, fp, fn
    return 2 * precision * recall / (precision + recall), tp, fp, fn


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main() -> None:
    ap = argparse.ArgumentParser(description="Evaluate clean-filter task")
    ap.add_argument(
        "-o", "--output", required=True, help="Your submission (.jsonl, utf-8)"
    )
    args = ap.parse_args()

    gt_map   = load_id2text(GT_PATH)
    pred_map = load_id2text(Path(args.output).expanduser())

    score, tp, fp, fn = compute_f1(gt_map, pred_map)

    print({"eval_score": f"{score:.4f}"})
    # 供调试用，可注释掉
    # print(f"[DBG] tp={tp} fp={fp} fn={fn} | gt={len(gt_map)} pred={len(pred_map)}")


if __name__ == "__main__":
    main()