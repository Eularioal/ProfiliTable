import pandas as pd
import numpy as np
import random
import os
import re
from datetime import datetime, timedelta

def generate_text_with_issues():
    """生成包含多余空格和重复单词的文本"""
    base_texts = [
        "This is a great product with excellent quality",
        "The service was amazing and the staff very helpful",
        "I love this place it has wonderful atmosphere",
        "The food was delicious and the price reasonable",
        "Excellent customer service and fast delivery",
        "Great value for money and high quality",
        "Outstanding product with perfect design",
        "Wonderful experience and friendly staff",
        "Amazing quality and beautiful presentation",
        "Perfect location with easy access"
    ]
    
    issues_to_add = [
        # 添加多余空格的函数
        lambda text: f"  {text}  ",  # 前后空格
        lambda text: f" {text} ",    # 前后单个空格
        lambda text: text.replace(" ", "  "),  # 单词间双空格
        lambda text: text.replace(" ", "   "), # 单词间三空格
        lambda text: re.sub(r'\s+', '  ', text),  # 多个空格
        
        # 添加重复单词的函数
        lambda text: text.replace("great", "great great"),
        lambda text: text.replace("the", "the the"),
        lambda text: text.replace("and", "and and"),
        lambda text: text.replace("with", "with with"),
        lambda text: text.replace("was", "was was"),
        lambda text: text.replace("is", "is is"),
        lambda text: text.replace("has", "has has"),
        
        # 组合问题
        lambda text: f"  {text.replace('excellent', 'excellent excellent')}  ",
        lambda text: f" {text.replace(' ', '  ').replace('service', 'service service')} ",
        lambda text: text.replace("amazing", "amazing amazing amazing").replace(" ", "   "),
    ]
    
    text = random.choice(base_texts)
    
    # 随机应用1-3个问题
    num_issues = random.randint(1, 3)
    selected_issues = random.sample(issues_to_add, num_issues)
    
    for issue_func in selected_issues:
        text = issue_func(text)
    
    return text

def clean_text(text):
    """清理文本：删除多余空格并移除连续重复的单词"""
    if pd.isna(text):
        return text
    
    # 删除多余空格
    text = str(text).strip()
    text = re.sub(r'\s+', ' ', text)
    
    # 移除连续重复的单词
    words = text.split()
    cleaned_words = []
    prev_word = None
    
    for word in words:
        if word != prev_word:
            cleaned_words.append(word)
        prev_word = word
    
    return ' '.join(cleaned_words)

def generate_data():
    """生成原始数据和清洗后的数据"""
    np.random.seed(42)
    random.seed(42)
    
    # 确保目录存在
    os.makedirs('raw', exist_ok=True)
    os.makedirs('expected', exist_ok=True)
    
    # 生成基础数据
    n_records = 200
    data = []
    
    categories = ['Electronics', 'Clothing', 'Books', 'Home & Garden', 'Sports', 'Toys']
    
    for i in range(n_records):
        # 生成包含问题的文本
        text_with_issues = generate_text_with_issues()
        
        record = {
            'id': f'record_{i:04d}',
            'text': text_with_issues,
            'rating': round(random.uniform(1, 5), 1),
            'price': round(random.uniform(10, 1000), 2),
            'quantity': random.randint(1, 100),
            'category': random.choice(categories),
            'date': (datetime(2023, 1, 1) + timedelta(days=random.randint(0, 365))).strftime('%Y-%m-%d'),
            'score': round(random.uniform(0, 100), 2)
        }
        data.append(record)
    
    # 创建DataFrame
    df_raw = pd.DataFrame(data)
    
    # 随机添加缺失值
    missing_indices = random.sample(range(len(df_raw)), 30)
    for idx in missing_indices:
        # 随机选择一个数值列添加缺失值
        numeric_col = random.choice(['rating', 'price', 'quantity', 'score'])
        df_raw.loc[idx, numeric_col] = np.nan
    
    # 为非数值列添加一些缺失值
    missing_indices_cat = random.sample(range(len(df_raw)), 15)
    for idx in missing_indices_cat:
        df_raw.loc[idx, 'category'] = np.nan
    
    # 保存原始数据
    df_raw.to_csv('raw/customers.csv', index=False, encoding='utf-8')
    
    # 清洗数据生成GT
    df_clean = df_raw.copy()
    
    # 1. 清理text字段
    df_clean['text'] = df_clean['text'].apply(clean_text)
    
    # 2. 按列类型填充缺失值
    # 数值列用中位数填充
    numeric_columns = df_clean.select_dtypes(include=[np.number]).columns
    for col in numeric_columns:
        median_val = df_clean[col].median()
        df_clean[col] = df_clean[col].fillna(median_val)
    
    # 分类列用众数填充
    categorical_columns = df_clean.select_dtypes(include=['object']).columns
    categorical_columns = [col for col in categorical_columns if col != 'text']  # 排除text列
    
    for col in categorical_columns:
        mode_val = df_clean[col].mode()
        if len(mode_val) > 0:
            df_clean[col] = df_clean[col].fillna(mode_val[0])
    
    # 保存清洗后的数据
    df_clean.to_csv('expected/gt.csv', index=False, encoding='utf-8')
    
    print(f"原始数据生成完成: {len(df_raw)} 条记录")
    print(f"清洗后数据生成完成: {len(df_clean)} 条记录")
    
    # 统计信息
    print(f"原始数据中数值列缺失值: {df_raw[numeric_columns].isna().sum().sum()}")
    print(f"原始数据中分类列缺失值: {df_raw[categorical_columns].isna().sum().sum()}")
    print(f"清洗后数据中总缺失值: {df_clean.isna().sum().sum()}")
    
    # 显示一些text清理的例子
    print("\n文本清理示例:")
    for i in range(5):
        print(f"原始: {df_raw.iloc[i]['text']}")
        print(f"清理: {df_clean.iloc[i]['text']}")
        print()

if __name__ == "__main__":
    generate_data()