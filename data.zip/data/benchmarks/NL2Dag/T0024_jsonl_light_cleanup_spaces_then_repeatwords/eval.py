import argparse
import csv
import pandas as pd
import numpy as np
import re
from typing import List, Dict, Any


def load_csv(path):
    """加载CSV文件"""
    try:
        df = pd.read_csv(path, encoding='utf-8')
        return df.to_dict('records')
    except:
        # 如果UTF-8失败，尝试其他编码
        df = pd.read_csv(path, encoding='gbk')
        return df.to_dict('records')


def has_extra_spaces(text: str) -> bool:
    """检查文本是否包含多余空格"""
    if pd.isna(text):
        return False
    
    text = str(text)
    
    # 检查开头或结尾是否有空格
    if text != text.strip():
        return True
    
    # 检查是否有连续的多个空格
    if re.search(r'\s{2,}', text):
        return True
    
    return False


def has_consecutive_duplicate_words(text: str) -> bool:
    """检查文本是否包含连续重复的单词"""
    if pd.isna(text):
        return False
    
    text = str(text).strip()
    words = text.split()
    
    for i in range(len(words) - 1):
        if words[i] == words[i + 1]:
            return True
    
    return False


def check_text_cleaning(data: List[Dict[str, Any]]) -> bool:
    """检查text字段是否正确清理"""
    for record in data:
        text = record.get('text', '')
        
        # 检查是否还有多余空格
        if has_extra_spaces(text):
            return False
        
        # 检查是否还有连续重复的单词
        if has_consecutive_duplicate_words(text):
            return False
    
    return True


def check_missing_value_imputation(data: List[Dict[str, Any]]) -> bool:
    """检查缺失值是否正确填充"""
    if not data:
        return True
    
    df = pd.DataFrame(data)
    
    # 检查是否还有缺失值
    if df.isna().any().any():
        return False
    
    return True


def is_valid_record(record: Dict[str, Any]) -> bool:
    """检查单条记录是否有效"""
    # 检查text字段
    text = record.get('text', '')
    
    if has_extra_spaces(text):
        return False
    
    if has_consecutive_duplicate_words(text):
        return False
    
    return True


def calculate_text_cleaning_accuracy(expected_data: List[Dict[str, Any]], 
                                   processed_data: List[Dict[str, Any]]) -> float:
    """计算文本清理的准确率"""
    if len(expected_data) != len(processed_data):
        return 0.0
    
    correct_count = 0
    total_count = len(expected_data)
    
    # 构建映射
    expected_map = {record['id']: record for record in expected_data}
    processed_map = {record['id']: record for record in processed_data}
    
    for record_id in expected_map:
        if record_id in processed_map:
            expected_text = str(expected_map[record_id].get('text', '')).strip()
            processed_text = str(processed_map[record_id].get('text', '')).strip()
            
            if expected_text == processed_text:
                correct_count += 1
    
    return correct_count / total_count if total_count > 0 else 0.0


def calculate_missing_value_accuracy(expected_data: List[Dict[str, Any]], 
                                   processed_data: List[Dict[str, Any]]) -> float:
    """计算缺失值填充的准确率"""
    if len(expected_data) != len(processed_data):
        return 0.0
    
    expected_df = pd.DataFrame(expected_data)
    processed_df = pd.DataFrame(processed_data)
    
    # 检查数值列是否用中位数正确填充
    numeric_columns = expected_df.select_dtypes(include=[np.number]).columns
    
    total_accuracy = 0.0
    total_columns = 0
    
    for col in expected_df.columns:
        if col in processed_df.columns:
            expected_series = expected_df[col]
            processed_series = processed_df[col]
            
            # 对于数值列，检查值是否匹配（允许小误差）
            if col in numeric_columns:
                try:
                    expected_vals = pd.to_numeric(expected_series, errors='coerce')
                    processed_vals = pd.to_numeric(processed_series, errors='coerce')
                    
                    # 计算匹配度
                    matches = np.abs(expected_vals - processed_vals) < 1e-6
                    accuracy = matches.sum() / len(matches)
                    total_accuracy += accuracy
                    total_columns += 1
                except:
                    pass
            else:
                # 对于非数值列，直接比较
                matches = expected_series.astype(str) == processed_series.astype(str)
                accuracy = matches.sum() / len(matches)
                total_accuracy += accuracy
                total_columns += 1
    
    return total_accuracy / total_columns if total_columns > 0 else 0.0


def get_gt():
    """获取标准答案文件路径"""
    from pathlib import Path
    
    current_dir = Path(__file__).resolve().parent
    expected_dir = (current_dir / "./expected").resolve()
    csv_files = list(expected_dir.glob("*.csv"))
    
    if not csv_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")
    
    return csv_files[0]


def evaluate(processed_path):
    """评估处理结果"""
    expected_path = get_gt()
    expected = load_csv(expected_path)
    processed = load_csv(processed_path)
    
    # 基础检查
    text_cleaning_ok = check_text_cleaning(processed)
    missing_value_ok = check_missing_value_imputation(processed)
    
    # 计算准确率
    text_accuracy = calculate_text_cleaning_accuracy(expected, processed)
    missing_value_accuracy = calculate_missing_value_accuracy(expected, processed)
    
    # 计算整体分数
    # 文本清理占60%，缺失值填充占40%
    overall_score = 0.6 * text_accuracy + 0.4 * missing_value_accuracy
    
    # 如果基础检查不通过，严重降低分数
    if not text_cleaning_ok:
        overall_score *= 0.3
    
    if not missing_value_ok:
        overall_score *= 0.5
    
    # 确保分数在0-1之间
    overall_score = max(0.0, min(1.0, overall_score))
    
    result = {"eval_score": f"{overall_score:.4f}"}
    print(result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-o", "--output", help="Path to processed results file", required=True)
    args = parser.parse_args()
    
    evaluate(args.output)