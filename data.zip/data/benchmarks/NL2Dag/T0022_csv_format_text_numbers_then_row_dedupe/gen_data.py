import csv
import re
import random
import os
import numpy as np
import pandas as pd
from typing import List, Dict, Any

def generate_raw_data() -> List[Dict[str, Any]]:
    """生成包含各种问题的原始数据"""
    
    # 包含各种数字格式的文本样本
    text_samples = [
        "The price is 99.5 dollars",  # 一位小数
        "Total cost: 123.456 yuan",  # 三位小数
        "Amount: 45 cents",  # 整数
        "Value is 78.99 units",  # 已经是两位小数
        "Cost 234.1 per item",  # 一位小数
        "Price: 567.8900 each",  # 多位小数后面有0
        "Total 89 pieces",  # 整数
        "Rate: 12.345 percent",  # 三位小数
        "Fee is 456.70 dollars",  # 已经是两位小数
        "Sum: 789.12345 total",  # 五位小数
        "Cost 23.4 per unit",  # 一位小数
        "Price 345.67 each",  # 已经是两位小数
        "Value: 678.9 items",  # 一位小数
        "Amount 90.123 units",  # 三位小数
        "Total: 123.4567 pieces",  # 四位小数
        "Fee 45.6 dollars",  # 一位小数
        "Rate is 78.90 percent",  # 已经是两位小数
        "Cost: 234.567 each",  # 三位小数
        "Price 456 per item",  # 整数
        "Value: 789.01 units",  # 已经是两位小数
        "Discount of 15.5 percent applied",  # 一位小数
        "Tax rate 8.75 percent",  # 两位小数
        "Shipping cost 12 dollars",  # 整数
        "Weight: 3.14159 kg",  # 五位小数
        "Length is 45.6789 cm",  # 四位小数
        "Width: 23.5 inches",  # 一位小数
        "Height 67.890 mm",  # 三位小数（后面有0）
        "Volume: 123.45 liters",  # 两位小数
        "Temperature 36.7 degrees",  # 一位小数
        "Pressure: 101.325 kPa"  # 三位小数
    ]
    
    # 客户名称样本
    customer_names = [
        "John Smith", "Jane Doe", "Bob Wilson", "Alice Brown", "Charlie Davis",
        "Diana Miller", "Edward Jones", "Fiona Garcia", "George Martinez", "Helen Anderson",
        "Ivan Taylor", "Julia Thomas", "Kevin Jackson", "Linda White", "Mark Harris",
        "Nancy Martin", "Oscar Thompson", "Paula Garcia", "Quincy Lee", "Rachel Walker",
        "Steve Hall", "Tina Allen", "Victor Young", "Wendy King", "Xavier Wright",
        "Yvonne Lopez", "Zachary Hill", "Amy Green", "Brian Adams", "Carol Baker"
    ]
    
    # 产品类别样本
    categories = [
        "Electronics", "Clothing", "Books", "Home & Garden", "Sports",
        "Toys", "Health", "Beauty", "Automotive", "Tools",
        "Food", "Jewelry", "Music", "Movies", "Games"
    ]
    
    raw_data = []
    
    # 生成基础数据
    for i in range(120):
        customer_id = i + 1
        name = random.choice(customer_names)
        text = random.choice(text_samples)
        category = random.choice(categories)
        
        # 生成数值列，有些包含缺失值
        age = random.randint(18, 80) if random.random() > 0.1 else None  # 10%缺失率
        score = round(random.uniform(60, 100), 2) if random.random() > 0.15 else None  # 15%缺失率
        amount = round(random.uniform(100, 5000), 2) if random.random() > 0.12 else None  # 12%缺失率
        rating = round(random.uniform(1, 5), 1) if random.random() > 0.08 else None  # 8%缺失率
        
        raw_data.append({
            "customer_id": customer_id,
            "name": name,
            "text": text,
            "category": category,
            "age": age,
            "score": score,
            "amount": amount,
            "rating": rating
        })
    
    # 添加一些完全重复的记录用于测试去重
    duplicate_records = []
    for i in range(10):
        # 复制前10条记录
        original = raw_data[i].copy()
        duplicate_records.append(original)
        # 再添加一份
        duplicate_records.append(original.copy())
    
    # 添加重复记录到原始数据中
    raw_data.extend(duplicate_records)
    
    # 再添加一些额外数据以达到150+条
    for i in range(120, 160):
        customer_id = i + 1
        name = random.choice(customer_names)
        text = random.choice(text_samples)
        category = random.choice(categories)
        
        age = random.randint(18, 80) if random.random() > 0.1 else None
        score = round(random.uniform(60, 100), 2) if random.random() > 0.15 else None
        amount = round(random.uniform(100, 5000), 2) if random.random() > 0.12 else None
        rating = round(random.uniform(1, 5), 1) if random.random() > 0.08 else None
        
        raw_data.append({
            "customer_id": customer_id,
            "name": name,
            "text": text,
            "category": category,
            "age": age,
            "score": score,
            "amount": amount,
            "rating": rating
        })
    
    # 随机打乱数据顺序
    random.shuffle(raw_data)
    
    return raw_data

def format_numbers_in_text(text: str) -> str:
    """将文本中的数字格式化为两位小数"""
    def replace_number(match):
        number = float(match.group())
        return f"{number:.2f}"
    
    # 匹配数字（包括小数）
    pattern = r'\b\d+\.?\d*\b'
    return re.sub(pattern, replace_number, text)

def remove_exact_duplicates(data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """精确去重，保留首行出现的记录"""
    seen_records = set()
    deduplicated_data = []
    
    for record in data:
        # 创建记录的哈希用于去重（处理None值）
        record_items = []
        for k, v in sorted(record.items()):
            if v is None:
                record_items.append((k, 'NULL'))
            else:
                record_items.append((k, str(v)))
        record_tuple = tuple(record_items)
        
        if record_tuple not in seen_records:
            seen_records.add(record_tuple)
            deduplicated_data.append(record)
    
    return deduplicated_data

def fill_missing_values(data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """根据列类型自动填补缺失值，数值列用均值填充"""
    if not data:
        return data
    
    # 转换为DataFrame进行处理
    df = pd.DataFrame(data)
    
    # 识别数值列和非数值列
    numeric_columns = []
    non_numeric_columns = []
    
    for col in df.columns:
        # 尝试转换为数值类型来判断是否为数值列
        try:
            # 先替换None为NaN
            temp_series = df[col].replace([None, 'None', ''], np.nan)
            # 尝试转换为数值
            pd.to_numeric(temp_series, errors='raise')
            numeric_columns.append(col)
        except (ValueError, TypeError):
            non_numeric_columns.append(col)
    
    # 处理数值列：用均值填充
    for col in numeric_columns:
        if col in df.columns:
            # 转换为数值类型
            df[col] = pd.to_numeric(df[col], errors='coerce')
            # 用均值填充缺失值
            if df[col].notna().sum() > 0:  # 确保有非空值
                mean_value = df[col].mean()
                df[col].fillna(mean_value, inplace=True)
    
    # 处理非数值列：用最频繁的值填充
    for col in non_numeric_columns:
        if col in df.columns:
            mode_values = df[col].mode()
            if len(mode_values) > 0:
                df[col].fillna(mode_values[0], inplace=True)
    
    # 转换回字典列表
    result = df.to_dict('records')
    
    return result

def process_data(raw_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """处理数据，应用所有处理规则"""
    # 第一步：格式化text列中的数字为两位小数
    for record in raw_data:
        if 'text' in record and record['text']:
            record['text'] = format_numbers_in_text(record['text'])
    
    # 第二步：精确去重，保留首行出现的记录
    deduped_data = remove_exact_duplicates(raw_data)
    
    # 第三步：填补缺失值
    filled_data = fill_missing_values(deduped_data)
    
    return filled_data

def save_to_csv(data: List[Dict[str, Any]], filepath: str):
    """保存数据到CSV文件（UTF-8编码）"""
    if not data:
        return
    
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    # 确保数值字段的格式正确
    for record in data:
        for key, value in record.items():
            if isinstance(value, float):
                # 保持浮点数的精度
                if key in ['age']:
                    record[key] = int(round(value))  # age应该是整数
                else:
                    record[key] = round(value, 2)  # 其他数值保留两位小数
    
    with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = data[0].keys()
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)

def main():
    """主函数，生成测试数据"""
    print("生成原始数据...")
    raw_data = generate_raw_data()
    print(f"生成了 {len(raw_data)} 条原始记录")
    
    print("处理数据...")
    gt_data = process_data(raw_data)
    print(f"处理后得到了 {len(gt_data)} 条记录")
    
    # 保存原始数据到 raw/customers.csv
    print("保存原始数据到 raw/customers.csv...")
    save_to_csv(raw_data, 'raw/customers.csv')
    
    # 保存处理后的数据到 expected/gt.csv
    print("保存GT数据到 expected/gt.csv...")
    save_to_csv(gt_data, 'expected/gt.csv')
    
    print("数据生成完成！")
    print(f"原始数据: {len(raw_data)} 条记录")
    print(f"GT数据: {len(gt_data)} 条记录")
    print(f"去重率: {(len(raw_data) - len(gt_data)) / len(raw_data) * 100:.1f}%")
    
    # 统计缺失值情况
    missing_count = 0
    total_values = 0
    for record in raw_data:
        for key, value in record.items():
            total_values += 1
            if value is None:
                missing_count += 1
    
    print(f"原始数据缺失值比例: {missing_count / total_values * 100:.1f}%")

if __name__ == "__main__":
    main()