import argparse
import csv
import os
import re
import numpy as np
import pandas as pd
from typing import List, Dict, Any


def load_csv(path):
    data = []
    with open(path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # 转换数值字段
            for key, value in row.items():
                if key in ['customer_id', 'age']:
                    try:
                        row[key] = int(float(value)) if value else None
                    except (ValueError, TypeError):
                        row[key] = None
                elif key in ['score', 'amount', 'rating']:
                    try:
                        row[key] = float(value) if value else None
                    except (ValueError, TypeError):
                        row[key] = None
            data.append(row)
    return data


def are_numbers_formatted(text: str) -> bool:
    """检查文本中的数字是否都格式化为两位小数"""
    if not text:
        return True
    
    # 查找所有数字
    numbers = re.findall(r'\b\d+\.?\d*\b', text)
    
    for num_str in numbers:
        try:
            # 检查是否为两位小数格式
            if '.' in num_str:
                decimal_part = num_str.split('.')[1]
                if len(decimal_part) != 2:
                    return False
            else:
                # 整数应该被格式化为.00
                return False
        except (ValueError, IndexError):
            continue
    
    return True


def check_no_exact_duplicates(data: List[Dict[str, Any]]) -> bool:
    """检查是否存在完全重复的记录"""
    seen_records = set()
    
    for record in data:
        # 创建记录的哈希用于检查重复
        record_items = []
        for k, v in sorted(record.items()):
            if v is None:
                record_items.append((k, 'NULL'))
            else:
                record_items.append((k, str(v)))
        record_tuple = tuple(record_items)
        
        if record_tuple in seen_records:
            return False
        seen_records.add(record_tuple)
    
    return True


def check_missing_values_filled(data: List[Dict[str, Any]]) -> bool:
    """检查缺失值是否正确填充"""
    if not data:
        return True
    
    # 检查是否还有None值
    for record in data:
        for key, value in record.items():
            if value is None or value == '' or str(value).lower() in ['none', 'nan', 'null']:
                return False
    
    return True


def validate_mean_filling(original_data: List[Dict[str, Any]], processed_data: List[Dict[str, Any]]) -> bool:
    """验证数值列是否用均值正确填充"""
    if not original_data or not processed_data:
        return True
    
    # 识别数值列
    numeric_columns = []
    for col in original_data[0].keys():
        if col in ['customer_id', 'age', 'score', 'amount', 'rating']:
            numeric_columns.append(col)
    
    # 创建原始数据的索引
    original_df = pd.DataFrame(original_data)
    processed_df = pd.DataFrame(processed_data)
    
    for col in numeric_columns:
        if col in original_df.columns and col in processed_df.columns:
            # 计算原始数据的均值（排除None）
            original_series = pd.to_numeric(original_df[col], errors='coerce')
            if original_series.notna().sum() > 0:
                expected_mean = original_series.mean()
                
                # 检查处理后的数据中，原来为None的位置是否填充了均值
                for i, (orig_val, proc_val) in enumerate(zip(original_df[col], processed_df[col])):
                    if pd.isna(orig_val) or orig_val is None:
                        # 原来是缺失值，检查是否填充了均值
                        proc_val_numeric = pd.to_numeric(proc_val, errors='coerce')
                        if abs(proc_val_numeric - expected_mean) > 0.01:  # 允许小的浮点误差
                            return False
    
    return True


def is_valid_record(record):
    """检查单条记录是否符合要求"""
    text = record.get('text', '')
    
    # 检查文本中数字是否格式化为两位小数
    if not are_numbers_formatted(text):
        return False
    
    # 检查是否有缺失值
    for key, value in record.items():
        if value is None or value == '' or str(value).lower() in ['none', 'nan', 'null']:
            return False
    
    return True


def is_valid_dataset(data: List[Dict[str, Any]]) -> bool:
    """检查整个数据集是否有效"""
    # 检查是否有重复记录
    if not check_no_exact_duplicates(data):
        return False
    
    # 检查缺失值是否填充
    if not check_missing_values_filled(data):
        return False
    
    return True


def get_gt():
    from pathlib import Path

    # 获取 eval.py 所在目录
    current_dir = Path(__file__).resolve().parent

    # 找到 expected 目录
    expected_dir = (current_dir / "./expected").resolve()

    # 查找第一个 .csv 文件
    csv_files = list(expected_dir.glob("*.csv"))

    if not csv_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")

    # 取第一个文件作为 expected_path
    expected_path = csv_files[0]

    return expected_path


def evaluate(processed_path):
    expected_path = get_gt()
    expected = load_csv(expected_path)
    processed = load_csv(processed_path)

    # 构造映射方便比对（使用customer_id作为键）
    expected_map = {entry["customer_id"]: entry for entry in expected}
    processed_map = {entry["customer_id"]: entry for entry in processed}

    # 只评估交集部分
    common_ids = set(expected_map.keys()) & set(processed_map.keys())

    true_positives = 0
    failed_ids = []
    
    for customer_id in common_ids:
        gt = expected_map[customer_id]
        pred = processed_map[customer_id]

        # 检查所有字段是否匹配且记录有效
        fields_match = True
        for key in gt.keys():
            if key in ['score', 'amount', 'rating']:
                # 数值字段允许小的浮点误差
                gt_val = float(gt[key]) if gt[key] is not None else None
                pred_val = float(pred[key]) if pred[key] is not None else None
                if gt_val is None or pred_val is None:
                    if gt_val != pred_val:
                        fields_match = False
                        break
                elif abs(gt_val - pred_val) > 0.01:
                    fields_match = False
                    break
            else:
                if str(gt[key]) != str(pred[key]):
                    fields_match = False
                    break
        
        if fields_match and is_valid_record(pred):
            true_positives += 1
        else:
            failed_ids.append(customer_id)

    # 检查是否有不应该出现的记录
    unexpected_ids = set(processed_map.keys()) - set(expected_map.keys())
    
    # 检查是否有遗漏的记录
    missing_ids = set(expected_map.keys()) - set(processed_map.keys())

    # 检查整个数据集的有效性
    dataset_valid = is_valid_dataset(processed)

    predicted_total = len(processed_map)
    gold_total = len(expected_map)

    precision = true_positives / predicted_total if predicted_total > 0 else 0.0
    recall = true_positives / gold_total if gold_total > 0 else 0.0
    f1 = (2 * precision * recall) / (precision + recall) if precision + recall > 0 else 0.0

    # 如果数据集无效，降低F1分数
    if not dataset_valid:
        f1 *= 0.3  # 严重惩罚
        print("警告: 数据集无效（可能存在重复记录或未填充的缺失值），F1分数已降低")

    # 输出详细信息用于调试
    if failed_ids:
        print(f"Failed IDs: {failed_ids[:10]}...")  # 只显示前10个
    if unexpected_ids:
        print(f"Unexpected records: {len(unexpected_ids)}")
    if missing_ids:
        print(f"Missing records: {len(missing_ids)}")
    
    # print(f"True Positives: {true_positives}")
    # print(f"Predicted Total: {predicted_total}")
    # print(f"Gold Total: {gold_total}")
    # print(f"Dataset Valid: {dataset_valid}")
    # print(f"Precision: {precision:.4f}")
    # print(f"Recall: {recall:.4f}")

    result = {"eval_score": f"{f1:.4f}"}
    print(result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-o", "--output", help="Path to processed results file", required=True)
    args = parser.parse_args()

    evaluate(args.output)