#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成模拟 JSONL 数据 (raw/customers.jsonl) 及其治理后的基准
(expected/gt.jsonl)。

清洗流程（必须按顺序）:
1. 去除 text 的 HTML 标签并解码实体
2. 去除 LaTeX 标签 / 控制序列
3. 英文缩写按词边界替换为全称（保持大小写风格）
4. 移除 Emoji（含 ZWJ 与肤色修饰符）
5. 过滤包含屏蔽词记录（大小写不敏感）
6. 基于行指纹去重；指纹 = 键名排序后 "k=v&..." 的 SHA-1，
   同指纹记录仅保留 id 最小
"""

from __future__ import annotations
import html
import json
import random
import re
import sys
from hashlib import sha1
from pathlib import Path
from typing import Dict, List, Tuple

# --------------------------------------------------------------------------- #
# 路径
# --------------------------------------------------------------------------- #
RAW_DIR = Path("raw");      RAW_DIR.mkdir(exist_ok=True, parents=True)
EXP_DIR = Path("expected"); EXP_DIR.mkdir(exist_ok=True, parents=True)
RAW_F = RAW_DIR / "customers.jsonl"
GT_F  = EXP_DIR / "gt.jsonl"

N_BASE = 140   # 唯一道指纹行数
N_DUP  = 60    # 制造重复 (不同 id)
N_BLOCK = 20   # 含屏蔽词样本
TOTAL = N_BASE + N_DUP + N_BLOCK

# --------------------------------------------------------------------------- #
# 正则 & 工具
# --------------------------------------------------------------------------- #
TAG_RE = re.compile(r"<[^>]+>")
LATEX_RE = re.compile(
    r"""
    \$[^$]+\$
    |\\\(.+?\\\)
    |\\\[.+?\\\]
    |\\[a-zA-Z]+\{.*?\}
    |\\[a-zA-Z]+
    """,
    re.VERBOSE | re.DOTALL,
)

CONTRA = {
    "can't": "cannot",
    "won't": "will not",
    "i'm": "i am",
    "it's": "it is",
    "you're": "you are",
    "they're": "they are",
    "don't": "do not",
}
CONTRA_RE = re.compile(r"\b(" + "|".join(map(re.escape, CONTRA)) + r")\b", re.I)

def _match_case(src: str, tgt: str) -> str:
    if src.isupper():        return tgt.upper()
    if src[0].isupper():     return tgt.capitalize()
    return tgt.lower()

EMOJI_RE = re.compile(
    "["                       # 单字符 emoji 基本区块
    "\U0001F300-\U0001F64F"
    "\U0001F680-\U0001F6FF"
    "\U0001F900-\U0001F9FF"
    "\U0001FA00-\U0001FAFF"
    "\u2600-\u26FF"
    "\u2700-\u27BF"
    "]+", flags=re.UNICODE,
)
ZWJ = re.compile(r"\u200d")
SKIN = re.compile(r"[\U0001F3FB-\U0001F3FF]")

BLOCKLIST = {"forbidden", "badword", "classified"}
BL_RE = re.compile("|".join(map(re.escape, BLOCKLIST)), re.I)

def normalize_text(text: str) -> str:
    # 1 HTML
    text = html.unescape(text)
    text = TAG_RE.sub("", text)
    # 2 LaTeX
    text = LATEX_RE.sub("", text)
    # 3 contractions
    text = CONTRA_RE.sub(lambda m: _match_case(m.group(), CONTRA[m.group().lower()]), text)
    # 4 emoji
    text = EMOJI_RE.sub("", text)
    text = ZWJ.sub("", text)
    text = SKIN.sub("", text)
    # 空白压缩
    text = re.sub(r"\s{2,}", " ", text).strip()
    return text

def has_block(text: str) -> bool:
    return bool(BL_RE.search(text))

def fingerprint(rec: Dict) -> str:
    kv = "&".join(f"{k}={rec[k]}" for k in sorted(rec.keys()))
    return sha1(kv.encode("utf-8")).hexdigest()

# --------------------------------------------------------------------------- #
# 生成原始数据
# --------------------------------------------------------------------------- #
names = ["Alice","Bob","Carol","Dave","Eve","Frank","Grace","Heidi"]
html_snips = ["<b>{}</b>", "<i>{}</i>", "<span style='color:red'>&lt;HOT&gt;</span>"]
latex_snips= ["$E=mc^2$", r"\(a^2+b^2=c^2\)", r"\frac{1}{2}", r"\alpha+\beta"]
emojis = ["😀","😂","🥳","🚀","👍","❤️","👩‍💻"]

texts: List[str] = [
    "Hi, I'm {name}. I can't believe the price! {html} {latex} {emoji}",
    "You're going to love it. It's awesome! {html} {emoji} {latex}",
    "They won't deliver until next week {emoji} {latex} so I'm waiting."
]

def make_text() -> str:
    t = random.choice(texts)
    return t.format(name=random.choice(names),
                    html=random.choice(html_snips).format("amazing"),
                    latex=random.choice(latex_snips),
                    emoji=random.choice(emojis))

raw_records: List[Dict] = []
for i in range(1, N_BASE + 1):
    raw_records.append({"id": i, "text": make_text(), "user": random.choice(names)})

# 生成重复行 (不同 id, 内容相同/极相似)
for i in range(N_BASE + 1, N_BASE + N_DUP + 1):
    src = random.choice(raw_records)               # 取一条
    dup = src.copy()
    dup["id"] = i
    # 在 text 前或后再拼一点 HTML/emoji 改变原文但清洗后指纹相同
    dup["text"] = src["text"] + " " + random.choice(emojis)
    raw_records.append(dup)

# 生成包含屏蔽词行
for i in range(N_BASE + N_DUP + 1, TOTAL + 1):
    raw_records.append({
        "id": i,
        "text": f"This line contains forbidden content and won't pass 😁",
        "user": random.choice(names)
    })

# 写 raw
with RAW_F.open("w", encoding="utf-8") as f:
    for rec in raw_records:
        json.dump(rec, f, ensure_ascii=False)
        f.write("\n")

# --------------------------------------------------------------------------- #
# 生成 GT
# --------------------------------------------------------------------------- #
fp2rec: Dict[str, Dict] = {}
for rec in raw_records:
    txt = normalize_text(rec["text"])
    if has_block(txt):
        continue
    rec_norm = rec.copy()
    rec_norm["text"] = txt
    fp = fingerprint(rec_norm)
    if fp not in fp2rec or rec_norm["id"] < fp2rec[fp]["id"]:
        fp2rec[fp] = rec_norm

gt_records = sorted(fp2rec.values(), key=lambda r: r["id"])

with GT_F.open("w", encoding="utf-8") as f:
    for rec in gt_records:
        json.dump(rec, f, ensure_ascii=False)
        f.write("\n")

print(f"✓ raw: {len(raw_records)} lines  ->  gt: {len(gt_records)} lines")