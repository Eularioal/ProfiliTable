#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
评测逻辑
1. 读取 expected/gt.jsonl，使用整行 SHA-1 指纹作为“真值集合”。
2. 对参赛输出：
   • 逐行读取并计算指纹  
   • 若指纹存在于 GT，则记 TP；否则忽略
3. F1 = 2·P·R / (P+R)
   P = TP / 预测行数
   R = TP / GT 行数
分值范围 [0,1]，输出 {"eval_score":"0.xxxx"}
"""

from __future__ import annotations
import argparse, json, sys, re
from hashlib import sha1
from pathlib import Path

GT_PATH = Path(__file__).parent / "expected" / "gt.jsonl"

def fp(rec: dict) -> str:
    kv = "&".join(f"{k}={rec[k]}" for k in sorted(rec.keys()))
    return sha1(kv.encode("utf-8")).hexdigest()

def load_fps(fp_path: Path) -> set[str]:
    s = set()
    with fp_path.open(encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            s.add(fp(json.loads(line)))
    return s

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-o","--output",required=True,help="your cleaned jsonl")
    args = ap.parse_args()

    gt_fps = load_fps(GT_PATH)
    pred_fps = load_fps(Path(args.output).expanduser())

    tp = len(gt_fps & pred_fps)
    if not pred_fps:
        precision = 0.0
    else:
        precision = tp / len(pred_fps)
    recall = tp / len(gt_fps) if gt_fps else 0.0
    f1 = 0.0 if precision + recall == 0 else 2*precision*recall/(precision+recall)

    print(json.dumps({"eval_score": f"{f1:.4f}"}))

if __name__ == "__main__":
    main()