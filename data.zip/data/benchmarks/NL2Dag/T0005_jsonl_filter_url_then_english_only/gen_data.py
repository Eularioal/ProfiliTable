#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
gen_data.py

1. 随机生成 200 条客户数据 → raw/customers.jsonl
2. 按要求清洗得到       → expected/gt.jsonl

处理流程：
  a. 删除 text 含 URL 的记录
  b. 只保留英文 (全部 ASCII) 的 text
  c. 删除 content 含恶意 / 消极词的记录
"""

from __future__ import annotations

import json
import os
import random
import re
from pathlib import Path
from typing import Dict, List

# ---------------------------------------------------------------------
# 目录与路径
# ---------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent
RAW_DIR = ROOT / "raw"
EXP_DIR = ROOT / "expected"
RAW_DIR.mkdir(exist_ok=True)
EXP_DIR.mkdir(exist_ok=True)

RAW_JSONL = RAW_DIR / "customers.jsonl"
GT_JSONL = EXP_DIR / "gt.jsonl"

# ---------------------------------------------------------------------
# 规则所需静态资源
# ---------------------------------------------------------------------
URL_PAT = re.compile(r"(http://|https://|www\.)", flags=re.I)
ASCII_ONLY = re.compile(r"^[\x20-\x7E]+$")  # 仅可打印 ASCII

BAD_WORDS = {
    "hate", "idiot", "stupid", "awful", "terrible",
    "garbage", "trash", "useless", "kill", "bad",
}

GOOD_TEXTS = [
    "The quick brown fox jumps over the lazy dog.",
    "Artificial intelligence is transforming the world.",
    "We will meet at the conference next Monday.",
    "Open source software accelerates innovation.",
    "Her dedication to the project was admirable.",
    "Fast and reliable data pipelines are critical.",
]
GOOD_CONTENTS = [
    "Thank you for your continuous support!",
    "We appreciate your positive feedback.",
    "Looking forward to future collaboration.",
]
BAD_CONTENTS = [
    "I hate this stupid product.",
    "Your service is garbage and useless.",
    "This is an awful idea and completely trash.",
]

# ---------------------------------------------------------------------
# 过滤函数
# ---------------------------------------------------------------------
def contains_url(text: str) -> bool:
    return bool(URL_PAT.search(text))


def is_english(text: str) -> bool:
    return bool(ASCII_ONLY.match(text))


def contains_bad_words(content: str) -> bool:
    tokens = re.findall(r"[A-Za-z]+", content.lower())
    return any(tok in BAD_WORDS for tok in tokens)


def keep(record: Dict[str, str]) -> bool:
    if contains_url(record["text"]):
        return False
    if not is_english(record["text"]):
        return False
    if contains_bad_words(record["content"]):
        return False
    return True


# ---------------------------------------------------------------------
# 数据生成
# ---------------------------------------------------------------------
def make_record(idx: int) -> Dict[str, str]:
    text = random.choice(GOOD_TEXTS)
    content = random.choice(GOOD_CONTENTS)

    r = random.random()
    if r < 0.25:
        # 注入 URL
        text += f" Check https://example{idx}.com for details."
    elif r < 0.50:
        # 注入非英文
        text = "这是一个包含中文字符的句子，用于测试。"
    # 15% 概率恶意 content
    if random.random() < 0.15:
        content = random.choice(BAD_CONTENTS)

    return {
        "id": idx,
        "text": text,
        "content": content,
    }


# ---------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------
def main() -> None:
    random.seed(2024)

    raw_records: List[Dict[str, str]] = [make_record(i) for i in range(1, 201)]

    with RAW_JSONL.open("w", encoding="utf-8") as f:
        for rec in raw_records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    gt_records = [rec for rec in raw_records if keep(rec)]

    with GT_JSONL.open("w", encoding="utf-8") as f:
        for rec in gt_records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    print(f"Generated {len(raw_records)} raw → {len(gt_records)} GT records.")


if __name__ == "__main__":
    main()