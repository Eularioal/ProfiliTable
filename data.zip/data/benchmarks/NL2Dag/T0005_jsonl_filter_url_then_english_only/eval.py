#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py ─ Evaluate the result of the “URL + English + bad-content filter” operator.

评测逻辑
========
1. 官方基准文件      expected/gt.jsonl
2. 参赛者输出文件    (--output / 位置参数 指定)

若一条记录满足以下全部条件则视为 **TP**：
  • `id` 在 GT 中存在
  • 该 `id` 对应的整条 JSON（每个字段和值）与 GT 完全一致

计算
-----
precision = TP / 预测记录数
recall    = TP / GT 记录数
F1        = 2·P·R / (P+R)                (若分母 0 则 F1=0)

最终输出 JSON：
{
  "eval_score": 0.xxxx,
  "details": {
      "tp": ...,
      "pred": ...,
      "gt": ...,
      "precision": 0.xxxx,
      "recall": 0.xxxx
  }
}

用法
----
python eval.py -o /path/to/output.jsonl
python eval.py    /path/to/output.jsonl      # 位置参数亦可
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, Tuple

GT_PATH = Path(__file__).parent / "expected" / "gt.jsonl"


# ──────────────────────────────── IO ────────────────────────────────
def load_jsonl(path: Path) -> Dict[int, dict]:
    """
    读取 jsonl 文件并转成 {id: full_record}，
    同时做完整性检查：文件存在、JSON 解码、缺字段、id 重复。
    """
    if not path.is_file():
        raise FileNotFoundError(path)

    data: Dict[int, dict] = {}
    with path.open(encoding="utf-8") as f:
        for ln, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"{path} line {ln}: JSON decode error → {e}") from None

            for field in ("id", "text", "content"):
                if field not in obj:
                    raise KeyError(f"{path} line {ln}: missing '{field}' field")

            _id = obj["id"]
            if _id in data:
                raise ValueError(f"{path} line {ln}: duplicated id {_id}")
            data[_id] = obj
    return data


# ────────────────────────────── Metric ──────────────────────────────
def compute_f1(
    gt: Dict[int, dict], pred: Dict[int, dict]
) -> Tuple[float, int, int, int]:
    """
    基于 id+整条记录完全一致计算 F1。返回 (f1, TP, |pred|, |gt|)
    """
    if not pred:
        return 0.0, 0, 0, len(gt)

    tp = sum(1 for _id, rec in pred.items() if _id in gt and rec == gt[_id])
    precision = tp / len(pred)
    recall = tp / len(gt) if gt else 0.0

    if precision + recall == 0:
        return 0.0, tp, len(pred), len(gt)
    f1 = 2 * precision * recall / (precision + recall)
    return f1, tp, len(pred), len(gt)


# ─────────────────────────────── CLI ────────────────────────────────
def parse_args() -> Path:
    parser = argparse.ArgumentParser(
        description="Evaluate JSONL cleansing-operator output"
    )
    parser.add_argument("-o", "--output", help="path to output jsonl")
    parser.add_argument("positional", nargs="?", help="path to output jsonl (positional)")
    args = parser.parse_args()

    output_path = args.output or args.positional
    if not output_path:
        parser.error("missing output file – provide with -o or positional argument")
    return Path(output_path)


def main() -> None:
    pred_path = parse_args()

    gt_dict = load_jsonl(GT_PATH)
    pred_dict = load_jsonl(pred_path)

    f1, tp, pred_n, gt_n = compute_f1(gt_dict, pred_dict)

    result = {
        "eval_score": round(f1, 4)
    }
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()