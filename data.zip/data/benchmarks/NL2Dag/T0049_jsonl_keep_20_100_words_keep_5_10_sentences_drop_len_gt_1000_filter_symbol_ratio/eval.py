#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Offline evaluator for the '20-100 words, 5-10 sentences …' cleansing task.

运行:
    python eval.py -o /path/to/your_output.jsonl
"""

from __future__ import annotations

import argparse, json, re, sys, hashlib, html
from pathlib import Path
from typing import Dict, Tuple

ROOT    = Path(__file__).resolve().parent
GT_PATH = ROOT / "expected" / "gt.jsonl"

###############################################################################
# 1. 过滤规则（同 gen_data.py）
###############################################################################
RE_SENT_SPLIT = re.compile(r"[.!?]\s+")
RE_TOKEN      = re.compile(r"\w+|[^\w\s]")

def word_count(t: str) -> int:
    return len(re.findall(r"\b\w+\b", t))

def sentence_count(t: str) -> int:
    return len([s for s in RE_SENT_SPLIT.split(t) if s.strip()])

def symbol_ratio(t: str) -> float:
    toks = RE_TOKEN.findall(t)
    if not toks:
        return 1.0
    sym = sum(1 for tok in toks if not re.fullmatch(r"\w+", tok))
    return sym / len(toks)

def legal(text: str) -> bool:
    return (
        20 <= word_count(text) <= 100
        and 5 <= sentence_count(text) <= 10
        and len(text) <= 1000
        and symbol_ratio(text) <= 0.5
    )

###############################################################################
# 2. 读取 JSONL 为 {id: text}
###############################################################################
def load_id_text(path: Path) -> Dict[str, str]:
    if not path.is_file():
        sys.exit(f"[Eval] File not found: {path}")
    res = {}
    with path.open(encoding="utf-8") as f:
        for ln, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                sys.exit(f"[Eval] {path} L{ln}: bad JSON — {e}")
            if "id" not in obj or "text" not in obj:
                sys.exit(f"[Eval] {path} L{ln}: missing id/text")
            id_ = str(obj["id"])
            txt = obj["text"]
            if not isinstance(txt, str):
                sys.exit(f"[Eval] {path} L{ln}: text must be str")
            res[id_] = txt
    return res

###############################################################################
# 3. PRF
###############################################################################
def prf(gt: Dict[str, str], pred: Dict[str, str]) -> Tuple[float, float, float]:
    if not pred:
        return 0.0, 0.0, 0.0
    tp = sum(1 for k, v in pred.items() if gt.get(k) == v)
    p  = tp / len(pred)
    r  = tp / len(gt)
    f1 = 0.0 if p + r == 0 else 2 * p * r / (p + r)
    return p, r, f1

###############################################################################
# 4. 主程序
###############################################################################
def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("-o", "--output", required=True, help="your result jsonl")
    args = ap.parse_args()

    gt   = load_id_text(GT_PATH)
    pred = load_id_text(Path(args.output))

    # ——— 过滤掉任何不符合规则的预测行 ———
    # invalid = [k for k, t in pred.items() if not legal(t)]
    # for k in invalid:
    #     pred.pop(k)

    _, _, f1 = prf(gt, pred)
    print({"eval_score": f"{f1:.4f}"})

if __name__ == "__main__":
    main()