#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
根据任务要求生成两份数据：
  • raw/customers.jsonl      —— 未经过筛选的原始数据
  • expected/gt.jsonl        —— 依次执行 4 条规则后留下的记录
规则
  1) 单词数介于 20~100
  2) 句子数介于 5~10
  3) 字符总长不超过 1000
  4) '符号/单词' 比例 ≤ 0.5     （符号 = 非 \w 的 token）
"""
import json, os, random, pathlib, re, string, textwrap
from typing import List

ROOT = pathlib.Path(__file__).resolve().parent
RAW_PATH = ROOT / "raw" / "customers.jsonl"
GT_PATH  = ROOT / "expected" / "gt.jsonl"
RAW_PATH.parent.mkdir(exist_ok=True, parents=True)
GT_PATH.parent.mkdir(exist_ok=True, parents=True)

###############################################################################
# 1. 文本构造工具
###############################################################################
WORDS = [w.strip() for w in textwrap.dedent("""
    lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
    consequat duis aute irure dolor in reprehenderit in voluptate velit esse
    cillum dolore eu fugiat nulla pariatur excepteur sint occaecat cupidatat
    non proident sunt in culpa qui officia deserunt mollit anim id est laborum
""").split()]

PUNCTS = list(".,!?;:-—()[]{}")

def random_sentence(min_w=3, max_w=15) -> str:
    n = random.randint(min_w, max_w)
    words = random.choices(WORDS, k=n)
    sent = " ".join(words).capitalize() + random.choice([".", "!", "?"])
    return sent

def noisy_paragraph(id_: int) -> str:
    """生成 3~15 句、10~150 单词、夹杂随机符号的段落"""
    n_sent = random.randint(3, 15)
    sents: List[str] = [random_sentence() for _ in range(n_sent)]
    txt = " ".join(sents)
    # 随机在 20% 几率处插入符号 token
    if random.random() < 0.2:
        extra = random.choices(PUNCTS, k=random.randint(5, 15))
        txt += " " + " ".join(extra)
    return txt

###############################################################################
# 2. 过滤规则实现
###############################################################################
RE_SENT_SPLIT = re.compile(r"[.!?]\s+")
RE_TOKEN      = re.compile(r"\w+|[^\w\s]")

def word_count(text: str) -> int:
    return len(re.findall(r"\b\w+\b", text))

def sentence_count(text: str) -> int:
    return len([s for s in RE_SENT_SPLIT.split(text) if s.strip()])

def symbol_ratio(text: str) -> float:
    tokens = RE_TOKEN.findall(text)
    if not tokens:
        return 1.0
    symbol = sum(1 for t in tokens if not re.fullmatch(r"\w+", t))
    return symbol / len(tokens)

def keep(text: str) -> bool:
    """是否满足 4 条规则"""
    wc = word_count(text)
    sc = sentence_count(text)
    if not (20 <= wc <= 100):
        return False
    if not (5 <= sc <= 10):
        return False
    if len(text) > 1000:
        return False
    if symbol_ratio(text) > 0.5:
        return False
    return True

###############################################################################
# 3. 生成原始数据
###############################################################################
RAW_N = 220          # raw 行数（保证 >100）
raw_records = []
for i in range(1, RAW_N + 1):
    raw_records.append({"id": i, "text": noisy_paragraph(i)})

with RAW_PATH.open("w", encoding="utf-8") as f:
    for r in raw_records:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")

###############################################################################
# 4. 生成 GT
###############################################################################
gt_records = [r for r in raw_records if keep(r["text"])]

assert len(gt_records) > 100, "GT 记录应 >100，请调高 RAW_N"

with GT_PATH.open("w", encoding="utf-8") as f:
    for r in gt_records:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")

print(f"✔ raw={len(raw_records)}, gt={len(gt_records)} written.")