import csv
import re
import random
import os
from typing import List, Dict, Any
from datetime import datetime, timedelta
from datasketch import MinHashLSH, MinHash

def generate_raw_data() -> List[Dict[str, Any]]:
    """生成包含各种问题的原始数据"""
    
    # 基础文本内容（用于生成相似文本）
    base_texts = [
        "This is a great product with excellent quality.",
        "The service was amazing and staff very helpful.",
        "I really enjoyed the experience and would recommend it.",
        "The design is beautiful and functional.",
        "Great value for money and fast delivery.",
        "Outstanding customer support and quick response.",
        "The interface is user friendly and intuitive.",
        "High quality materials and excellent craftsmanship.",
        "Perfect solution for our business needs.",
        "Innovative features and reliable performance.",
        "Exceptional quality and attention to detail.",
        "Smooth operation and easy maintenance.",
        "Professional service and timely delivery.",
        "Creative design and practical functionality.",
        "Efficient workflow and improved productivity.",
        "Reliable system with consistent performance.",
        "Advanced technology and modern features.",
        "Comprehensive solution for complex problems.",
        "Effective strategy and successful implementation.",
        "Positive impact on our business operations."
    ]
    
    raw_data = []
    review_id_counter = 1
    
    # 生成基础数据，每个id会有多条记录（不同的update_time）
    base_date = datetime(2024, 1, 1)
    
    for customer_id in range(1, 51):  # 50个不同的客户ID
        # 每个客户ID生成2-4条记录（不同的update_time）
        num_records = random.randint(2, 4)
        
        for record_idx in range(num_records):
            # 生成不同的update_time
            days_offset = record_idx * random.randint(1, 30)
            update_time = (base_date + timedelta(days=days_offset)).strftime("%Y-%m-%d %H:%M:%S")
            
            # 选择基础文本并添加多余空格
            base_text = random.choice(base_texts)
            text_with_spaces = add_extra_spaces(base_text)
            
            # 生成指标数据
            metric1 = round(random.uniform(10, 100), 2)
            metric2 = round(random.uniform(100, 1000), 2)
            metric3 = round(random.uniform(1000, 10000), 2)
            metric4 = round(random.uniform(0.1, 10), 2)
            
            raw_data.append({
                "id": customer_id,
                "review_id": review_id_counter,
                "update_time": update_time,
                "text": text_with_spaces,
                "metric1": metric1,
                "metric2": metric2,
                "metric3": metric3,
                "metric4": metric4,
                "category": "normal"
            })
            review_id_counter += 1
    
    # 添加相似文本组（用于MinHash去重测试）
    similar_text_base = "The product quality is excellent and delivery was fast"
    similar_texts = [
        "The product quality is excellent and delivery was fast.",
        "Product quality is excellent and the delivery was fast.",
        "Excellent product quality and fast delivery service.",
        "The quality of product is excellent and delivery fast.",
        "Product has excellent quality and fast delivery."
    ]
    
    for i, similar_text in enumerate(similar_texts):
        customer_id = 100 + i
        update_time = (base_date + timedelta(days=i)).strftime("%Y-%m-%d %H:%M:%S")
        text_with_spaces = add_extra_spaces(similar_text)
        
        metric1 = round(random.uniform(10, 100), 2)
        metric2 = round(random.uniform(100, 1000), 2)
        metric3 = round(random.uniform(1000, 10000), 2)
        metric4 = round(random.uniform(0.1, 10), 2)
        
        raw_data.append({
            "id": customer_id,
            "review_id": review_id_counter,
            "update_time": update_time,
            "text": text_with_spaces,
            "metric1": metric1,
            "metric2": metric2,
            "metric3": metric3,
            "metric4": metric4,
            "category": "similar"
        })
        review_id_counter += 1
    
    # 添加更多数据以达到150+条记录
    additional_customers = range(200, 250)  # 50个额外客户
    for customer_id in additional_customers:
        num_records = random.randint(1, 3)
        
        for record_idx in range(num_records):
            days_offset = record_idx * random.randint(1, 20)
            update_time = (base_date + timedelta(days=days_offset)).strftime("%Y-%m-%d %H:%M:%S")
            
            base_text = random.choice(base_texts)
            text_with_spaces = add_extra_spaces(base_text)
            
            metric1 = round(random.uniform(10, 100), 2)
            metric2 = round(random.uniform(100, 1000), 2)
            metric3 = round(random.uniform(1000, 10000), 2)
            metric4 = round(random.uniform(0.1, 10), 2)
            
            raw_data.append({
                "id": customer_id,
                "review_id": review_id_counter,
                "update_time": update_time,
                "text": text_with_spaces,
                "metric1": metric1,
                "metric2": metric2,
                "metric3": metric3,
                "metric4": metric4,
                "category": "additional"
            })
            review_id_counter += 1
    
    return raw_data

def add_extra_spaces(text: str) -> str:
    """添加多余空格到文本中"""
    # 随机在单词间添加多余空格
    words = text.split()
    result = []
    
    for i, word in enumerate(words):
        result.append(word)
        if i < len(words) - 1:
            # 随机添加1-3个空格
            spaces = ' ' * random.randint(1, 3)
            result.append(spaces)
    
    # 有时在开头或结尾添加空格
    final_text = ''.join(result)
    if random.random() < 0.3:
        final_text = ' ' + final_text
    if random.random() < 0.3:
        final_text = final_text + ' '
    
    return final_text

def clean_text_spaces(text: str) -> str:
    """清除文本中的多余空格"""
    # 移除开头和结尾的空格，并将多个空格替换为单个空格
    return re.sub(r'\s+', ' ', text.strip())

def get_minhash(text: str, num_perm: int = 128) -> MinHash:
    """计算文本的MinHash"""
    # 简单的shingle生成（2-gram）
    shingles = set()
    words = text.lower().split()
    for i in range(len(words) - 1):
        shingle = f"{words[i]} {words[i+1]}"
        shingles.add(shingle)
    
    # 如果文本太短，使用单词作为shingle
    if len(shingles) == 0:
        shingles = set(words)
    
    minhash = MinHash(num_perm=num_perm)
    for shingle in shingles:
        minhash.update(shingle.encode('utf8'))
    return minhash

def deduplicate_similar_texts(data: List[Dict[str, Any]], threshold: float = 0.9) -> List[Dict[str, Any]]:
    """使用MinHash进行近似文本去重"""
    if not data:
        return data
    
    lsh = MinHashLSH(threshold=threshold, num_perm=128)
    
    # 构建LSH索引
    minhashes = {}
    for record in data:
        text = record['text']
        minhash = get_minhash(text)
        minhashes[record['review_id']] = minhash
        lsh.insert(record['review_id'], minhash)
    
    # 找到相似文本组
    similar_groups = []
    processed_ids = set()
    
    for record in data:
        review_id = record['review_id']
        if review_id in processed_ids:
            continue
        
        # 查找相似的文档
        similar_ids = lsh.query(minhashes[review_id])
        
        if len(similar_ids) > 1:
            # 按review_id排序，保留最小的
            similar_ids = sorted(similar_ids, key=int)
            similar_groups.append(similar_ids)
            processed_ids.update(similar_ids)
    
    # 构建要保留的ID集合
    keep_ids = set(record['review_id'] for record in data)
    
    for group in similar_groups:
        # 保留review_id最小的，移除其他的
        keep_id = group[0]
        for remove_id in group[1:]:
            keep_ids.discard(remove_id)
    
    # 返回去重后的数据
    return [record for record in data if record['review_id'] in keep_ids]

def process_data(raw_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """处理数据，应用所有处理规则"""
    # 第一步：按id字段去重，保留每组最新的update_time记录
    id_groups = {}
    for record in raw_data:
        customer_id = record['id']
        update_time = record['update_time']
        
        if customer_id not in id_groups or update_time > id_groups[customer_id]['update_time']:
            id_groups[customer_id] = record
    
    deduped_by_id = list(id_groups.values())
    
    # 第二步：清除text字段中的多余空格
    for record in deduped_by_id:
        record['text'] = clean_text_spaces(record['text'])
    
    # 第三步：使用MinHash进行近似去重
    deduped_by_similarity = deduplicate_similar_texts(deduped_by_id, threshold=0.9)
    
    # 第四步：宽转长（unpivot）操作
    long_data = []
    for record in deduped_by_similarity:
        base_record = {
            'id': record['id'],
            'review_id': record['review_id'],
            'update_time': record['update_time'],
            'text': record['text']
        }
        
        # 转换指标列为key-value形式
        for metric in ['metric1', 'metric2', 'metric3', 'metric4']:
            long_record = base_record.copy()
            long_record['metric_name'] = metric
            long_record['metric_value'] = record[metric]
            long_data.append(long_record)
    
    return long_data

def save_to_csv(data: List[Dict[str, Any]], filepath: str):
    """保存数据到CSV文件（UTF-8无BOM）"""
    if not data:
        return
    
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = data[0].keys()
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)

def main():
    """主函数，生成测试数据"""
    print("生成原始数据...")
    raw_data = generate_raw_data()
    print(f"生成了 {len(raw_data)} 条原始记录")
    
    print("处理数据...")
    gt_data = process_data(raw_data)
    print(f"处理后得到了 {len(gt_data)} 条记录")
    
    # 保存原始数据到 raw/customers.csv
    print("保存原始数据到 raw/customers.csv...")
    save_to_csv(raw_data, 'raw/customers.csv')
    
    # 保存处理后的数据到 expected/gt.csv
    print("保存GT数据到 expected/gt.csv...")
    save_to_csv(gt_data, 'expected/gt.csv')
    
    print("数据生成完成！")
    print(f"原始数据: {len(raw_data)} 条记录")
    print(f"GT数据: {len(gt_data)} 条记录")
    
    # 统计处理效果
    unique_ids = len(set(record['id'] for record in raw_data))
    processed_unique_ids = len(set(record['id'] for record in gt_data)) // 4  # 除以4因为每个id有4个指标
    print(f"原始唯一ID数: {unique_ids}")
    print(f"处理后唯一ID数: {processed_unique_ids}")

if __name__ == "__main__":
    main()