import argparse
import csv
import os
import re
from typing import List, Dict, Any, Set
from datasketch import MinHashLSH, MinHash


def load_csv(path):
    data = []
    with open(path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data


def has_extra_spaces(text: str) -> bool:
    """检查文本是否包含多余空格"""
    # 检查开头或结尾是否有空格
    if text != text.strip():
        return True
    # 检查是否有连续的多个空格
    if re.search(r'\s{2,}', text):
        return True
    return False


def get_minhash(text: str, num_perm: int = 128) -> MinHash:
    """计算文本的MinHash"""
    # 简单的shingle生成（2-gram）
    shingles = set()
    words = text.lower().split()
    for i in range(len(words) - 1):
        shingle = f"{words[i]} {words[i+1]}"
        shingles.add(shingle)
    
    # 如果文本太短，使用单词作为shingle
    if len(shingles) == 0:
        shingles = set(words)
    
    minhash = MinHash(num_perm=num_perm)
    for shingle in shingles:
        minhash.update(shingle.encode('utf8'))
    return minhash


def calculate_similarity(text1: str, text2: str) -> float:
    """计算两个文本的相似度"""
    minhash1 = get_minhash(text1)
    minhash2 = get_minhash(text2)
    return minhash1.jaccard(minhash2)


def check_no_similar_duplicates(data: List[Dict[str, Any]], threshold: float = 0.9) -> bool:
    """检查是否存在高相似度的重复文本"""
    texts = []
    text_to_record = {}
    
    for record in data:
        text = record['text']
        if text not in text_to_record:
            texts.append(text)
            text_to_record[text] = []
        text_to_record[text].append(record)
    
    # 检查不同文本之间的相似度
    for i in range(len(texts)):
        for j in range(i + 1, len(texts)):
            similarity = calculate_similarity(texts[i], texts[j])
            if similarity >= threshold:
                return False
    
    return True


def check_data_structure(data: List[Dict[str, Any]]) -> bool:
    """检查数据结构是否符合宽转长格式"""
    if not data:
        return False
    
    # 检查必要的列是否存在
    required_columns = {'id', 'review_id', 'update_time', 'text', 'metric_name', 'metric_value'}
    actual_columns = set(data[0].keys())
    
    if not required_columns.issubset(actual_columns):
        return False
    
    # 检查每个id是否有4条记录（metric1, metric2, metric3, metric4）
    id_metrics = {}
    for record in data:
        record_id = record['id']
        metric_name = record['metric_name']
        
        if record_id not in id_metrics:
            id_metrics[record_id] = set()
        id_metrics[record_id].add(metric_name)
    
    # 每个ID应该有4个指标
    expected_metrics = {'metric1', 'metric2', 'metric3', 'metric4'}
    for record_id, metrics in id_metrics.items():
        if metrics != expected_metrics:
            return False
    
    return True


def check_id_deduplication(data: List[Dict[str, Any]]) -> bool:
    """检查是否正确按ID去重（每个ID只保留一条原始记录，展开为4条长表记录）"""
    # 按ID分组，检查每组的update_time是否一致
    id_groups = {}
    for record in data:
        record_id = record['id']
        update_time = record['update_time']
        
        if record_id not in id_groups:
            id_groups[record_id] = set()
        id_groups[record_id].add(update_time)
    
    # 每个ID应该只有一个update_time
    for record_id, update_times in id_groups.items():
        if len(update_times) != 1:
            return False
    
    return True


def is_valid_record(record):
    """检查单条记录是否符合要求"""
    text = record.get('text', '')
    
    # 检查文本是否清理了多余空格
    if has_extra_spaces(text):
        return False
    
    return True


def is_valid_dataset(data: List[Dict[str, Any]]) -> bool:
    """检查整个数据集是否有效"""
    # 检查数据结构
    if not check_data_structure(data):
        return False
    
    # 检查ID去重
    if not check_id_deduplication(data):
        return False
    
    # 检查相似文本去重
    if not check_no_similar_duplicates(data, threshold=0.9):
        return False
    
    return True


def get_gt():
    from pathlib import Path

    # 获取 eval.py 所在目录
    current_dir = Path(__file__).resolve().parent

    # 找到 expected 目录
    expected_dir = (current_dir / "./expected").resolve()

    # 查找第一个 .csv 文件
    csv_files = list(expected_dir.glob("*.csv"))

    if not csv_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")

    # 取第一个文件作为 expected_path
    expected_path = csv_files[0]

    return expected_path


def evaluate(processed_path):
    expected_path = get_gt()
    expected = load_csv(expected_path)
    processed = load_csv(processed_path)

    # 构造映射方便比对（使用id和metric_name作为联合键）
    def make_key(record):
        return f"{record['id']}_{record['metric_name']}"
    
    expected_map = {make_key(entry): entry for entry in expected}
    processed_map = {make_key(entry): entry for entry in processed}

    # 只评估交集部分
    common_keys = set(expected_map.keys()) & set(processed_map.keys())

    true_positives = 0
    failed_keys = []
    
    for key in common_keys:
        gt = expected_map[key]
        pred = processed_map[key]

        # 检查所有字段是否匹配且记录有效
        fields_match = (
            gt["id"] == pred["id"] and
            gt["review_id"] == pred["review_id"] and
            gt["update_time"] == pred["update_time"] and
            gt["text"] == pred["text"] and
            gt["metric_name"] == pred["metric_name"] and
            gt["metric_value"] == pred["metric_value"]
        )
        
        if fields_match and is_valid_record(pred):
            true_positives += 1
        else:
            failed_keys.append(key)

    # 检查是否有不应该出现的记录
    unexpected_keys = set(processed_map.keys()) - set(expected_map.keys())
    
    # 检查是否有遗漏的记录
    missing_keys = set(expected_map.keys()) - set(processed_map.keys())

    # 检查整个数据集的有效性
    dataset_valid = is_valid_dataset(processed)

    predicted_total = len(processed_map)
    gold_total = len(expected_map)

    precision = true_positives / predicted_total if predicted_total > 0 else 0.0
    recall = true_positives / gold_total if gold_total > 0 else 0.0
    f1 = (2 * precision * recall) / (precision + recall) if precision + recall > 0 else 0.0

    # 如果数据集结构无效，大幅降低F1分数
    if not dataset_valid:
        f1 *= 0.2  # 严重惩罚
        print("警告: 数据集无效（可能存在重复ID、相似文本或格式错误），F1分数已大幅降低")

    # 输出详细信息用于调试
    if failed_keys:
        print(f"Failed keys: {failed_keys[:10]}...")  # 只显示前10个
    if unexpected_keys:
        print(f"Unexpected records: {len(unexpected_keys)}")
    if missing_keys:
        print(f"Missing records: {len(missing_keys)}")
    

    result = {"eval_score": f"{f1:.4f}"}
    print(result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-o", "--output", help="Path to processed results file", required=True)
    args = parser.parse_args()

    evaluate(args.output)