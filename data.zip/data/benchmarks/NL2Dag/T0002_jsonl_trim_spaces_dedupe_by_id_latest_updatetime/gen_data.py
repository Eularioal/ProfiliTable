#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import csv
import os
import random
import re
from pathlib import Path
from typing import List, Dict

ROOT = Path(__file__).resolve().parent
RAW_DIR = ROOT / "raw"
EXP_DIR = ROOT / "expected"
RAW_DIR.mkdir(exist_ok=True)
EXP_DIR.mkdir(exist_ok=True)

CUSTOMERS_CSV = RAW_DIR / "customers.csv"
GT_CSV = EXP_DIR / "gt.csv"

URL_PAT = re.compile(r"(http://|https://|www\.)", flags=re.I)
# 简易英文检测：仅允许 ASCII 可打印字符
ASCII_ONLY_PAT = re.compile(r"^[\x20-\x7E]+$")

# 一小撮常见拼写 / 语法错误（全部小写）
MISSPELLINGS = {
    "teh",          # the
    "recieve",      # receive
    "seperate",     # separate
    "definately",   # definitely
    "wich",         # which
    "occurence",    # occurrence
    "adress",       # address
    "erroor",       # error
}


def contains_url(text: str) -> bool:
    return bool(URL_PAT.search(text))


def is_english(text: str) -> bool:
    """极简英文检测：全 ASCII 即认为是英文。"""
    return bool(ASCII_ONLY_PAT.match(text))


def has_spelling_error(text: str) -> bool:
    tokens = re.findall(r"[A-Za-z]+", text.lower())
    return any(tok in MISSPELLINGS for tok in tokens)


def filter_text(text: str) -> bool:
    """返回 True 表示保留，False 表示应该剔除。"""
    if contains_url(text):
        return False
    if not is_english(text):
        return False
    if has_spelling_error(text):
        return False
    return True


def generate_sentence() -> str:
    """伪造一条英文句子，按概率注入‘问题’。"""
    good_sentences = [
        "The quick brown fox jumps over the lazy dog.",
        "Artificial intelligence is transforming every industry.",
        "We will meet at the conference next Monday morning.",
        "Open source software encourages collaboration and innovation.",
        "Her dedication to the project was truly admirable.",
        "Fast reliable data pipelines are critical for analytics.",
    ]
    sentence = random.choice(good_sentences)

    r = random.random()
    if r < 0.20:
        # 注入 URL
        sentence += f" Visit https://example{random.randint(1,9)}.com for more."
    elif r < 0.40:
        # 注入非英文
        sentence = "这是一个包含中文字符的句子，用于测试过滤。"
    elif r < 0.60:
        # 注入拼写错误
        sentence = sentence.replace("the", "teh", 1)
    # 否则保持正常
    return sentence


def build_customers(n: int = 200) -> List[Dict[str, str]]:
    data = []
    for cid in range(1, n + 1):
        row = {
            "id": str(cid),
            "text": generate_sentence(),
        }
        data.append(row)
    return data


def main() -> None:
    customers = build_customers(200)

    # 写入 raw/customers.csv
    with CUSTOMERS_CSV.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "text"])
        writer.writeheader()
        writer.writerows(customers)

    # 计算并写入 expected/gt.csv
    gt_rows = [row for row in customers if filter_text(row["text"])]
    with GT_CSV.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "text"])
        writer.writeheader()
        writer.writerows(gt_rows)

    print(f"Generated {len(customers)} raw rows → {len(gt_rows)} GT rows.")
    print(f"Raw data:      {CUSTOMERS_CSV.relative_to(ROOT)}")
    print(f"Ground-truth:  {GT_CSV.relative_to(ROOT)}")


if __name__ == "__main__":
    main()