#!/usr/bin/env python3
# -*- coding: utf-8 -*-


from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Dict, Tuple

GT_PATH = Path(__file__).parent / "expected" / "gt.csv"


# ----------------------------------------------------------------------
# IO helpers
# ----------------------------------------------------------------------
def load_csv_as_dict(path: Path) -> Dict[str, str]:
    """
    读取 CSV，返回 {id(str): text(str)}。
    执行基础完整性检查：文件存在、字段缺失、id 重复。
    """
    if not path.is_file():
        raise FileNotFoundError(f"File not found: {path}")

    data: Dict[str, str] = {}
    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        # 必须包含 id 和 text 两列
        for ln, row in enumerate(reader, 2):  # header 行算 1
            if "id" not in row or "text" not in row:
                raise KeyError(f"{path} line {ln}: missing 'id' or 'text' column")

            _id = str(row["id"])
            if _id in data:
                raise ValueError(f"{path} line {ln}: duplicated id '{_id}'")

            data[_id] = row["text"]
    return data


# ----------------------------------------------------------------------
# Metric
# ----------------------------------------------------------------------
def compute_f1(
    gt: Dict[str, str], pred: Dict[str, str]
) -> Tuple[float, int, int, int]:
    """
    根据 id & text 完全匹配计算 F1。
    返回 (f1, TP, |pred|, |gt|)
    """
    if not pred:
        return 0.0, 0, 0, len(gt)

    tp = sum(1 for _id, txt in pred.items() if _id in gt and gt[_id] == txt)

    precision = tp / len(pred)
    recall = tp / len(gt) if gt else 0.0

    if precision + recall == 0:
        return 0.0, tp, len(pred), len(gt)
    f1 = 2 * precision * recall / (precision + recall)
    return f1, tp, len(pred), len(gt)


# ----------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(
        description="Evaluate CSV cleansing-operator output"
    )
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Path to the cleansed CSV produced by your operator",
    )
    args = parser.parse_args()

    gt_dict = load_csv_as_dict(GT_PATH)
    pred_dict = load_csv_as_dict(Path(args.output))

    f1, tp, pred_n, gt_n = compute_f1(gt_dict, pred_dict)

    result = {
        "eval_score": round(f1, 4)
    }
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()