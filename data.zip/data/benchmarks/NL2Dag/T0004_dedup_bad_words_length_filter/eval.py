import argparse
import csv
import os
import re


def load_csv(path):
    data = []
    with open(path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data


def has_extra_spaces(text):
    """检查是否有多余空格"""
    # 检查开头或结尾是否有空格
    if text != text.strip():
        return True
    # 检查是否有连续的多个空格
    if re.search(r'\s{2,}', text):
        return True
    return False


def has_links(text):
    """检查文本是否包含链接"""
    link_patterns = [
        r'http://',
        r'https://',
        r'www\.'
    ]
    for pattern in link_patterns:
        if re.search(pattern, text, re.IGNORECASE):
            return True
    return False


def is_english(text):
    """检查文本是否为英文"""
    # 简单的英文检测：主要包含ASCII字符和基本标点
    english_chars = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 .,!?;:()-"\'/\\')
    text_chars = set(text)
    
    # 如果非英文字符超过20%，认为不是英文
    non_english_chars = text_chars - english_chars
    if len(text) > 0 and len(non_english_chars) / len(text_chars) > 0.2:
        return False
    
    # 检查是否包含基本的英文单词模式
    words = re.findall(r'\b[a-zA-Z]+\b', text)
    if len(words) == 0:
        return False
    
    return True


def has_spelling_grammar_errors(text):
    """检查文本是否包含明显的拼写或语法错误"""
    # 常见的拼写错误模式
    error_patterns = [
        r'\bdont\b',  # don't
        r'\bcant\b',  # can't
        r'\bits\b(?=\s+a\s)',  # its -> it's
        r'\byour\s+going\b',  # you're going
        r'\btheir\s+going\b',  # they're going
        r'\bto\s+the\s+\w+\s+tommorow\b',  # tomorrow
        r'\bcould\s+of\b',  # could have
        r'\bwould\s+of\b',  # would have
        r'\bshould\s+of\b',  # should have
        r'\brecieve\b',  # receive
        r'\bwe\s+was\b',  # we were
        r'\bi\s+seen\b',  # I saw
        r'\bloose\b(?=\s+the)',  # lose
        r'\bwether\b',  # weather
        r'\bbeleive\b',  # believe
        r'\bdiffcult\b',  # difficult
        r'\bobvius\b',  # obvious
        r'\bpractise\b(?=\s*$)',  # practice (as noun)
        r'\bexperiance\b',  # experience
        r'\btruely\b',  # truly
        r'\bamazng\b',  # amazing
        r'\bdefinatly\b',  # definitely
        r'\bagian\b',  # again
        r'\bsentance\b',  # sentence
        r'\bspeling\b',  # spelling
        r'\berors\b',  # errors
        r'\bgrammer\b',  # grammar
        r'\bbeautifull\b',  # beautiful
        r'\bpicknick\b',  # picnic
        r'\blibary\b',  # library
        r'\bproprly\b',  # properly
        r'\boportunity\b',  # opportunity
        r'\brestaraunt\b',  # restaurant
        r'\bproblms\b',  # problems
        r'\bunpredictible\b',  # unpredictable
    ]
    
    for pattern in error_patterns:
        if re.search(pattern, text, re.IGNORECASE):
            return True
    
    return False


def is_valid_record(record):
    """检查记录是否符合文本清洁任务要求"""
    text = record.get("text", "")
    
    # 条件1: 不应有多余空格
    if has_extra_spaces(text):
        return False
    
    # 条件2: 不应包含链接
    if has_links(text):
        return False
    
    # 条件3: 应该是英文
    if not is_english(text):
        return False
    
    # 条件4: 不应有拼写或语法错误
    if has_spelling_grammar_errors(text):
        return False
    
    return True


def get_gt():
    from pathlib import Path

    # 获取 eval.py 所在目录
    current_dir = Path(__file__).resolve().parent

    # 找到 expected 目录
    expected_dir = (current_dir / "./expected").resolve()

    # 查找第一个 .csv 文件
    csv_files = list(expected_dir.glob("*.csv"))

    if not csv_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")

    # 取第一个文件作为 expected_path
    expected_path = csv_files[0]

    return expected_path


def evaluate(processed_path):
    expected_path = get_gt()
    expected = load_csv(expected_path)
    processed = load_csv(processed_path)

    # 构造映射方便比对
    expected_map = {entry["id"]: entry for entry in expected}
    processed_map = {entry["id"]: entry for entry in processed}

    # 只评估交集部分
    common_ids = set(expected_map.keys()) & set(processed_map.keys())

    true_positives = 0
    failed_ids = []
    
    for cid in common_ids:
        gt = expected_map[cid]
        pred = processed_map[cid]

        # text 相同(去掉首尾空格对比) 且记录有效
        if (gt["text"].strip() == pred["text"].strip() and 
            is_valid_record(pred) and 
            gt.get("category") == pred.get("category")):
            true_positives += 1
        else:
            failed_ids.append(cid)

    # 检查是否有不应该出现的记录（在processed中但不在expected中）
    unexpected_ids = set(processed_map.keys()) - set(expected_map.keys())
    
    # 检查是否有遗漏的记录（在expected中但不在processed中）
    missing_ids = set(expected_map.keys()) - set(processed_map.keys())

    predicted_total = len(processed_map)
    gold_total = len(expected_map)

    precision = true_positives / predicted_total if predicted_total > 0 else 0.0
    recall = true_positives / gold_total if gold_total > 0 else 0.0
    f1 = (2 * precision * recall) / (precision + recall) if precision + recall > 0 else 0.0

    # 输出详细信息用于调试
    if failed_ids:
        print(f"Failed IDs: {failed_ids[:10]}...")  # 只显示前10个
    if unexpected_ids:
        print(f"Unexpected records (should be filtered): {len(unexpected_ids)}")
    if missing_ids:
        print(f"Missing records (should be kept): {len(missing_ids)}")
    
    result = {"eval_score": f"{f1:.4f}"}
    print(result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-o", "--output", help="Path to processed results file", required=True)
    args = parser.parse_args()

    evaluate(args.output)