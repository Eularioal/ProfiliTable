import json
import csv
import re
import random
import os
from typing import List, Dict, Any

def generate_raw_data() -> List[Dict[str, Any]]:
    """生成包含各种问题的原始数据"""
    
    # 正常的英文文本
    clean_texts = [
        "This is a clean English sentence.",
        "Machine learning is transforming the world.",
        "Python is a versatile programming language.",
        "The weather is beautiful today.",
        "I love reading books in my spare time.",
        "Technology continues to evolve rapidly.",
        "Education is the key to success.",
        "Teamwork makes the dream work.",
        "Innovation drives business growth.",
        "Communication is essential in relationships.",
        "Travel broadens the mind and soul.",
        "Exercise is important for good health.",
        "Music has the power to heal.",
        "Art expresses what words cannot say.",
        "Science helps us understand the universe.",
        "Friendship is one of life's greatest gifts.",
        "Patience is a virtue worth cultivating.",
        "Knowledge is power when applied wisely.",
        "Creativity flourishes in open environments.",
        "Success requires dedication and hard work.",
        "Nature provides endless inspiration for life.",
        "Learning never stops for curious minds.",
        "Kindness creates ripples of positive change.",
        "Dreams give direction to our efforts.",
        "Balance is key to a fulfilling life."
    ]
    
    # 包含多余空格的文本
    spaced_texts = [
        "This   has    multiple   spaces   between words.",
        "  Leading and trailing spaces  ",
        "Inconsistent    spacing   in   this  sentence.",
        "   Too   many    spaces    everywhere   ",
        "Mixed  spacing   and   formatting  issues.",
        "Random     gaps    in   the   text   flow.",
        "Irregular   white   space   distribution  here.",
        "  Extra   spaces   at   beginning   and   end  "
    ]
    
    # 包含链接的文本
    link_texts = [
        "Check out this website: http://example.com",
        "Visit https://www.google.com for more info",
        "Go to www.facebook.com to connect",
        "Link: http://github.com/user/repo",
        "See https://stackoverflow.com for help",
        "Browse www.amazon.com for products",
        "Reference: http://docs.python.org",
        "More at https://medium.com/article",
        "Visit www.linkedin.com for networking",
        "Check http://wikipedia.org for facts"
    ]
    
    # 非英文文本
    non_english_texts = [
        "这是一段中文文本。",
        "Esto es texto en español.",
        "C'est du texte en français.",
        "Dies ist deutscher Text.",
        "Questo è testo italiano.",
        "これは日本語のテキストです。",
        "Это русский текст.",
        "यह हिंदी पाठ है।",
        "이것은 한국어 텍스트입니다.",
        "هذا نص باللغة العربية."
    ]
    
    # 包含拼写/语法错误的文本
    error_texts = [
        "This sentance has speling erors.",
        "I dont think this grammer is correct.",
        "Their going too the store tommorow.",
        "Its a beautifull day for a picknick.",
        "I could of went to the libary yesterday.",
        "The recieve was not working proprly.",
        "We was planning to go their later.",
        "Your going to loose the oportunity.",
        "I seen him at the restaraunt.",
        "She dont want no more problms.",
        "The wether is unpredictible this year.",
        "I cant beleive how diffcult this is.",
        "Its obvius that we need more practise.",
        "The experiance was truely amazng.",
        "We should definatly try agian tomorrow."
    ]
    
    raw_data = []
    record_id = 1
    
    # 添加清洁的英文文本（这些会保留在GT中）
    for text in clean_texts:
        raw_data.append({
            "id": record_id,
            "text": text,
            "category": "clean"
        })
        record_id += 1
    
    # 添加包含多余空格的文本（清理后会保留）
    for text in spaced_texts:
        raw_data.append({
            "id": record_id,
            "text": text,
            "category": "spaced"
        })
        record_id += 1
    
    # 添加包含链接的文本（会被移除）
    for text in link_texts:
        raw_data.append({
            "id": record_id,
            "text": text,
            "category": "links"
        })
        record_id += 1
    
    # 添加非英文文本（会被移除）
    for text in non_english_texts:
        raw_data.append({
            "id": record_id,
            "text": text,
            "category": "non_english"
        })
        record_id += 1
    
    # 添加包含错误的文本（会被移除）
    for text in error_texts:
        raw_data.append({
            "id": record_id,
            "text": text,
            "category": "errors"
        })
        record_id += 1
    
    # 生成更多混合数据以达到150+条记录
    additional_clean = [
        "Data science combines statistics and programming.",
        "Artificial intelligence is reshaping industries.",
        "Cloud computing offers scalable solutions.",
        "Cybersecurity protects digital assets effectively.",
        "Blockchain technology ensures data integrity.",
        "Mobile applications enhance user experience.",
        "Social media connects people worldwide.",
        "E-commerce revolutionizes retail business models.",
        "Digital transformation accelerates business growth.",
        "Analytics provides insights for decision making.",
        "Automation increases operational efficiency significantly.",
        "User interface design impacts usability.",
        "Database management ensures data reliability.",
        "Network security prevents unauthorized access.",
        "Software development follows agile methodologies.",
        "Project management coordinates team efforts.",
        "Quality assurance maintains product standards.",
        "Version control tracks code changes.",
        "Testing validates software functionality thoroughly.",
        "Documentation supports system maintenance.",
        "Performance optimization improves system speed.",
        "Scalability planning accommodates future growth.",
        "Integration connects different system components.",
        "Deployment strategies minimize service disruption.",
        "Monitoring tools track system health.",
        "Backup procedures protect against data loss.",
        "Recovery plans ensure business continuity.",
        "Security policies protect organizational assets.",
        "Training programs develop employee skills.",
        "Innovation drives competitive advantage.",
        "Collaboration tools enhance team productivity.",
        "Communication protocols ensure message clarity.",
        "Planning processes guide project execution.",
        "Evaluation metrics measure project success.",
        "Feedback loops improve continuous processes.",
        "Leadership skills inspire team performance.",
        "Problem solving requires analytical thinking.",
        "Decision making involves risk assessment.",
        "Strategy development guides organizational direction.",
        "Implementation plans detail execution steps.",
        "Review processes validate project outcomes.",
        "Improvement initiatives enhance organizational capability.",
        "Best practices guide efficient operations.",
        "Standards ensure consistent quality delivery.",
        "Compliance requirements protect organizational interests.",
        "Governance frameworks guide decision processes.",
        "Risk management protects against uncertainties.",
        "Change management facilitates smooth transitions.",
        "Knowledge management preserves organizational learning.",
        "Resource allocation optimizes available assets.",
        "Time management improves personal productivity.",
        "Goal setting provides clear direction.",
        "Priority management focuses efforts effectively.",
        "Delegation skills distribute workload efficiently.",
        "Motivation techniques inspire peak performance.",
        "Recognition programs reward outstanding contributions.",
        "Development opportunities enhance career growth.",
        "Mentoring relationships accelerate learning processes.",
        "Networking activities build professional connections.",
        "Skill development increases career opportunities.",
        "Career planning guides professional advancement."
    ]
    
    for text in additional_clean:
        raw_data.append({
            "id": record_id,
            "text": text,
            "category": "clean"
        })
        record_id += 1
    
    # 随机打乱数据顺序
    random.shuffle(raw_data)
    
    return raw_data

def clean_text(text: str) -> str:
    """删除多余空格"""
    # 移除开头和结尾的空格，并将多个空格替换为单个空格
    return re.sub(r'\s+', ' ', text.strip())

def has_links(text: str) -> bool:
    """检查文本是否包含链接"""
    link_patterns = [
        r'http://',
        r'https://',
        r'www\.'
    ]
    for pattern in link_patterns:
        if re.search(pattern, text, re.IGNORECASE):
            return True
    return False

def is_english(text: str) -> bool:
    """检查文本是否为英文"""
    # 简单的英文检测：主要包含ASCII字符和基本标点
    english_chars = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 .,!?;:()-"\'/\\')
    text_chars = set(text)
    
    # 如果非英文字符超过20%，认为不是英文
    non_english_chars = text_chars - english_chars
    if len(text) > 0 and len(non_english_chars) / len(text_chars) > 0.2:
        return False
    
    # 检查是否包含基本的英文单词模式
    words = re.findall(r'\b[a-zA-Z]+\b', text)
    if len(words) == 0:
        return False
    
    return True

def has_spelling_grammar_errors(text: str) -> bool:
    """检查文本是否包含明显的拼写或语法错误"""
    # 常见的拼写错误模式
    error_patterns = [
        r'\bdont\b',  # don't
        r'\bcant\b',  # can't
        r'\bits\b(?=\s+a\s)',  # its -> it's
        r'\byour\s+going\b',  # you're going
        r'\btheir\s+going\b',  # they're going
        r'\bto\s+the\s+\w+\s+tommorow\b',  # tomorrow
        r'\bcould\s+of\b',  # could have
        r'\bwould\s+of\b',  # would have
        r'\bshould\s+of\b',  # should have
        r'\brecieve\b',  # receive
        r'\bwe\s+was\b',  # we were
        r'\bi\s+seen\b',  # I saw
        r'\bloose\b(?=\s+the)',  # lose
        r'\bwether\b',  # weather
        r'\bbeleive\b',  # believe
        r'\bdiffcult\b',  # difficult
        r'\bobvius\b',  # obvious
        r'\bpractise\b(?=\s*$)',  # practice (as noun)
        r'\bexperiance\b',  # experience
        r'\btruely\b',  # truly
        r'\bamazng\b',  # amazing
        r'\bdefinatly\b',  # definitely
        r'\bagian\b',  # again
        r'\bsentance\b',  # sentence
        r'\bspeling\b',  # spelling
        r'\berors\b',  # errors
        r'\bgrammer\b',  # grammar
        r'\bbeautifull\b',  # beautiful
        r'\bpicknick\b',  # picnic
        r'\blibary\b',  # library
        r'\bproprly\b',  # properly
        r'\boportunity\b',  # opportunity
        r'\brestaraunt\b',  # restaurant
        r'\bproblms\b',  # problems
        r'\bunpredictible\b',  # unpredictable
    ]
    
    for pattern in error_patterns:
        if re.search(pattern, text, re.IGNORECASE):
            return True
    
    return False

def process_data(raw_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """处理数据，应用所有清洗规则"""
    processed_data = []
    
    for record in raw_data:
        text = record['text']
        
        # 1. 删除多余空格
        cleaned_text = clean_text(text)
        
        # 2. 检查是否包含链接
        if has_links(cleaned_text):
            continue  # 跳过包含链接的记录
        
        # 3. 检查是否为英文
        if not is_english(cleaned_text):
            continue  # 跳过非英文记录
        
        # 4. 检查是否有拼写或语法错误
        if has_spelling_grammar_errors(cleaned_text):
            continue  # 跳过有错误的记录
        
        # 如果通过所有检查，添加到处理后的数据中
        processed_record = record.copy()
        processed_record['text'] = cleaned_text
        processed_data.append(processed_record)
    
    return processed_data

def save_to_csv(data: List[Dict[str, Any]], filepath: str):
    """保存数据到CSV文件"""
    if not data:
        return
    
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = data[0].keys()
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)

def main():
    """主函数，生成测试数据"""
    print("生成原始数据...")
    raw_data = generate_raw_data()
    print(f"生成了 {len(raw_data)} 条原始记录")
    
    print("处理数据...")
    gt_data = process_data(raw_data)
    print(f"处理后保留了 {len(gt_data)} 条记录")
    
    # 保存原始数据到 raw/customers.csv
    print("保存原始数据到 raw/customers.csv...")
    save_to_csv(raw_data, 'raw/customers.csv')
    
    # 保存处理后的数据到 expected/gt.csv
    print("保存GT数据到 expected/gt.csv...")
    save_to_csv(gt_data, 'expected/gt.csv')
    
    print("数据生成完成！")
    print(f"原始数据: {len(raw_data)} 条记录")
    print(f"GT数据: {len(gt_data)} 条记录")
    print(f"清洗率: {(len(raw_data) - len(gt_data)) / len(raw_data) * 100:.1f}%")

if __name__ == "__main__":
    main()