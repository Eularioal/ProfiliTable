import argparse
import csv
import os
import re
import pandas as pd
import numpy as np
from typing import List, Dict, Any
from datetime import datetime
import ipaddress


def load_csv(path):
    """加载CSV文件"""
    data = []
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data


def is_valid_ipv4(ip_str: str) -> bool:
    """检查IPv4地址是否有效"""
    try:
        ipaddress.IPv4Address(str(ip_str).strip())
        return True
    except:
        return False


def is_valid_date_format(date_str: str) -> bool:
    """检查日期格式是否为YYYY-MM-DD"""
    try:
        datetime.strptime(str(date_str).strip(), '%Y-%m-%d')
        return True
    except:
        return False


def check_ipv4_filtering(data: List[Dict[str, Any]]) -> bool:
    """检查是否正确删除了无效IPv4地址的行"""
    for record in data:
        ip = record.get('ipv4_address', '')
        if not is_valid_ipv4(ip):
            return False
    return True


def check_date_filtering(data: List[Dict[str, Any]]) -> bool:
    """检查是否正确删除了无效日期格式的行"""
    for record in data:
        date = record.get('date', '')
        if not is_valid_date_format(date):
            return False
    return True


def check_deduplication(data: List[Dict[str, Any]]) -> bool:
    """检查是否正确按ipv4_address和date去重，优先保留非_dup结尾的记录"""
    # 按ipv4_address和date分组
    groups = {}
    for record in data:
        key = (record['ipv4_address'], record['date'])
        if key not in groups:
            groups[key] = []
        groups[key].append(record)
    
    # 检查每组是否只有一条记录，且优先保留非_dup结尾的
    for key, records in groups.items():
        if len(records) > 1:
            return False
        
        # 如果只有一条记录，检查原始数据中是否存在_dup版本应该被删除的情况
        record = records[0]
        id_val = record['id']
        if id_val.endswith('_dup'):
            # 如果保留的是_dup结尾的，这通常不正确（除非没有非_dup版本）
            # 这里我们假设正确的逻辑是优先保留非_dup的
            return False
    
    return True


def check_missing_value_imputation(data: List[Dict[str, Any]]) -> bool:
    """检查是否正确填充了数值列的缺失值"""
    if not data:
        return True
    
    # 转换为DataFrame以便检查
    df = pd.DataFrame(data)
    
    # 识别数值列
    numeric_columns = []
    for col in df.columns:
        if col not in ['id', 'ipv4_address', 'date']:  # 排除非数值列
            try:
                # 尝试转换为数值类型
                pd.to_numeric(df[col], errors='raise')
                numeric_columns.append(col)
            except:
                continue
    
    # 检查数值列是否还有缺失值
    for col in numeric_columns:
        if df[col].isna().any():
            return False
    
    return True


def calculate_completeness_score(data: List[Dict[str, Any]]) -> float:
    """计算数据完整性分数"""
    if not data:
        return 0.0
    
    total_checks = 4
    passed_checks = 0
    
    # 检查IPv4过滤
    if check_ipv4_filtering(data):
        passed_checks += 1
    
    # 检查日期格式过滤  
    if check_date_filtering(data):
        passed_checks += 1
    
    # 检查去重
    if check_deduplication(data):
        passed_checks += 1
    
    # 检查缺失值填充
    if check_missing_value_imputation(data):
        passed_checks += 1
    
    return passed_checks / total_checks


def is_valid_record(record: Dict[str, Any]) -> bool:
    """检查单条记录是否有效"""
    # 检查必要字段是否存在
    required_fields = ['id', 'ipv4_address', 'date']
    for field in required_fields:
        if field not in record or not record[field]:
            return False
    
    # 检查IPv4地址是否有效
    if not is_valid_ipv4(record['ipv4_address']):
        return False
    
    # 检查日期格式是否有效
    if not is_valid_date_format(record['date']):
        return False
    
    return True


def is_valid_dataset(data: List[Dict[str, Any]]) -> bool:
    """检查整个数据集是否有效"""
    if not data:
        return False
    
    # 检查所有记录是否有效
    for record in data:
        if not is_valid_record(record):
            return False
    
    # 检查是否正确执行了所有清洗步骤
    if not check_ipv4_filtering(data):
        return False
    
    if not check_date_filtering(data):
        return False
    
    if not check_deduplication(data):
        return False
    
    if not check_missing_value_imputation(data):
        return False
    
    return True


def get_gt():
    """获取标准答案文件路径"""
    from pathlib import Path

    # 获取 eval.py 所在目录
    current_dir = Path(__file__).resolve().parent

    # 找到 expected 目录
    expected_dir = (current_dir / "./expected").resolve()

    # 查找第一个 .csv 文件
    csv_files = list(expected_dir.glob("*.csv"))

    if not csv_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")

    # 取第一个文件作为 expected_path
    expected_path = csv_files[0]

    return expected_path


def evaluate(processed_path):
    """评估处理结果"""
    expected_path = get_gt()
    expected = load_csv(expected_path)
    processed = load_csv(processed_path)

    # 构造映射方便比对（使用id作为键）
    expected_map = {entry['id']: entry for entry in expected}
    processed_map = {entry['id']: entry for entry in processed}

    # 计算交集
    common_ids = set(expected_map.keys()) & set(processed_map.keys())

    true_positives = 0
    failed_ids = []
    
    for record_id in common_ids:
        gt = expected_map[record_id]
        pred = processed_map[record_id]

        # 检查所有字段是否匹配
        fields_match = True
        for field in gt.keys():
            if field in pred:
                # 对于数值字段，允许小的浮点误差
                if field not in ['id', 'ipv4_address', 'date']:
                    try:
                        gt_val = float(gt[field])
                        pred_val = float(pred[field])
                        if abs(gt_val - pred_val) > 1e-6:
                            fields_match = False
                            break
                    except:
                        if str(gt[field]).strip() != str(pred[field]).strip():
                            fields_match = False
                            break
                else:
                    if str(gt[field]).strip() != str(pred[field]).strip():
                        fields_match = False
                        break
            else:
                fields_match = False
                break
        
        if fields_match and is_valid_record(pred):
            true_positives += 1
        else:
            failed_ids.append(record_id)

    # 检查是否有不应该出现的记录
    unexpected_ids = set(processed_map.keys()) - set(expected_map.keys())
    
    # 检查是否有遗漏的记录
    missing_ids = set(expected_map.keys()) - set(processed_map.keys())

    # 检查整个数据集的有效性
    dataset_valid = is_valid_dataset(processed)

    predicted_total = len(processed_map)
    gold_total = len(expected_map)

    precision = true_positives / predicted_total if predicted_total > 0 else 0.0
    recall = true_positives / gold_total if gold_total > 0 else 0.0
    f1 = (2 * precision * recall) / (precision + recall) if precision + recall > 0 else 0.0

    # 如果数据集无效，降低F1分数
    if not dataset_valid:
        completeness_score = calculate_completeness_score(processed)
        f1 *= max(0.1, completeness_score)  # 根据完整性调整惩罚程度
        print(f"警告: 数据集无效，F1分数已调整。完整性分数: {completeness_score:.4f}")

    # 输出详细信息用于调试
    if failed_ids:
        print(f"Failed IDs: {failed_ids[:10]}...")  # 只显示前10个
    if unexpected_ids:
        print(f"Unexpected records: {len(unexpected_ids)}")
        if len(unexpected_ids) <= 5:
            print(f"Unexpected IDs: {list(unexpected_ids)}")
    if missing_ids:
        print(f"Missing records: {len(missing_ids)}")
        if len(missing_ids) <= 5:
            print(f"Missing IDs: {list(missing_ids)}")
    

    result = {"eval_score": f"{f1:.4f}"}
    print(result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-o", "--output", help="Path to processed results file", required=True)
    args = parser.parse_args()

    evaluate(args.output)