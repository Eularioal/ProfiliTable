import pandas as pd
import numpy as np
import random
import os
from datetime import datetime, timedelta
import ipaddress

def generate_valid_ipv4():
    """生成有效的IPv4地址"""
    return f"{random.randint(1, 254)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"

def generate_invalid_ipv4():
    """生成无效的IPv4地址"""
    invalid_types = [
        f"{random.randint(256, 999)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}",  # 超出范围
        f"{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}",  # 缺少段
        f"{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}",  # 多余段
        "invalid.ip.address.format",  # 非数字
        "",  # 空值
        "192.168.1",  # 不完整
        "300.300.300.300"  # 超出范围
    ]
    return random.choice(invalid_types)

def generate_valid_date():
    """生成有效的YYYY-MM-DD格式日期"""
    start_date = datetime(2020, 1, 1)
    end_date = datetime(2024, 12, 31)
    time_between = end_date - start_date
    days_between = time_between.days
    random_days = random.randrange(days_between)
    random_date = start_date + timedelta(days=random_days)
    return random_date.strftime('%Y-%m-%d')

def generate_invalid_date():
    """生成无效的日期格式"""
    invalid_formats = [
        "2023/01/15",  # 错误分隔符
        "01-15-2023",  # 美式格式
        "15-01-2023",  # 欧式格式
        "2023-1-5",    # 缺少前导零
        "23-01-15",    # 年份缩写
        "",            # 空值
        "invalid-date",  # 非日期
        "2023-13-45",  # 无效月日
        "2023-02-30"   # 无效日期
    ]
    return random.choice(invalid_formats)

def is_valid_ipv4(ip):
    """检查IPv4地址是否有效"""
    try:
        ipaddress.IPv4Address(ip)
        return True
    except:
        return False

def is_valid_date(date_str):
    """检查日期格式是否为YYYY-MM-DD"""
    try:
        datetime.strptime(str(date_str), '%Y-%m-%d')
        return True
    except:
        return False

def generate_data():
    """生成原始数据和清洗后的数据"""
    np.random.seed(42)
    random.seed(42)
    
    # 确保目录存在
    os.makedirs('raw', exist_ok=True)
    os.makedirs('expected', exist_ok=True)
    
    # 生成基础有效数据
    base_data = []
    valid_ips = [generate_valid_ipv4() for _ in range(100)]
    valid_dates = [generate_valid_date() for _ in range(50)]
    
    # 生成200条基础记录
    for i in range(200):
        base_data.append({
            'id': f'record_{i:04d}',
            'ipv4_address': random.choice(valid_ips),
            'date': random.choice(valid_dates),
            'value': round(random.uniform(10, 100), 2)  # 数值列用于测试缺失值填充
        })
    
    # 添加一些无效IPv4地址的记录
    for i in range(30):
        base_data.append({
            'id': f'invalid_ip_{i:03d}',
            'ipv4_address': generate_invalid_ipv4(),
            'date': random.choice(valid_dates),
            'value': round(random.uniform(10, 100), 2)
        })
    
    # 添加一些无效日期的记录
    for i in range(25):
        base_data.append({
            'id': f'invalid_date_{i:03d}',
            'ipv4_address': random.choice(valid_ips),
            'date': generate_invalid_date(),
            'value': round(random.uniform(10, 100), 2)
        })
    
    # 添加重复记录（包括_dup结尾的）
    duplicate_base = random.sample([d for d in base_data if is_valid_ipv4(d['ipv4_address']) and is_valid_date(d['date'])], 20)
    for i, dup in enumerate(duplicate_base):
        # 添加原记录的重复
        base_data.append({
            'id': dup['id'],
            'ipv4_address': dup['ipv4_address'],
            'date': dup['date'],
            'value': dup['value']
        })
        
        # 添加以_dup结尾的重复记录
        base_data.append({
            'id': f"{dup['id']}_dup",
            'ipv4_address': dup['ipv4_address'],
            'date': dup['date'],
            'value': round(random.uniform(10, 100), 2)
        })
    
    # 随机打乱数据
    random.shuffle(base_data)
    
    # 创建DataFrame并添加一些缺失值
    df_raw = pd.DataFrame(base_data)
    
    # 随机添加缺失值到value列
    missing_indices = random.sample(range(len(df_raw)), 15)
    for idx in missing_indices:
        df_raw.loc[idx, 'value'] = np.nan
    
    # 保存原始数据
    df_raw.to_csv('raw/customers.csv', index=False)
    
    # 清洗数据生成GT
    df_clean = df_raw.copy()
    
    # 1. 删除非法IPv4地址的行
    df_clean = df_clean[df_clean['ipv4_address'].apply(is_valid_ipv4)]
    
    # 2. 删除非YYYY-MM-DD格式的日期行
    df_clean = df_clean[df_clean['date'].apply(is_valid_date)]
    
    # 3. 按ipv4_address和date去重，优先保留非_dup结尾的记录
    # 先按是否以_dup结尾排序（False在前，即非_dup的在前）
    df_clean['is_dup'] = df_clean['id'].str.endswith('_dup')
    df_clean = df_clean.sort_values('is_dup')
    
    # 去重，保留第一个（即非_dup的）
    df_clean = df_clean.drop_duplicates(subset=['ipv4_address', 'date'], keep='first')
    df_clean = df_clean.drop('is_dup', axis=1)
    
    # 4. 数值列缺失值用均值填充
    numeric_columns = df_clean.select_dtypes(include=[np.number]).columns
    for col in numeric_columns:
        mean_val = df_clean[col].mean()
        df_clean[col] = df_clean[col].fillna(mean_val)
    
    # 重置索引并保存
    df_clean = df_clean.reset_index(drop=True)
    df_clean.to_csv('expected/gt.csv', index=False)
    
    print(f"原始数据生成完成: {len(df_raw)} 条记录")
    print(f"清洗后数据生成完成: {len(df_clean)} 条记录")
    print(f"无效IPv4记录: {len(df_raw) - len(df_raw[df_raw['ipv4_address'].apply(is_valid_ipv4)])}")
    print(f"无效日期记录: {len(df_raw[df_raw['ipv4_address'].apply(is_valid_ipv4)]) - len(df_raw[df_raw['ipv4_address'].apply(is_valid_ipv4) & df_raw['date'].apply(is_valid_date)])}")
    print(f"原始数据中的缺失值: {df_raw['value'].isna().sum()}")
    print(f"清洗后数据中的缺失值: {df_clean['value'].isna().sum()}")

if __name__ == "__main__":
    generate_data()