#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Scoring rules
-------------
1. 只看 id 集合的 F1 (50%)
2. 对命中 id 的 text 完全一致率 (30%)
3. 对命中 id 的 review_id 是否为最小值 (20%)

最终 0-1 分：0.5·F1 + 0.3·text_acc + 0.2·review_acc
"""

from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from typing import Dict, List, Set

GT_PATH = Path(__file__).parent / "expected" / "gt.jsonl"

def load(path: Path) -> List[dict]:
    if not path.is_file():
        raise FileNotFoundError(path)
    data, seen = [], set()
    with path.open(encoding="utf-8-sig") as f:
        for ln, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"{path}:{ln} bad json: {e}") from None
            if obj["id"] in seen:
                raise ValueError(f"{path}:{ln} duplicate id={obj['id']}")
            seen.add(obj["id"])
            data.append(obj)
    return data

def f1(gt: Set[int], pred: Set[int]) -> float:
    if not pred: return 0.0
    tp = len(gt & pred)
    p, r = tp / len(pred), tp / len(gt)
    return 0.0 if p + r == 0 else 2 * p * r / (p + r)

def accuracy(gt_map: Dict[int, str], pred_map: Dict[int, str], ids: Set[int]) -> float:
    if not ids: return 0.0
    ok = sum(gt_map[i] == pred_map[i] for i in ids)
    return ok / len(ids)

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("-o", "--output", required=True, help="your jsonl")
    args = ap.parse_args()

    gt = load(GT_PATH)
    pred = load(Path(args.output))

    gt_ids, pred_ids = {r["id"] for r in gt}, {r["id"] for r in pred}
    common = gt_ids & pred_ids

    gt_text = {r["id"]: r["text"] for r in gt}
    pred_text = {r["id"]: r["text"] for r in pred}
    gt_rev  = {r["id"]: r["review_id"] for r in gt}
    pred_rev = {r["id"]: r["review_id"] for r in pred}

    s_f1   = f1(gt_ids, pred_ids)
    s_txt  = accuracy(gt_text, pred_text, common)
    s_rev  = accuracy(gt_rev, pred_rev, common)

    score = 0.5 * s_f1 + 0.3 * s_txt + 0.2 * s_rev
    print(json.dumps({
        # "id_F1": round(s_f1, 4),
        # "text_acc": round(s_txt, 4),
        # "review_acc": round(s_rev, 4),
        "eval_score": round(score, 4)
    }, ensure_ascii=False))

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"eval_score": 0.0, "error": str(e)}, ensure_ascii=False))
        sys.exit(1)