#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generate demo data for the 5-step deep-clean task.

1) >100 dirty customer records ➜ raw/customers.jsonl
2) Apply 5-step pipeline ➜ expected/gt.jsonl
"""
import json
import os
import random
import re
import uuid
from datetime import datetime, timedelta
from itertools import combinations
from pathlib import Path
from typing import Dict, List, Set

# ---------------- 工具 ----------------

def rand_dt(base: datetime) -> str:
    return (base + timedelta(seconds=random.randint(0, 30 * 24 * 3600))).isoformat(timespec="seconds")

def noisy_sentence(s: str) -> str:
    """插入重复词、多余空格、偶尔嵌入 URL"""
    w = s.split()
    i = random.randint(0, len(w) - 1)
    w.insert(i, w[i])              # 连续重复
    txt = " ".join(w)
    # 随机塞 1-3 个多余空格
    for _ in range(random.randint(1, 3)):
        pos = random.randint(1, len(txt) - 2)
        txt = txt[:pos] + " " + txt[pos:]
    # 10% 概率插 URL
    if random.random() < 0.1:
        txt += f" http://example.com/{uuid.uuid4().hex[:6]}"
    return txt

URL_RE = re.compile(r"https?://\S+")

def contains_url(t: str) -> bool:
    return bool(URL_RE.search(t))

def dedup_words(t: str) -> str:
    words, out = t.split(), []
    seen: Set[str] = set()
    for w in words:
        if w not in seen:
            seen.add(w)
            out.append(w)
    return " ".join(out)

def clean_text(t: str) -> str:
    t = URL_RE.sub("", t)          # 理论上已删含 URL，但保险再去掉
    t = dedup_words(t)
    return " ".join(t.split())     # merge spaces & strip

def shingles(t: str, k: int = 3) -> Set[str]:
    tok = t.split()
    if len(tok) < k:
        return {" ".join(tok)}
    return {" ".join(tok[i:i+k]) for i in range(len(tok)-k+1)}

def jaccard(a: Set[str], b: Set[str]) -> float:
    inter = a & b
    union = a | b
    return len(inter) / len(union) if union else 0.0

# ---------------- 生成 RAW ----------------

random.seed(2025)
BASE = datetime.utcnow()

sentences = [
    "good product", "very bad experience", "average quality",
    "totally worth the price", "will buy again", "not recommended",
    "excellent service", "packaging was poor", "fast delivery",
    "color was different", "size fits well", "battery life is short",
    "highly recommended", "terrible customer support", "value for money",
]

raw: List[Dict] = []

# 主体 150 条
for _ in range(150):
    s = random.choice(sentences)
    raw.append({
        "id": random.randint(1, 80),          # 故意制造 id 冲突
        "review_id": str(uuid.uuid4()),
        "text": noisy_sentence(s),
        "update_time": rand_dt(BASE)
    })

# 制造近似重复文本（MinHash ≥0.9）
for a, b in random.sample(list(combinations(sentences, 2)), 15):
    base = f"{a} and {b}"
    for _ in range(2):
        raw.append({
            "id": random.randint(81, 110),
            "review_id": str(uuid.uuid4()),
            "text": noisy_sentence(base),
            "update_time": rand_dt(BASE)
        })

# 额外 20 条带 URL（应被删掉）
for _ in range(20):
    s = random.choice(sentences)
    raw.append({
        "id": random.randint(111, 130),
        "review_id": str(uuid.uuid4()),
        "text": s + f" https://spam.site/{uuid.uuid4().hex[:5]} ad",
        "update_time": rand_dt(BASE)
    })

Path("raw").mkdir(exist_ok=True)
with open("raw/customers.jsonl", "w", encoding="utf-8") as f:
    for r in raw:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")
print(f"[gen_data] wrote {len(raw)} raw records")

# ---------------- 生成 GT ----------------

# ① 删含 URL
step1 = [r for r in raw if not contains_url(r["text"])]

# ②+③ 清洗文本
for r in step1:
    r["text_clean"] = clean_text(r["text"])

# ④ MinHash ≥0.9 去重，保最小 review_id
groups: List[List[Dict]] = []
visited = set()
for i, r in enumerate(step1):
    if i in visited:
        continue
    g = [r]
    sh1 = shingles(r["text_clean"])
    for j in range(i + 1, len(step1)):
        if j in visited:
            continue
        if jaccard(sh1, shingles(step1[j]["text_clean"])) >= 0.9:
            g.append(step1[j])
            visited.add(j)
    groups.append(g)

after_minhash: List[Dict] = []
for g in groups:
    chosen = min(g, key=lambda x: x["review_id"])
    after_minhash.append(chosen)

# ⑤ id 去重：保最新 update_time
latest: Dict[int, Dict] = {}
for r in after_minhash:
    rid = r["id"]
    if rid not in latest or r["update_time"] > latest[rid]["update_time"]:
        latest[rid] = r

gt = [{
    "id": v["id"],
    "review_id": v["review_id"],
    "text": v["text_clean"],
    "update_time": v["update_time"],
} for v in latest.values()]

gt.sort(key=lambda x: x["id"])

Path("expected").mkdir(exist_ok=True)
with open("expected/gt.jsonl", "w", encoding="utf-8") as f:
    for r in gt:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")
print(f"[gen_data] wrote {len(gt)} GT records")