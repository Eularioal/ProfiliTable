#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
按照 (first_name,last_name,dob) 键对齐，
逐行全字段一致计 1 分，否则 0 分。
最终得分 = 命中行数 / GT 行数，范围 [0,1]。
"""

from __future__ import annotations
import argparse, csv, json
from pathlib import Path


def get_gt():
    from pathlib import Path

    # 获取 gen_data.py 所在目录
    current_dir = Path(__file__).resolve().parent

    # 找到 expected 目录
    expected_dir = (current_dir / "./expected").resolve()

    # 查找第一个 .jsonl 文件
    jsonl_files = list(expected_dir.glob("*.csv"))

    if not jsonl_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")

    # 取第一个文件作为 expected_path
    expected_path = jsonl_files[0]

    return expected_path



def load_map(fp: Path):
    with fp.open(encoding="utf-8-sig") as f:
        rdr = csv.DictReader(f)
        return {(r["first_name"],r["last_name"],r["dob"]): r for r in rdr}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-o","--output",required=True,help="your cleaned csv")
    args = ap.parse_args()
    gt_path = get_gt()
    gt = load_map(gt_path)
    pred = load_map(Path(args.output).expanduser())

    matched = sum(1 for k,v in gt.items() if k in pred and pred[k]==v)
    score = matched / len(gt) if gt else 0.0
    print(json.dumps({"eval_score": f"{score:.4f}"}))

if __name__ == "__main__":
    main()