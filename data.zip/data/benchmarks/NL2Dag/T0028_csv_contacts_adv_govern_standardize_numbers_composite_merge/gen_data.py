#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成模拟客户 CSV 以及清洗后的 GT（UTF-8 编码）

治理规则
1. phone / email 标准化
   • phone → 保留数字, 统一输出 +1XXXXXXXXXX（美国 10 位）
   • email → 去首尾空格并小写
2. text 字段中的所有数字统一保留两位小数
3. 以 (first_name,last_name,dob) 作为复合键去重：
   • 对重复记录做“字段非空并集”合并
   • created_at 留最早时间戳
"""

from __future__ import annotations
import csv
import json
import random
import re
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List

# --------------------------------------------------------------------------- #
# 常量
# --------------------------------------------------------------------------- #
RAW_DIR = Path("raw"); RAW_DIR.mkdir(exist_ok=True, parents=True)
EXP_DIR = Path("expected"); EXP_DIR.mkdir(exist_ok=True, parents=True)

RAW_CSV = RAW_DIR / "customers.csv"
GT_CSV  = EXP_DIR / "gt.csv"

N_BASE = 140    # 唯一复合键行数
N_DUP  = 60     # 复制行（带缺失/冲突）=> raw 总行 200

FIRST_NAMES = ["Alice","Bob","Carol","Dave","Eve","Frank","Grace","Heidi"]
LAST_NAMES  = ["Smith","Johnson","Williams","Brown","Jones","Miller","Davis"]
EMAIL_DOMS  = ["example.com","test.org","mail.net"]
TEXT_TPLS   = [
    "Customer spent {amt} USD on electronics.",
    "Order total was {amt}. Shipment pending.",
    "Refunded {amt} due to defect.",
]

PHONE_FMT = ["({}) {}-{}", "{}-{}-{}", "{} {} {}"]

# --------------------------------------------------------------------------- #
# 清洗函数
# --------------------------------------------------------------------------- #
_re_num = re.compile(r"\d+(?:\.\d+)?")

def normalize_phone(raw: str) -> str:
    digits = re.sub(r"[^\d]", "", raw)
    digits = digits[-10:].rjust(10, "0")  # 不足补0 / 只取后10位
    return f"+1{digits}"

def normalize_email(raw: str) -> str:
    return raw.strip().lower()

def format_number(m: str) -> str:
    return f"{float(m):.2f}"

def normalize_text(raw: str) -> str:
    return _re_num.sub(lambda m: format_number(m.group()), raw)

# --------------------------------------------------------------------------- #
# 生成原始数据
# --------------------------------------------------------------------------- #
def random_phone() -> str:
    d = "".join(random.choices("0123456789", k=10))
    f = random.choice(PHONE_FMT)
    if "{}-{}-{}" in f:
        return f.format(d[:3], d[3:6], d[6:])
    if "({})" in f:
        return f.format(d[:3], d[3:6], d[6:])
    return f.format(d[:3], d[3:6], d[6:])

def rand_email(fname: str, lname: str) -> str:
    dom = random.choice(EMAIL_DOMS)
    return f"{fname[0]}{lname}{random.randint(1,99)}@{dom}"

today = datetime.utcnow()

def base_row(idx: int) -> Dict[str,str]:
    fname = random.choice(FIRST_NAMES)
    lname = random.choice(LAST_NAMES)
    dob   = datetime(1970,1,1)+timedelta(days=random.randint(0,18000))
    phone = random_phone()
    email = rand_email(fname.lower(), lname.lower())
    amt   = random.uniform(1, 500)
    text  = random.choice(TEXT_TPLS).format(amt=f"{amt:.4f}")  # 多余小数
    created_at = today - timedelta(days=random.randint(0,3650),
                                   seconds=random.randint(0,86400))
    return {
        "first_name": fname,
        "last_name" : lname,
        "dob"       : dob.strftime("%Y-%m-%d"),
        "phone"     : phone,
        "email"     : email,
        "text"      : text,
        "created_at": created_at.strftime("%Y-%m-%d %H:%M:%S"),
    }

rows: List[Dict[str,str]] = []
for i in range(N_BASE):
    base = base_row(i)
    rows.append(base)

# 制造重复：随机移除部分字段 / 修改冲突数据
for _ in range(N_DUP):
    src = dict(random.choice(rows))            # 复制
    # 模拟缺失
    if random.random() < 0.5:  src["phone"] = ""
    if random.random() < 0.5:  src["email"] = ""
    if random.random() < 0.5:  src["text"]  = ""
    # created_at 稍晚，产生冲突
    created_plus = datetime.strptime(src["created_at"], "%Y-%m-%d %H:%M:%S") \
                   + timedelta(days=random.randint(1, 365))
    src["created_at"] = created_plus.strftime("%Y-%m-%d %H:%M:%S")
    rows.append(src)

# 写入 raw CSV
with RAW_CSV.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

# --------------------------------------------------------------------------- #
# 生成治理后的 GT
# --------------------------------------------------------------------------- #
grouped: Dict[tuple, Dict[str,str]] = {}
for r in rows:
    key = (r["first_name"], r["last_name"], r["dob"])

    # 单行先做字段级标准化
    norm_row = {
        **r,
        "phone": normalize_phone(r["phone"]) if r["phone"] else "",
        "email": normalize_email(r["email"]) if r["email"] else "",
        "text" : normalize_text(r["text"])   if r["text"]  else "",
    }

    if key not in grouped:
        grouped[key] = norm_row
    else:
        tgt = grouped[key]
        # 非空并集：phone / email / text
        for col in ("phone", "email", "text"):
            vals = {v for v in [tgt[col], norm_row[col]] if v}
            tgt[col] = " | ".join(sorted(vals)) if vals else ""
        # created_at 保最早
        if norm_row["created_at"] < tgt["created_at"]:
            tgt["created_at"] = norm_row["created_at"]

# 写 GT
gt_rows = list(grouped.values())
with GT_CSV.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(gt_rows[0].keys()))
    writer.writeheader()
    writer.writerows(gt_rows)

print(f"✓ raw rows: {len(rows)}, gt rows: {len(gt_rows)}")