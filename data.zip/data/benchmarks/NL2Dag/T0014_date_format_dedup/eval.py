import json
import argparse
import csv
from pathlib import Path

# Function to load JSONL files
def load_jsonl(path):
    entries = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            entries.append(json.loads(line))
    return entries

# Function to load CSV files (since your data is in CSV format)
def load_csv(path):
    entries = []
    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            entries.append(row)
    return entries

# Function to evaluate F1 score
def evaluate(expected_path, processed_path):
    # Load data
    expected = load_csv(expected_path)
    processed = load_csv(processed_path)

    # Convert processed data to a set of ids for comparison
    processed_ids = set(entry['id'] for entry in processed)

    # Convert expected data to a set of ids for comparison
    expected_ids = set(entry['id'] for entry in expected)

    # Calculate true positives, predicted total, and gold total
    true_positives = len(expected_ids & processed_ids)
    predicted_total = len(processed_ids)
    gold_total = len(expected_ids)

    # Calculate precision, recall, and F1 score
    precision = true_positives / predicted_total if predicted_total > 0 else 0.0
    recall = true_positives / gold_total if gold_total > 0 else 0.0
    f1 = (2 * precision * recall) / (precision + recall) if precision + recall > 0 else 0.0


    print(json.dumps({"eval_score": f"{f1:.4f}"}))


# Function to get the expected path (GT data)
def get_gt():
    current_dir = Path(__file__).resolve().parent

    # Adjust the directory according to your file structure
    expected_dir = (current_dir / "./expected").resolve()

    # Find the .jsonl file
    jsonl_files = list(expected_dir.glob("*.csv"))

    if not jsonl_files:
        raise FileNotFoundError(f"No .jsonl file found in {expected_dir}")

    # Return the first file found
    expected_path = jsonl_files[0]

    return expected_path

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate CSV vs. GT data")
    parser.add_argument(
        "-o", "--output", required=True, help="Path to the processed CSV file"
    )
    args = parser.parse_args()

    expected_path = get_gt()
    processed_path = args.output

    # Perform evaluation
    evaluate(expected_path, processed_path)
