import csv
from pathlib import Path
from datetime import datetime, timedelta
import random
import pandas as pd

def generate_gt_csv(gt_path: Path, num_records=100):
    """生成 GT CSV，日期为标准 YYYY-MM-DD"""
    gt_path.parent.mkdir(parents=True, exist_ok=True)
    start_date = datetime(2020, 1, 1)
    records = []
    for i in range(num_records):
        random_days = random.randint(0, 1500)
        date_val = (start_date + timedelta(days=random_days)).strftime("%Y-%m-%d")
        records.append({"id": f"c_{i:04d}", "date": date_val})
    # 保存
    with open(gt_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "date"])
        writer.writeheader()
        writer.writerows(records)
    print(f"✅ GT CSV saved to {gt_path}")


def generate_customers_csv(gt_path: Path, customers_path: Path):
    """在 GT 基础上生成 customers CSV，包含重复和非标准日期"""
    # 读取 GT
    gt_df = pd.read_csv(gt_path)

    # 复制一部分 GT 数据（制造重复）
    duplicate_samples = gt_df.sample(30, random_state=42).copy()
    duplicate_samples['id'] = duplicate_samples['id'].astype(str) + "_dup"


    # 制造非标准日期格式
    non_standard_dates = [
        "2025/08/27", "27-08-2025", "Aug 27, 2025", "20250827", "08-27-25",
        "2025年08月27日", "27th August 2025", "Wed, 27 Aug 2025"
    ]*50
    non_standard_samples = pd.DataFrame({
        "id": range(1001, 1001 + len(non_standard_dates)),
        "date": non_standard_dates
    })

    # 合并所有数据
    customers_df = pd.concat([gt_df, duplicate_samples, non_standard_samples], ignore_index=True)

    # 保存
    customers_path.parent.mkdir(parents=True, exist_ok=True)
    customers_df.to_csv(customers_path, index=False)
    print(f"⚠️ Customers CSV saved to {customers_path}")


if __name__ == "__main__":
    base_dir = Path(__file__).parent
    gt_csv_path = base_dir / "expected/gt.csv"
    customers_csv_path = base_dir / "raw/customers.csv"

    generate_gt_csv(gt_csv_path)
    generate_customers_csv(gt_csv_path, customers_csv_path)
