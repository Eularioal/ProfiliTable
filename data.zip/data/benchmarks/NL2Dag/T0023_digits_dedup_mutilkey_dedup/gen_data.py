
import csv
import random
from pathlib import Path
import faker

# 设置路径
gt_file_path = Path(__file__).parent / "expected/gt.csv"
output_file = Path(__file__).parent / "raw/customers.csv"

# 读取gt.csv文件内容
with open(gt_file_path, mode='r', newline='', encoding='utf-8') as file:
    reader = csv.reader(file)
    headers = next(reader)  # 获取表头
    data = [row for row in reader]  # 获取所有数据

# 噪声1：完全一样的email记录（其他字段不同）
same_email_records = []
fake = faker.Faker()

for record in random.sample(data, 80):  # 随机采样80条记录
    new_record = record.copy()
    new_record[0] = random.randint(1001, 2000)  # 修改id
    new_record[5] = f"{random.uniform(150, 200):.2f}"  # 随机修改height
    first_name = fake.first_name()
    last_name = fake.last_name()
    dob = fake.date_of_birth(minimum_age=18, maximum_age=80).isoformat()
    same_email_records.append(new_record)

# 噪声2：完全一致的 first_name, last_name, dob 记录
same_name_dob_records = []
for record in random.sample(data, 80):
    new_record = record.copy()
    new_record[0] = random.randint(2001, 3000)  # 修改id
    email = fake.email()
    new_record[5] = f"{random.uniform(150, 200):.2f}"
    same_name_dob_records.append(new_record)

# 噪声3：修改height为更多位小数，但保留两位小数后与原始一致
modified_height_records = []
for record in random.sample(data, 50):
    new_record = record.copy()  # 不修改id
    original_height = float(record[5])
    # 生成一个带3~6位小数的数，使其四舍五入到2位小数后等于 original_height
    extra_digits = random.randint(3, 6)
    noise = random.uniform(-0.004999, 0.004999)  # 确保四舍五入后不变
    perturbed_height = original_height + noise

    formatted_height = f"{perturbed_height:.{extra_digits}f}"
    # 验证（可选）：assert round(float(formatted_height), 2) == original_height
    new_record[5] = formatted_height
    modified_height_records.append(new_record)

# 合并原始数据和噪声数据
final_data = data + same_email_records + same_name_dob_records + modified_height_records

# 写入新的CSV文件
with open(output_file, mode='w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerow(headers)
    writer.writerows(final_data)

print(f"CSV 文件已生成并保存到 {output_file}")