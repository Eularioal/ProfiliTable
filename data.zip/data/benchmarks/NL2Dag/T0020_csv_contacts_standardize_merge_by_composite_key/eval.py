#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Evaluate the result of the “customer-dedup” operator.

• 必须满足预处理：
  1. phone 仅数字
  2. email 小写
• 以 (first_name,last_name,dob) 为键，评估键集合的 F1
• 如果预测行违反 phone/email 规范，将被丢弃
• 返回 {"eval_score": x.xxxx}   —— 0 ≤ x ≤ 1
"""

from __future__ import annotations
import argparse
import csv
import re
from pathlib import Path
from typing import Dict, Set, Tuple

ROOT = Path(__file__).resolve().parent
GT_PATH = ROOT / "expected" / "gt.csv"

KEY_COLS = ("first_name", "last_name", "dob")

DIGIT_RE = re.compile(r"^\d*$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

def load_keys(path: Path, validate: bool = False) -> Set[Tuple[str, str, str]]:
    keys: Set[Tuple[str, str, str]] = set()

    with path.open(encoding="utf-8-sig") as f:
        rdr = csv.DictReader(f)
        for ln, row in enumerate(rdr, 2):  # +1 header
            key = tuple(row[c] for c in KEY_COLS)

            if validate:
                phone = row.get("phone", "")
                email = row.get("email", "")
                # phone 仅数字
                if phone and not DIGIT_RE.fullmatch(phone):
                    continue
                # email 小写 & 基本格式
                if email and (email != email.lower() or not EMAIL_RE.fullmatch(email)):
                    continue

            keys.add(key)
    return keys


def f1(gt: Set, pred: Set) -> float:
    if not pred:
        return 0.0
    tp = len(gt & pred)
    precision = tp / len(pred)
    recall = tp / len(gt)
    return 0.0 if precision + recall == 0 else 2 * precision * recall / (precision + recall)


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate customer-dedup output")
    parser.add_argument("-o", "--output", required=True, help="path to your csv")
    args = parser.parse_args()

    gt_keys = load_keys(GT_PATH)
    pred_keys = load_keys(Path(args.output), validate=True)

    score = round(f1(gt_keys, pred_keys), 4)
    print({"eval_score": f"{score:.4f}"})


if __name__ == "__main__":
    main()