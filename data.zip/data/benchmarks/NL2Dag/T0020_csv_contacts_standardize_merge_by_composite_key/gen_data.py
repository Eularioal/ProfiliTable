#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成 customers.csv（含重复与格式噪声）
→ 按规则清洗得到 gt.csv

规则
-----
1. 标准化 phone / email
   • phone: 仅保留数字（如 5551234567）
   • email: 全部小写并 strip
2. 以 (first_name, last_name, dob) 为复合键去重
3. 键外字段取“非空并集”；若冲突则保 earliest created_at 所在行的值
4. 输出 CSV (UTF-8)
"""
import csv
import os
import random
import re
from datetime import datetime, timedelta
from pathlib import Path

# ---------------- 配置 ---------------- #
SEED = 2024
BASE_CNT = 120          # 唯一客户数  (≥100 after dedup)
DUP_PROB = 0.35         # 每个客户再生成重复行的概率
RAW_PATH = Path("raw/customers.csv")
GT_PATH  = Path("expected/gt.csv")

random.seed(SEED)
RAW_PATH.parent.mkdir(parents=True, exist_ok=True)
GT_PATH.parent.mkdir(parents=True, exist_ok=True)

FIRST = ["Alice", "Bob", "Carol", "David", "Eve", "Frank", "Grace", "Heidi",
         "Ivan", "Judy", "Mallory", "Niaj", "Olivia", "Peggy", "Rupert"]
LAST  = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis",
         "Wilson", "Taylor", "Anderson"]

STREETS = ["Oak Ave", "Pine St", "Maple Rd", "Elm Street", "Cedar Blvd"]

PHONE_FMT = [
    "({a}) {b}-{c}",
    "{a}-{b}-{c}",
    "+1 {a} {b} {c}",
    "{a}{b}{c}"
]

def rand_phone() -> str:
    a = random.randint(100, 999)
    b = random.randint(100, 999)
    c = random.randint(1000, 9999)
    fmt = random.choice(PHONE_FMT)
    return fmt.format(a=a, b=b, c=c)

def norm_phone(p: str) -> str:
    return re.sub(r"\D", "", p)

def rand_email(fn: str, ln: str) -> str:
    dom = random.choice(["example.com", "mail.test", "demo.org"])
    user = f"{fn}.{ln}{random.randint(1,99)}"
    if random.random() < .3:
        user = user.upper()
    return f"{user}@{dom}"

def norm_email(e: str) -> str:
    return e.strip().lower()

def rand_address() -> str:
    num = random.randint(100, 9999)
    return f"{num} {random.choice(STREETS)}, NY"

START_DATE = datetime(1970, 1, 1)
def rand_dob() -> str:
    offset = random.randint(0, 18000)   # ~50 年
    return (START_DATE + timedelta(days=offset)).strftime("%Y-%m-%d")

NOW = datetime.now()

def rand_created() -> str:
    delta = timedelta(days=random.randint(0, 365), seconds=random.randint(0, 86400))
    return (NOW - delta).strftime("%Y-%m-%d %H:%M:%S")

FIELDS = ["first_name", "last_name", "dob", "phone", "email", "address", "created_at"]

# ---------------- 生成 RAW ---------------- #
raw_rows = []
for _ in range(BASE_CNT):
    fn = random.choice(FIRST)
    ln = random.choice(LAST)
    dob = rand_dob()

    # 至少 1 行
    reps = 1
    while random.random() < DUP_PROB:
        reps += 1

    for i in range(reps):
        row = {
            "first_name": fn,
            "last_name": ln,
            "dob": dob,
            "phone": rand_phone(),
            "email": rand_email(fn, ln),
            "address": rand_address() if random.random() < 0.9 else "",
            "created_at": rand_created(),
        }
        # 故意制造缺失
        if random.random() < .15:
            row["phone"] = ""
        if random.random() < .15:
            row["email"] = ""
        if random.random() < .15:
            row["address"] = ""
        raw_rows.append(row)

# 打乱
random.shuffle(raw_rows)

with RAW_PATH.open("w", newline="", encoding="utf-8") as f:
    wr = csv.DictWriter(f, fieldnames=FIELDS)
    wr.writeheader()
    wr.writerows(raw_rows)

print(f"✔ raw saved: {RAW_PATH} ({len(raw_rows)} lines)")

# ---------------- 去重合并 → GT ---------------- #
def merge_rows(rows):
    # rows 已按 created_at 升序
    base = rows[0].copy()
    for r in rows[1:]:
        for col in ("phone", "email", "address"):
            if base[col]:                        # 已有值
                continue
            if r[col]:
                base[col] = r[col]
    return base

# 标准化并按 key 分组
groups = {}
for r in raw_rows:
    key = (r["first_name"], r["last_name"], r["dob"])

    # 先标准化
    r["phone"] = norm_phone(r["phone"]) if r["phone"] else ""
    r["email"] = norm_email(r["email"]) if r["email"] else ""

    groups.setdefault(key, []).append(r)

# 对每组按 created_at 升序并合并
gt_rows = []
for key, rows in groups.items():
    rows.sort(key=lambda x: x["created_at"])
    merged = merge_rows(rows)
    gt_rows.append(merged)

# 保证输出 deterministic
gt_rows.sort(key=lambda x: (x["first_name"], x["last_name"], x["dob"]))

assert len(gt_rows) >= 100

with GT_PATH.open("w", newline="", encoding="utf-8") as f:
    wr = csv.DictWriter(f, fieldnames=FIELDS)
    wr.writeheader()
    wr.writerows(gt_rows)

print(f"✔ GT saved: {GT_PATH} ({len(gt_rows)} lines)")