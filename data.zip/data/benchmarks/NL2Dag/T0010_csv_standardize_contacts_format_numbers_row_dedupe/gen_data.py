import csv
import re
import random
import os
import pandas as pd
from typing import List, Dict, Any

def generate_raw_data() -> List[Dict[str, Any]]:
    """生成包含各种问题的原始数据"""
    
    # 电话号码样本（包含各种格式问题）
    phone_samples = [
        "86-138-0013-8000",  # 有破折号
        "+86 139 0013 9000",  # 有空格
        "86 150-1234-5678",  # 混合格式
        "+86-151-2345-6789",  # 标准格式
        "152 3456 7890",  # 缺少国家码，有空格
        "153-4567-8901",  # 缺少国家码，有破折号
        "+86  154  5678  9012",  # 多个空格
        "86-155-6789-0123",
        "156 7890 1234",
        "+86-157-8901-2345",
        "158-9012-3456",
        "+86 159 0123 4567",
        "86-160-1234-5678",
        "161 2345 6789",
        "+86-162-3456-7890",
        "163-4567-8901",
        "+86 164 5678 9012",
        "86-165-6789-0123",
        "166 7890 1234",
        "+86-167-8901-2345"
    ]
    
    # 邮箱样本（包含各种问题）
    email_samples = [
        "John.Doe@Gmail.com",  # 大小写混合
        "jane.smith@GMAIL.COM",  # 全大写
        "bob.wilson@gmail.com",  # 正常
        "alice.brown@Gmail.Com",  # 混合大小写
        "charlie.davis@yahoo.com",  # 非Gmail
        "diana.miller@OUTLOOK.COM",  # 非Gmail大写
        "edward.jones@gmail.com",  # 正常
        "fiona.garcia@Gmail.COM",  # 混合
        "george.martinez@hotmail.com",  # 非Gmail
        "helen.anderson@GMAIL.com",  # 混合
        "ivan.taylor@gmail.com",  # 正常
        "julia.thomas@Gmail.com",  # 首字母大写
        "kevin.jackson@yahoo.com",  # 非Gmail
        "linda.white@gmail.COM",  # 混合
        "mark.harris@GMAIL.com",  # 混合
        "nancy.martin@outlook.com",  # 非Gmail
        "oscar.thompson@Gmail.com",  # 首字母大写
        "paula.garcia@gmail.com",  # 正常
        "quincy.lee@YAHOO.COM",  # 非Gmail大写
        "rachel.walker@gmail.com"  # 正常
    ]
    
    # 包含数字的文本样本（需要格式化为两位小数）
    text_samples = [
        "The price is 99.5 dollars",  # 一位小数
        "Total cost: 123.456 yuan",  # 三位小数
        "Amount: 45 cents",  # 整数
        "Value is 78.99 units",  # 已经是两位小数
        "Cost 234.1 per item",  # 一位小数
        "Price: 567.8900 each",  # 多位小数
        "Total 89 pieces",  # 整数
        "Rate: 12.345 percent",  # 三位小数
        "Fee is 456.70 dollars",  # 已经是两位小数
        "Sum: 789.12345 total",  # 五位小数
        "Cost 23.4 per unit",  # 一位小数
        "Price 345.67 each",  # 已经是两位小数
        "Value: 678.9 items",  # 一位小数
        "Amount 90.123 units",  # 三位小数
        "Total: 123.4567 pieces",  # 四位小数
        "Fee 45.6 dollars",  # 一位小数
        "Rate is 78.90 percent",  # 已经是两位小数
        "Cost: 234.567 each",  # 三位小数
        "Price 456 per item",  # 整数
        "Value: 789.01 units"  # 已经是两位小数
    ]
    
    raw_data = []
    
    # 生成基础数据
    for i in range(120):
        customer_id = i + 1
        phone = random.choice(phone_samples)
        email = random.choice(email_samples)
        text = random.choice(text_samples)
        
        # 生成指标数据
        metric1 = round(random.uniform(10, 100), 2)
        metric2 = round(random.uniform(100, 1000), 2)
        metric3 = round(random.uniform(1000, 10000), 2)
        
        raw_data.append({
            "customer_id": customer_id,
            "phone": phone,
            "email": email,
            "text": text,
            "metric1": metric1,
            "metric2": metric2,
            "metric3": metric3,
            "category": "normal"
        })
    
    # 添加一些重复数据用于测试去重
    duplicate_records = []
    for i in range(5):
        # 复制前5条记录
        original = raw_data[i].copy()
        duplicate_records.append(original)
    
    # 添加重复记录到原始数据中
    raw_data.extend(duplicate_records)
    
    # 再添加一些额外数据以达到150+条
    for i in range(120, 150):
        customer_id = i + 1
        phone = random.choice(phone_samples)
        email = random.choice(email_samples)
        text = random.choice(text_samples)
        
        metric1 = round(random.uniform(10, 100), 2)
        metric2 = round(random.uniform(100, 1000), 2)
        metric3 = round(random.uniform(1000, 10000), 2)
        
        raw_data.append({
            "customer_id": customer_id,
            "phone": phone,
            "email": email,
            "text": text,
            "metric1": metric1,
            "metric2": metric2,
            "metric3": metric3,
            "category": "normal"
        })
    
    return raw_data

def standardize_phone(phone: str) -> str:
    """标准化电话号码"""
    # 去除所有空格和破折号
    phone = re.sub(r'[\s\-]', '', phone)
    
    # 如果没有国家码，添加+86
    if not phone.startswith('+86') and not phone.startswith('86'):
        phone = '+86' + phone
    elif phone.startswith('86') and not phone.startswith('+86'):
        phone = '+' + phone
    
    return phone

def standardize_email(email: str) -> str:
    """标准化邮箱地址"""
    # 转换为小写
    email = email.lower()
    
    # 如果是Gmail，去除点号别名
    if '@gmail.com' in email:
        local_part, domain = email.split('@')
        # 去除点号
        local_part = local_part.replace('.', '')
        email = f"{local_part}@{domain}"
    
    return email

def format_numbers_in_text(text: str) -> str:
    """将文本中的数字格式化为两位小数"""
    def replace_number(match):
        number = float(match.group())
        return f"{number:.2f}"
    
    # 匹配数字（包括小数）
    pattern = r'\b\d+\.?\d*\b'
    return re.sub(pattern, replace_number, text)

def process_data(raw_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """处理数据，应用所有处理规则"""
    processed_data = []
    
    # 第一步：标准化phone和email字段
    for record in raw_data:
        record = record.copy()
        record['phone'] = standardize_phone(record['phone'])
        record['email'] = standardize_email(record['email'])
        record['text'] = format_numbers_in_text(record['text'])
        processed_data.append(record)
    
    # 第二步：精确去重，保留首条出现的记录
    seen_records = set()
    deduped_data = []
    
    for record in processed_data:
        # 创建记录的哈希用于去重（排除category字段）
        record_tuple = tuple(sorted([(k, v) for k, v in record.items() if k != 'category']))
        
        if record_tuple not in seen_records:
            seen_records.add(record_tuple)
            deduped_data.append(record)
    
    # 第三步：宽转长（unpivot）
    long_data = []
    for record in deduped_data:
        base_record = {
            'customer_id': record['customer_id'],
            'phone': record['phone'],
            'email': record['email'],
            'text': record['text']
        }
        
        # 转换指标列为key-value形式
        for metric in ['metric1', 'metric2', 'metric3']:
            long_record = base_record.copy()
            long_record['metric_name'] = metric
            long_record['metric_value'] = record[metric]
            long_data.append(long_record)
    
    return long_data

def save_to_csv(data: List[Dict[str, Any]], filepath: str):
    """保存数据到CSV文件（UTF-8无BOM）"""
    if not data:
        return
    
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = data[0].keys()
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)

def main():
    """主函数，生成测试数据"""
    print("生成原始数据...")
    raw_data = generate_raw_data()
    print(f"生成了 {len(raw_data)} 条原始记录")
    
    print("处理数据...")
    gt_data = process_data(raw_data)
    print(f"处理后得到了 {len(gt_data)} 条记录")
    
    # 保存原始数据到 raw/customers.csv
    print("保存原始数据到 raw/customers.csv...")
    save_to_csv(raw_data, 'raw/customers.csv')
    
    # 保存处理后的数据到 expected/gt.csv
    print("保存GT数据到 expected/gt.csv...")
    save_to_csv(gt_data, 'expected/gt.csv')
    
    print("数据生成完成！")
    print(f"原始数据: {len(raw_data)} 条记录")
    print(f"GT数据: {len(gt_data)} 条记录")
    
    # 统计去重效果
    unique_customers = len(set(record['customer_id'] for record in raw_data))
    print(f"去重后唯一客户数: {unique_customers}")

if __name__ == "__main__":
    main()