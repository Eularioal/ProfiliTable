import argparse
import csv
import os
import re
from typing import List, Dict, Any, Set


def load_csv(path):
    data = []
    with open(path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(row)
    return data


def is_phone_standardized(phone: str) -> bool:
    """检查电话号码是否已标准化"""
    # 应该以+86开头，且不包含空格和破折号
    if not phone.startswith('+86'):
        return False
    
    # 不应包含空格或破折号
    if ' ' in phone or '-' in phone:
        return False
    
    # 长度应该合理（+86加11位数字）
    if len(phone) != 14:  # +86 + 11位数字
        return False
    
    return True


def is_email_standardized(email: str) -> bool:
    """检查邮箱是否已标准化"""
    # 应该全部是小写
    if email != email.lower():
        return False
    
    # 如果是Gmail，不应该包含点号别名
    if '@gmail.com' in email:
        local_part = email.split('@')[0]
        if '.' in local_part:
            return False
    
    return True


def are_numbers_formatted(text: str) -> bool:
    """检查文本中的数字是否都格式化为两位小数"""
    # 查找所有数字
    numbers = re.findall(r'\b\d+\.?\d*\b', text)
    
    for num_str in numbers:
        try:
            num = float(num_str)
            # 检查是否为整数或恰好两位小数
            if '.' in num_str:
                decimal_part = num_str.split('.')[1]
                if len(decimal_part) != 2:
                    return False
            else:
                # 整数应该被格式化为.00
                return False
        except ValueError:
            continue
    
    return True


def check_data_structure(data: List[Dict[str, Any]]) -> bool:
    """检查数据结构是否符合宽转长格式"""
    if not data:
        return False
    
    # 检查必要的列是否存在
    required_columns = {'customer_id', 'phone', 'email', 'text', 'metric_name', 'metric_value'}
    actual_columns = set(data[0].keys())
    
    if not required_columns.issubset(actual_columns):
        return False
    
    # 检查每个customer_id是否有3条记录（metric1, metric2, metric3）
    customer_metrics = {}
    for record in data:
        customer_id = record['customer_id']
        metric_name = record['metric_name']
        
        if customer_id not in customer_metrics:
            customer_metrics[customer_id] = set()
        customer_metrics[customer_id].add(metric_name)
    
    # 每个客户应该有3个指标
    expected_metrics = {'metric1', 'metric2', 'metric3'}
    for customer_id, metrics in customer_metrics.items():
        if metrics != expected_metrics:
            return False
    
    return True


def check_no_duplicates(data: List[Dict[str, Any]]) -> bool:
    """检查是否存在重复记录"""
    seen_records = set()
    
    for record in data:
        # 创建记录的哈希用于检查重复
        record_tuple = tuple(sorted(record.items()))
        
        if record_tuple in seen_records:
            return False
        seen_records.add(record_tuple)
    
    return True


def is_valid_record(record):
    """检查单条记录是否符合要求"""
    # 检查电话号码标准化
    if not is_phone_standardized(record.get('phone', '')):
        return False
    
    # 检查邮箱标准化
    if not is_email_standardized(record.get('email', '')):
        return False
    
    # 检查文本中数字格式化
    if not are_numbers_formatted(record.get('text', '')):
        return False
    
    return True


def is_valid_dataset(data: List[Dict[str, Any]]) -> bool:
    """检查整个数据集是否有效"""
    # 检查数据结构
    if not check_data_structure(data):
        return False
    
    # 检查无重复
    if not check_no_duplicates(data):
        return False
    
    return True


def get_gt():
    from pathlib import Path

    # 获取 eval.py 所在目录
    current_dir = Path(__file__).resolve().parent

    # 找到 expected 目录
    expected_dir = (current_dir / "./expected").resolve()

    # 查找第一个 .csv 文件
    csv_files = list(expected_dir.glob("*.csv"))

    if not csv_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")

    # 取第一个文件作为 expected_path
    expected_path = csv_files[0]

    return expected_path


def evaluate(processed_path):
    expected_path = get_gt()
    expected = load_csv(expected_path)
    processed = load_csv(processed_path)

    # 构造映射方便比对（使用customer_id和metric_name作为联合键）
    def make_key(record):
        return f"{record['customer_id']}_{record['metric_name']}"
    
    expected_map = {make_key(entry): entry for entry in expected}
    processed_map = {make_key(entry): entry for entry in processed}

    # 只评估交集部分
    common_keys = set(expected_map.keys()) & set(processed_map.keys())

    true_positives = 0
    failed_keys = []
    
    for key in common_keys:
        gt = expected_map[key]
        pred = processed_map[key]

        # 检查所有字段是否匹配且记录有效
        fields_match = (
            gt["customer_id"] == pred["customer_id"] and
            gt["phone"] == pred["phone"] and
            gt["email"] == pred["email"] and
            gt["text"] == pred["text"] and
            gt["metric_name"] == pred["metric_name"] and
            gt["metric_value"] == pred["metric_value"]
        )
        
        if fields_match and is_valid_record(pred):
            true_positives += 1
        else:
            failed_keys.append(key)

    # 检查是否有不应该出现的记录
    unexpected_keys = set(processed_map.keys()) - set(expected_map.keys())
    
    # 检查是否有遗漏的记录
    missing_keys = set(expected_map.keys()) - set(processed_map.keys())

    # 检查整个数据集的有效性
    dataset_valid = is_valid_dataset(processed)

    predicted_total = len(processed_map)
    gold_total = len(expected_map)

    precision = true_positives / predicted_total if predicted_total > 0 else 0.0
    recall = true_positives / gold_total if gold_total > 0 else 0.0
    f1 = (2 * precision * recall) / (precision + recall) if precision + recall > 0 else 0.0

    # 如果数据集结构无效，大幅降低F1分数
    if not dataset_valid:
        f1 *= 0.3  # 严重惩罚
        print("警告: 数据集结构无效（可能存在重复或格式错误），F1分数已大幅降低")

    # 输出详细信息用于调试
    if failed_keys:
        print(f"Failed keys: {failed_keys[:10]}...")  # 只显示前10个
    if unexpected_keys:
        print(f"Unexpected records: {len(unexpected_keys)}")
    if missing_keys:
        print(f"Missing records: {len(missing_keys)}")
    
    result = {"eval_score": f"{f1:.4f}"}
    print(result)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-o", "--output", help="Path to processed results file", required=True)
    args = parser.parse_args()

    evaluate(args.output)