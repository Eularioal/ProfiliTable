#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据生成脚本 - 生成原始customers数据和处理后的GT数据
"""

import json
import random
import re
import os

def create_directories():
    """创建必要的目录结构"""
    os.makedirs('raw', exist_ok=True)
    os.makedirs('expected', exist_ok=True)

def generate_sample_data():
    """生成包含各种情况的样本数据"""
    
    # 脏话列表（用于生成测试数据）
    dirty_words = ['傻逼', '操', '妈的', '草', '靠', '卧槽', '尼玛', '滚', '死']
    
    # 正常文本样本
    normal_texts = [
        "欢迎来到我们的在线商店",
        "今天天气真不错",
        "这个产品质量很好",
        "客服态度很友善",
        "配送速度很快",
        "价格实惠，性价比高",
        "包装很精美",
        "已经推荐给朋友了",
        "下次还会再来购买",
        "整体购物体验很满意"
    ]
    
    customers_data = []
    
    # 生成120条记录以确保超过100条
    for i in range(120):
        record = {
            "id": i + 1,
            "name": f"用户{i+1}",
            "email": f"user{i+1}@example.com"
        }
        
        # 根据不同情况生成text字段
        situation = random.randint(1, 8)
        
        if situation == 1:
            # 空字符串
            record["text"] = ""
        elif situation == 2:
            # 全空格
            record["text"] = "   "
        elif situation == 3:
            # 包含脏话
            text = random.choice(normal_texts)
            dirty_word = random.choice(dirty_words)
            record["text"] = f"{text}，但是{dirty_word}这个问题"
        elif situation == 4:
            # 包含多余空格
            text = random.choice(normal_texts)
            record["text"] = f"  {text}    真的很好  "
        elif situation == 5:
            # 包含脏话和多余空格
            text = random.choice(normal_texts)
            dirty_word = random.choice(dirty_words)
            record["text"] = f"   {text}  {dirty_word}   还行吧   "
        elif situation == 6:
            # 连续多个空格在中间
            text = random.choice(normal_texts)
            record["text"] = text.replace("很", "    很    ")
        elif situation == 7:
            # 多个脏话
            text = random.choice(normal_texts)
            dirty1 = random.choice(dirty_words)
            dirty2 = random.choice(dirty_words)
            record["text"] = f"{dirty1}，{text}，{dirty2}服务"
        else:
            # 正常文本
            record["text"] = random.choice(normal_texts)
        
        customers_data.append(record)
    
    return customers_data

def clean_text(text):
    """
    清理文本：
    1. 删除连续多余空格
    2. 将脏话替换为星号
    """
    if not text or text.isspace():
        return text
    
    # 脏话字典
    dirty_words = ['傻逼', '操', '妈的', '草', '靠', '卧槽', '尼玛', '滚', '死']
    
    # 删除连续多余空格（保留单个空格）
    cleaned_text = re.sub(r'\s+', ' ', text.strip())
    
    # 替换脏话为对应长度的星号
    for word in dirty_words:
        if word in cleaned_text:
            stars = '*' * len(word)
            cleaned_text = cleaned_text.replace(word, stars)
    
    return cleaned_text

def filter_and_process_data(customers_data):
    """
    过滤和处理数据：
    1. 过滤text为空或全空格的记录
    2. 清理剩余记录的text字段
    """
    gt_data = []
    
    for record in customers_data:
        # 过滤空文本或全空格文本
        if record.get("text") and not record["text"].isspace():
            # 创建新记录副本
            cleaned_record = record.copy()
            # 清理文本
            cleaned_record["text"] = clean_text(record["text"])
            gt_data.append(cleaned_record)
    
    return gt_data

def save_jsonl(data, filepath):
    """保存数据为JSONL格式"""
    with open(filepath, 'w', encoding='utf-8') as f:
        for item in data:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

def main():
    """主函数"""
    print("开始生成数据...")
    
    # 创建目录
    create_directories()
    
    # 生成原始数据
    customers_data = generate_sample_data()
    print(f"生成了 {len(customers_data)} 条原始数据")
    
    # 保存原始数据
    save_jsonl(customers_data, 'raw/customers.jsonl')
    print("原始数据已保存到 raw/customers.jsonl")
    
    # 处理数据生成GT
    gt_data = filter_and_process_data(customers_data)
    print(f"处理后得到 {len(gt_data)} 条GT数据")
    
    # 保存GT数据
    save_jsonl(gt_data, 'expected/gt.jsonl')
    print("GT数据已保存到 expected/gt.jsonl")
    
    print("\n数据生成完成！")
    print(f"原始数据：{len(customers_data)} 条")
    print(f"GT数据：{len(gt_data)} 条")
    print(f"过滤掉：{len(customers_data) - len(gt_data)} 条空文本记录")

if __name__ == "__main__":
    main()