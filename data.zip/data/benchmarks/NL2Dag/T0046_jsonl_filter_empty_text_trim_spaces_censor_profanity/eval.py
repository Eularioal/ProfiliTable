#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Evaluate the output of the 'JSONL data cleansing' task

    任务
    1) 过滤 text 为空或全空格的记录
    2) 删除 text 中连续多余空格（压缩所有空白为单空格，去首尾）
    3) 将所有脏话替换为星号
    输出 JSONL（UTF-8）

评测规则
------------
• 只接受"已清洗"的结果文件进行评测。
• 对于每一条记录，既要保留正确的 id，又要保证 text 与
  expected/gt.jsonl 中的清洗结果完全一致（大小写、空格都算）。
• 评测指标：
    precision = TP / |pred|
    recall    = TP / |gt|
    F1        = 2·P·R / (P+R)
  其中 TP = 预测中同时满足 `(id 相同 & text 完全相同)` 的条目数。

使用方法
---------

python eval.py -o /path/to/your_output.jsonl

会打印形如 {"eval_score": "0.9231"} 的 JSON。
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, Tuple

ROOT = Path(__file__).resolve().parent
GT_PATH = ROOT / "expected" / "gt.jsonl"

def load_jsonl_id_text(path: Path) -> Dict[str, str]:
    """
    读取 jsonl，返回 {id: text}。
    - 要求每行是 JSON 对象，至少包含 'id' 和 'text' 字段。
    - id 将被转成字符串用作键（与生成数据一致）。
    - 如果同一个 id 出现多次，后出现的记录会覆盖先前的。
    """
    if not path.is_file():
        sys.exit(f"[Eval] File not found: {path}")

    data: Dict[str, str] = {}
    with path.open(encoding="utf-8") as f:
        for ln, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                sys.exit(f"[Eval] {path} L{ln}: JSON decode error -- {e}")

            if "id" not in obj or "text" not in obj:
                sys.exit(f"[Eval] {path} L{ln}: missing 'id' or 'text' field")

            id_val = obj["id"]
            # 与项目数据一致，id 为字符串；若不是字符串也尝试转为字符串进行对齐
            if isinstance(id_val, (int, float)):
                id_key = str(id_val)
            elif isinstance(id_val, str):
                id_key = id_val
            else:
                sys.exit(f"[Eval] {path} L{ln}: 'id' must be str/int, got {type(id_val).__name__}")

            text_val = obj["text"]
            if not isinstance(text_val, str):
                sys.exit(f"[Eval] {path} L{ln}: 'text' must be str")

            data[id_key] = text_val
    
    return data

def compute_prf(gt: Dict[str, str], pred: Dict[str, str]) -> Tuple[float, float, float]:
    """
    计算 Precision, Recall, F1 分数
    TP: 预测结果中 id 存在于 GT 且 text 完全一致的记录数
    """
    if not pred:
        return 0.0, 0.0, 0.0

    # TP: id 存在于 gt 且 text 完全一致
    tp = sum(1 for k, v in pred.items() if gt.get(k) == v)
    
    precision = tp / len(pred) if pred else 0.0
    recall = tp / len(gt) if gt else 0.0

    if precision + recall == 0:
        return precision, recall, 0.0
    
    f1 = 2 * precision * recall / (precision + recall)
    return precision, recall, f1

def detailed_comparison(gt: Dict[str, str], pred: Dict[str, str]) -> None:
    """
    输出详细的对比信息（调试用）
    """
    print(f"\n=== 详细评估报告 ===", file=sys.stderr)
    print(f"GT 记录数: {len(gt)}", file=sys.stderr)
    print(f"预测记录数: {len(pred)}", file=sys.stderr)
    
    # 统计各种情况
    exact_matches = 0
    missing_in_pred = 0
    extra_in_pred = 0
    text_mismatches = 0
    
    all_gt_ids = set(gt.keys())
    all_pred_ids = set(pred.keys())
    
    # 检查GT中的每个记录
    for gt_id, gt_text in gt.items():
        if gt_id in pred:
            if pred[gt_id] == gt_text:
                exact_matches += 1
            else:
                text_mismatches += 1
        else:
            missing_in_pred += 1
    
    # 检查预测中多出的记录
    extra_in_pred = len(all_pred_ids - all_gt_ids)
    
    print(f"完全匹配: {exact_matches}", file=sys.stderr)
    print(f"文本不匹配: {text_mismatches}", file=sys.stderr)
    print(f"预测中缺失: {missing_in_pred}", file=sys.stderr)
    print(f"预测中多余: {extra_in_pred}", file=sys.stderr)
    
    # 显示前几个不匹配的例子
    if text_mismatches > 0:
        print(f"\n前3个文本不匹配示例:", file=sys.stderr)
        count = 0
        for gt_id, gt_text in gt.items():
            if gt_id in pred and pred[gt_id] != gt_text and count < 3:
                print(f"ID {gt_id}:", file=sys.stderr)
                print(f"  GT:   '{gt_text}'", file=sys.stderr)
                print(f"  Pred: '{pred[gt_id]}'", file=sys.stderr)
                count += 1

def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate JSONL data cleansing output")
    parser.add_argument(
        "-o", "--output", required=True, help="Path to your jsonl output file"
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true", 
        help="Show detailed comparison (output to stderr)"
    )
    args = parser.parse_args()

    # 加载GT数据和预测结果
    try:
        gt_map = load_jsonl_id_text(GT_PATH)
    except SystemExit:
        sys.exit(f"[Eval] Failed to load GT file: {GT_PATH}")
    
    try:
        pred_map = load_jsonl_id_text(Path(args.output))
    except SystemExit:
        sys.exit(f"[Eval] Failed to load prediction file: {args.output}")

    # 计算评估指标
    precision, recall, f1 = compute_prf(gt_map, pred_map)

    # 如果启用详细模式，输出详细信息到stderr
    if args.verbose:
        detailed_comparison(gt_map, pred_map)
        print(f"\nPrecision: {precision:.4f}", file=sys.stderr)
        print(f"Recall: {recall:.4f}", file=sys.stderr)
        print(f"F1: {f1:.4f}", file=sys.stderr)

    # 输出最终评分（JSON格式到stdout）
    print(json.dumps({"eval_score": f"{f1:.4f}"}))

if __name__ == "__main__":
    main()