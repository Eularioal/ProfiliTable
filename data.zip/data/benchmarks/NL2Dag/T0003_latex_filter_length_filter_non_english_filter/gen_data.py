import json
import random
import os
import re
import uuid
from langdetect import detect
from utils.llm_serving import LLMServing  # Optional: To use LLM for text generation

# Initialize the LLM model
llm = LLMServing()

# Function to check if a string is LaTeX-heavy
def contains_latex(text):
    """Check if a text contains more than 5 LaTeX tags."""
    latex_pattern = r"\$[^$]*\$|\[.*?\]"
    latex_tags = re.findall(latex_pattern, text)
    return len(latex_tags) > 5

# Function to filter out non-English text
def is_english(text):
    """Check if the text is in English using langdetect."""
    try:
        return detect(text) == 'en'
    except:
        return False

# Function to filter and clean the text
def clean_text(text):
    """Filter text based on length and LaTeX tags."""
    # Discard texts with more than 5 LaTeX tags
    if contains_latex(text):
        return None

    # Keep only texts with 20-100 words
    words = text.split()
    if len(words) < 20 or len(words) > 100:
        return None

    # Check if the text is in English
    if not is_english(text):
        return None

    # Clean extra spaces
    text = ' '.join(text.split())
    return text


def generate_length_noise(text):
    """Generate noise by making the text either too short or too long."""
    words = text.split()
    if random.choice([True, False]):  # Shorten the text
        return ' '.join(words[:random.randint(5, 15)])  # Shortened version (5-15 words)
    else:  # Lengthen the text
        return ' '.join(words + ['extra'] * random.randint(50, 150))  # Lengthened version (50-150 extra words)

# 1. Function to generate LaTeX noise by inserting LaTeX tags randomly in the text
def generate_latex_noise(text):
    """Generate noise by inserting LaTeX tags at random positions in the text."""
    latex_tags = ["$\\alpha$", "$\\beta$", "$\\gamma$", "$\\delta$", "$\\epsilon$"]
    words = text.split()
    
    # Insert LaTeX tags at random positions
    for i in range(random.randint(1, 3)):  # Insert 1 to 3 LaTeX tags
        insert_position = random.randint(0, len(words) - 1)
        latex_tag = random.choice(latex_tags)
        words.insert(insert_position, latex_tag)  # Insert LaTeX tag at random position
    
    # Recreate the text with inserted LaTeX tags
    noisy_text = ' '.join(words)
    return noisy_text


# 2. Function to generate non-English noise with varied languages
def generate_non_english_noise(text):
    """Generate noise by replacing the text with sentences in random non-English languages."""
    non_english_texts = [
        "Este es un texto en español.",  # Spanish
        "Ceci est un texte en français.",  # French
        "Dies ist ein Text auf Deutsch.",  # German
        "Questo è un testo in italiano.",  # Italian
        "这是一个中文文本。"  # Chinese
    ]
    
    # Randomly choose a non-English sentence
    non_english_text = random.choice(non_english_texts)
    return non_english_text  # Replace with non-English sentence

# Function to generate GT data (30 valid entries)
def generate_gt_data(output_dir, task_id):
    """Generate ground truth data and save as JSONL."""
    gt_data = []

    topics = [
        "the weather today", 
        "the importance of education", 
        "advancements in technology", 
        "space exploration", 
        "climate change"
    ]

    # Generate valid sentences from the model
    user_inputs = []
    for _ in range(30):  # Generate 15 pairs of topics (30 sentences total)
        pair = random.sample(topics, 2)  # Randomly select 2 topics
        user_inputs.append(f"Write a short formal text about {pair[0]} and {pair[1]}")

    system_prompt = "You are an AI that writes formal English. Keep the text appropriate for academic contexts, concise, and between 20-100 words."

    # Generate sentences using the LLM
    generated_texts = llm.generate_from_input(user_inputs, system_prompt)

    # Filter and save valid texts
    for text in generated_texts:
        cleaned_text = clean_text(text)
        if cleaned_text:
            gt_data.append({
                "id": str(uuid.uuid4()),
                "text": cleaned_text
            })

    # Save the GT data to a JSONL file
    gt_output_path = os.path.join(output_dir, "expected", "gt.jsonl")
    os.makedirs(os.path.dirname(gt_output_path), exist_ok=True)
    with open(gt_output_path, 'w') as f:
        for entry in gt_data:
            f.write(json.dumps(entry) + '\n')

    print(f"Generated {len(gt_data)} GT entries at {gt_output_path}")

    # Add noise to create a noisy dataset
    noisy_data = []
    for _ in range(100):  # Generate 10 noisy samples
        noise_type = random.choice([generate_latex_noise, generate_length_noise, generate_non_english_noise])
        
        # Choose a random entry from the GT data
        noisy_record = random.choice(gt_data)
        noisy_text = noisy_record['text']
        
        # Apply noise based on selected noise type
        if noise_type == generate_latex_noise:
            noisy_text = generate_latex_noise(noisy_text)
        elif noise_type == generate_length_noise:
            noisy_text = generate_length_noise(noisy_text)
        elif noise_type == generate_non_english_noise:
            noisy_text = generate_non_english_noise(noisy_text)
            
        noisy_data.append({
            "id": str(uuid.uuid4()), 
            "text": noisy_text
        })

    # Combine GT data and noisy data
    all_data = gt_data + noisy_data

    # Save the combined data with noise to the raw JSONL file
    raw_output_path = os.path.join(output_dir, task_id, "raw", "customers.jsonl")
    os.makedirs(os.path.dirname(raw_output_path), exist_ok=True)
    with open(raw_output_path, 'w') as f:
        for entry in all_data:
            f.write(json.dumps(entry) + '\n')

    print(f"Generated {len(all_data)} entries (GT + Noisy) at {raw_output_path}")


if __name__ == "__main__":
    task_id = "T0003_"  # Example task_id, modify as needed
    output_dir = "data/benchmarks/NL2Dag"  # Modify to your desired output directory
    generate_gt_data(os.path.join(output_dir, task_id), task_id)
