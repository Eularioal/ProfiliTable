#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Evaluate the result of the *four-step* customer-dedup task.

评测维度  
1. 记录集合是否正确（id + MinHash 去重）：使用 F1 评分  
2. 对于命中的 id，text 是否与 GT 完全一致（清洗、最新行）  
3. 对于命中的 id，review_id 是否为该组中最小值

最终得分 = 0.5·F1  + 0.3·text_accuracy  + 0.2·review_accuracy ∈ [0,1]

使用方法
--------
python eval.py -o /path/to/your_output.jsonl
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Set, Tuple

GT_PATH = Path(__file__).parent / "expected" / "gt.jsonl"


def load_jsonl(path: Path) -> List[dict]:
    if not path.is_file():
        raise FileNotFoundError(path)
    data: List[dict] = []
    dup_check: Set[int] = set()
    with path.open(encoding="utf-8") as f:
        for ln, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"{path}:{ln} JSON 解码失败: {e}") from None

            for field in ("id", "review_id", "text", "update_time"):
                if field not in obj:
                    raise KeyError(f"{path}:{ln} 缺少字段 `{field}`")

            if obj["id"] in dup_check:
                raise ValueError(f"{path}:{ln} 出现重复 id={obj['id']}")
            dup_check.add(obj["id"])
            data.append(obj)
    return data


def compute_f1(gt: Set[int], pred: Set[int]) -> float:
    if not pred:
        return 0.0
    tp = len(gt & pred)
    precision = tp / len(pred)
    recall = tp / len(gt) if gt else 0.0
    return 0.0 if precision + recall == 0 else 2 * precision * recall / (precision + recall)


def text_accuracy(
    gt_map: Dict[int, str], pred_map: Dict[int, str], common: Set[int]
) -> float:
    if not common:
        return 0.0
    correct = sum(gt_map[i] == pred_map[i] for i in common)
    return correct / len(common)


def review_accuracy(
    gt_map: Dict[int, str], pred_map: Dict[int, str], common: Set[int]
) -> float:
    if not common:
        return 0.0
    correct = sum(gt_map[i] == pred_map[i] for i in common)
    return correct / len(common)


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate 4-step customer dedup result")
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Path to the jsonl produced by your operator",
    )
    args = parser.parse_args()

    # ---------- load ----------
    gt_recs = load_jsonl(GT_PATH)
    pred_recs = load_jsonl(Path(args.output))

    gt_ids = {r["id"] for r in gt_recs}
    pred_ids = {r["id"] for r in pred_recs}

    # build quick maps
    gt_text = {r["id"]: r["text"] for r in gt_recs}
    pred_text = {r["id"]: r["text"] for r in pred_recs}
    gt_rev  = {r["id"]: r["review_id"] for r in gt_recs}
    pred_rev = {r["id"]: r["review_id"] for r in pred_recs}

    common_ids = gt_ids & pred_ids

    # ---------- metrics ----------
    f1 = compute_f1(gt_ids, pred_ids)
    txt_acc = text_accuracy(gt_text, pred_text, common_ids)
    rev_acc = review_accuracy(gt_rev, pred_rev, common_ids)

    score = 0.5 * f1 + 0.3 * txt_acc + 0.2 * rev_acc

    # ---------- output ----------
    result = {
        # "id_F1": round(f1, 4),
        # "text_acc": round(txt_acc, 4),
        # "review_acc": round(rev_acc, 4),
        "eval_score": round(score, 4),
    }
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        # 保证评测脚本异常时也返回 0 分，避免评测系统崩溃
        print(json.dumps({"eval_score": 0.0, "error": str(e)}, ensure_ascii=False))
        sys.exit(1)