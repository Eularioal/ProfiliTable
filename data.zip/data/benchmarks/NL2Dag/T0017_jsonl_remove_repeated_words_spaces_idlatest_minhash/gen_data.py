#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1) 生成 >100 条模拟 customers 数据 (含脏文本、重复 id、近似重复文本等)
2) 按题目 4 步处理得到 GT 并写入 expected/gt.jsonl
"""
import json
import os
import random
import string
import uuid
from datetime import datetime, timedelta
from itertools import combinations, groupby
from pathlib import Path
from typing import Dict, List, Tuple


# ---------- STEP-0: 一些工具 ----------

def rand_dt(base: datetime) -> str:
    """返回随机时间字符串 (ISO-8601)"""
    delta = random.randint(0, 7 * 24 * 3600)      #  7 天内
    return (base + timedelta(seconds=delta)).isoformat(timespec="seconds")


def noisy_repeat(sentence: str) -> str:
    """
    生成带有“连续重复词 + 多余空格”的脏句子
    例:  "good product"  ->  "good  good   product"
    """
    words = sentence.split()
    if len(words) < 2:
        return sentence
    i = random.randint(0, len(words) - 2)
    words.insert(i, words[i])            # 连续重复一个词
    txt = " ".join(words)
    # 再随机塞几个多余空格
    for _ in range(random.randint(1, 3)):
        pos = random.randint(1, len(txt) - 2)
        txt = txt[:pos] + " " + txt[pos:]
    return txt


def clean_text(text: str) -> str:
    """
    1) 去掉“连续重复词”
    2) 合并多余空格 & 首尾 strip
    """
    words, cleaned = text.split(), []
    for w in words:
        if not cleaned or w != cleaned[-1]:
            cleaned.append(w)
    return " ".join(cleaned)


def shingles(text: str, k: int = 3) -> set:
    """返回 k-gram shingle 集合（用于近似去重）"""
    tokens = text.split()
    if len(tokens) < k:
        return {" ".join(tokens)}
    return {" ".join(tokens[i : i + k]) for i in range(len(tokens) - k + 1)}


def jaccard(a: set, b: set) -> float:
    inter = a & b
    union = a | b
    return len(inter) / len(union) if union else 0.0


# ---------- STEP-1: 生成原始 customers ----------

random.seed(42)
BASE_DT = datetime.utcnow()

sentences = [
    "good product", "very bad experience", "average quality",
    "totally worth the price", "will buy again", "not recommended",
    "excellent service", "packaging was poor", "fast delivery",
    "color was different", "size fits well", "battery life is short",
    "highly recommended", "terrible customer support", "value for money",
]

raw_records: List[Dict] = []

# 生成 150 条随机记录，故意制造脏数据 + 重复 id + 近似文本
for i in range(150):
    base_sentence = random.choice(sentences)
    txt = noisy_repeat(base_sentence)
    rec_id = random.randint(1, 60)                 # 60 以内随机 id，产生重复 id
    review_id = str(uuid.uuid4())
    raw_records.append({
        "id": rec_id,
        "review_id": review_id,
        "text": txt,
        "update_time": rand_dt(BASE_DT),
    })

# 再造一些“近似重复文本” (MinHash/Jaccard >0.8)
for a, b in random.sample(list(combinations(sentences, 2)), 20):
    base = f"{a} and {b}"
    for _ in range(2):     # 每组造两条记录
        txt = noisy_repeat(base)
        raw_records.append({
            "id": random.randint(61, 90),
            "review_id": str(uuid.uuid4()),
            "text": txt,
            "update_time": rand_dt(BASE_DT),
        })

# 写入 raw/customers.jsonl
Path("raw").mkdir(exist_ok=True)
with open("raw/customers.jsonl", "w", encoding="utf-8") as f:
    for r in raw_records:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")

print(f"Wrote {len(raw_records)} raw records → raw/customers.jsonl")


# ---------- STEP-2: 依题意生成 GT ----------

# 1) 清洗 text
for r in raw_records:
    r["text_clean"] = clean_text(r["text"])

# 2) 按 id ==键== 保留最新 update_time
tmp: Dict[int, Dict] = {}
for r in raw_records:
    rid = r["id"]
    if rid not in tmp or r["update_time"] > tmp[rid]["update_time"]:
        tmp[rid] = r

records_by_id = list(tmp.values())

# 3) MinHash/Jaccard 近似去重 (≥0.8)，保留最小 review_id
groups: List[List[Dict]] = []
visited = set()

for i, rec in enumerate(records_by_id):
    if i in visited:
        continue
    grp = [rec]
    sh1 = shingles(rec["text_clean"])
    for j in range(i + 1, len(records_by_id)):
        if j in visited:
            continue
        rec2 = records_by_id[j]
        if jaccard(sh1, shingles(rec2["text_clean"])) >= 0.8:
            grp.append(rec2)
            visited.add(j)
    groups.append(grp)

gt_records: List[Dict] = []
for grp in groups:
    # 取最小 review_id
    chosen = min(grp, key=lambda x: x["review_id"])
    gt_records.append({
        "id": chosen["id"],
        "review_id": chosen["review_id"],
        "text": chosen["text_clean"],
        "update_time": chosen["update_time"],
    })

# 按 id 排序方便肉眼核对
gt_records.sort(key=lambda x: x["id"])

Path("expected").mkdir(exist_ok=True)
with open("expected/gt.jsonl", "w", encoding="utf-8") as f:
    for r in gt_records:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")

print(f"Wrote {len(gt_records)} GT records → expected/gt.jsonl")