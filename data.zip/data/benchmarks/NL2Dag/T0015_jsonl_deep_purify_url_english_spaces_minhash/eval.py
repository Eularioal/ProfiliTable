#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Evaluate the output of the “JSONL 深度净化” operator.

规则：
1. 不含 URL                           （https?:// 或 www.）
2. 仅包含 ASCII 字符（视为英文）       （出现任意非 ASCII → 非英文）
3. 删除多余空格                       （strip 之后内部不得出现连续空格）
4. 近似去重（≥0.9，保留最小 review_id）——
   该属性在基准 GT 中已满足；评测阶段通过检查 review_id 是否匹配 GT 来验证。

计分逻辑：
• 只把 _合法且唯一_ 的预测记录计入 **valid_pred_ids**：
  - JSON 解析正常
  - 含 `review_id` 与 `text`
  - 通过规则 1–3
  - `review_id` 不重复
• 采用 review_id 集合的 F1 分数作为最终得分：
        precision = |GT ∩ valid_pred| / |valid_pred|
        recall    = |GT ∩ valid_pred| / |GT|
        F1        = 2PR / (P + R)

Usage
-----
python eval.py -o /path/to/your_output.jsonl
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Set

ROOT = Path(__file__).resolve().parent
GT_PATH = ROOT / "expected" / "gt.jsonl"

URL_RE = re.compile(r"https?://|www\.", re.I)
NON_EN_RE = re.compile(r"[^\x00-\x7F]")          # 非 ASCII 判定


def normalize_spaces(text: str) -> str:
    """strip + collapse internal whitespaces to single spaces"""
    return " ".join(text.strip().split())


def load_gt_ids() -> Set[int]:
    ids: Set[int] = set()
    with GT_PATH.open(encoding="utf-8") as f:
        for ln, line in enumerate(f, 1):
            if not line.strip():
                continue
            obj = json.loads(line)
            if "review_id" not in obj:
                raise KeyError(f"GT line {ln}: missing 'review_id'")
            ids.add(obj["review_id"])
    return ids


def load_valid_pred_ids(path: Path) -> Set[int]:
    """
    Return the set of review_id from predictions **that pass all validation rules**.
    Duplicated ids / invalid lines are discarded.
    """
    pred_ids: Set[int] = set()
    seen_ids: Set[int] = set()

    with path.open(encoding="utf-8") as f:
        for ln, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                # skip malformed JSON
                continue

            rid = obj.get("review_id")
            txt = obj.get("text")
            if rid is None or txt is None:
                # missing required field
                continue

            # duplicate id → invalid
            if rid in seen_ids:
                continue
            seen_ids.add(rid)

            # rule-1: URL
            if URL_RE.search(txt):
                continue
            # rule-2: non-english
            if NON_EN_RE.search(txt):
                continue
            # rule-3: extra spaces
            if txt != normalize_spaces(txt):
                continue

            pred_ids.add(rid)

    return pred_ids


def compute_f1(gt_ids: Set[int], pred_ids: Set[int]) -> float:
    if not pred_ids:
        return 0.0
    tp = len(gt_ids & pred_ids)
    precision = tp / len(pred_ids)
    recall = tp / len(gt_ids)
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Evaluate JSONL deep-cleanup output"
    )
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Path to your cleaned jsonl file",
    )
    args = parser.parse_args()

    gt_ids = load_gt_ids()
    pred_ids = load_valid_pred_ids(Path(args.output))
    f1 = compute_f1(gt_ids, pred_ids)

    # 输出四舍五入到 4 位小数，满足 0 ≤ score ≤ 1
    print({"eval_score": f"{f1:.4f}"})


if __name__ == "__main__":
    main()