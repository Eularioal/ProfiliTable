#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成带噪声数据(raw/customers.jsonl) ➜ 按规则净化 ➜ expected/gt.jsonl
规则：
    ① 去掉含 URL 的记录
    ② 过滤非英文记录（出现任何非 ASCII 字符即视为非英文）
    ③ 删除多余空格（strip + collapse）
    ④ MinHash 近似去重（Jaccard ≥ 0.9，保留 review_id 最小的）
"""
import json
import os
import random
import re
import string
from pathlib import Path

from datasketch import MinHash, MinHashLSH

# --------------------------------------------------------------------------- #
# 超参数
RAW_NUM = 150          # 原始条目数 (>100 以保证 GT>100)
SEED    = 42           # 可复现随机种子
DUP_RATE = 0.12        # 近似重复比例
URL_RATE = 0.10        # 含 URL 噪声比例
NON_EN_RATE = 0.10     # 非英文噪声比例
# --------------------------------------------------------------------------- #

random.seed(SEED)

ROOT = Path(__file__).resolve().parent
RAW_PATH = ROOT / "raw" / "customers.jsonl"
GT_PATH  = ROOT / "expected" / "gt.jsonl"
RAW_PATH.parent.mkdir(parents=True, exist_ok=True)
GT_PATH.parent.mkdir(parents=True, exist_ok=True)

# --------------------------- 数据生成辅助 ---------------------------------- #
SAMPLE_SENTENCES = [
    "This product exceeded my expectations and I would definitely recommend it to friends.",
    "Absolutely terrible! It broke after two uses and customer service was useless.",
    "Solid build quality, decent price, nothing spectacular but it works as advertised.",
    "Shipping was faster than I thought. Overall, quite happy with the purchase.",
    "Colors are vibrant and the material feels premium. Will buy again.",
    "Battery life could be better, but the performance is top-notch for the price.",
    "Great value! I've already ordered another one for my office.",
    "Packaging was damaged on arrival, but the item inside was perfectly fine.",
    "Setup was confusing at first, but once configured it runs flawlessly.",
    "Five stars! 👏👏👏",   # 有 emoji，属于“非英文”
]

URLS = [
    "https://example.com",
    "http://foo.bar/review",
    "www.buy-now.test/deal",
]

NON_EN_SENTENCES = [
    "这款产品真的很好用，下次还会购买！",
    "Excelente producto, superó mis expectativas.",
    "Très satisfait de mon achat, je le recommande.",
]

def random_sentence():
    return random.choice(SAMPLE_SENTENCES)

def inject_noise(txt: str, idx: int) -> str:
    r = random.random()
    # 插入 URL
    if r < URL_RATE:
        txt += f" Check this out: {random.choice(URLS)}"
    # 非英文
    elif r < URL_RATE + NON_EN_RATE:
        txt = random.choice(NON_EN_SENTENCES)
    # 制造重复（近似）
    elif r < URL_RATE + NON_EN_RATE + DUP_RATE:
        # 选择一个已有句子，替换几个词
        if idx > 0:
            base = random_sentence()
            words = base.split()
            if len(words) > 4:
                # 随机替换 1-2 个词
                for _ in range(random.randint(1, 2)):
                    pos = random.randint(0, len(words)-1)
                    words[pos] = random.choice(words)
                txt = " ".join(words)
            else:
                txt = base
    # 随机插入多余空格
    if random.random() < 0.3:
        txt = "  " + txt.replace(" ", "  ") + "  "
    return txt

# --------------------------- 生成 RAW -------------------------------------- #
with RAW_PATH.open("w", encoding="utf-8") as f:
    for rid in range(1, RAW_NUM + 1):
        sent = random_sentence()
        noisy = inject_noise(sent, rid)
        record = {"review_id": rid, "text": noisy}
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

print(f"✔ raw data written to {RAW_PATH} ({RAW_NUM} lines)")

# --------------------------- 净化 pipeline --------------------------------- #
URL_RE = re.compile(r"https?://|www\.", re.I)
NON_EN_RE = re.compile(r"[^\x00-\x7F]")   # 非 ASCII

def clean_text(txt: str) -> str:
    # ③ 去多余空格
    txt = " ".join(txt.strip().split())
    return txt

def to_minhash(txt: str, num_perm=128) -> MinHash:
    m = MinHash(num_perm=num_perm)
    # 按 word shingles
    for token in txt.lower().split():
        m.update(token.encode("utf-8"))
    return m

# MinHash LSH index
lsh = MinHashLSH(threshold=0.9, num_perm=128)

clean_records = []
with RAW_PATH.open(encoding="utf-8") as f:
    for line in f:
        rec = json.loads(line)
        rid, txt = rec["review_id"], rec["text"]

        # ① 含 URL 去掉
        if URL_RE.search(txt):
            continue
        # ② 过滤非英文
        if NON_EN_RE.search(txt):
            continue
        # ③ 清理空格
        txt = clean_text(txt)
        if not txt:
            continue

        # ④ 近似去重
        mh = to_minhash(txt)
        dup_ids = lsh.query(mh)
        if dup_ids:
            # 已存在相似文本，找最小 review_id
            exist_idx = dup_ids[0]        # 只有一个，因为我们自己控制
            exist_rid, _ = clean_records[exist_idx]
            # 保留最小 review_id
            if rid < exist_rid:
                clean_records[exist_idx] = (rid, txt)
        else:
            lsh.insert(len(clean_records), mh)
            clean_records.append((rid, txt))

# 按 review_id 升序输出
clean_records.sort(key=lambda x: x[0])

with GT_PATH.open("w", encoding="utf-8") as f:
    for rid, txt in clean_records:
        f.write(json.dumps({"review_id": rid, "text": txt}, ensure_ascii=False) + "\n")

print(f"✔ GT written to {GT_PATH} ({len(clean_records)} lines)")
assert len(clean_records) >= 100, "GT 必须 ≥100 行"