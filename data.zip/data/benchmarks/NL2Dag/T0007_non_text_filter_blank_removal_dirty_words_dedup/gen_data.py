import json
import random
import copy
from pathlib import Path
import uuid

# =============== 辅助函数 ===============
def add_symbols_noise(text):
    """在文本随机位置插入过多符号"""
    symbols = random.choice([
        "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "??????????????????????????????????????????????????????????????????????????????????????????????????????????????", "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", "##############################################################################################################"])
    words = text.split()
    if len(words) > 2:
        insert_pos = random.randint(1, len(words)-1)
        words.insert(insert_pos, symbols)
    return " ".join(words)

def add_spaces_noise(text):
    """在文本中插入多余空格"""
    return text.replace(" ", "  ")  # 双倍空格

def unmask_profanity(text, badwords=None):
    """把 **** 替换成随机脏话"""
    if badwords is None:
        badwords = ["fuck", "shit", "bitch", "asshole", "damn"]
    while "****" in text:
        text = text.replace("****", random.choice(badwords), 1)
    return text

def create_near_duplicate(record):
    """创建一个类似记录（near-duplicate），用于 MinHash 去重测试"""
    dup = copy.deepcopy(record)
    dup["id"] = str(record["id"]) + "_dup"
    dup["text"] = record["text"].replace(".", " .").replace('and', '&')  # 轻微改动
    return dup


# =============== 主流程 ===============
def main(gt_file, output_file, noise_ratio=0.2):
    # 读取 GT 数据
    with open(gt_file, "r", encoding="utf-8") as f:
        gt_records = [json.loads(line) for line in f]

    noisy_records = copy.deepcopy(gt_records)

    n = len(gt_records)
    # num_noise_each = max(1, int(n * noise_ratio / 4))  # 每类噪声数量
    num_noise_each = max(1, int(n * noise_ratio))

    added_recs = []

    new_record = {}
    # 1️⃣ 过多符号
    for rec in random.sample(noisy_records, num_noise_each):
        added_recs.append({
            'id': str(uuid.uuid4()),
            'items': rec['items'],
            'text': add_symbols_noise(rec["text"]),
            'sources': rec['sources']
        })

    # 2️⃣ 多余空格
    for rec in random.sample(noisy_records, num_noise_each):
        rec["text"] = add_spaces_noise(rec["text"])

    # 3️⃣ 替换脏话
    for rec in random.sample(noisy_records, num_noise_each):
        rec["text"] = unmask_profanity(rec["text"])

    # 4️⃣ 添加 near-duplicate 记录
    duplicates = []
    for i, rec in enumerate(random.sample(gt_records, num_noise_each)):
        tem_rec = create_near_duplicate(rec)
        tem_rec['id'] = 1000 + i
        duplicates.append(tem_rec)

    noisy_records.extend(duplicates)
    noisy_records.extend(added_recs)
    
    # 写入 noisy 文件
    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    with open(output_file, "w", encoding="utf-8") as f:
        for rec in noisy_records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    print(f"✅ GT {len(gt_records)} 条, Noisy {len(noisy_records)} 条 写入 {output_file}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--gt_file", type=str, required=True, help="GT 文件路径 (jsonl)")
    parser.add_argument("-o", "--output_file", type=str, required=True, help="输出 noisy 文件路径")
    parser.add_argument("--noise_ratio", type=float, default=0.2, help="噪声比例 (默认 0.2)")
    args = parser.parse_args()

    main(args.gt_file, args.output_file, args.noise_ratio)
