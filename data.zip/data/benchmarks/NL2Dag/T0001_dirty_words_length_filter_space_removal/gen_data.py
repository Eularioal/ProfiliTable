import json
import random
import os
from utils.llm_serving import LLMServing
import uuid
import re

# Initialize the LLM model
llm = LLMServing()

# Define the filtering conditions as a function for clarity
def filter_text(text):
    """ This ensures the text is already valid per the conditions """
    # 2) Filter out text with fewer than 50 words
    if len(text.split()) < 50:
        return None
    
    # 3) Filter out text with fewer than 5 sentences
    if len(re.findall(r'\.', text)) < 5:
        return None
    
    # 4) Discard text with more than 100 characters
    if len(text) < 100:
        return None
    
    # 5) Clean up extra spaces
    text = ' '.join(text.split())
    
    return text

# Define noise generation functions
def generate_profanity_noise(text):
    """ Introduce profanity into the text """
    profanity_list = ['fucking', 'shit', 'bitch', 'asshole', 'damn']
    # Replace a random word with profanity
    words = text.split()
    if words:
        words[random.randint(0, len(words) - 1)] = random.choice(profanity_list)
    return ' '.join(words)

def generate_short_text_noise(text):
    """ Generate a shorter version of the text (less than 50 words) """
    words = text.split()
    return ' '.join(words[:random.randint(10, 30)])

def generate_extra_spaces_noise(text):
    """ Introduce extra spaces into the text """
    words = text.split()  # Split text into words
    noisy_text = '     '.join(words)  # Add 3 spaces between each word
    return noisy_text


# Generate synthetic data for GT (30 entries)
def generate_gt_data(output_dir, task_id):
    """ Generate ground truth data and save as JSONL """
    gt_data = []
    
    topics = ["the weather today", "the importance of education", "advancements in technology", "space exploration", "climate change"]
    
    # Randomly select 30 samples of two topics each
    selected_topic_pairs = []
    for _ in range(30):
        pair = random.sample(topics, 2)  # Randomly choose 2 topics from the list
        selected_topic_pairs.append(pair)
    
    # Generate sentences based on topic pairs (using the large model)
    user_inputs = [f"Write a formal and coherent text about {pair[0]} and {pair[1]}" for pair in selected_topic_pairs]
    
    # Generate valid sentences from the model
    system_prompt = "You are an AI that writes formal, coherent, and grammatically correct sentences. The text must be suitable for an academic context, at least 100 words, with at least 10 sentences, and must avoid profanity."
    generated_texts = llm.generate_from_input(user_inputs, system_prompt)
    
    # Now filter and save valid texts
    for text in generated_texts:
        filtered_text = filter_text(text)
        
        if filtered_text:
            # Add to the GT data
            gt_data.append({
                "id": str(uuid.uuid4()),
                "text": filtered_text
            })
    
    
    gt_output_path = os.path.join(output_dir, "expected/gt.jsonl")
    with open(gt_output_path, 'w') as f:
        for entry in gt_data:
            f.write(json.dumps(entry) + '\n')

    print(f"Generated {len(gt_data)} GT entries at {gt_output_path}")


    noisy_data = []
    for _ in range(100):
        noise_type = random.choice([generate_profanity_noise, generate_short_text_noise, generate_extra_spaces_noise])
        
        if noise_type == generate_extra_spaces_noise:
            noisy_record = random.choice(gt_data)
            noisy_text = noisy_record['text']
            
            noisy_text = generate_extra_spaces_noise(noisy_text)
            
            noisy_record['text'] = noisy_text
            
        else:
            # Use existing generated text to introduce other types of noise
            noise_text = random.choice(generated_texts)
            noisy_text = noise_type(noise_text)
            
            # We do not filter noisy data, as they are meant to be noisy
            noisy_data.append({
                "id": str(uuid.uuid4()),  # Generate a new ID for the other noise types
                "text": noisy_text
            })

    # Combine GT data and noisy data
    all_data = gt_data + noisy_data

    raw_output_path = os.path.join(output_dir, "raw/customers.jsonl")
    with open(raw_output_path, 'w') as f:
        for entry in all_data:
            f.write(json.dumps(entry) + '\n')

    print(f"Generated {len(all_data)} GT entries at {raw_output_path}")


if __name__ == "__main__":
    task_id = "T0000_"  # Example task_id, modify as needed
    output_dir = "data/benchmarks/NL2Dag"  # Modify to your desired output directory
    # os.makedirs(os.path.join(output_dir, task_id, "expected"), exist_ok=True)
    
    generate_gt_data(os.path.join(output_dir, task_id), task_id)
