import json
import argparse
def load_jsonl(path):
    entries = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            entries.append(json.loads(line))
    return entries
    
def evaluate(expected_path, processed_path):
    expected = load_jsonl(expected_path)
    processed = load_jsonl(processed_path)

    expected_entries = set((entry['id'], entry['text'].strip()) for entry in expected)
    processed_entries = set((entry['id'], entry['text'].strip()) for entry in processed)

    true_positives = len(expected_entries & processed_entries)
    predicted_total = len(processed_entries)
    gold_total = len(expected_entries)

    precision = true_positives / predicted_total if predicted_total > 0 else 0.0
    recall = true_positives / gold_total if gold_total > 0 else 0.0
    f1 = (2 * precision * recall) / (precision + recall) if precision + recall > 0 else 0.0

    result = {"eval_score": f"{f1:.4f}"}
    print(result)


def get_gt():
    from pathlib import Path

    current_dir = Path(__file__).resolve().parent

    expected_dir = (current_dir / "./expected").resolve()

    jsonl_files = list(expected_dir.glob("*.jsonl"))

    if not jsonl_files:
        raise FileNotFoundError(f"No .jsonl file found in {expected_dir}")

    expected_path = jsonl_files[0]

    return expected_path

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="filter non-english data")
    parser.add_argument(
        "-o",
        "--output",
        required=False,
        help="Path to the deduplicated jsonl produced by your operator",
    )
    args = parser.parse_args()
    expected_path = get_gt()
    processed_path = args.output
    evaluate(expected_path, processed_path)
