#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Evaluate the output of the 'Incremental Merge with Text Cleaning' task

    任务
    1) 对 text 字段进行清洗：去HTML标签与实体，替换英文缩写为全称，移除Emoji
    2) 执行增量合并去重：主键id，比较updated_at选择较新记录
    3) 输出合并结果为JSONL（UTF-8），字段结构保持不变

评测规则
------------
• 只接受"已处理"的结果文件进行评测。
• 对于每一条记录，要求：
  - id 必须正确
  - 所有字段（name, email, text, status, updated_at）都要与GT完全一致
  - text字段的清洗结果要完全匹配（大小写、空格都算）
• 评测指标：
    record_accuracy = 完全匹配的记录数 / GT记录总数
    field_accuracy  = 所有字段匹配总数 / (GT记录总数 × 字段数)
    final_score     = (record_accuracy × 0.7) + (field_accuracy × 0.3)

使用方法
---------

python eval.py -o /path/to/your_output.jsonl

会打印形如 {"eval_score": "0.9231"} 的 JSON。
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List, Any, Tuple

ROOT = Path(__file__).resolve().parent
GT_PATH = ROOT / "expected" / "gt.jsonl"

def load_jsonl_records(path: Path) -> Dict[str, Dict[str, Any]]:
    """
    读取 jsonl，返回 {id: record}。
    - 要求每行是 JSON 对象，至少包含 'id' 字段。
    - id 将被转成字符串用作键。
    - 如果同一个 id 出现多次，后出现的记录会覆盖先前的。
    """
    if not path.is_file():
        sys.exit(f"[Eval] File not found: {path}")

    data: Dict[str, Dict[str, Any]] = {}
    with path.open(encoding="utf-8") as f:
        for ln, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                sys.exit(f"[Eval] {path} L{ln}: JSON decode error -- {e}")

            if "id" not in obj:
                sys.exit(f"[Eval] {path} L{ln}: missing 'id' field")

            id_val = obj["id"]
            # 统一将id转为字符串
            if isinstance(id_val, (int, float)):
                id_key = str(id_val)
            elif isinstance(id_val, str):
                id_key = id_val
            else:
                sys.exit(f"[Eval] {path} L{ln}: 'id' must be str/int, got {type(id_val).__name__}")

            data[id_key] = obj
    return data

def compare_records(gt_record: Dict[str, Any], pred_record: Dict[str, Any]) -> Tuple[bool, int, int]:
    """
    比较两条记录是否完全匹配。
    返回：(是否完全匹配, 匹配的字段数, 总字段数)
    """
    # 定义需要比较的关键字段
    key_fields = ["id", "name", "email", "text", "status", "updated_at"]
    
    total_fields = len(key_fields)
    matched_fields = 0
    
    for field in key_fields:
        gt_val = gt_record.get(field)
        pred_val = pred_record.get(field)
        
        # 对于id字段，统一转为字符串比较
        if field == "id":
            if isinstance(gt_val, (int, float)):
                gt_val = str(gt_val)
            if isinstance(pred_val, (int, float)):
                pred_val = str(pred_val)
        
        if gt_val == pred_val:
            matched_fields += 1
    
    is_perfect_match = matched_fields == total_fields
    return is_perfect_match, matched_fields, total_fields

def compute_scores(gt_data: Dict[str, Dict[str, Any]], 
                  pred_data: Dict[str, Dict[str, Any]]) -> Tuple[float, float, float]:
    """
    计算评分指标。
    返回：(record_accuracy, field_accuracy, final_score)
    """
    if not gt_data:
        return 0.0, 0.0, 0.0
    
    total_records = len(gt_data)
    perfect_matches = 0
    total_field_matches = 0
    total_fields = 0
    
    for gt_id, gt_record in gt_data.items():
        if gt_id not in pred_data:
            # 预测中缺少该记录，所有字段都不匹配
            total_fields += 5  # 假设5个关键字段
            continue
        
        pred_record = pred_data[gt_id]
        is_perfect, matched_fields, total_field_count = compare_records(gt_record, pred_record)
        
        if is_perfect:
            perfect_matches += 1
        
        total_field_matches += matched_fields
        total_fields += total_field_count
    
    # 计算记录级准确率
    record_accuracy = perfect_matches / total_records
    
    # 计算字段级准确率
    field_accuracy = total_field_matches / total_fields if total_fields > 0 else 0.0
    
    # 计算最终评分（记录级权重更高）
    final_score = (record_accuracy * 0.7) + (field_accuracy * 0.3)
    
    return record_accuracy, field_accuracy, final_score

def validate_merge_logic(gt_data: Dict[str, Dict[str, Any]], 
                        pred_data: Dict[str, Dict[str, Any]]) -> float:
    """
    验证合并逻辑的正确性。
    检查是否有遗漏记录或多余记录。
    返回结构一致性得分（0-1）。
    """
    gt_ids = set(gt_data.keys())
    pred_ids = set(pred_data.keys())
    
    # 检查记录数量和ID集合
    missing_ids = gt_ids - pred_ids  # GT中有但预测中没有的
    extra_ids = pred_ids - gt_ids    # 预测中有但GT中没有的
    
    if not missing_ids and not extra_ids:
        return 1.0  # 完美匹配
    
    # 计算结构一致性得分
    total_gt = len(gt_ids)
    correct_ids = len(gt_ids & pred_ids)
    structure_score = correct_ids / total_gt if total_gt > 0 else 0.0
    
    return structure_score

def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate incremental merge output")
    parser.add_argument(
        "-o", "--output", required=True, help="Path to your jsonl output file"
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Print detailed evaluation info"
    )
    args = parser.parse_args()

    # 加载GT数据和预测数据
    gt_data = load_jsonl_records(GT_PATH)
    pred_data = load_jsonl_records(Path(args.output))
    
    # 计算评分
    record_acc, field_acc, final_score = compute_scores(gt_data, pred_data)
    structure_score = validate_merge_logic(gt_data, pred_data)
    
    # 综合最终得分（结构一致性也很重要）
    final_eval_score = (final_score * 0.8) + (structure_score * 0.2)
    
    if args.verbose:
        print(f"[Eval] GT records: {len(gt_data)}")
        print(f"[Eval] Predicted records: {len(pred_data)}")
        print(f"[Eval] Record accuracy: {record_acc:.4f}")
        print(f"[Eval] Field accuracy: {field_acc:.4f}")
        print(f"[Eval] Structure score: {structure_score:.4f}")
        print(f"[Eval] Content score: {final_score:.4f}")
        print(f"[Eval] Final score: {final_eval_score:.4f}")
        
        # 显示一些不匹配的示例
        mismatched_count = 0
        for gt_id, gt_record in list(gt_data.items())[:3]:  # 只显示前3个
            if gt_id in pred_data:
                pred_record = pred_data[gt_id]
                is_perfect, _, _ = compare_records(gt_record, pred_record)
                if not is_perfect:
                    mismatched_count += 1
                    if mismatched_count <= 2:  # 最多显示2个不匹配的例子
                        print(f"[Eval] Mismatch example ID {gt_id}:")
                        print(f"  GT text: {gt_record.get('text', '')[:100]}...")
                        print(f"  Pred text: {pred_record.get('text', '')[:100]}...")
    
    # 输出最终评分
    print(json.dumps({"eval_score": f"{final_eval_score:.4f}"}))

if __name__ == "__main__":
    main()