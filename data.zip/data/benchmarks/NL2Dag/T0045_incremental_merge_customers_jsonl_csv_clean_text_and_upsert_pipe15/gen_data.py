import json
import csv
import random
import datetime
from pathlib import Path
import re
import html

# 创建目录结构
Path("raw").mkdir(exist_ok=True)
Path("expected").mkdir(exist_ok=True)

def clean_text(text):
    """清洗文本：去HTML标签与实体，替换英文缩写，移除Emoji"""
    if not text:
        return text
    
    # 去除HTML标签
    text = re.sub(r'<[^>]+>', '', text)
    
    # 去除HTML实体
    text = html.unescape(text)
    
    # 替换常见英文缩写为全称
    abbreviations = {
        r'\bDr\.\s': 'Doctor ',
        r'\bMr\.\s': 'Mister ',
        r'\bMrs\.\s': 'Missus ',
        r'\bMs\.\s': 'Miss ',
        r'\bCo\.\s': 'Company ',
        r'\bInc\.\s': 'Incorporated ',
        r'\bLtd\.\s': 'Limited ',
        r'\bCorp\.\s': 'Corporation ',
        r'\betc\.\s': 'et cetera ',
        r'\bi\.e\.\s': 'that is ',
        r'\be\.g\.\s': 'for example ',
        r'\bUSA\b': 'United States of America',
        r'\bUK\b': 'United Kingdom',
        r'\bNYC\b': 'New York City',
        r'\bLA\b': 'Los Angeles',
    }
    
    for abbr, full in abbreviations.items():
        text = re.sub(abbr, full, text, flags=re.IGNORECASE)
    
    # 移除Emoji (Unicode ranges)
    emoji_pattern = re.compile("["
        u"\U0001F600-\U0001F64F"  # emoticons
        u"\U0001F300-\U0001F5FF"  # symbols & pictographs
        u"\U0001F680-\U0001F6FF"  # transport & map symbols
        u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
        u"\U00002702-\U000027B0"
        u"\U000024C2-\U0001F251"
        "]+", flags=re.UNICODE)
    text = emoji_pattern.sub(r'', text)
    
    return text.strip()

def parse_datetime(dt_str):
    """解析时间字符串，支持多种格式"""
    if not dt_str:
        return None
    
    formats = [
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%SZ", 
        "%Y-%m-%dT%H:%M:%S.%f%z",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d"
    ]
    
    for fmt in formats:
        try:
            return datetime.datetime.strptime(dt_str, fmt)
        except ValueError:
            continue
    
    return None

def merge_incremental(base_data, incremental_data, strategy="keep_base"):
    """执行增量合并"""
    merged = {}
    
    # 先加载基准数据
    for record in base_data:
        merged[record['id']] = record
    
    # 处理增量数据
    for inc_record in incremental_data:
        record_id = inc_record['id']
        
        if record_id not in merged:
            # 新记录，直接追加
            merged[record_id] = inc_record
        else:
            # 存在的记录，比较updated_at
            base_record = merged[record_id]
            
            base_time = parse_datetime(base_record.get('updated_at'))
            inc_time = parse_datetime(inc_record.get('updated_at'))
            
            if base_time and inc_time:
                if inc_time > base_time:
                    # 增量更新时间更新
                    merged[record_id] = inc_record
                elif inc_time == base_time:
                    # 时间相同，按策略处理
                    if strategy == "keep_incremental":
                        merged[record_id] = inc_record
                    # 默认保留基准
            elif inc_time and not base_time:
                # 只有增量有时间戳
                merged[record_id] = inc_record
    
    return list(merged.values())

# 生成样本文本数据
sample_texts = [
    "Welcome to <b>Tech Corp.</b> - your trusted partner! 😊 Contact Dr. Smith for more info.",
    "<p>Visit our NYC office at <em>123 Main St.</em> 🏢 Mr. Johnson will assist you.</p>",
    "🎉 Special offer from ABC Inc.! Call Mrs. Davis at (555) 123-4567.",
    "<div>Please contact Ms. Brown at our LA branch for assistance. 📞</div>",
    "📧 Email us at support@company.co.uk for help with your order.",
    "🚀 Innovation at XYZ Ltd. - transforming the future! Contact our CEO.",
    "<span>Located in the USA 🇺🇸, we serve customers worldwide.</span>",
    "Thank you for choosing our services! 💯 - Management Team",
    "📅 Schedule your appointment with Dr. Anderson today!",
    "<h1>Premium Services</h1> 🌟 Available throughout the UK.",
]

# 生成基准数据 (customers.jsonl)
base_records = []
for i in range(1, 81):  # 80条基准记录
    record = {
        "id": i,
        "name": f"Customer {i}",
        "email": f"customer{i}@example.com",
        "text": random.choice(sample_texts),
        "status": random.choice(["active", "inactive", "pending"]),
        "updated_at": (datetime.datetime.now() - datetime.timedelta(days=random.randint(1, 30))).isoformat() + "Z"
    }
    base_records.append(record)

# 保存基准数据
with open("raw/customers.jsonl", "w", encoding="utf-8") as f:
    for record in base_records:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

# 生成增量数据 (customers.csv)
incremental_records = []

# 添加一些新记录
for i in range(81, 111):  # 30条新记录
    record = {
        "id": i,
        "name": f"New Customer {i}",
        "email": f"newcustomer{i}@example.com", 
        "text": random.choice(sample_texts),
        "status": random.choice(["active", "inactive", "pending"]),
        "updated_at": (datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 5))).isoformat() + "Z"
    }
    incremental_records.append(record)

# 添加一些更新的记录（覆盖基准中的部分记录）
for i in range(1, 21):  # 更新前20条记录
    updated_time = datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 10))
    record = {
        "id": i,
        "name": f"Updated Customer {i}",
        "email": f"updated{i}@example.com",
        "text": random.choice(sample_texts),
        "status": random.choice(["active", "inactive", "pending"]),
        "updated_at": updated_time.isoformat() + "Z"
    }
    incremental_records.append(record)

# 保存增量数据为CSV
with open("raw/customers.csv", "w", encoding="utf-8", newline="") as f:
    if incremental_records:
        writer = csv.DictWriter(f, fieldnames=incremental_records[0].keys())
        writer.writeheader()
        writer.writerows(incremental_records)

print("已生成基准数据：raw/customers.jsonl (80条记录)")
print("已生成增量数据：raw/customers.csv (50条记录，包含30条新记录和20条更新)")

# 生成GT数据（预期结果）
# 先对基准数据清洗text字段
cleaned_base = []
for record in base_records:
    cleaned_record = record.copy()
    cleaned_record['text'] = clean_text(record['text'])
    cleaned_base.append(cleaned_record)

# 对增量数据清洗text字段  
cleaned_incremental = []
for record in incremental_records:
    cleaned_record = record.copy()
    cleaned_record['text'] = clean_text(record['text'])
    cleaned_incremental.append(cleaned_record)

# 执行合并
gt_data = merge_incremental(cleaned_base, cleaned_incremental, "keep_base")

# 按id排序以保持一致性
gt_data.sort(key=lambda x: x['id'])

# 保存GT数据
with open("expected/gt.jsonl", "w", encoding="utf-8") as f:
    for record in gt_data:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

print(f"已生成GT数据：expected/gt.jsonl ({len(gt_data)}条记录)")