import os
import json
import random
import argparse
import csv
from pathlib import Path
import copy

try:
    from utils.llm_serving import LLMServing
except ImportError:
    LLMServing = None

# 脏话列表（可扩展）
BAD_WORDS = ["fuck", "shit", "bitch", "asshole", "damn", "bitches", "bitchy", "fucked", "fucking"]

def mask_profanity(text):
    """将脏话替换为 ****"""
    words = text.split()
    masked_words = []
    for w in words:
        lw = w.lower().strip(".,!?")
        if lw in BAD_WORDS:
            masked_words.append("****")
        else:
            masked_words.append(w)
    return " ".join(masked_words)

def generate_items(unique=True):
    """生成 items 数组，若 unique=False 则可能包含重复"""
    candidates = ["apple", "banana", "pear", "grape", "orange",
                  "book", "pen", "paper", "computer", "phone"]
    items = random.sample(candidates, k=random.randint(3, 6))
    if not unique:  # 引入重复
        items.append(random.choice(items))
    return items

def generate_text(topics, llm=None, mask=True, length="normal"):
    """
    生成文本
    mask=True -> 屏蔽脏话
    mask=False -> 保留脏话
    length 控制长度: "normal"(30-80), "short"(<20), "long"(>100)
    """
    topic_pair = random.sample(topics, 2)
    topic_str = " and ".join(topic_pair)

    if llm:
        user_input = f"Write a paragraph about {topic_str}. Insert at least one of these words: {', '.join(BAD_WORDS)}.You can only use the dirty words that I mentioned and don't use any participle of them."
        system_prompt = "You are an AI that writes English paragraphs and may insert mild profanities."
        results = llm.generate_from_input([user_input], system_prompt)
        text = results[0]
    else:
        text = (
            f"This text is about {topic_str}. "
            f"It describes ideas in a clear manner but sometimes people say shit or fuck in casual speech. "
            f"Nevertheless, the main content remains formal and informative."
        )

    words = text.split()
    if len(words) < 30:
        words = words * 2

    if length == "normal":
        text = " ".join(words[:random.randint(30, 80)])
    elif length == "short":
        text = " ".join(words[:random.randint(5, 15)])
    elif length == "long":
        text = " ".join(words * 5)  # >100
    else:
        text = " ".join(words[:random.randint(30, 80)])

    if mask:
        text = mask_profanity(text)

    return text

def generate_sources():
    """随机选择来源"""
    candidates = ["dataset_a.jsonl", "dataset_b.jsonl", "dataset_c.jsonl"]
    return random.sample(candidates, k=random.randint(1, 2))

    # === 保存文件 ===
    def save_records(records, filepath, fmt):
        if fmt == "jsonl":
            with open(filepath, "w", encoding="utf-8") as f:
                for r in records:
                    f.write(json.dumps(r, ensure_ascii=False) + "\n")
        elif fmt == "csv":
            keys = records[0].keys()
            with open(filepath, "w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=keys)
                writer.writeheader()
                writer.writerows(records)
        else:
            raise ValueError("Unsupported format: choose jsonl or csv")

def save_records(records, filepath, fmt):
    if fmt == "jsonl":
        with open(filepath, "w", encoding="utf-8") as f:
            for r in records:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    elif fmt == "csv":
        keys = records[0].keys()
        with open(filepath, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            writer.writerows(records)
    else:
        raise ValueError("Unsupported format: choose jsonl or csv")

def add_spaces_noise(text):
    """在文本中插入多余空格"""
    return text.replace(" ", "  ")  # 双倍空格

def unmask_profanity(text, badwords=None):
    """把 **** 替换成随机脏话"""
    if badwords is None:
        badwords = ["fuck", "shit", "bitch", "asshole", "damn"]
    while "****" in text:
        text = text.replace("****", random.choice(badwords), 1)  # 每次替换一个
    return text

import random
import datetime
import re

def generate_id_card():
    # 生成随机的前17位数字（省市区+出生日期+顺序码）
    address_code = random.randint(100000, 999999)  # 地址码
    birth_date = datetime.date(random.randint(1950, 2000), random.randint(1, 12), random.randint(1, 28))  # 随机出生日期
    birth_code = birth_date.strftime("%Y%m%d")  # 出生日期部分
    sequence_code = random.randint(100, 999)  # 顺序码

    # 组合前17位
    id_card = f"{address_code}{birth_code}{sequence_code}"

    # 校验码（简单示例，真实的校验码生成较为复杂，通常涉及一系列的算法）
    check_code = random.randint(0, 9)  # 这里用随机数生成简单的校验码

    # 完整的身份证号
    return id_card + str(check_code)

def replace_with_id_card(text):
    # 使用正则表达式匹配 "****"
    id_card = generate_id_card()  # 生成一个身份证号
    return re.sub(r'\*{4}', id_card, text)  # 替换文本中的 "****" 为身份证号

def add_symbols_noise(text):
    """在文本随机位置插入过多符号"""
    symbols = random.choice([
        "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "??????????????????????????????????????????????????????????????????????????????????????????????????????????????", "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", "##############################################################################################################"])
    words = text.split()
    if len(words) > 2:
        insert_pos = random.randint(1, len(words)-1)
        words.insert(insert_pos, symbols)
    return " ".join(words)

def add_random_bullet_point(text):
    """
    随机选择一种项目符号并将其添加到文本的开头。

    :param text: 需要处理的文本
    :return: 带有随机项目符号的文本
    """
    # 项目符号列表
    bullet_points = ["•", "*", "-", "➤", "→", "✔️"]
    
    # 随机选择一个项目符号
    bullet = random.choice(bullet_points)
    
    # 返回添加了随机项目符号的文本
    return f"{bullet} {text}"

def add_random_bullet_point(text):
    """
    随机选择一种项目符号并将其添加到文本的开头。

    :param text: 需要处理的文本
    :return: 带有随机项目符号的文本
    """
    # 项目符号列表
    bullet_points = ["•", "*", "-", "➤", "→", "✔️"]
    
    # 随机选择一个项目符号
    bullet = random.choice(bullet_points)
    
    # 返回添加了随机项目符号的文本
    return f"{bullet} {text}"

def main(task_id, output_format="jsonl", use_llm=False):
    output_dir = Path(f"data/benchmarks/NL2Dag/{task_id}")
    output_dir.mkdir(parents=True, exist_ok=True)

    gt_file = output_dir / f"expected/gt.{output_format}"
    noisy_file = output_dir / f"raw/customers.{output_format}"

    topics = ["technology", "education", "environment", "health", "science",
              "culture", "economy", "art", "history", "sports"]

    llm = LLMServing() if (use_llm and LLMServing) else None

    # ✅ 生成 GT 数据
    gt_records = []
    for i in range(100):
        record = {
            "id": i + 1,
            "items": generate_items(unique=True),
            "text": generate_text(topics, llm=llm, mask=True, length="normal"),
            "sources": generate_sources()
        }
        gt_records.append(record)

    save_records(gt_records, gt_file, output_format)

    # import copy
    noisy_records = gt_records

    # # 1️⃣ 对 GT 数据随机挑选一些记录，引入 items 重复
    # gt_items_noise_sample = noisy_records[:15]
    # for record in gt_items_noise_sample:
    #     record["items"].append(random.choice(record["items"]))  # 引入重复

    # 2️⃣ 对 GT 数据随机挑选一些记录，引入脏话屏蔽失败
    gt_profanity_noise_sample = noisy_records[:50]  # 或者根据你的逻辑挑选
    for record in gt_profanity_noise_sample:
        record["text"] = unmask_profanity(record["text"])

    gt_profanity_noise_sample = noisy_records[50:]  # 或者根据你的逻辑挑选
    for record in gt_profanity_noise_sample:
        tem_rec = copy.deepcopy(record)
        tem_rec['id'] = int(record['id']) + 1000
        tem_rec['text'] = add_symbols_noise(record['text'])
        noisy_records.append(tem_rec)

    gt_profanity_noise_sample = random.sample(noisy_records, 50)  # 或者根据你的逻辑挑选
    for record in gt_profanity_noise_sample:
        tem_rec = copy.deepcopy(record)
        tem_rec['id'] = int(record['id']) + 5000
        tem_rec['text'] = add_symbols_noise(record['text'])
        noisy_records.append(tem_rec)
    # 2️⃣ 多余空格
    # for rec in noisy_records[50:]:
    #     rec["text"] = add_spaces_noise(rec["text"])

    # for rec in random.sample(noisy_records, 50):
    #     rec["text"] = replace_with_id_card(rec["text"])

    # # 3️⃣ 词数不符合要求，独立生成
    # for i in range(70):
    #     noisy_records.append({
    #         "id": 300 + i,  # 新 id
    #         "items": generate_items(unique=True),
    #         "text": generate_text(topics, llm=llm, mask=True, length=random.choice(["short", "long"])),
    #         "sources": generate_sources()
    #     })

    save_records(noisy_records, noisy_file, output_format)

    # print(f"✅ GT data generated at: {gt_file}")
    print(f"⚠️ Noisy data generated at: {noisy_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--task_id", type=str, required=True, help="Task ID, e.g., T0001")
    parser.add_argument("-f", "--format", type=str, default="jsonl", choices=["jsonl", "csv"], help="Output format")
    parser.add_argument("--use_llm", action="store_true", help="Whether to use LLM to generate texts")
    args = parser.parse_args()

    main(args.task_id, output_format=args.format, use_llm=args.use_llm)
