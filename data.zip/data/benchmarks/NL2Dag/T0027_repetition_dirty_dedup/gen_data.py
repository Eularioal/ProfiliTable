import json
import random
import copy
from pathlib import Path
import uuid


# 脏话列表（可扩展）
BAD_WORDS = ["fuck", "shit", "bitch", "asshole", "damn", "bitches", "bitchy", "fucked", "fucking"]

# =============== 辅助函数 ===============

def mask_profanity(text):
    """将脏话替换为 ****"""
    words = text.split()
    masked_words = []
    for w in words:
        lw = w.lower().strip(".,!?")
        if lw in BAD_WORDS:
            masked_words.append("****")
        else:
            masked_words.append(w)
    return " ".join(masked_words)

def add_spaces_noise(text):
    """在文本中插入多余空格"""
    return text.replace(" ", "  ")  # 双倍空格

def unmask_profanity(text, badwords=None):
    """把 **** 替换成随机脏话"""
    if badwords is None:
        badwords = ["fuck", "shit", "bitch", "asshole", "damn"]
    while "****" in text:
        text = text.replace("****", random.choice(badwords), 1)
    return text

def create_near_duplicate(record):
    """创建一个类似记录（near-duplicate），用于 MinHash 去重测试"""
    dup = copy.deepcopy(record)
    dup["id"] = int(record["id"]) + 1000
    dup["text"] = record["text"].replace(".", " .").replace('and', '&')  # 轻微改动
    return dup

def generate_text(topics, llm=None, mask=True, length="normal"):
    """
    生成文本
    mask=True -> 屏蔽脏话
    mask=False -> 保留脏话
    length 控制长度: "normal"(30-80), "short"(<20), "long"(>100)
    """
    topic_pair = random.sample(topics, 2)
    topic_str = " and ".join(topic_pair)

    if llm:
        user_input = f"Write a paragraph about {topic_str}. Insert at least one of these words: {', '.join(BAD_WORDS)}.You can only use the dirty words that I mentioned and don't use any participle of them."
        system_prompt = "You are an AI that writes English paragraphs and may insert mild profanities."
        results = llm.generate_from_input([user_input], system_prompt)
        text = results[0]
    else:
        text = (
            f"This text is about {topic_str}. "
            f"It describes ideas in a clear manner but sometimes people say shit or fuck in casual speech. "
            f"Nevertheless, the main content remains formal and informative."
        )

    words = text.split()
    if len(words) < 30:
        words = words * 2

    if length == "normal":
        text = " ".join(words[:random.randint(30, 80)])
    elif length == "short":
        text = " ".join(words[:random.randint(5, 15)])
    elif length == "long":
        text = " ".join(words * 5)  # >100
    else:
        text = " ".join(words[:random.randint(30, 80)])

    if mask:
        text = mask_profanity(text)

    return text


def introduce_repetition(text, max_repeats=10, prob=0.2):
    """
    在文本中随机挑选一些词，在后面重复几次。
    :param text: 输入字符串
    :param max_repeats: 每个词最多重复几次
    :param prob: 每个词被选中重复的概率
    :return: 带有重复词的字符串
    """
    words = text.split()
    new_words = []
    for w in words:
        new_words.append(w)
        if random.random() < prob:  # 以概率选择要重复的词
            repeats = random.randint(1, max_repeats)
            new_words.extend([w] * repeats)  # 在后面重复
    return " ".join(new_words)

# =============== 主流程 ===============
def main(gt_file, output_file, noise_ratio=0.2):
    # 读取 GT 数据
    with open(gt_file, "r", encoding="utf-8") as f:
        gt_records = [json.loads(line) for line in f]

    noisy_records = copy.deepcopy(gt_records)

    n = len(gt_records)
    # num_noise_each = max(1, int(n * noise_ratio / 4))  # 每类噪声数量
    num_noise_each = max(1, int(n * noise_ratio))

    # new_record = {}
    # # 1️⃣ 过多符号
    for rec in random.sample(noisy_records, num_noise_each):
        rec['text'] = introduce_repetition(rec['text'])

    # # 2️⃣ 多余空格
    # for rec in random.sample(noisy_records, num_noise_each):
    #     rec["text"] = add_spaces_noise(rec["text"])

    # 3️⃣ 替换脏话
    for rec in random.sample(noisy_records, num_noise_each):
        rec["text"] = unmask_profanity(rec["text"])

    # 4️⃣ 添加 near-duplicate 记录
    duplicates = []
    for rec in random.sample(gt_records, num_noise_each):
        duplicates.append(create_near_duplicate(rec))
    
    noisy_records.extend(duplicates)

    # topics = [
    #     "the weather today", 
    #     "the importance of education", 
    #     "advancements in technology", 
    #     "space exploration", 
    #     "climate change"
    # ]

    # from utils.llm_serving import LLMServing  # Optional: To use LLM for text generation

    # # Initialize the LLM model
    # llm = LLMServing()
    
    # # 词数不符合要求，独立生成
    # for i in range(70):
    #     added_rec = copy.deepcopy(random.choice(gt_records))
    #     added_rec['text'] = generate_text(topics, llm=llm, mask=True, length=random.choice(["short", "long"]))
    #     added_rec['id'] = 300 + i
    #     noisy_records.append(added_rec)
    
    # 写入 noisy 文件
    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    with open(output_file, "w", encoding="utf-8") as f:
        for rec in noisy_records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    print(f"✅ GT {len(gt_records)} 条, Noisy {len(noisy_records)} 条 写入 {output_file}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--gt_file", type=str, required=True, help="GT 文件路径 (jsonl)")
    parser.add_argument("-o", "--output_file", type=str, required=True, help="输出 noisy 文件路径")
    parser.add_argument("--noise_ratio", type=float, default=0.2, help="噪声比例 (默认 0.2)")
    args = parser.parse_args()

    main(args.gt_file, args.output_file, args.noise_ratio)
