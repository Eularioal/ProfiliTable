import csv
import argparse
import re

def load_csv(path):
    entries = []
    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            entries.append(row)
    return entries

def evaluate(expected_path, processed_path):
    # 加载 CSV 文件
    expected = load_csv(expected_path)
    processed = load_csv(processed_path)

    # 构造 ID 集合
    expected_ids = set(entry['id'] for entry in expected)
    processed_ids = set(entry['id'] for entry in processed)

    # 指标计算
    true_positives = 0
    common_ids = expected_ids & processed_ids  # 找到两个文件中共同的 ID

    # 遍历所有共同的 ID，比较 money 字段
    for cid in common_ids:
        expected_row = next((entry for entry in expected if entry['id'] == cid), None)
        processed_row = next((entry for entry in processed if entry['id'] == cid), None)

        if expected_row and processed_row:
            expected_money = float(expected_row['money'])
            processed_money = float(processed_row['money'])
            pattern = r"^\d+(\.\d{2})?$"
    
            processed_money_str = processed_row['money']
            if abs(expected_money - processed_money) < 0.01 and re.match(pattern, processed_money_str):
                true_positives += 1

    predicted_total = len(processed_ids)
    gold_total = len(expected_ids)

    precision = true_positives / predicted_total if predicted_total > 0 else 0.0
    recall = true_positives / gold_total if gold_total > 0 else 0.0
    f1 = (2 * precision * recall) / (precision + recall) if precision + recall > 0 else 0.0

    # 输出评估结果
    result = {"eval_score": f"{f1:.4f}"}
    print(result)

def get_gt():
    from pathlib import Path

    # 获取 gen_data.py 所在目录
    current_dir = Path(__file__).resolve().parent

    # 找到 expected 目录
    expected_dir = (current_dir / "expected").resolve()

    # 查找第一个 .csv 文件
    csv_files = list(expected_dir.glob("*.csv"))

    if not csv_files:
        raise FileNotFoundError(f"No .csv file found in {expected_dir}")

    # 取第一个文件作为 expected_path
    expected_path = csv_files[0]

    return expected_path

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate CSV vs. GT data")
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Path to the processed CSV produced by your operator",
    )
    args = parser.parse_args()
    expected_path = get_gt()
    processed_path = args.output
    evaluate(expected_path, processed_path)
