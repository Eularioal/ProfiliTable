
import csv
import random
from faker import Faker
from pathlib import Path

# 初始化 Faker
fake = Faker()

def generate_data(num_records):
    """
    生成包含 account, money 和 id 的数据。

    :param num_records: 需要生成的记录数量
    :return: 生成的记录列表
    """
    data = []
    for i in range(1, num_records + 1):
        account = ''.join([str(random.randint(0, 9)) for _ in range(16)])  # 随机生成 16 位数字
        money = round(random.uniform(10, 1000), 2)  # 随机生成两位小数的金额
        record = {"id": i, "account": account, "money": money}
        data.append(record)
    return data

def load_gt_data(gt_file_path):
    """
    加载 gt 文件，返回记录列表。

    :param gt_file_path: gt 文件路径
    :return: gt 数据列表
    """
    gt_data = []
    with open(gt_file_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            gt_data.append(row)
    return gt_data

def modify_data(gt_data):
    """
    对数据进行修改：随机采样一些记录，将其 money 改为非两位小数（但四舍五入到两位时与原值一致），
    并插入一些不合法的 account 和重复记录。
    
    :param gt_data: gt 数据
    :return: 修改后的数据
    """
    # 创建一个深拷贝，避免修改原始gt_data的引用
    modified_data = []
    for record in gt_data:
        modified_data.append({
            "id": int(record["id"]),
            "account": record["account"],
            "money": float(record["money"])
        })
    
    # 随机采样一部分记录，将 money 改成非两位小数
    num_to_modify = 50
    for record in random.sample(modified_data, num_to_modify):
        original_money = record["money"]
        
        # 生成一个小数位数更多但四舍五入到两位时与原值一致的值
        decimal_places = random.choice([3, 4, 5])
        
        # 方法：先确定四舍五入到两位的边界值
        # 例如：原值123.45，四舍五入到两位时范围是[123.445, 123.455)
        # 在这个范围内生成一个小数位数更多的值
        
        # 确定原值四舍五入到两位时的上下边界
        lower_bound = original_money - 0.005  # 比原值小0.005
        upper_bound = original_money + 0.004999  # 比原值小一点点，确保开区间
        
        # 在边界范围内生成一个新值
        while True:
            new_money = round(random.uniform(lower_bound, upper_bound), decimal_places)
            # 验证四舍五入到两位后是否与原值一致
            if round(new_money, 2) == round(original_money, 2):
                record["money"] = new_money
                break
    
    # 插入一些不合法的 account 记录（非 16 位数字）
    for i in range(50):
        modified_data.append({
            "id": len(modified_data) + 1000,
            "account": ''.join([str(random.randint(0, 9)) for _ in range(random.randint(17, 20))]),
            "money": round(random.uniform(10, 1000), 2)
        })
    
    # 插入重复记录（创建真正的副本）
    num_duplicates = 30
    for i in range(num_duplicates):
        original_record = random.choice(modified_data)
        # 创建深拷贝
        duplicate_record = {
            "id": len(modified_data) + 2000 + i,
            "account": original_record["account"],
            "money": original_record["money"]
        }
        modified_data.append(duplicate_record)
    
    return modified_data

def save_to_csv(data, filename):
    """
    将数据保存到 CSV 文件中。

    :param data: 数据列表
    :param filename: 保存的文件名
    """
    with open(filename, mode="w", newline="", encoding="utf-8") as file:
        fieldnames = ["id", "account", "money"]
        writer = csv.DictWriter(file, fieldnames=fieldnames)

        writer.writeheader()  # 写入表头
        for row in data:
            writer.writerow(row)  # 写入数据行

# 生成数据并进行修改
# num_records = 100  # 生成 100 条记录
# data = generate_data(num_records)

# 加载 gt 文件中的数据
gt_file_path = Path(__file__).parent / "expected/gt.csv"  # 假设 gt.csv 在当前目录下
gt_data = load_gt_data(gt_file_path)

# 修改数据：添加非两位小数的 money，插入不合法的 account 和重复记录
modified_data = modify_data(gt_data)

# 保存修改后的数据到 customers.csv
output_path = Path(__file__).parent / "raw/customers_new.csv"
save_to_csv(modified_data, output_path)

print(f"Data has been saved to {output_path}")
