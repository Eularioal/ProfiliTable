#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
eval.py – 评测 “CSV 文本洁净三连 + 宽转长 (unpivot)” 算子结果

评测要求
--------
GT 位于   expected/gt.csv
选手输出  (--output 或位置参数给出)

一行被判定为真阳性 (TP) 的条件
  • 在 GT 中存在完全相同的一行  
    （六列 id, name, region, text, metric, value 完全一致）

计分
----
precision = TP / 预测唯一行数
recall    = TP / GT 唯一行数
F1        = 0  (若分母为 0)  否则 2PR/(P+R)

输出
-----
{"eval_score": 0.xxxx, "details": {...}}

用法
----
python eval.py -o your_result.csv
python eval.py    your_result.csv
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Dict, List, Set, Tuple

GT_PATH = Path(__file__).parent / "expected" / "gt.csv"
REQUIRED_COLS = ["id", "name", "region", "text", "metric", "value"]


# ──────────────────────────── IO ────────────────────────────
def load_csv_as_set(path: Path) -> Set[Tuple[str, ...]]:
    """
    读取 CSV → set(tuple(fields))  
    并做完整性检查：文件存在、字段缺失。
    """
    if not path.is_file():
        raise FileNotFoundError(path)

    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        # 检查字段
        missing = [c for c in REQUIRED_COLS if c not in reader.fieldnames]
        if missing:
            raise KeyError(f"{path}: missing columns {missing}")

        rows: Set[Tuple[str, ...]] = set()
        for ln, row in enumerate(reader, 2):  # header 行算 1
            key = tuple(row[col] for col in REQUIRED_COLS)
            rows.add(key)
    return rows


# ────────────────────────── Metric ─────────────────────────
def compute_f1(gt_set: Set[Tuple[str, ...]], pred_set: Set[Tuple[str, ...]]):
    if not pred_set:
        return 0.0, 0, 0, len(gt_set)

    tp = len(gt_set & pred_set)
    precision = tp / len(pred_set)
    recall = tp / len(gt_set) if gt_set else 0.0
    f1 = 0.0 if precision + recall == 0 else 2 * precision * recall / (precision + recall)
    return f1, tp, len(pred_set), len(gt_set)


# ─────────────────────────── CLI ───────────────────────────
def parse_args() -> Path:
    parser = argparse.ArgumentParser(description="Evaluate CSV unpivot operator output")
    parser.add_argument("-o", "--output", help="path to output csv")
    parser.add_argument("positional", nargs="?", help="path to output csv (positional)")
    args = parser.parse_args()

    out = args.output or args.positional
    if not out:
        parser.error("missing output file – provide by -o or positional arg")
    return Path(out)


def main() -> None:
    pred_path = parse_args()

    gt_set = load_csv_as_set(GT_PATH)
    pred_set = load_csv_as_set(pred_path)

    f1, tp, pred_n, gt_n = compute_f1(gt_set, pred_set)

    print(
        json.dumps(
            {
                "eval_score": round(f1, 4)
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()