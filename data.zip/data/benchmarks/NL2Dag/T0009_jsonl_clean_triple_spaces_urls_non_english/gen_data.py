#!/usr/bin/env python3
# -*- coding: utf-8 -*-


from __future__ import annotations

import csv
import random
import re
from pathlib import Path
from typing import Dict, List

# ──────────────────── 路径 ────────────────────
ROOT = Path(__file__).resolve().parent
RAW_DIR = ROOT / "raw"
EXP_DIR = ROOT / "expected"
RAW_DIR.mkdir(exist_ok=True)
EXP_DIR.mkdir(exist_ok=True)

RAW_CSV = RAW_DIR / "customers.csv"
GT_CSV = EXP_DIR / "gt.csv"

# ──────────────────── 静态资源 ────────────────────
FIRST_NAMES = [
    "Alice", "Bob", "Carol", "David", "Eve", "Frank", "Grace", "Heidi",
    "Ivan", "Judy", "Mallory", "Niaj", "Olivia", "Peggy", "Rupert"
]
LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia",
    "Miller", "Davis", "Rodriguez", "Martinez"
]
REGIONS = ["APAC", "EMEA", "AMER"]

GOOD_TEXTS = [
    "The quick brown fox jumps over the lazy dog.",
    "Artificial intelligence is reshaping the world.",
    "Open source drives rapid innovation.",
    "We will meet at the conference next Monday.",
    "Data pipelines must be reliable and fast."
]
CN_TEXT = "这是一个包含中文字符的句子，用于测试。"

METRICS = ["sales_q1", "sales_q2", "profit_q1", "profit_q2"]

URL_PAT = re.compile(r"(http://|https://|www\.)", re.I)
ASCII_ONLY = re.compile(r"^[\x20-\x7E]+$")
MULTI_SPACE = re.compile(r"\s+")

# ──────────────────── 工具函数 ────────────────────
def rand_name() -> str:
    return f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"

def rand_region() -> str:
    return random.choice(REGIONS)

def make_text(idx: int) -> str:
    txt = random.choice(GOOD_TEXTS)
    r = random.random()
    if r < 0.25:
        txt += f" Visit https://example{idx}.com for details."
    elif r < 0.50:
        txt = CN_TEXT
    # 加些空格噪声
    txt = f"   {txt}   "
    return txt

def gen_row(idx: int) -> Dict[str, str]:
    row = {
        "id": idx,
        "name": rand_name(),
        "region": rand_region(),
        "text": make_text(idx),
        "sales_q1":  f"{random.uniform( 5000, 20000):.2f}",
        "sales_q2":  f"{random.uniform( 5000, 20000):.2f}",
        "profit_q1": f"{random.uniform( 1000,  8000):.2f}",
        "profit_q2": f"{random.uniform( 1000,  8000):.2f}",
    }
    return row

def strip_spaces(s: str) -> str:
    return MULTI_SPACE.sub(" ", s.strip())

def keep_row(txt: str) -> bool:
    txt_clean = strip_spaces(txt)
    if URL_PAT.search(txt_clean):
        return False
    if not ASCII_ONLY.match(txt_clean):
        return False
    return True

def unpivot(row: Dict[str, str]) -> List[Dict[str, str]]:
    base = {k: row[k] for k in ("id", "name", "region", "text")}
    return [{**base, "metric": m, "value": row[m]} for m in METRICS]

# ──────────────────── 主流程 ────────────────────
def main() -> None:
    random.seed(42)

    # 1. 生成宽表
    wide: List[Dict[str, str]] = [gen_row(i) for i in range(1, 201)]

    with RAW_CSV.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "name", "region", "text", *METRICS])
        writer.writeheader()
        writer.writerows(wide)

    # 2. 清洗 + unpivot
    long_rows: List[Dict[str, str]] = []
    for row in wide:
        row["text"] = strip_spaces(row["text"])
        if keep_row(row["text"]):
            long_rows.extend(unpivot(row))

    with GT_CSV.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f, fieldnames=["id", "name", "region", "text", "metric", "value"]
        )
        writer.writeheader()
        writer.writerows(long_rows)

    print(
        f"Wide rows : {len(wide)}\n"
        f"Long rows : {len(long_rows)} (after cleaning & unpivot)"
    )

if __name__ == "__main__":
    main()