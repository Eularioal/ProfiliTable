import csv

def load_csv_as_dict(path):
    data = {}
    with open(path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            data[row["id"]] = row
    return data

def evaluate(expected_path, processed_path):
    expected = load_csv_as_dict(expected_path)
    processed = load_csv_as_dict(processed_path)

    correct = 0
    total = len(expected)

    for id_, expected_row in expected.items():
        processed_row = processed.get(id_)
        if not processed_row:
            print(f"⚠️ Missing record id={id_} in processed output.")
            continue
        if expected_row["currency"].strip() == processed_row["currency"].strip() and \
            int(float(expected_row["height"])) == int(float(processed_row["height"])):
            correct += 1

    accuracy = correct / total if total > 0 else 0.0


    result = {"eval_score": f"{accuracy:.4f}"}
    print(result)
def get_gt():
    from pathlib import Path

    # 获取 gen_data.py 所在目录
    current_dir = Path(__file__).resolve().parent

    # 找到 expected 目录
    expected_dir = (current_dir / "./expected").resolve()

    # 查找第一个 .jsonl 文件
    jsonl_files = list(expected_dir.glob("*.csv"))

    if not jsonl_files:
        raise FileNotFoundError(f"No .jsonl file found in {expected_dir}")

    # 取第一个文件作为 expected_path
    expected_path = jsonl_files[0]

    return expected_path

import argparse
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="filter non-english data")
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Path to the processed jsonl produced by your operator",
    )
    args = parser.parse_args()
    expected_path = get_gt()
    processed_path = args.output
    evaluate(expected_path, processed_path)
