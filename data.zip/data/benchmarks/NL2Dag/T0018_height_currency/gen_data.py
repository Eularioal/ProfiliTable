
import pandas as pd
import random
from pathlib import Path

# 路径
base_dir = Path(__file__).parent
gt_path = base_dir / "expected/gt.csv"
customers_path = base_dir / "raw/customers.csv"

# 读取 GT 数据
gt_df = pd.read_csv(gt_path)

# 随机挑选部分记录进行格式转换
num_modify = 70
modify_indices = random.sample(list(gt_df.index), num_modify)

# ISO-4217 到全称映射
currency_map = {
    "USD": "US Dollar",
    "EUR": "Euro",
    "JPY": "Japanese Yen",
    "GBP": "British Pound",
    "AUD": "Australian Dollar",
    "CAD": "Canadian Dollar",
    "CHF": "Swiss Franc",
    "CNY": "Chinese Yuan",
    "SEK": "Swedish Krona",
    "NZD": "New Zealand Dollar",
    "MXN": "Mexican Peso",
    "SGD": "Singapore Dollar",
    "HKD": "Hong Kong Dollar",
    "NOK": "Norwegian Krone",
    "KRW": "South Korean Won",
    "TRY": "Turkish Lira",
    "INR": "Indian Rupee",
    "RUB": "Russian Ruble",
    "BRL": "Brazilian Real",
    "ZAR": "South African Rand"
}

# 修改选中的记录
for idx in modify_indices:
    gt_df.at[idx, "height"] = gt_df.at[idx, "height"] / 100  # 除以 100
    iso_code = gt_df.at[idx, "currency"]
    if iso_code in currency_map:
        gt_df.at[idx, "currency"] = currency_map[iso_code]

# 保存到 customers.csv
gt_df.to_csv(customers_path, index=False)
print(f"⚠️ Customers CSV saved to {customers_path}")

