
import json
import random
from pathlib import Path
import copy

def load_jsonl(path):
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            data.append(json.loads(line))
    return data

def save_jsonl(data, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for entry in data:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

def modify_firmware_version(version):
    """随机改变 firmware_version 格式"""
    v = version.lstrip("v")
    formats = [
        v,
        f"version {v}",
        f"fw-{v.replace('.', '-')}",
        f"{v}_release"
    ]
    return random.choice(formats)

def main():
    base_dir = Path(__file__).parent  # 任务根目录
    gt_file = base_dir / "expected/gt.jsonl"
    customers_file = base_dir / "raw/customers.jsonl"

    gt_data = load_jsonl(gt_file)
    gt_data_copy = copy.deepcopy(gt_data)
    customers_data = []

    # 随机挑选 20 条 GT 数据生成带格式变化的 firmware_version
    sample_for_fw = random.sample(gt_data_copy, min(20, len(gt_data)))
    for i, record in enumerate(sample_for_fw, start=1000):
        # new_record = record.copy()
        # new_record["id"] = i
        record["firmware_version"] = modify_firmware_version(record["firmware_version"])
        # customers_data.append(record)

    # 生成一些 text 近似的记录（使用 GT 的 text 做基础，可再简单修改）
    for j in range(10):
        sample_for_text = random.sample(gt_data, min(20, len(gt_data)))
        for i, record in enumerate(sample_for_text, start=1020):
            new_record = record.copy()
            new_record["id"] = i + 20*(j+1)
            # 对 text 做小幅修改，使其近似
            words = new_record["text"].split()
            random.shuffle(words)
            new_record["text"] = " ".join(words[:len(words)//2] + words[:len(words)//2])
            customers_data.append(new_record)

    save_jsonl(gt_data + customers_data, customers_file)
    print(f"⚠️ Customers JSONL generated at: {customers_file}")

if __name__ == "__main__":
    main()
